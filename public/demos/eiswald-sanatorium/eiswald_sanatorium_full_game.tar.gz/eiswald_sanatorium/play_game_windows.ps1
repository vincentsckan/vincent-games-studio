﻿# play_game_windows.ps1
# 《霧嶺療養院：白鴉之冬》Windows 一鍵自動安裝 Godot 4.3 引擎並啟動遊戲腳本
$ErrorActionPreference = "Continue"
$ProjectDir = $PSScriptRoot
$EngineDir = Join-Path $ProjectDir ".engine"
$GodotExe = Join-Path $EngineDir "Godot_v4.3-stable_win64.exe"
$ZipPath = Join-Path $EngineDir "godot43.zip"
$DownloadUrl = "https://github.com/godotengine/godot/releases/download/4.3-stable/Godot_v4.3-stable_win64.exe.zip"

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host " 《霧嶺療養院：白鴉之冬》(Eiswald Sanatorium) 啟動器" -ForegroundColor Yellow
Write-Host "==========================================================" -ForegroundColor Cyan

if (-not (Test-Path $GodotExe)) {
    Write-Host "[1/2] 首次執行：正在自動下載 Godot 4.3 (64-bit 免安裝版)..." -ForegroundColor Green
    New-Item -ItemType Directory -Force -Path $EngineDir | Out-Null
    Invoke-WebRequest -Uri $DownloadUrl -OutFile $ZipPath
    Write-Host "[2/2] 正在解壓縮 Godot 4.3 引擎..." -ForegroundColor Green
    Expand-Archive -Path $ZipPath -DestinationPath $EngineDir -Force
    Remove-Item -Path $ZipPath -Force -ErrorAction SilentlyContinue
}

# 確保 Godot 4.3 全域類別快取 (global_script_class_cache.cfg) 與 3D GLB 模型已匯入
$ClassCacheFile = Join-Path $ProjectDir ".godot\global_script_class_cache.cfg"
if (-not (Test-Path $ClassCacheFile)) {
    Write-Host "正在初始化 3D 場景資源與類別快取 (--import)..." -ForegroundColor Cyan
    Start-Process -FilePath $GodotExe -ArgumentList "--path `"$ProjectDir`" --import --headless" -Wait -NoNewWindow
}

Write-Host "正在啟動《霧嶺療養院：白鴉之冬》3D 遊戲視窗..." -ForegroundColor Yellow
Start-Process -FilePath $GodotExe -ArgumentList "--path `"$ProjectDir`""
