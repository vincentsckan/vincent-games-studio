# 《霧嶺療養院：白鴉之冬》初步場景、主角人物、Boss 及武器設定總覽

> [!NOTE]
> 本圖鑑整合目前已實裝於 Godot 4.3 3D 專案（`C:\Users\vincent sc kan\.gemini\antigravity\scratch\eiswald_sanatorium` 及雲端主機 `vincentkan-vm-20260921-000319:/home/vincentsc_kan/eiswald_sanatorium`）中的**四大主題場景、主角薇拉、雙頭目 AI 與四大武器數值設定**。

````carousel
![四大放射狀主題園區中央樞紐（雪絨花童話村、鬧鬼山丘、海洋王國、地下挖掘場）](C:/Users/vincent sc kan/.gemini/antigravity/brain/28493837-ce06-47a8-8bfb-d6086c825a71/scene_fairytale_hub_1794968568643.png)
<!-- slide -->
![主角「特別調查員 薇拉·林德奎斯特 (Vera Lindqvist)」角色設定與 3D 雷射瞄準姿態](C:/Users/vincent sc kan/.gemini/antigravity/brain/28493837-ce06-47a8-8bfb-d6086c825a71/protagonist_vera_1794968572584.png)
<!-- slide -->
![中段頭目「克羅爾醫生」、最終頭目「白髓母體君王」與調查員手提箱四大武器庫展示](C:/Users/vincent sc kan/.gemini/antigravity/brain/28493837-ce06-47a8-8bfb-d6086c825a71/boss_and_weapons_1794970312854.png)
````

---

## 一、初步場景架構（四大放射狀箱庭主題分區）

場景建構程式碼位於 [ResortHubBuilder.gd](file:///C:/Users/vincent%20sc%20kan/.gemini/antigravity/scratch/eiswald_sanatorium/src/world/ResortHubBuilder.gd) 與 [MainGame.tscn](file:///C:/Users/vincent%20sc%20kan/.gemini/antigravity/scratch/eiswald_sanatorium/scenes/main/MainGame.tscn)，採用等距 45° 可自由旋轉的立體微縮模型視角 (Diorama View)，結合 Godot 4 **SDFGI 全局光照、體積霧 (Volumetric Fog) 與 GPU 暴風雪粒子**：

| 主題分區 | 對應《Crow Country》分區 | 場景座標與空間配置 | 核心 3D 建築／模型資產 (`.glb`) | 場景專屬機關、陷阱與光影色調 |
| :--- | :--- | :--- | :--- | :--- |
| **1. 雪絨花童話村**<br/>*(Edelweiss Fairytale Village)* | **童話鎮**<br/>*(Fairytale Town)* | **中央樞紐**<br/>`X: 0, Z: -8`<br/>（含山門停車場 `Z: +13`、安全屋 `X: -17.5`、蘑菇屋 `X: -22, Z: +8`） | • `fairytale_carousel.glb`（發條冰雪旋轉木馬）<br/>• `toadstool_cottage.glb`（巨型毒蠅傘蘑菇屋）<br/>• `arcade_cabinet_retro.glb`（1991 街機機台）<br/>• `investigator_sedan.glb`（主角調查員轎車） | • **色調**：暖琥珀壁爐火光 vs. 冰冷暴風雪藍霧（童話反差恐怖）<br/>• **機關**：木板封門（需撬棍）、老爺鐘 (`0415`)、街機 (`1991`)<br/>• **陷阱**：高壓易爆油桶、雪山捕熊夾 |
| **2. 霧嶺鬧鬼山丘**<br/>*(Haunted Hilltop & Crypt)* | **鬧鬼山丘**<br/>*(Haunted Hilltop)* | **西翼放射區**<br/>`X: -38, Z: -8` | • `haunted_coffin_prop.glb`（哥德十字石棺與彩繪木棺）<br/>• 古堡烏鴉座自動鋼琴與三聖骸骨祭壇 | • **色調**：幽暗哥德紫霧與慘白月光<br/>• **機關**：**真假鬼屋彈出式棺木**（紙板假幽靈 vs. 真實怪物突襲）、烏鴉座鋼琴 (`13542`)、骸骨石棺 (`741`)、**南側單向插銷捷徑門**<br/>• **陷阱**：感應地雷 (Proximity Mine) |
| **3. 冰川海洋王國**<br/>*(Glacial Ocean Kingdom)* | **海洋王國**<br/>*(Ocean Kingdom)* | **東翼放射區**<br/>`X: +26, Z: -8` | • `pirate_galleon_ship.glb`（「破冰船號」海盜船餐廳）<br/>• 深海圓頂水族館巨型展示槽 | • **色調**：深邃藍綠色水波焦散光影 (Aquatic Caustics)<br/>• **機關**：三艙水壓調節盤 (`85 PSI` 取得強酸液瓶)、海盜船長羅盤與甲板大砲 (`2486`)、**西側單向插銷捷徑門**<br/>• **陷阱**：破裂白髓毒氣管線 |
| **4. 地下挖掘場與秘密設施**<br/>*(The Pale Roots & Bio-Lab)* | **地下挖掘場**<br/>*(The Roots / Underground)* | **北側地底深處**<br/>`X: 0, Z: -32 ~ -39` | • `pale_ichor_fluid.gdshader`（白髓泉源母體池）<br/>• 礦坑高壓渦輪配電盤、克拉拉冷凍艙終端 | • **色調**：潮濕陰暗鐵鏽工業風與詭異猩紅生物發光<br/>• **機關**：強酸腐蝕鐵鍊入口、礦坑 `440V` 配電盤、基因實驗室 `1989` 冷凍艙終端<br/>• **陷阱**：可射落砸碎怪物的**脆弱鐘乳石吊燈天花板** |

---

## 二、主角人物設定：薇拉·林德奎斯特 (Vera Lindqvist)

角色控制與雙視角邏輯實裝於 [PlayerController.gd](file:///C:/Users/vincent%20sc%20kan/.gemini/antigravity/scratch/eiswald_sanatorium/src/player/PlayerController.gd)、[CameraRig.gd](file:///C:/Users/vincent%20sc%20kan/.gemini/antigravity/scratch/eiswald_sanatorium/src/player/CameraRig.gd) 與 [Player.tscn](file:///C:/Users/vincent%20sc%20kan/.gemini/antigravity/scratch/eiswald_sanatorium/scenes/player/Player.tscn)：

* **身分背景**：24 歲，聯邦特別調查局（Special Investigation Bureau）年輕探員。表面上受託調查 1989 年渡假村創辦人女兒「克拉拉·范斯」失蹤懸案，實際上其兄長正是當年地底挖掘場事故被滅口的工程師。
* **外觀特徵**：深栗色短鮑伯頭，身穿 1991 年代復古深海藍防寒調查員長風衣、戰術槍套背心與雪地靴，右肩配戴黃銅聚光手電筒 (`SpotLight3D`)。
* **操作與能力參數**：
  * **基礎生命值 (ECG Vitals)**：`100 HP`，分為四段心電圖狀態：
    * `FINE (綠, 65~100 HP)` → `CAUTION (黃, 30~64 HP)` → `DANGER (紅, <30 HP)` → `ICHOR_INFECTED (紫, 白髓中毒持續扣血)`。
  * **雙操作模式即時切換 (`F4`)**：
    * **現代全方向直接移動**：移動速度 `4.6 m/s`，舉槍橫移速度 `2.0 m/s`。
    * **經典坦克式操作 (Tank Controls)**：`W/S` 前進（`4.6 m/s`）／後退（`2.8 m/s`），`A/D` 原地旋轉方向（`2.8 rad/s`）。
  * **緊急迴避 (`Shift`)**：向後或朝移動方向快速閃避翻滾（速度 `8.4 m/s`，持續 `0.28s`）。
  * **手提箱容量**：初始 `10 格`，解開鬧鬼山丘「三聖骸骨石棺 (`741`)」後擴充至 **`12 格`**。

---

## 三、Boss 與區域怪物設定（含部位弱點判定系統）

AI 狀態機與部位弱點判定實裝於 [EnemyBase.gd](file:///C:/Users/vincent%20sc%20kan/.gemini/antigravity/scratch/eiswald_sanatorium/src/ai/EnemyBase.gd)、[BossHelenaAI.gd](file:///C:/Users/vincent%20sc%20kan/.gemini/antigravity/scratch/eiswald_sanatorium/src/ai/BossHelenaAI.gd) 與 [HitboxComponent.gd](file:///C:/Users/vincent%20sc%20kan/.gemini/antigravity/scratch/eiswald_sanatorium/src/ai/HitboxComponent.gd)：

### 1. 兩大核心頭目 (Bosses)

| 頭目名稱 | 登場區域 | 生命值与移動速度 | 外觀與攻擊模式 | 弱點部位與戰術攻略 (`HitboxComponent`) |
| :--- | :--- | :--- | :--- | :--- |
| **中段頭目：水療部主任 海倫娜·克羅爾**<br/>*(Dr. Helena Kroll, The Hydrotherapy Matriarch)* | 第三分區：冰川海洋王國／水療展示廳 | • **HP**：`320`<br/>• **一階段速度**：`2.65 m/s`<br/>• **二階段狂暴速度**（HP ≤ 50%）：`3.45 m/s`<br/>• **單次傷害**：`32`（附帶白髓感染） | 身穿染血的療養院主任白袍，半邊身軀已與白瓷般的「白髓」結晶融合，背負高壓地熱蒸汽鋼瓶，手持巨型骨骼手術鋸。 | • **頭部弱點 (`HEAD_WEAKPOINT`)**：承受 **2.2x 暴擊傷害** 並觸發 `0.75s` 硬直。<br/>• **背後高壓氣閥 (`PRESSURE_VALVE_CRITICAL`)**：使用雷射瞄準射擊氣閥或使用火焰噴射器可造成 **2.2x 額外引爆傷害**。<br/>• **膝蓋致殘 (`LEG_CRIPPLE`)**：射擊雙腿可使其移動速度永久降低 **58%**！ |
| **最終頭目：白髓母體君王**<br/>*(The Pale Ichor Sovereign / Mutated Vance)* | 第四分區：地下挖掘場／秘密基因實驗室母體池 (`Z4_R10_SecretBioLab`) | • **HP**：`320`（謀殺之鴉模式下提升 +40%）<br/>• **移動速度**：`2.65 ~ 3.85 m/s`<br/>• **單次傷害**：`32 ~ 46`（必附帶白髓劇毒） | 亞歷山大·范斯將自己與地底 300 公尺的太古「白髓泉源」融合後誕生的巨大雙翼白鴉畸變君王，全身佈滿脈動的深紅血管與白瓷骨刺 (`boss_pale_sovereign.glb`)。 | • 推薦使用 **【白鴉 .44 馬格南】** 待準星完全收縮 (`100%`) 後瞄準頭部弱點，或使用 **【地熱高壓火焰噴射器】** 持續焚燒其白髓再生細胞，亦可射落母體池上方的 **【脆弱鐘乳石吊燈】** 對其造成 `125` 點重創！ |

### 2. 三大主題分區常駐怪物 (Zone Enemies)
1. **童話村異變木偶師 (`monster_fairytale_puppet.glb`)**：徘徊於雪絨花童話村，身穿紅色胡桃鉗木偶服、臉部硬化為白瓷的異變員工（HP `90`、速度 `2.15 m/s`）。
2. **鬧鬼山丘棺木潛行者 (`monster_haunted_stalker.glb`)**：潛伏於哥德墓園石棺中，混在「假鬼屋彈簧紙板幽靈」之間發動突襲的瘦長骸骨畸變體。
3. **海洋王國深水潛水夫 (`monster_ocean_diver.glb`)**：身穿沉重黃銅舊式深海潛水服的異變研究員，徘徊於破裂毒氣管線周圍。

---

## 四、四大標誌性武器與準星收縮系統 (`WeaponSystem.gd`)

武器參數與改裝邏輯實裝於 [InventoryManager.gd](file:///C:/Users/vincent%20sc%20kan/.gemini/antigravity/scratch/eiswald_sanatorium/src/inventory/InventoryManager.gd) 與 [WeaponSystem.gd](file:///C:/Users/vincent%20sc%20kan/.gemini/antigravity/scratch/eiswald_sanatorium/src/player/WeaponSystem.gd)：

> [!TIP]
> **準星收縮暴擊機制 (Reticle Shrink Focus)**：按住滑鼠右鍵舉槍時，站立不動 **1.1 秒** 會使準星從外擴狀態平滑收縮至 `100%` 紅心鎖定，此時開火直接享有 **+55% 基礎傷害加成**，若同時命中怪物頭部弱點 (`2.2x`)，單發總倍率高達 **`3.41x`**！

| 武器名稱 | 取得方式與改裝途徑 | 彈匣容量 | 單發基礎傷害 | 射速間隔 | 有效射程 | 雷射光束顏色與戰術特性 |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **1. VP-9 制式手槍**<br/>*(Service Handgun)* | • **初始配備**<br/>• **改裝**：童話鎮復古街機破關 (`1991`) 獲得【擴容強化套件】 | 初始 `12` 發<br/>*(改裝後 **`18` 發**)* | 初始 `28`<br/>*(改裝後 **`36`**)* | `0.34s` | `24.0m` | 🔴 **緋紅雷射光束**<br/>精準穩定、彈藥最充裕，適合搭配準星收縮射擊敵人膝蓋致殘、引爆油桶與射擊高處「水晶雪絨花」。 |
| **2. 阿爾卑斯雙管霰彈槍**<br/>*(Double-Barrel Shotgun)* | • **第一分區：雪絨花童話村**<br/>中央廣場北側獵人展示架拾取 | `4` 發 | **`85`** | `0.72s` | `12.0m` | 🟠 **琥珀橘雷射光束**<br/>近距離爆發力極強，具備強制擊退與硬直效果，適合在狹窄走廊突圍。 |
| **3. 白鴉 .44 馬格南左輪**<br/>*(White Crow .44 Magnum)* | • **取得**：鬧鬼山丘古堡自動鋼琴 (`13542`)<br/>• **改裝**：海洋王國醫療室 X 光燈箱 (`509`) 獲得【加長膛線槍管】 | 初始 `6` 發<br/>*(改裝後 **`8` 發**)* | 初始 `145`<br/>*(改裝後 **`195`**，滿收縮爆頭高達 **`665`**)* | `0.65s` | `28.0m` | 🟡 **皇家金雷射光束**<br/>全遊戲單發貫穿力最強的王牌武器，準星收縮後一槍即可秒殺普通怪物、重創頭目核心。 |
| **4. 地熱高壓火焰噴射器**<br/>*(Geothermal Flamethrower)* | • **取得**：地下挖掘場礦坑配電盤 (`440`)<br/>• **改裝**：冷凍標本庫微縮膠卷投影機 (`824`) 獲得【白磷增壓噴嘴】 | 初始 `25` 燃料<br/>*(改裝後 **`40` 燃料**)* | 初始 `42` / 跳<br/>*(改裝後 **`68` / 跳**，對白髓享 **2.2x 焚燒加成**)* | **`0.14s`**<br/>*(支援按住左鍵全自動連發噴射)* | `9.5m` | 🔥 **烈焰橙雷射導引線**<br/>持續性高溫火柱，專門克制白髓再生細胞與最終頭目「白髓母體君王」。 |
