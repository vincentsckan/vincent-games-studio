shader_type canvas_item;

uniform sampler2D screen_tex : hint_screen_texture, repeat_disable, filter_nearest;
uniform float dither_strength : hint_range(0.0, 1.0) = 0.38;
uniform float color_levels : hint_range(16.0, 128.0) = 42.0;
uniform float warmth_tint : hint_range(0.0, 1.0) = 0.28;
uniform float vignette_strength : hint_range(0.0, 1.0) = 0.55;

float bayer4x4(vec2 pos) {
	int x = int(mod(pos.x, 4.0));
	int y = int(mod(pos.y, 4.0));
	int idx = x + y * 4;
	float m[16] = float[](
		0.0,  8.0,  2.0, 10.0,
		12.0, 4.0, 14.0,  6.0,
		3.0, 11.0,  1.0,  9.0,
		15.0, 7.0, 13.0,  5.0
	);
	return (m[idx] / 16.0) - 0.5;
}

void fragment() {
	// Subtle retro texel sampling & ordered Bayer dithering like Crow Country
	vec2 pixel_coord = floor(FRAGCOORD.xy * 0.5);
	vec3 col = texture(screen_tex, SCREEN_UV).rgb;

	// Warm Crow Country amber-gold highlight & deep espresso shadow grading
	float luma = dot(col, vec3(0.299, 0.587, 0.114));
	vec3 warm_high = col * vec3(1.08, 0.96, 0.78);
	vec3 deep_shadow = col * vec3(0.92, 0.76, 0.62);
	col = mix(deep_shadow, warm_high, smoothstep(0.08, 0.65, luma));
	col = mix(col, col * vec3(1.06, 0.94, 0.76), warmth_tint);

	// 4x4 Bayer Matrix Ordered Dithering + Color Quantization
	float d = bayer4x4(pixel_coord) * dither_strength;
	col = floor((col + d / color_levels) * color_levels + 0.5) / color_levels;

	// Cozy Diorama Box Edge Vignette
	vec2 centered_uv = SCREEN_UV * 2.0 - 1.0;
	float vig = 1.0 - dot(centered_uv * vec2(0.85, 0.95), centered_uv * vec2(0.85, 0.95)) * vignette_strength;
	col *= clamp(vig, 0.0, 1.0);

	COLOR = vec4(clamp(col, 0.0, 1.0), 1.0);
}
