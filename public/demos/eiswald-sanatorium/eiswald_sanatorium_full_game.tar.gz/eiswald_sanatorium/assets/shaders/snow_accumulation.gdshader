shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back, diffuse_burley, specular_schlick_ggx;

uniform vec4 base_albedo : source_color = vec4(0.11, 0.09, 0.08, 1.0);
uniform vec4 snow_albedo : source_color = vec4(0.24, 0.29, 0.37, 1.0);
uniform float base_roughness : hint_range(0.0, 1.0) = 0.85;
uniform float snow_roughness : hint_range(0.0, 1.0) = 0.82;
uniform float snow_metallic : hint_range(0.0, 1.0) = 0.02;
uniform float snow_threshold : hint_range(-1.0, 1.0) = 0.42;
uniform float snow_blend_sharpness : hint_range(1.0, 32.0) = 6.0;
uniform float frost_sparkle_intensity : hint_range(0.0, 2.0) = 0.04;

varying vec3 world_normal;
varying vec3 world_pos;

float hash31(vec3 p) {
	p = fract(p * 0.1031);
	p += dot(p, p.yzx + 33.33);
	return fract((p.x + p.y) * p.z);
}

void vertex() {
	world_normal = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
	world_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	float up_dot = dot(world_normal, vec3(0.0, 1.0, 0.0));
	float patch_noise = hash31(floor(world_pos * 1.8)) * 0.35 + hash31(floor(world_pos * 9.0)) * 0.12;
	float snow_mask = clamp((up_dot + patch_noise - snow_threshold) * snow_blend_sharpness, 0.0, 1.0);

	// Cobblestone tile pattern on cleared pathways
	vec2 tile_uv = fract(world_pos.xz * 1.25);
	float mortar = step(0.06, tile_uv.x) * step(0.06, tile_uv.y);
	vec3 stone_col = base_albedo.rgb * mix(0.72, 1.08, mortar);

	float sparkle = pow(hash31(floor(world_pos * 40.0 + VIEW * 2.0)), 16.0) * frost_sparkle_intensity * snow_mask;
	vec3 final_color = mix(stone_col, snow_albedo.rgb + vec3(sparkle), snow_mask);

	ALBEDO = final_color;
	ROUGHNESS = mix(base_roughness, snow_roughness, snow_mask);
	METALLIC = mix(0.02, snow_metallic, snow_mask);
	SPECULAR = mix(0.18, 0.25, snow_mask);
}
