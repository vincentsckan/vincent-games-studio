shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_disabled, diffuse_burley, specular_schlick_ggx;

uniform vec4 cloth_base_color : source_color = vec4(0.12, 0.19, 0.29, 1.0);
uniform vec4 cloth_fold_dark : source_color = vec4(0.06, 0.10, 0.17, 1.0);
uniform vec4 cloth_sheen_color : source_color = vec4(0.28, 0.38, 0.52, 1.0);
uniform float weave_scale : hint_range(20.0, 400.0) = 180.0;
uniform float base_roughness : hint_range(0.0, 1.0) = 0.72;

varying vec3 local_p;

void vertex() {
	local_p = VERTEX;
}

void fragment() {
	// Fine diagonal twill / wool weave micro-pattern
	vec2 weave_uv = UV * weave_scale;
	float twill = sin((weave_uv.x + weave_uv.y) * 3.14159) * cos((weave_uv.x - weave_uv.y) * 3.14159);

	// Natural vertical cloth fold shading from normal curvature
	float fold_ao = clamp(0.5 + 0.5 * sin(UV.x * 25.1327), 0.0, 1.0);
	vec3 col = mix(cloth_fold_dark.rgb, cloth_base_color.rgb, mix(0.65, 1.0, fold_ao));
	col *= (1.0 + twill * 0.045);

	// Soft velvet/wool edge sheen (Fresnel grazing light on coat & scarf edges)
	float fresnel = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), 3.0);
	col = mix(col, cloth_sheen_color.rgb, fresnel * 0.35);

	ALBEDO = col;
	ROUGHNESS = clamp(base_roughness - twill * 0.04, 0.25, 0.95);
	SPECULAR = 0.28;
	METALLIC = 0.02;
}
