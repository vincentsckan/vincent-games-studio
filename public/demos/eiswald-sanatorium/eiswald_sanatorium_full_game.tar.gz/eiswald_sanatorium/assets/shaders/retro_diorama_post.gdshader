shader_type canvas_item;

uniform sampler2D screen_texture : hint_screen_texture, repeat_disable, filter_nearest;
uniform bool retro_mode_enabled = false;
uniform float color_depth : hint_range(8.0, 256.0) = 48.0;
uniform float vignette_intensity : hint_range(0.0, 1.0) = 0.38;
uniform float film_grain_strength : hint_range(0.0, 0.15) = 0.025;

float rand(vec2 co) {
	return fract(sin(dot(co.xy, vec2(12.9898, 78.233))) * 43758.5453);
}

void fragment() {
	vec2 uv = SCREEN_UV;
	if (retro_mode_enabled) {
		vec2 grid = vec2(640.0, 360.0);
		uv = floor(uv * grid) / grid;
	}

	vec3 col = texture(screen_texture, uv).rgb;

	if (retro_mode_enabled) {
		col = floor(col * color_depth) / color_depth;
	}

	float grain = (rand(uv + vec2(TIME * 1.3, TIME * 0.7)) - 0.5) * film_grain_strength;
	col += vec3(grain);

	vec2 d = SCREEN_UV - vec2(0.5);
	float vig = 1.0 - dot(d, d) * vignette_intensity * 1.8;
	col *= clamp(vig, 0.0, 1.0);

	COLOR = vec4(col, 1.0);
}
