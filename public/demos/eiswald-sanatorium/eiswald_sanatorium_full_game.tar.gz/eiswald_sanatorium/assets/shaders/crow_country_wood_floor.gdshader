shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back, diffuse_burley, specular_schlick_ggx;

uniform vec4 plank_warm_a : source_color = vec4(0.42, 0.16, 0.08, 1.0);
uniform vec4 plank_warm_b : source_color = vec4(0.30, 0.11, 0.05, 1.0);
uniform vec4 seam_dark : source_color = vec4(0.10, 0.03, 0.02, 1.0);

varying vec3 world_p;

float hash21(vec2 p) {
	p = fract(p * vec2(127.1, 311.7));
	p += dot(p, p + 19.19);
	return fract(p.x * p.y);
}

void vertex() {
	world_p = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	// Warm reddish-mahogany polished floorboards running along Z like the Crow Country screenshot
	float strip_x = world_p.x * 3.2;
	float col_id = floor(strip_x);
	float fx = fract(strip_x);

	float strip_z = world_p.z * 0.65 + mod(col_id, 2.0) * 0.5;
	float row_id = floor(strip_z);
	float fz = fract(strip_z);

	float gap = smoothstep(0.02, 0.06, fx) * smoothstep(0.02, 0.06, 1.0 - fx)
		* smoothstep(0.01, 0.03, fz) * smoothstep(0.01, 0.03, 1.0 - fz);

	float rnd = hash21(vec2(col_id, row_id));
	float grain = sin(world_p.z * 18.0 + sin(world_p.x * 45.0) * 1.5) * 0.5 + 0.5;
	vec3 wood = mix(plank_warm_a.rgb, plank_warm_b.rgb, rnd * 0.65 + grain * 0.35);

	ALBEDO = mix(seam_dark.rgb, wood, gap);
	ROUGHNESS = mix(0.9, 0.38 + rnd * 0.15, gap);
	SPECULAR = 0.45;
}
