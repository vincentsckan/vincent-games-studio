shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back, diffuse_burley, specular_schlick_ggx;

uniform vec4 paper_bg : source_color = vec4(0.24, 0.16, 0.10, 1.0);
uniform vec4 paper_motif : source_color = vec4(0.36, 0.25, 0.14, 1.0);
uniform vec4 wainscot_wood : source_color = vec4(0.18, 0.08, 0.05, 1.0);

varying vec3 local_p;
varying vec3 world_p;

void vertex() {
	local_p = VERTEX;
	world_p = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	// Lower 1.05m of wall is dark mahogany wainscoting panels, upper is Victorian damask wallpaper
	float h = world_p.y;
	if (h < 1.05) {
		float panel_x = fract((world_p.x + world_p.z) * 1.4);
		float panel_y = fract(h * 1.1);
		float recess = step(0.12, panel_x) * step(panel_x, 0.88) * step(0.15, panel_y) * step(panel_y, 0.85);
		vec3 wcol = wainscot_wood.rgb * mix(1.0, 0.76, recess);
		ALBEDO = wcol;
		ROUGHNESS = 0.48;
	} else {
		vec2 wuv = vec2(world_p.x + world_p.z, h) * 3.5;
		float stripe = sin(wuv.x * 6.28318) * 0.5 + 0.5;
		float damask = sin(wuv.x * 6.28318) * sin(wuv.y * 6.28318);
		vec3 pcol = mix(paper_bg.rgb, paper_motif.rgb, clamp(stripe * 0.35 + damask * 0.45, 0.0, 1.0));
		ALBEDO = pcol;
		ROUGHNESS = 0.78;
	}
}
