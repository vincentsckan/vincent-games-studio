shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back, diffuse_burley, specular_schlick_ggx;

uniform vec4 rug_crimson : source_color = vec4(0.46, 0.09, 0.08, 1.0);
uniform vec4 rug_dark_border : source_color = vec4(0.18, 0.05, 0.05, 1.0);
uniform vec4 rug_gold_motif : source_color = vec4(0.72, 0.52, 0.22, 1.0);
uniform vec4 rug_teal_accent : source_color = vec4(0.14, 0.26, 0.24, 1.0);

void fragment() {
	// UV centered at (0.5, 0.5)
	vec2 p = abs(UV - vec2(0.5)) * 2.0; // 0 at center, 1 at edge
	float edge_d = max(p.x, p.y);

	float outer_edge = step(0.92, edge_d);
	float border_band = step(0.74, edge_d) * (1.0 - step(0.90, edge_d));
	float gold_guard_outer = step(0.89, edge_d) * (1.0 - step(0.915, edge_d));
	float gold_guard_inner = step(0.71, edge_d) * (1.0 - step(0.735, edge_d));

	// High-resolution floral arabesque & rosette motifs (no blocky low-res triangles)
	vec2 fine_uv = UV * vec2(44.0, 30.0);
	vec2 f_cell = fract(fine_uv) - 0.5;
	float rosette = smoothstep(0.36, 0.22, length(f_cell)) * (0.6 + 0.4 * cos(atan(f_cell.y, f_cell.x) * 8.0));
	float lattice = smoothstep(0.08, 0.02, abs(abs(f_cell.x) + abs(f_cell.y) - 0.42));

	// Border repeating medallion motifs
	vec2 border_uv = fract(UV * vec2(28.0, 18.0)) - 0.5;
	float border_motif = smoothstep(0.34, 0.16, length(border_uv)) * (0.5 + 0.5 * cos(atan(border_uv.y, border_uv.x) * 4.0));

	// Central ornate medallion + inner star
	vec2 c_uv = (UV - vec2(0.5)) * vec2(1.45, 1.0);
	float c_dist = length(c_uv);
	float c_ang = atan(c_uv.y, c_uv.x);
	float petal_r = 0.27 + 0.028 * cos(c_ang * 12.0);
	float medallion_outer = smoothstep(petal_r + 0.02, petal_r - 0.01, c_dist);
	float medallion_inner = smoothstep(0.15, 0.12, c_dist);
	float medallion_ring = medallion_outer * (1.0 - medallion_inner);

	// Corner spandrels
	float corner_dist = length((p - vec2(0.70, 0.70)) * vec2(1.2, 1.0));
	float corner_spandrel = smoothstep(0.28, 0.24, corner_dist) * (1.0 - step(0.71, edge_d));

	vec3 col = rug_crimson.rgb;
	col = mix(col, rug_dark_border.rgb, 0.25 * lattice);
	col = mix(col, rug_gold_motif.rgb, 0.16 * rosette);
	col = mix(col, rug_dark_border.rgb, border_band * 0.88 + outer_edge * 0.55);
	col = mix(col, rug_gold_motif.rgb, border_band * border_motif * 0.65);
	col = mix(col, rug_teal_accent.rgb, (medallion_ring + corner_spandrel) * 0.72);
	col = mix(col, rug_gold_motif.rgb, (gold_guard_outer + gold_guard_inner + medallion_inner * 0.45) * 0.82);

	// Fine woven wool-pile grain & subtle age patina
	float weave_x = sin(UV.x * 520.0);
	float weave_y = sin(UV.y * 360.0);
	float weave = weave_x * weave_y * 0.035 + sin(UV.x * 90.0 + UV.y * 65.0) * 0.02;
	ALBEDO = clamp(col + vec3(weave), vec3(0.02), vec3(0.95));
	ROUGHNESS = clamp(0.86 - weave * 0.4, 0.72, 0.96);
	SPECULAR = 0.14;
}
