shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back, diffuse_burley, specular_schlick_ggx;

uniform vec4 wood_light : source_color = vec4(0.28, 0.18, 0.11, 1.0);
uniform vec4 wood_dark : source_color = vec4(0.14, 0.08, 0.05, 1.0);
uniform float plank_scale : hint_range(1.0, 20.0) = 5.0;

varying vec3 world_p;
varying vec3 world_n;

float hash21(vec2 p) {
	p = fract(p * vec2(127.1, 311.7));
	p += dot(p, p + 19.19);
	return fract(p.x * p.y);
}

void vertex() {
	world_p = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	world_n = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
}

void fragment() {
	vec2 uv = (abs(world_n.y) > 0.6) ? world_p.xz : ((abs(world_n.x) > 0.5) ? world_p.zy : world_p.xy);
	float plank_id = floor(uv.y * plank_scale);
	float plank_f = fract(uv.y * plank_scale);
	float plank_gap = smoothstep(0.02, 0.06, plank_f) * smoothstep(0.02, 0.06, 1.0 - plank_f);

	float rnd = hash21(vec2(plank_id, 4.2));
	float grain_wave = sin((uv.x * 2.5 + rnd * 6.0) * 6.28318 + sin(uv.y * 38.0) * 1.4);
	float fine_fiber = sin(uv.y * 160.0 + uv.x * 12.0) * 0.5 + 0.5;
	float grain = clamp(grain_wave * 0.35 + fine_fiber * 0.35 + rnd * 0.3, 0.0, 1.0);

	vec3 col = mix(wood_dark.rgb, wood_light.rgb, grain) * mix(0.35, 1.0, plank_gap);

	ALBEDO = col;
	ROUGHNESS = mix(0.82, 0.58, grain) * plank_gap + (1.0 - plank_gap) * 0.95;
	SPECULAR = 0.28;
	METALLIC = 0.0;
}
