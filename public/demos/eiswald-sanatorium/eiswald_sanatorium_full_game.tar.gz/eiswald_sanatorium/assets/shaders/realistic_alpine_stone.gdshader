shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back, diffuse_burley, specular_schlick_ggx;

uniform vec4 stone_color_a : source_color = vec4(0.24, 0.25, 0.29, 1.0);
uniform vec4 stone_color_b : source_color = vec4(0.16, 0.17, 0.21, 1.0);
uniform vec4 mortar_color : source_color = vec4(0.08, 0.08, 0.10, 1.0);
uniform vec4 snow_cap_color : source_color = vec4(0.28, 0.34, 0.42, 1.0);
uniform float block_scale : hint_range(0.5, 10.0) = 2.2;

varying vec3 world_p;
varying vec3 world_n;

float hash21(vec2 p) {
	p = fract(p * vec2(234.34, 435.345));
	p += dot(p, p + 34.23);
	return fract(p.x * p.y);
}

float hash31(vec3 p) {
	p = fract(p * 0.1031);
	p += dot(p, p.yzx + 33.33);
	return fract((p.x + p.y) * p.z);
}

void vertex() {
	world_p = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	world_n = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
}

void fragment() {
	// Triplanar-style world coordinates for running-bond ashlar stone masonry
	vec2 uv = (abs(world_n.x) > 0.5) ? world_p.zy : world_p.xy;
	uv *= block_scale;

	float row = floor(uv.y * 2.0);
	uv.x += mod(row, 2.0) * 0.5;
	vec2 cell = floor(vec2(uv.x, uv.y * 2.0));
	vec2 f = fract(vec2(uv.x, uv.y * 2.0));

	// Irregular stone joint bevel & mortar groove
	float edge_x = smoothstep(0.03, 0.08, f.x) * smoothstep(0.03, 0.08, 1.0 - f.x);
	float edge_y = smoothstep(0.05, 0.12, f.y) * smoothstep(0.05, 0.12, 1.0 - f.y);
	float stone_mask = edge_x * edge_y;

	float block_rnd = hash21(cell);
	float rock_grain = hash31(floor(world_p * 28.0)) * 0.12 + hash31(floor(world_p * 85.0)) * 0.06;

	vec3 stone_col = mix(stone_color_a.rgb, stone_color_b.rgb, block_rnd) * (0.92 + rock_grain);
	vec3 col = mix(mortar_color.rgb, stone_col, stone_mask);

	// Top-facing snow dusting on stone ledges
	float up_snow = clamp((world_n.y - 0.55) * 4.0, 0.0, 1.0);
	col = mix(col, snow_cap_color.rgb, up_snow * 0.75);

	ALBEDO = col;
	ROUGHNESS = mix(0.92, 0.78 - rock_grain * 0.3, stone_mask);
	SPECULAR = 0.25;
	METALLIC = 0.02;
}
