shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_disabled, diffuse_burley, specular_schlick_ggx;

uniform vec4 tile_color_a : source_color = vec4(0.56, 0.14, 0.14, 1.0);
uniform vec4 tile_color_b : source_color = vec4(0.38, 0.09, 0.10, 1.0);
uniform vec4 snow_color : source_color = vec4(0.28, 0.34, 0.43, 1.0);
uniform float tile_density : hint_range(2.0, 24.0) = 8.0;

varying vec3 world_p;
varying vec3 world_n;

float hash21(vec2 p) {
	p = fract(p * vec2(321.1, 145.7));
	p += dot(p, p + 27.3);
	return fract(p.x * p.y);
}

void vertex() {
	world_p = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	world_n = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
}

void fragment() {
	vec2 uv = world_p.xz * tile_density * 0.35 + vec2(0.0, world_p.y * tile_density * 0.5);
	float row = floor(uv.y);
	uv.x += mod(row, 2.0) * 0.5;
	vec2 cell = floor(uv);
	vec2 f = fract(uv);

	// Scalloped overlapping tile curve
	float arch = sin(f.x * 3.14159) * 0.25;
	float overlap = smoothstep(0.06, 0.18, f.y + arch);
	float side_seam = smoothstep(0.03, 0.08, f.x) * smoothstep(0.03, 0.08, 1.0 - f.x);

	float rnd = hash21(cell);
	vec3 t_col = mix(tile_color_a.rgb, tile_color_b.rgb, rnd) * (0.65 + 0.35 * overlap) * (0.75 + 0.25 * side_seam);

	// Frost/snow gathered at bottom lip of each tile
	float snow_lip = (1.0 - overlap) * clamp(world_n.y + 0.3, 0.0, 1.0);
	vec3 col = mix(t_col, snow_color.rgb, snow_lip * 0.72);

	ALBEDO = col;
	ROUGHNESS = mix(0.45, 0.85, snow_lip);
	SPECULAR = 0.42;
}
