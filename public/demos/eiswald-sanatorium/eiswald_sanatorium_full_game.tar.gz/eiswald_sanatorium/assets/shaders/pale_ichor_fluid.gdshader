shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back, diffuse_burley, specular_schlick_ggx;

uniform vec4 ichor_base_color : source_color = vec4(0.45, 0.48, 0.56, 1.0);
uniform vec4 ichor_vein_color : source_color = vec4(0.62, 0.10, 0.16, 1.0);
uniform float emission_strength : hint_range(0.0, 5.0) = 0.45;
uniform float flow_speed : hint_range(0.1, 4.0) = 0.8;

void fragment() {
	vec2 uv1 = UV * 4.0 + vec2(TIME * flow_speed * 0.15, TIME * flow_speed * 0.1);
	vec2 uv2 = UV * 7.0 - vec2(TIME * flow_speed * 0.1, TIME * flow_speed * 0.2);
	float wave = sin(uv1.x * 3.14159 + cos(uv1.y * 3.14159)) * 0.5 + 0.5;
	float veins = smoothstep(0.62, 0.78, sin(uv2.x * 6.28 + wave * 4.0) * 0.5 + 0.5);

	vec3 col = mix(ichor_base_color.rgb, ichor_vein_color.rgb, veins * 0.65);
	ALBEDO = col;
	ROUGHNESS = 0.12;
	METALLIC = 0.15;
	EMISSION = mix(vec3(0.18, 0.22, 0.28), ichor_vein_color.rgb, veins) * emission_strength;
}
