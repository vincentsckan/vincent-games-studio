shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back, diffuse_burley, specular_schlick_ggx;

uniform vec4 skin_base_color : source_color = vec4(0.91, 0.74, 0.65, 1.0);
uniform vec4 subsurface_color : source_color = vec4(0.88, 0.32, 0.28, 1.0);
uniform vec4 blush_color : source_color = vec4(0.84, 0.42, 0.42, 1.0);
uniform vec4 lip_color : source_color = vec4(0.74, 0.34, 0.36, 1.0);
uniform float base_roughness : hint_range(0.0, 1.0) = 0.44;

varying vec3 local_pos;
varying vec3 local_norm;

float hash31(vec3 p) {
	p = fract(p * 0.1031);
	p += dot(p, p.yzx + 33.33);
	return fract((p.x + p.y) * p.z);
}

void vertex() {
	local_pos = VERTEX;
	local_norm = NORMAL;
}

void fragment() {
	// Natural facial zones based on head local coordinates
	// Lip zone around y in [0.123, 0.146], z < -0.105, |x| < 0.032
	float lip_mask = smoothstep(0.032, 0.016, abs(local_pos.x))
		* smoothstep(0.013, 0.004, abs(local_pos.y - 0.135))
		* smoothstep(-0.095, -0.115, local_pos.z);

	// Cheek & nose bridge warm blush
	float cheek_dist_l = length(local_pos - vec3(-0.048, 0.172, -0.095));
	float cheek_dist_r = length(local_pos - vec3(0.048, 0.172, -0.095));
	float nose_dist = length(local_pos - vec3(0.0, 0.175, -0.135));
	float blush_mask = clamp(
		smoothstep(0.048, 0.01, cheek_dist_l) * 0.45 +
		smoothstep(0.048, 0.01, cheek_dist_r) * 0.45 +
		smoothstep(0.032, 0.005, nose_dist) * 0.32,
		0.0, 0.65
	);

	// Subtle orbital eye-socket natural shadow
	float eye_dist_l = length(local_pos - vec3(-0.034, 0.206, -0.102));
	float eye_dist_r = length(local_pos - vec3(0.034, 0.206, -0.102));
	float socket_shadow = clamp(
		smoothstep(0.032, 0.010, eye_dist_l) * 0.22 +
		smoothstep(0.032, 0.010, eye_dist_r) * 0.22,
		0.0, 0.25
	);

	// Micro skin pore variation
	float pore = (hash31(floor(local_pos * 420.0)) - 0.5) * 0.03;

	vec3 col = skin_base_color.rgb;
	col = mix(col, blush_color.rgb, blush_mask);
	col *= (1.0 - socket_shadow);
	col = mix(col, lip_color.rgb, lip_mask);
	col += vec3(pore * 0.4);

	// Subsurface scattering wrap & soft rim glow for realistic living human skin
	float fresnel = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), 3.2);
	vec3 sss_glow = subsurface_color.rgb * (0.06 + fresnel * 0.10);

	ALBEDO = col;
	ROUGHNESS = mix(base_roughness + pore, 0.26, lip_mask);
	SPECULAR = mix(0.38, 0.62, lip_mask);
	METALLIC = 0.0;
	EMISSION = sss_glow;
}
