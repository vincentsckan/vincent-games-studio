shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_disabled, diffuse_burley, specular_schlick_ggx;

uniform vec4 hair_root_color : source_color = vec4(0.42, 0.31, 0.16, 1.0);
uniform vec4 hair_mid_color : source_color = vec4(0.78, 0.64, 0.36, 1.0);
uniform vec4 hair_tip_color : source_color = vec4(0.92, 0.82, 0.54, 1.0);
uniform float strand_density : hint_range(20.0, 300.0) = 140.0;

float hash21(vec2 p) {
	p = fract(p * vec2(123.34, 456.21));
	p += dot(p, p + 45.32);
	return fract(p.x * p.y);
}

void fragment() {
	// UV.x runs across hair lock width, UV.y runs from root (0.0) to tip (1.0)
	float strand_id = floor(UV.x * strand_density);
	float strand_var = hash21(vec2(strand_id, 1.0));
	float fine_fiber = sin(UV.x * strand_density * 6.28318) * 0.5 + 0.5;

	// Root-to-tip realistic hair color gradient
	vec3 grad_col = mix(hair_root_color.rgb, hair_mid_color.rgb, smoothstep(0.0, 0.35, UV.y));
	grad_col = mix(grad_col, hair_tip_color.rgb, smoothstep(0.45, 0.95, UV.y));

	// Individual strand darkening & golden highlights
	grad_col *= mix(0.76, 1.14, strand_var * 0.65 + fine_fiber * 0.35);

	// Anisotropic Kajiya-Kay style shifted hair sheen band along UV.y
	float sheen_shift = (strand_var - 0.5) * 0.14;
	float view_dot = clamp(dot(NORMAL, VIEW), 0.0, 1.0);
	float aniso_band1 = exp(-pow((UV.y + sheen_shift - 0.36) * 6.5, 2.0)) * view_dot;
	float aniso_band2 = exp(-pow((UV.y - sheen_shift * 0.6 - 0.58) * 9.0, 2.0)) * view_dot;

	vec3 final_col = grad_col + vec3(0.98, 0.90, 0.68) * (aniso_band1 * 0.22 + aniso_band2 * 0.12);

	ALBEDO = final_col;
	ROUGHNESS = mix(0.32, 0.48, fine_fiber);
	SPECULAR = 0.55;
	METALLIC = 0.05;
}
