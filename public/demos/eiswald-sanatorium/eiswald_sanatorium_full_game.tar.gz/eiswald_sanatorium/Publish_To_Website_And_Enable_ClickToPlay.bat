@echo off
chcp 65001 >nul
title 《霧嶺療養院：白鴉之冬》網站發佈與本機一鍵啟動安裝器
echo =====================================================================
echo  《霧嶺療養院：白鴉之冬》(Eiswald Sanatorium: Winter of the White Crow)
echo  1. 註冊本機 vincentgame:// 網頁點擊即玩啟動協定
echo  2. 同步完整遊戲與 3D 模型至 Google Cloud VM
echo  3. 發佈遊戲與 Icon 至 https://vincentsckan.github.io/vincent-games-studio/
echo =====================================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0publish_to_website_and_vm.ps1"
echo.
pause
