﻿$ErrorActionPreference = "Continue"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

# Close the previous un-imported Godot window if still open
Stop-Process -Name "Godot_v4.3-stable_win64" -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 500

# Launch the newly imported full 3D game window
$GodotExe = Join-Path $ProjectRoot ".engine\Godot_v4.3-stable_win64.exe"
Start-Process -FilePath $GodotExe -ArgumentList "--path `"$ProjectRoot`""
Write-Host "[OK] 已關閉舊視窗並重新啟動完整匯入後的《霧嶺療養院：白鴉之冬》3D 遊戲視窗！" -ForegroundColor Green
