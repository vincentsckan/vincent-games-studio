class_name PauseInventoryUI
extends PanelContainer
## PauseInventoryUI.gd
## Implements Crow Country's signature Investigator Briefcase, 3D Item Rotation Inspector,
## Dynamic Color-Coded Architectural Map (Red = Items Left, Blue = Cleared, Green = Safe Room),
## and Live S-Rank Evaluation Telemetry.

var tab_container: TabContainer
var slot_buttons: Array[Button] = []
var selected_slot_index: int = -1
var combine_source_slot: int = -1

var item_detail_title: Label
var item_detail_desc: Label
var action_feedback_label: Label
var map_summary_text: RichTextLabel
var rank_report_text: RichTextLabel

func _ready() -> void:
	set_anchors_preset(Control.PRESET_CENTER)
	position = Vector2(-480, -300)
	custom_minimum_size = Vector2(960, 600)
	_build_notebook_ui()
	InventoryManager.inventory_updated.connect(func(): refresh_all_tabs(false))

func _build_notebook_ui() -> void:
	var root_vbox := VBoxContainer.new()
	root_vbox.add_theme_constant_override("separation", 10)
	add_child(root_vbox)

	var header_row := HBoxContainer.new()
	root_vbox.add_child(header_row)

	var title_lbl := Label.new()
	title_lbl.text = "📂 特別調查員手提箱與霧嶺建築藍圖 (按 [Tab] / [M] 開關)"
	title_lbl.add_theme_font_size_override("font_size", 22)
	title_lbl.modulate = Color(0.96, 0.84, 0.45)
	title_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header_row.add_child(title_lbl)

	var close_btn := Button.new()
	close_btn.text = "返回遊戲 [Tab]"
	close_btn.pressed.connect(func(): visible = false)
	header_row.add_child(close_btn)

	tab_container = TabContainer.new()
	tab_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root_vbox.add_child(tab_container)

	# TAB 1: Briefcase Inventory & 3D Inspection
	var inv_tab := HBoxContainer.new()
	inv_tab.name = "1. 調查員手提箱 (Briefcase)"
	inv_tab.add_theme_constant_override("separation", 20)
	tab_container.add_child(inv_tab)

	var grid := GridContainer.new()
	grid.columns = 2
	grid.custom_minimum_size = Vector2(430, 440)
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	inv_tab.add_child(grid)

	for i in range(8):
		var btn := Button.new()
		btn.custom_minimum_size = Vector2(205, 86)
		btn.pressed.connect(_on_slot_clicked.bind(i))
		grid.add_child(btn)
		slot_buttons.append(btn)

	var right_col := VBoxContainer.new()
	right_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right_col.add_theme_constant_override("separation", 12)
	inv_tab.add_child(right_col)

	item_detail_title = Label.new()
	item_detail_title.add_theme_font_size_override("font_size", 22)
	item_detail_title.modulate = Color(0.95, 0.85, 0.48)
	right_col.add_child(item_detail_title)

	item_detail_desc = Label.new()
	item_detail_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	item_detail_desc.custom_minimum_size = Vector2(440, 150)
	item_detail_desc.add_theme_font_size_override("font_size", 17)
	right_col.add_child(item_detail_desc)

	var action_row := HBoxContainer.new()
	action_row.add_theme_constant_override("separation", 12)
	right_col.add_child(action_row)

	var use_btn := Button.new()
	use_btn.text = "使用 / 裝備"
	use_btn.custom_minimum_size = Vector2(135, 44)
	use_btn.pressed.connect(_on_use_pressed)
	action_row.add_child(use_btn)

	var combine_btn := Button.new()
	combine_btn.text = "組合道具"
	combine_btn.custom_minimum_size = Vector2(135, 44)
	combine_btn.pressed.connect(_on_combine_pressed)
	action_row.add_child(combine_btn)

	var inspect_3d_btn := Button.new()
	inspect_3d_btn.text = "🔍 3D 翻轉檢視背面"
	inspect_3d_btn.custom_minimum_size = Vector2(165, 44)
	inspect_3d_btn.pressed.connect(_on_inspect_3d_pressed)
	action_row.add_child(inspect_3d_btn)

	action_feedback_label = Label.new()
	action_feedback_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	action_feedback_label.add_theme_font_size_override("font_size", 16)
	action_feedback_label.modulate = Color(0.55, 0.95, 0.68)
	right_col.add_child(action_feedback_label)

	# TAB 2: Crow Country-style Architectural Map
	var map_tab := VBoxContainer.new()
	map_tab.name = "2. 霧嶺箱庭建築地圖 (Map)"
	tab_container.add_child(map_tab)

	map_summary_text = RichTextLabel.new()
	map_summary_text.bbcode_enabled = true
	map_summary_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	map_summary_text.add_theme_font_size_override("normal_font_size", 17)
	map_tab.add_child(map_summary_text)

	# TAB 3: S-Rank Telemetry & Case Files
	var rank_tab := VBoxContainer.new()
	rank_tab.name = "3. 調查評級與卷宗 (S-Rank)"
	tab_container.add_child(rank_tab)

	rank_report_text = RichTextLabel.new()
	rank_report_text.bbcode_enabled = true
	rank_report_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	rank_report_text.add_theme_font_size_override("normal_font_size", 18)
	rank_tab.add_child(rank_report_text)

func refresh_all_tabs(open_map_directly: bool = false) -> void:
	if open_map_directly and tab_container:
		tab_container.current_tab = 1

	# Refresh inventory grid
	for i in range(slot_buttons.size()):
		var btn: Button = slot_buttons[i]
		if i < InventoryManager.slots.size():
			var entry: Dictionary = InventoryManager.slots[i]
			var def: ItemData = InventoryManager.item_catalog.get(entry["id"])
			var d_name: String = def.display_name if def else String(entry["id"])
			var equipped_tag: String = " [已裝備]" if entry["id"] == InventoryManager.equipped_weapon_id else ""
			btn.text = "%s%s\n數量: x%d" % [d_name, equipped_tag, int(entry["qty"])]
			btn.disabled = false
		else:
			btn.text = "— 空欄位 —"
			btn.disabled = true

	_refresh_map_tab()
	_refresh_rank_tab()

func _on_slot_clicked(slot_idx: int) -> void:
	if slot_idx >= InventoryManager.slots.size():
		return
	AudioManager.play_synth_sfx("ui_click")

	if combine_source_slot != -1 and combine_source_slot != slot_idx:
		var msg: String = InventoryManager.combine_slots(combine_source_slot, slot_idx)
		combine_source_slot = -1
		action_feedback_label.text = msg
		refresh_all_tabs(false)
		return

	selected_slot_index = slot_idx
	var entry: Dictionary = InventoryManager.slots[slot_idx]
	var def: ItemData = InventoryManager.item_catalog.get(entry["id"])
	if def:
		item_detail_title.text = "【%s】" % def.display_name
		item_detail_desc.text = def.description

func _on_use_pressed() -> void:
	if selected_slot_index < 0 or selected_slot_index >= InventoryManager.slots.size():
		return
	var res: String = InventoryManager.use_slot(selected_slot_index)
	action_feedback_label.text = res
	refresh_all_tabs(false)

func _on_combine_pressed() -> void:
	if selected_slot_index < 0 or selected_slot_index >= InventoryManager.slots.size():
		return
	combine_source_slot = selected_slot_index
	action_feedback_label.text = "請點擊另一個道具欄位進行合成（例如：高山雪絨藥草 + 無菌止血紗布）。"

func _on_inspect_3d_pressed() -> void:
	if selected_slot_index < 0 or selected_slot_index >= InventoryManager.slots.size():
		return
	var item_id: String = InventoryManager.slots[selected_slot_index]["id"]
	var clue: String = InventoryManager.trigger_3d_inspect_secret(item_id)
	action_feedback_label.text = clue
	refresh_all_tabs(false)

func _refresh_map_tab() -> void:
	if map_summary_text == null:
		return
	var sb: String = "[b][color=#f5d76e]【霧嶺高山療養渡假村 — 區域探索狀態圖】[/color][/b]\n"
	sb += "圖例：[color=#4cd964]■ 綠色 = 茶歇安全屋[/color]  |  [color=#5ac8fa]■ 藍色 = 已完全搜刮[/color]  |  [color=#ff5e5e]■ 紅色 = 尚有未取得道具/謎題[/color]  |  [color=#8e8e93]□ 灰色 = 尚未踏足[/color]\n\n"

	for r_id in GameManager.room_database.keys():
		var r: Dictionary = GameManager.room_database[r_id]
		var current_marker: String = "  [b][color=#ffe66d]◀ 目前所在位置[/color][/b]" if r_id == GameManager.current_room_id else ""
		var st: int = int(r["status"])
		var color_hex: String = "#8e8e93"
		var status_str: String = "未探索"
		match st:
			GameManager.RoomStatus.SAFE_ROOM:
				color_hex = "#4cd964"
				status_str = "安全屋 (剩餘物資: %d)" % int(r["remaining_items"])
			GameManager.RoomStatus.VISITED_CLEARED:
				color_hex = "#5ac8fa"
				status_str = "已完全搜刮 (Cleared)"
			GameManager.RoomStatus.VISITED_ITEMS_REMAIN:
				color_hex = "#ff5e5e"
				status_str = "尚有 %d 項線索/物資" % int(r["remaining_items"])
		sb += "[color=%s]■ %s — [%s][/color]%s\n" % [color_hex, String(r["name"]), status_str, current_marker]

	sb += "\n[b][color=#f5d76e]【地圖已記錄的門鎖與機關備忘錄】[/color][/b]\n"
	if GameManager.discovered_door_notes.is_empty():
		sb += "• 尚未發現鎖上的門扉。\n"
	else:
		for d_id in GameManager.discovered_door_notes.keys():
			sb += "• %s\n" % String(GameManager.discovered_door_notes[d_id])

	map_summary_text.text = sb

func _refresh_rank_tab() -> void:
	if rank_report_text == null:
		return
	var r: Dictionary = GameManager.calculate_survival_rank()
	var sb: String = "[b][color=#f5d76e]【《霧嶺療養院：白鴉之冬》即時 S-Rank 評級統計】[/color][/b]\n\n"
	sb += "• 當前預測通關評價：[b][color=#4cd964]【 %s 級 】[/color][/b] (綜合評分：%d)\n" % [String(r["rank"]), int(r["score"])]
	sb += "• 累計調查時間：%s\n" % String(r["play_time_formatted"])
	sb += "• 醫療用品使用次數：%d 次 (S+ 要求 ≤ 1 次)\n" % int(r["heals_used"])
	sb += "• 雪山神諭占卜機提示次數：%d 次 (S+ 要求 0 次)\n" % int(r["oracle_hints_used"])
	sb += "• 水晶雪絨花收集進度：%s\n" % String(r["edelweiss_found"])
	sb += "• 射擊命中率：%s\n" % String(r["accuracy"])
	sb += "• 預計解鎖通關獎勵：[color=#5ac8fa]%s[/color]\n" % String(r["reward"])
	rank_report_text.text = sb
