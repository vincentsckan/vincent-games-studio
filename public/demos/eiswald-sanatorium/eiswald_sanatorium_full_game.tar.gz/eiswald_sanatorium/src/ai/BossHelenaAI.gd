class_name BossHelenaAI
extends EnemyBase
## BossHelenaAI.gd
## Commercial Indie-AAA Multi-Phase Boss Controller for:
## - Mid-Boss: Dr. Helena Kroll (The Hydrotherapy Matriarch)
## - Final Boss: The Pale Ichor Sovereign
## Features telegraphed Geothermal Steam / Pale Ichor AoE Shockwaves, Back-Valve critical weakpoints,
## and Enrage Phase 2 speed & emission surge.

@export var phase_two_triggered: bool = false
@export var aoe_cooldown: float = 6.5

var _aoe_timer: float = 4.0

func _ready() -> void:
	max_hp = 340.0
	move_speed = 2.65
	attack_damage = 32.0
	super._ready()

func _physics_process(delta: float) -> void:
	super._physics_process(delta)
	if is_dead or GameManager.current_mode == GameManager.GameMode.EXPLORATION_ONLY:
		return

	if state == AIState.CHASE:
		_aoe_timer -= delta
		if _aoe_timer <= 0.0:
			_aoe_timer = aoe_cooldown * (0.7 if phase_two_triggered else 1.0)
			_execute_telegraphed_steam_aoe()

func _execute_telegraphed_steam_aoe() -> void:
	var player: Node3D = get_tree().get_first_node_in_group("player") as Node3D
	if player == null or global_position.distance_to(player.global_position) > 7.5:
		return

	AudioManager.play_synth_sfx("gunshot_shotgun")
	var ring_light := OmniLight3D.new()
	ring_light.light_color = Color(0.95, 0.22, 0.32) if phase_two_triggered else Color(0.45, 0.88, 1.0)
	ring_light.light_energy = 7.5
	ring_light.omni_range = 6.0
	get_parent().add_child(ring_light)
	ring_light.global_position = global_position + Vector3(0, 1.0, 0)

	if global_position.distance_to(player.global_position) <= 3.6:
		GameManager.apply_player_damage(18.0, true)

	var tw := create_tween()
	tw.tween_property(ring_light, "light_energy", 0.0, 0.55)
	tw.tween_callback(ring_light.queue_free)

func apply_damage(amount: float, is_incendiary: bool, zone_tag: String) -> void:
	super.apply_damage(amount, is_incendiary, zone_tag)
	if not is_dead and not phase_two_triggered and current_hp <= max_hp * 0.5:
		phase_two_triggered = true
		move_speed = 3.55
		AudioManager.play_synth_sfx("gunshot_shotgun")
