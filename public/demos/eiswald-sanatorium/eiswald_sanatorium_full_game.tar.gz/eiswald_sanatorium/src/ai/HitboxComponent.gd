class_name HitboxComponent
extends Area3D
## HitboxComponent.gd
## Locational hitbox attached to enemy body parts (Head, Torso, Legs, or Back Geothermal Valve)
## for Crow Country-style precision 3D laser-sight targeting.

enum BodyZone {
	TORSO = 0,
	HEAD_WEAKPOINT = 1,
	LEG_CRIPPLE = 2,
	PRESSURE_VALVE_CRITICAL = 3
}

@export var body_zone: BodyZone = BodyZone.TORSO
@export var damage_multiplier: float = 1.0
@export var zone_display_name: String = "軀幹"
@export var parent_enemy_path: NodePath

var parent_enemy: Node = null

func _ready() -> void:
	if not parent_enemy_path.is_empty():
		parent_enemy = get_node_or_null(parent_enemy_path)
	else:
		parent_enemy = get_parent()

func get_aim_label() -> String:
	if parent_enemy and parent_enemy.get("is_dead") == true:
		return ""
	var prefix: String = parent_enemy.get("enemy_title") if parent_enemy and parent_enemy.get("enemy_title") != null else "異變住客"
	return "%s — 【%s】" % [prefix, zone_display_name]

func is_weakpoint_hitbox() -> bool:
	return body_zone == BodyZone.HEAD_WEAKPOINT or body_zone == BodyZone.PRESSURE_VALVE_CRITICAL

func on_laser_shot_hit(base_damage: float, _hit_pos: Vector3, is_incendiary: bool) -> void:
	if parent_enemy == null:
		parent_enemy = get_parent()
	if parent_enemy and parent_enemy.has_method("apply_damage"):
		var final_dmg: float = base_damage * damage_multiplier
		var zone_tag: String = "TORSO"
		match body_zone:
			BodyZone.HEAD_WEAKPOINT:
				zone_tag = "HEAD"
			BodyZone.LEG_CRIPPLE:
				zone_tag = "LEG"
			BodyZone.PRESSURE_VALVE_CRITICAL:
				zone_tag = "VALVE"
		parent_enemy.call("apply_damage", final_dmg, is_incendiary, zone_tag)
