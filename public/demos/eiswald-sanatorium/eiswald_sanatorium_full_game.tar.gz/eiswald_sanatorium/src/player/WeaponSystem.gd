class_name WeaponSystem
extends Node3D
## WeaponSystem.gd
## Implements Crow Country's 3D Laser-Sight + Reticle Shrink Focus Critical System.
## Standing still while aiming shrinks the reticle over 1.1s, boosting weakpoint/headshot damage up to +55%.

signal weapon_fired(weapon_id: String, clip_remaining: int, reserve_remaining: int)
signal target_locked(target_name: String, is_weakpoint: bool)
signal reticle_focus_changed(focus_ratio: float, aiming_active: bool)

@onready var ray_cast: RayCast3D = $LaserRayCast3D
@onready var laser_beam_mesh: MeshInstance3D = $LaserBeamMesh
@onready var laser_hit_dot: OmniLight3D = $LaserHitDotLight
@onready var muzzle_flash_light: OmniLight3D = $MuzzleFlashLight

var is_aiming: bool = false
var aim_pitch_offset_deg: float = 0.0
var focus_charge: float = 0.0 # 0.0 (wide reticle) -> 1.0 (fully shrunk critical reticle)
var is_moving_while_aiming: bool = false
var _cooldown_timer: float = 0.0
var _muzzle_timer: float = 0.0
var _laser_dot_mesh: MeshInstance3D
var _held_weapon_node: Node3D

func _ready() -> void:
	_build_laser_dot_mesh()
	_rebuild_held_weapon_mesh(InventoryManager.equipped_weapon_id)
	InventoryManager.weapon_equipped.connect(_on_weapon_equipped)
	set_aiming_active(false)

func _on_weapon_equipped(weapon_id: String) -> void:
	_rebuild_held_weapon_mesh(weapon_id)
	if laser_beam_mesh and InventoryManager.weapon_states.has(weapon_id):
		var col: Color = InventoryManager.weapon_states[weapon_id]["laser_color"]
		var mat := laser_beam_mesh.get_active_material(0) as ShaderMaterial
		if mat:
			mat.set_shader_parameter("laser_color", col)
		if _laser_dot_mesh and _laser_dot_mesh.material_override is StandardMaterial3D:
			var dmat := _laser_dot_mesh.material_override as StandardMaterial3D
			dmat.albedo_color = col
			dmat.emission = col
		if laser_hit_dot:
			laser_hit_dot.light_color = col

func _build_laser_dot_mesh() -> void:
	_laser_dot_mesh = MeshInstance3D.new()
	_laser_dot_mesh.name = "LaserHitDotMesh"
	var sm := SphereMesh.new()
	sm.radius = 0.026
	sm.height = 0.052
	_laser_dot_mesh.mesh = sm
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = Color(1.0, 0.16, 0.22)
	mat.emission_enabled = true
	mat.emission = Color(1.0, 0.16, 0.22)
	mat.emission_energy_multiplier = 2.4
	_laser_dot_mesh.material_override = mat
	_laser_dot_mesh.visible = false
	add_child(_laser_dot_mesh)

func _rebuild_held_weapon_mesh(weapon_id: String) -> void:
	if _held_weapon_node:
		_held_weapon_node.queue_free()
	_held_weapon_node = Node3D.new()
	_held_weapon_node.name = "HeldWeaponModel"
	add_child(_held_weapon_node)

	var mat_gunmetal := StandardMaterial3D.new()
	mat_gunmetal.albedo_color = Color(0.20, 0.22, 0.25)
	mat_gunmetal.metallic = 0.78
	mat_gunmetal.roughness = 0.28

	var mat_wood := StandardMaterial3D.new()
	mat_wood.albedo_color = Color(0.42, 0.22, 0.10)
	mat_wood.roughness = 0.48

	var mat_chrome := StandardMaterial3D.new()
	mat_chrome.albedo_color = Color(0.78, 0.80, 0.84)
	mat_chrome.metallic = 0.90
	mat_chrome.roughness = 0.18

	var add_part := func(sz: Vector3, pos: Vector3, rot_x: float, mat: Material) -> void:
		var mi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = sz
		mi.mesh = bm
		mi.position = pos
		mi.rotation_degrees.x = rot_x
		mi.material_override = mat
		_held_weapon_node.add_child(mi)

	match weapon_id:
		"weapon_alpine_shotgun":
			add_part.call(Vector3(0.045, 0.065, 0.24), Vector3(0, -0.02, 0.10), 12.0, mat_wood)
			add_part.call(Vector3(0.055, 0.04, 0.44), Vector3(0, 0.02, -0.14), 0.0, mat_gunmetal)
		"weapon_white_crow_magnum":
			add_part.call(Vector3(0.032, 0.09, 0.045), Vector3(0, -0.05, 0.04), -14.0, mat_wood)
			add_part.call(Vector3(0.045, 0.055, 0.07), Vector3(0, 0.01, -0.02), 0.0, mat_chrome)
			add_part.call(Vector3(0.026, 0.032, 0.24), Vector3(0, 0.02, -0.14), 0.0, mat_chrome)
		"weapon_hunting_crossbow":
			add_part.call(Vector3(0.04, 0.05, 0.36), Vector3(0, 0.0, -0.06), 0.0, mat_wood)
			add_part.call(Vector3(0.34, 0.022, 0.035), Vector3(0, 0.015, -0.20), 0.0, mat_gunmetal)
		"weapon_mp5_smg":
			add_part.call(Vector3(0.036, 0.09, 0.04), Vector3(0, -0.05, 0.04), -10.0, mat_gunmetal)
			add_part.call(Vector3(0.044, 0.065, 0.28), Vector3(0, 0.015, -0.08), 0.0, mat_gunmetal)
			add_part.call(Vector3(0.024, 0.13, 0.032), Vector3(0, -0.06, -0.08), 8.0, mat_gunmetal)
		"weapon_sanatorium_rifle":
			add_part.call(Vector3(0.042, 0.065, 0.36), Vector3(0, -0.01, 0.02), 6.0, mat_wood)
			add_part.call(Vector3(0.024, 0.026, 0.42), Vector3(0, 0.025, -0.22), 0.0, mat_gunmetal)
			add_part.call(Vector3(0.026, 0.028, 0.16), Vector3(0, 0.055, -0.06), 0.0, mat_chrome)
		"weapon_geothermal_flamethrower":
			add_part.call(Vector3(0.08, 0.09, 0.34), Vector3(0, 0.0, -0.06), 0.0, mat_wood)
			add_part.call(Vector3(0.035, 0.035, 0.26), Vector3(0, 0.02, -0.24), 0.0, mat_chrome)
		_: # VP-9 Pistol
			add_part.call(Vector3(0.028, 0.085, 0.042), Vector3(0, -0.045, 0.03), -14.0, mat_gunmetal)
			add_part.call(Vector3(0.032, 0.038, 0.17), Vector3(0, 0.015, -0.04), 0.0, mat_gunmetal)

func set_aiming_active(active: bool) -> void:
	is_aiming = active
	if laser_beam_mesh:
		laser_beam_mesh.visible = active
	if laser_hit_dot:
		laser_hit_dot.visible = active
	if _laser_dot_mesh:
		_laser_dot_mesh.visible = active
	if _held_weapon_node:
		_held_weapon_node.visible = active
	if not active:
		focus_charge = 0.0
		aim_pitch_offset_deg = 0.0
		rotation_degrees.x = 0.0
	reticle_focus_changed.emit(focus_charge, is_aiming)

func adjust_aim_elevation(mouse_delta_y: float) -> void:
	if not is_aiming:
		return
	aim_pitch_offset_deg = clampf(aim_pitch_offset_deg - mouse_delta_y * 0.14, -28.0, 35.0)
	rotation_degrees.x = aim_pitch_offset_deg

func _physics_process(delta: float) -> void:
	if _cooldown_timer > 0.0:
		_cooldown_timer -= delta
	if _muzzle_timer > 0.0:
		_muzzle_timer -= delta
		if _muzzle_timer <= 0.0 and muzzle_flash_light:
			muzzle_flash_light.visible = false

	if not is_aiming or ray_cast == null:
		return

	# Reticle shrink calculation: shrinks when standing steady, blooms slightly if strafing
	if is_moving_while_aiming:
		focus_charge = clampf(focus_charge - delta * 0.75, 0.0, 1.0)
	else:
		focus_charge = clampf(focus_charge + delta * 0.90, 0.0, 1.0)
	reticle_focus_changed.emit(focus_charge, true)

	ray_cast.force_raycast_update()
	var max_len: float = 22.0
	var hit_point: Vector3 = ray_cast.to_global(Vector3(0.0, 0.0, -max_len))

	if ray_cast.is_colliding():
		hit_point = ray_cast.get_collision_point()
		var collider: Object = ray_cast.get_collider()
		if collider and collider.has_method("get_aim_label"):
			var is_weak: bool = bool(collider.call("is_weakpoint_hitbox")) if collider.has_method("is_weakpoint_hitbox") else false
			target_locked.emit(String(collider.call("get_aim_label")), is_weak)
		else:
			target_locked.emit("", false)
	else:
		target_locked.emit("", false)

	var beam_len: float = maxf(0.25, global_position.distance_to(hit_point) - 0.16)
	if laser_beam_mesh:
		laser_beam_mesh.scale = Vector3(1.0, beam_len * 0.5, 1.0)
		laser_beam_mesh.position = Vector3(0.0, 0.0, -0.16 - beam_len * 0.5)
	if laser_hit_dot:
		laser_hit_dot.global_position = hit_point + ray_cast.get_collision_normal() * 0.04
	if _laser_dot_mesh:
		_laser_dot_mesh.global_position = hit_point + ray_cast.get_collision_normal() * 0.02

func attempt_fire() -> bool:
	if not is_aiming or _cooldown_timer > 0.0:
		return false

	var w_id: String = InventoryManager.equipped_weapon_id
	if not InventoryManager.weapon_states.has(w_id):
		return false

	var st: Dictionary = InventoryManager.weapon_states[w_id]
	var clip: int = int(st["clip"])
	if clip <= 0:
		AudioManager.play_synth_sfx("door_locked")
		return false

	st["clip"] = clip - 1
	_cooldown_timer = float(st["fire_rate"])
	GameManager.shots_fired += 1

	var sfx_type: String = "gunshot_shotgun" if (w_id == "weapon_alpine_shotgun" or w_id == "weapon_white_crow_magnum") else "gunshot_pistol"
	AudioManager.play_synth_sfx(sfx_type)
	if muzzle_flash_light:
		muzzle_flash_light.visible = true
		_muzzle_timer = 0.07

	ray_cast.force_raycast_update()
	if ray_cast.is_colliding():
		var collider: Object = ray_cast.get_collider()
		var hit_pos: Vector3 = ray_cast.get_collision_point()
		# Up to +55% critical bonus when reticle is fully shrunk
		var crit_mult: float = 1.0 + (focus_charge * 0.55)
		var base_dmg: float = float(st["damage"]) * crit_mult
		var is_incendiary: bool = (w_id == "weapon_geothermal_flamethrower")

		if collider != null:
			if collider.has_method("on_laser_shot_hit"):
				GameManager.shots_hit += 1
				collider.call("on_laser_shot_hit", base_dmg, hit_pos, is_incendiary)
			elif collider.get_parent() and collider.get_parent().has_method("on_laser_shot_hit"):
				GameManager.shots_hit += 1
				collider.get_parent().call("on_laser_shot_hit", base_dmg, hit_pos, is_incendiary)

	# Recoil blooms the reticle back out after firing
	focus_charge = maxf(0.0, focus_charge - 0.65)
	reticle_focus_changed.emit(focus_charge, true)

	var reserve: int = InventoryManager.get_item_count(String(st["ammo_item_id"]))
	InventoryManager.inventory_updated.emit()
	weapon_fired.emit(w_id, int(st["clip"]), reserve)
	return true
