class_name CameraRig
extends Node3D
## CameraRig.gd
## Faithfully implements Crow Country's dual-mode 3D Diorama Camera:
## - Q / E rotates the camera in crisp 45-degree increments with smooth cubic easing.
## - Middle-mouse drag allows smooth free orbital inspection of the room.
## - Holding Right-Click (Aim) smoothly pulls the camera in, lowers pitch slightly, and tightens FOV for precision 3D laser-sight aiming.

@export var target_node: Node3D
@export var follow_smoothing: float = 8.5
@export var rotation_smoothing: float = 10.0
@export var exploration_distance: float = 6.85
@export var aiming_distance: float = 4.2
@export var exploration_pitch_deg: float = -33.5
@export var aiming_pitch_deg: float = -18.0
@export var exploration_fov: float = 36.0
@export var aiming_fov: float = 30.0

var target_yaw_deg: float = -4.5
var current_yaw_deg: float = -4.5
var is_aiming_mode: bool = false
var _shake_intensity: float = 0.0

@onready var spring_arm: SpringArm3D = $SpringArm3D
@onready var camera_3d: Camera3D = $SpringArm3D/Camera3D

func _ready() -> void:
	current_yaw_deg = target_yaw_deg
	rotation_degrees.y = current_yaw_deg
	if target_node != null:
		var forward_lead: Vector3 = -global_transform.basis.z.normalized() * 0.92
		forward_lead.y = 0.0
		global_position = target_node.global_position + Vector3(-0.12, 1.05, 0.0) + forward_lead
	if spring_arm:
		spring_arm.spring_length = exploration_distance
		spring_arm.rotation_degrees.x = exploration_pitch_deg
	if camera_3d:
		camera_3d.fov = exploration_fov

func _unhandled_input(event: InputEvent) -> void:
	if DialogueManager.is_dialogue_active or DialogueManager.is_document_active:
		return

	if event.is_action_pressed("camera_rotate_left"):
		target_yaw_deg -= 45.0
		AudioManager.play_synth_sfx("camera_snap")
	elif event.is_action_pressed("camera_rotate_right"):
		target_yaw_deg += 45.0
		AudioManager.play_synth_sfx("camera_snap")
	elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_MIDDLE):
		target_yaw_deg -= event.relative.x * 0.35
	elif event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			exploration_distance = clampf(exploration_distance - 0.55, 2.2, 11.0)
			exploration_pitch_deg = lerpf(-12.0, -34.0, (exploration_distance - 2.2) / 8.8)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			exploration_distance = clampf(exploration_distance + 0.55, 2.2, 11.0)
			exploration_pitch_deg = lerpf(-12.0, -34.0, (exploration_distance - 2.2) / 8.8)

func _physics_process(delta: float) -> void:
	current_yaw_deg = lerpf(current_yaw_deg, target_yaw_deg, clampf(delta * rotation_smoothing, 0.0, 1.0))
	rotation_degrees.y = current_yaw_deg

	if target_node != null:
		var forward_lead: Vector3 = -global_transform.basis.z.normalized() * 0.92
		forward_lead.y = 0.0
		var desired_pos: Vector3 = target_node.global_position + Vector3(-0.12, 1.05, 0.0) + forward_lead
		global_position = global_position.lerp(desired_pos, clampf(delta * follow_smoothing, 0.0, 1.0))

	if spring_arm and camera_3d:
		var desired_dist: float = aiming_distance if is_aiming_mode else exploration_distance
		var desired_pitch: float = aiming_pitch_deg if is_aiming_mode else exploration_pitch_deg
		var desired_fov: float = aiming_fov if is_aiming_mode else exploration_fov

		spring_arm.spring_length = lerpf(spring_arm.spring_length, desired_dist, clampf(delta * 7.5, 0.0, 1.0))
		spring_arm.rotation_degrees.x = lerpf(spring_arm.rotation_degrees.x, desired_pitch, clampf(delta * 7.5, 0.0, 1.0))
		camera_3d.fov = lerpf(camera_3d.fov, desired_fov, clampf(delta * 7.5, 0.0, 1.0))

		if _shake_intensity > 0.001:
			camera_3d.h_offset = randf_range(-_shake_intensity, _shake_intensity)
			camera_3d.v_offset = randf_range(-_shake_intensity, _shake_intensity)
			_shake_intensity = move_toward(_shake_intensity, 0.0, delta * 1.4)
		else:
			camera_3d.h_offset = 0.0
			camera_3d.v_offset = 0.0

func set_aiming_mode(active: bool) -> void:
	if is_aiming_mode != active:
		is_aiming_mode = active
		if is_aiming_mode:
			AudioManager.play_synth_sfx("laser_aim_on")

func apply_camera_shake(intensity: float = 0.18) -> void:
	_shake_intensity = maxf(_shake_intensity, intensity)

func get_camera_3d() -> Camera3D:
	return camera_3d
