class_name ItemInspector3D
extends Node3D
## ItemInspector3D.gd
## Renders a 3D rotatable preview of the selected inventory item inside the Briefcase UI
## and detects when the player rotates an item (like the Brass Pocket Watch) to its back side
## to reveal hidden engraved passcodes.

signal backface_hotspot_revealed(item_id: String)

var current_item_id: String = ""
var _mesh_holder: Node3D
var _secret_triggered: bool = false

func _ready() -> void:
	_mesh_holder = Node3D.new()
	add_child(_mesh_holder)

func display_item_mesh(item_id: String, color: Color) -> void:
	current_item_id = item_id
	_secret_triggered = false
	for child in _mesh_holder.get_children():
		child.queue_free()

	_mesh_holder.rotation = Vector3.ZERO

	var root_mesh := MeshInstance3D.new()
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.metallic = 0.72
	mat.roughness = 0.28

	if item_id == "brass_pocket_watch":
		var cyl := CylinderMesh.new()
		cyl.top_radius = 0.65
		cyl.bottom_radius = 0.65
		cyl.height = 0.22
		root_mesh.mesh = cyl
		root_mesh.rotation_degrees.x = 90.0

		# Engraved backface marker
		var back_plate := MeshInstance3D.new()
		var back_mesh := BoxMesh.new()
		back_mesh.size = Vector3(0.75, 0.05, 0.35)
		back_plate.mesh = back_mesh
		back_plate.position = Vector3(0, -0.13, 0)
		var glow_mat := StandardMaterial3D.new()
		glow_mat.albedo_color = Color(1.0, 0.85, 0.35)
		glow_mat.emission_enabled = true
		glow_mat.emission = Color(0.95, 0.65, 0.15)
		glow_mat.emission_energy_multiplier = 1.6
		back_plate.material_override = glow_mat
		root_mesh.add_child(back_plate)
	else:
		var box := BoxMesh.new()
		box.size = Vector3(0.85, 0.55, 0.35)
		root_mesh.mesh = box

	root_mesh.material_override = mat
	_mesh_holder.add_child(root_mesh)

func rotate_preview(delta_angles: Vector2) -> void:
	_mesh_holder.rotate_y(delta_angles.x * 0.015)
	_mesh_holder.rotate_x(delta_angles.y * 0.015)

	# Check if rotated near 180 degrees to inspect the back of the pocket watch
	var forward_z: Vector3 = _mesh_holder.global_transform.basis.z
	if not _secret_triggered and forward_z.z < -0.55:
		_secret_triggered = true
		backface_hotspot_revealed.emit(current_item_id)
