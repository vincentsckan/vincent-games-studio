extends Node
## InventoryManager.gd
## Manages the investigator briefcase, 4 signature weapons (Pistol, Shotgun, .44 Magnum, Flamethrower),
## medical supplies (First-Aid Spray, Antidote, Herbs), Metroidvania progression tools (Crowbar, Acid Vial, Keys),
## item combination recipes, and 3D item inspection secrets.

signal inventory_updated()
signal weapon_equipped(weapon_id: String)
signal item_combined(item_a: String, item_b: String, result_id: String)
signal secret_clue_discovered(item_id: String, clue_text: String)

var max_slots: int = 20
var item_catalog: Dictionary = {}
var slots: Array[Dictionary] = []
var storage_box: Array[Dictionary] = []
var collected_treasures: Array[String] = []

var equipped_weapon_id: String = "weapon_vp9_pistol"

var weapon_states: Dictionary = {
	"weapon_vp9_pistol": {
		"name": "VP-9 制式手槍 (Handgun)",
		"clip": 12,
		"max_clip": 12,
		"ammo_item_id": "ammo_9mm",
		"damage": 28.0,
		"fire_rate": 0.34,
		"range": 24.0,
		"laser_color": Color(1.0, 0.12, 0.18, 0.9)
	},
	"weapon_alpine_shotgun": {
		"name": "阿爾卑斯雙管霰彈槍 (Shotgun)",
		"clip": 4,
		"max_clip": 4,
		"ammo_item_id": "ammo_12gauge",
		"damage": 85.0,
		"fire_rate": 0.72,
		"range": 12.0,
		"laser_color": Color(1.0, 0.55, 0.15, 0.9)
	},
	"weapon_white_crow_magnum": {
		"name": "白鴉 .44 馬格南左輪 (Magnum)",
		"clip": 6,
		"max_clip": 6,
		"ammo_item_id": "ammo_44magnum",
		"damage": 145.0,
		"fire_rate": 0.65,
		"range": 28.0,
		"laser_color": Color(0.95, 0.85, 0.25, 0.95)
	},
	"weapon_geothermal_flamethrower": {
		"name": "地熱高壓火焰噴射器 (Flamethrower)",
		"clip": 25,
		"max_clip": 25,
		"ammo_item_id": "ammo_fuel_tank",
		"damage": 42.0,
		"fire_rate": 0.14,
		"range": 9.5,
		"laser_color": Color(1.0, 0.38, 0.08, 0.95)
	},
	"weapon_hunting_crossbow": {
		"name": "雪山精鋼連弩 (Crossbow)",
		"clip": 6,
		"max_clip": 6,
		"ammo_item_id": "ammo_bolts",
		"damage": 62.0,
		"fire_rate": 0.45,
		"range": 26.0,
		"laser_color": Color(0.28, 0.92, 0.52, 0.90)
	},
	"weapon_mp5_smg": {
		"name": "MP-91 特種衝鋒槍 (Tactical SMG)",
		"clip": 30,
		"max_clip": 30,
		"ammo_item_id": "ammo_9mm",
		"damage": 20.0,
		"fire_rate": 0.11,
		"range": 20.0,
		"laser_color": Color(0.25, 0.72, 1.0, 0.90)
	},
	"weapon_sanatorium_rifle": {
		"name": "瑞士毛瑟栓動步槍 (Alpine Rifle)",
		"clip": 5,
		"max_clip": 5,
		"ammo_item_id": "ammo_rifle",
		"damage": 130.0,
		"fire_rate": 0.85,
		"range": 34.0,
		"laser_color": Color(0.95, 0.35, 0.85, 0.92)
	}
}

var combination_recipes: Dictionary = {
	"herb_alpine+gauze_antiseptic": {"result": "medkit_compound", "qty": 1},
	"herb_alpine+ichor_antidote": {"result": "first_aid_spray", "qty": 1},
	"chemical_acid+salt_deicing": {"result": "acid_vial", "qty": 1}
}

func _ready() -> void:
	_register_catalog()
	_init_starter_loadout()

func _register_catalog() -> void:
	# 4 Signature Weapons
	item_catalog["weapon_vp9_pistol"] = ItemData.create(
		"weapon_vp9_pistol", "VP-9 制式手槍",
		"薇拉的隨身制式手槍。舉槍瞄準並站立不動 1 秒待『準星完全收縮』後，爆頭暴擊率與傷害大幅提升。",
		ItemData.ItemCategory.WEAPON, false, 1, 0.0, false, "", "", Color(0.55, 0.65, 0.78)
	)
	item_catalog["weapon_alpine_shotgun"] = ItemData.create(
		"weapon_alpine_shotgun", "阿爾卑斯雙管霰彈槍",
		"童話村獵人木屋陳列的 12 號口徑霰彈槍，近距離具備極強的群體擊退與破壞力。",
		ItemData.ItemCategory.WEAPON, false, 1, 0.0, false, "", "", Color(0.75, 0.48, 0.28)
	)
	item_catalog["weapon_white_crow_magnum"] = ItemData.create(
		"weapon_white_crow_magnum", "白鴉 .44 馬格南左輪",
		"藏於『鬧鬼山丘』古堡靈廟的傳奇大口徑左輪手槍。具備毀滅性的弱點貫穿力，是對付重型畸變體與頭目的王牌。",
		ItemData.ItemCategory.WEAPON, false, 1, 0.0, false, "", "", Color(0.95, 0.78, 0.22)
	)
	item_catalog["weapon_geothermal_flamethrower"] = ItemData.create(
		"weapon_geothermal_flamethrower", "地熱高壓火焰噴射器",
		"『地下挖掘場』礦坑工程隊改裝的高溫噴火器，能持續噴射烈焰焚毀白髓細胞防止復活。",
		ItemData.ItemCategory.WEAPON, false, 1, 0.0, false, "", "", Color(1.0, 0.42, 0.12)
	)
	item_catalog["weapon_hunting_crossbow"] = ItemData.create(
		"weapon_hunting_crossbow", "雪山精鋼連弩",
		"靜音、低後座力的精密連弩，射擊幾乎無噪音且具備極高的準星暴擊倍率。",
		ItemData.ItemCategory.WEAPON, false, 1, 0.0, false, "", "", Color(0.32, 0.88, 0.52)
	)
	item_catalog["weapon_mp5_smg"] = ItemData.create(
		"weapon_mp5_smg", "MP-91 特種衝鋒槍",
		"1991 年療養院警備隊制式 9mm 衝鋒槍，與手槍共用 9mm 彈藥，具備極高連射壓制力。",
		ItemData.ItemCategory.WEAPON, false, 1, 0.0, false, "", "", Color(0.30, 0.72, 0.98)
	)
	item_catalog["weapon_sanatorium_rifle"] = ItemData.create(
		"weapon_sanatorium_rifle", "瑞士毛瑟栓動步槍",
		"極遠射程與高穿甲威力的阿爾卑斯栓動步槍，適合在遠距離精準狙殺畸變體。",
		ItemData.ItemCategory.WEAPON, false, 1, 0.0, false, "", "", Color(0.88, 0.42, 0.85)
	)

	# Ammo Types
	item_catalog["ammo_9mm"] = ItemData.create("ammo_9mm", "9mm 手槍／衝鋒槍彈藥", "適用於 VP-9 手槍與 MP-91 衝鋒槍。", ItemData.ItemCategory.AMMO, true, 90)
	item_catalog["ammo_12gauge"] = ItemData.create("ammo_12gauge", "12號霰彈槍彈藥", "適用於阿爾卑斯雙管霰彈槍。", ItemData.ItemCategory.AMMO, true, 24)
	item_catalog["ammo_44magnum"] = ItemData.create("ammo_44magnum", ".44 馬格南高爆彈", "適用於白鴉 .44 馬格南左輪的珍貴大口徑子彈。", ItemData.ItemCategory.AMMO, true, 18)
	item_catalog["ammo_fuel_tank"] = ItemData.create("ammo_fuel_tank", "高壓濃縮燃料罐", "適用於地熱火焰噴射器的燃料補給。", ItemData.ItemCategory.AMMO, true, 100)
	item_catalog["ammo_bolts"] = ItemData.create("ammo_bolts", "精鋼弩箭組", "適用於雪山精鋼連弩。", ItemData.ItemCategory.AMMO, true, 36)
	item_catalog["ammo_rifle"] = ItemData.create("ammo_rifle", "7.5mm 瑞士步槍彈", "適用於瑞士毛瑟栓動步槍。", ItemData.ItemCategory.AMMO, true, 25)

	# 6 Rare Collectibles (Eiswald Treasures)
	item_catalog["collectible_snow_globe"] = ItemData.create(
		"collectible_snow_globe", "【珍藏 1/6】白鴉雪花水晶球",
		"精緻的玻璃雪花球，裡面微縮了 1991 年雪夜中的霧嶺療養院全景。",
		ItemData.ItemCategory.KEY_ITEM, false, 1, 0.0, false, "", "", Color(0.75, 0.92, 1.0)
	)
	item_catalog["collectible_golden_crow_crest"] = ItemData.create(
		"collectible_golden_crow_crest", "【珍藏 2/6】純金雙鴉徽章",
		"艾斯瓦爾德創辦人家族的純金胸針，背面刻有『白鴉降臨之冬』字樣。",
		ItemData.ItemCategory.KEY_ITEM, false, 1, 0.0, false, "", "", Color(0.98, 0.80, 0.25)
	)
	item_catalog["collectible_carousel_horse_figurine"] = ItemData.create(
		"collectible_carousel_horse_figurine", "【珍藏 3/6】雕花木馬微縮像",
		"童話中央廣場旋轉木馬的手工彩繪限量紀念品，漆面依然完好如新。",
		ItemData.ItemCategory.KEY_ITEM, false, 1, 0.0, false, "", "", Color(0.95, 0.55, 0.48)
	)
	item_catalog["collectible_cassette_1991"] = ItemData.create(
		"collectible_cassette_1991", "【珍藏 4/6】1991 療養院機密錄音帶",
		"貼著紅色標籤的卡式錄音帶，記錄了封園當晚地下實驗室的最後通話。",
		ItemData.ItemCategory.KEY_ITEM, false, 1, 0.0, false, "", "", Color(0.85, 0.28, 0.28)
	)
	item_catalog["collectible_porcelain_mask"] = ItemData.create(
		"collectible_porcelain_mask", "【珍藏 5/6】白鴉歌劇陶瓷面具",
		"鬧鬼山丘古堡劇場留下的精緻白瓷鳥喙面具，散發淡淡薰香。",
		ItemData.ItemCategory.KEY_ITEM, false, 1, 0.0, false, "", "", Color(0.95, 0.94, 0.90)
	)
	item_catalog["collectible_abyssal_pearl"] = ItemData.create(
		"collectible_abyssal_pearl", "【珍藏 6/6】深海發光珍珠匣",
		"海洋王國深海展示館的鎮館秘寶，珍珠在黑暗中仍散發幽藍微光。",
		ItemData.ItemCategory.KEY_ITEM, false, 1, 0.0, false, "", "", Color(0.32, 0.88, 0.95)
	)

	# Medical Supplies (First-Aid Spray, Antidote, Herbs)
	item_catalog["first_aid_spray"] = ItemData.create(
		"first_aid_spray", "急救噴霧 (First-Aid Spray)",
		"經典高壓醫療急救噴霧，使用後立即恢復 100 點完整生命值。",
		ItemData.ItemCategory.CONSUMABLE, true, 3, 100.0, false, "", "", Color(0.25, 0.88, 0.48)
	)
	item_catalog["ichor_antidote"] = ItemData.create(
		"ichor_antidote", "白髓解毒血清 (Antidote)",
		"中和體內的『白髓劇毒 (ICHOR_INFECTED)』並小幅恢復 25 點生命值。",
		ItemData.ItemCategory.CONSUMABLE, true, 5, 25.0, true, "", "", Color(0.72, 0.42, 0.95)
	)
	item_catalog["herb_alpine"] = ItemData.create(
		"herb_alpine", "高山雪絨藥草",
		"恢復 35 點生命值，可與無菌紗布或解毒血清組合。",
		ItemData.ItemCategory.CONSUMABLE, true, 5, 35.0, false, "", "", Color(0.32, 0.78, 0.45)
	)
	item_catalog["gauze_antiseptic"] = ItemData.create(
		"gauze_antiseptic", "無菌止血紗布",
		"可與高山雪絨藥草合成『複合急救包』。",
		ItemData.ItemCategory.COMBINABLE, true, 5
	)
	item_catalog["medkit_compound"] = ItemData.create(
		"medkit_compound", "聖裘德複合急救包",
		"恢復 85 點生命值並徹底清除白髓感染。",
		ItemData.ItemCategory.CONSUMABLE, true, 3, 85.0, true
	)

	# Metroidvania Progression Tools & Keys
	item_catalog["tool_crowbar"] = ItemData.create(
		"tool_crowbar", "精鋼撬棍 (Crowbar)",
		"建築師亞瑟交給你的堅固鋼製撬棍，能撬開『雪絨花童話村』被木板封死的『毒蠅傘蘑菇屋』大門。",
		ItemData.ItemCategory.KEY_ITEM, false, 1, 0.0, false, "", "", Color(0.82, 0.28, 0.25)
	)
	item_catalog["brass_pocket_watch"] = ItemData.create(
		"brass_pocket_watch", "停擺的銅製懷錶",
		"在童話村『毒蠅傘蘑菇屋』抽屜找到的精緻懷錶。背面似乎有刻字（在手提箱點擊【🔍 3D 翻轉檢視背面】查看）。",
		ItemData.ItemCategory.KEY_ITEM, false, 1, 0.0, false,
		"pocket_watch_secret_revealed",
		"【3D 檢視發現】你將銅製懷錶翻轉至背面，撥開暗扣後發現內蓋刻著：\n『童話破曉之時 —— 04 : 15』，並取出了嵌在機芯裡的【黃銅發條齒輪】！",
		Color(0.88, 0.68, 0.24)
	)
	item_catalog["key_bronze_wing"] = ItemData.create(
		"key_bronze_wing", "銅翼雙鴉鑰匙",
		"從童話村蘑菇屋老爺鐘取得的黃銅鑰匙，可解鎖中央廣場西側通往第二分區『霧嶺鬧鬼山丘 (Haunted Hilltop)』的哥德鐵門。",
		ItemData.ItemCategory.KEY_ITEM, false, 1, 0.0, false, "", "", Color(0.92, 0.58, 0.22)
	)
	item_catalog["key_silver_seahorse"] = ItemData.create(
		"key_silver_seahorse", "銀冠海馬鑰匙",
		"從『鬧鬼山丘』古堡星座鋼琴暗格取得的純銀鑰匙，柄部雕有深海皇冠海馬。可解鎖中央廣場東側通往第三分區『冰川海洋王國 (Ocean Kingdom)』的大門。",
		ItemData.ItemCategory.KEY_ITEM, false, 1, 0.0, false, "", "", Color(0.65, 0.88, 0.98)
	)
	item_catalog["acid_vial"] = ItemData.create(
		"acid_vial", "高濃度強酸液瓶 (Acid Vial)",
		"從『海洋王國』水下展示廳取得的強腐蝕性酸液瓶，可溶解中央廣場北側通往第四分區『地下挖掘場與秘密設施 (The Roots)』的重型鏽蝕鐵鍊！",
		ItemData.ItemCategory.KEY_ITEM, false, 1, 0.0, false, "", "", Color(0.65, 0.98, 0.22)
	)

func _init_starter_loadout() -> void:
	slots.clear()
	add_item("weapon_vp9_pistol", 1)
	add_item("ammo_9mm", 24)
	add_item("first_aid_spray", 1)
	add_item("ichor_antidote", 1)

func add_item(item_id: String, quantity: int = 1) -> bool:
	if not item_catalog.has(item_id):
		return false
	var def: ItemData = item_catalog[item_id]
	if def.stackable:
		for slot in slots:
			if slot["id"] == item_id and slot["qty"] < def.max_stack:
				slot["qty"] = mini(def.max_stack, int(slot["qty"]) + quantity)
				inventory_updated.emit()
				return true

	if slots.size() >= max_slots:
		return false

	slots.append({"id": item_id, "qty": quantity})
	if item_id.begins_with("collectible_") and not collected_treasures.has(item_id):
		collected_treasures.append(item_id)
	inventory_updated.emit()
	return true

func has_item(item_id: String, min_qty: int = 1) -> bool:
	return get_item_count(item_id) >= min_qty

func get_item_count(item_id: String) -> int:
	var total: int = 0
	for slot in slots:
		if slot["id"] == item_id:
			total += int(slot["qty"])
	return total

func consume_item(item_id: String, quantity: int = 1) -> bool:
	if not has_item(item_id, quantity):
		return false
	var remaining: int = quantity
	for i in range(slots.size() - 1, -1, -1):
		if slots[i]["id"] == item_id:
			var take: int = mini(remaining, int(slots[i]["qty"]))
			slots[i]["qty"] -= take
			remaining -= take
			if slots[i]["qty"] <= 0:
				slots.remove_at(i)
			if remaining <= 0:
				break
	inventory_updated.emit()
	return true

func use_slot(slot_index: int) -> String:
	if slot_index < 0 or slot_index >= slots.size():
		return ""
	var entry: Dictionary = slots[slot_index]
	var item_id: String = entry["id"]
	var def: ItemData = item_catalog.get(item_id)
	if def == null:
		return ""

	match def.category:
		ItemData.ItemCategory.WEAPON:
			equipped_weapon_id = item_id
			AudioManager.play_synth_sfx("ui_click")
			weapon_equipped.emit(equipped_weapon_id)
			inventory_updated.emit()
			return "已裝備武器：【%s】" % def.display_name
		ItemData.ItemCategory.CONSUMABLE:
			if GameManager.player_hp >= GameManager.player_max_hp and not def.cures_ichor:
				return "目前生命值已滿，無需使用【%s】。" % def.display_name
			GameManager.heal_player(def.heal_amount, def.cures_ichor)
			consume_item(item_id, 1)
			AudioManager.play_synth_sfx("item_pickup")
			return "已使用【%s】，生命體徵與狀態已恢復。" % def.display_name
		ItemData.ItemCategory.KEY_ITEM:
			if not def.inspect_secret_flag.is_empty():
				return trigger_3d_inspect_secret(item_id)
			return "這是關鍵道具【%s】，靠近對應的封鎖門或鎖頭按 [F] 即可自動使用。" % def.display_name
		_:
			return "【%s】可與其他醫療或化學道具組合使用。" % def.display_name

func combine_slots(slot_a: int, slot_b: int) -> String:
	if slot_a == slot_b or slot_a < 0 or slot_b < 0 or slot_a >= slots.size() or slot_b >= slots.size():
		return ""
	var id_a: String = slots[slot_a]["id"]
	var id_b: String = slots[slot_b]["id"]
	var key_1: String = "%s+%s" % [id_a, id_b]
	var key_2: String = "%s+%s" % [id_b, id_a]

	var recipe: Dictionary = combination_recipes.get(key_1, combination_recipes.get(key_2, {}))
	if recipe.is_empty():
		AudioManager.play_synth_sfx("door_locked")
		return "這兩樣物品無法組合在一起。"

	var result_id: String = recipe["result"]
	var result_qty: int = int(recipe["qty"])
	consume_item(id_a, 1)
	consume_item(id_b, 1)
	add_item(result_id, result_qty)
	AudioManager.play_synth_sfx("puzzle_solved")
	item_combined.emit(id_a, id_b, result_id)
	var res_def: ItemData = item_catalog[result_id]
	return "組合成功！獲得了【%s】。" % res_def.display_name

func trigger_3d_inspect_secret(item_id: String) -> String:
	if not item_catalog.has(item_id):
		return ""
	var def: ItemData = item_catalog[item_id]
	if def.inspect_secret_flag.is_empty():
		return "仔細翻轉檢視了【%s】，外觀沒有其他隱藏機關。" % def.display_name

	GameManager.set_flag(def.inspect_secret_flag, true)
	AudioManager.play_synth_sfx("puzzle_solved")
	secret_clue_discovered.emit(item_id, def.inspect_secret_text)
	return def.inspect_secret_text

func reload_equipped_weapon() -> bool:
	if not weapon_states.has(equipped_weapon_id):
		return false
	var st: Dictionary = weapon_states[equipped_weapon_id]
	var current_clip: int = int(st["clip"])
	var max_clip: int = int(st["max_clip"])
	if current_clip >= max_clip:
		return false
	var ammo_id: String = st["ammo_item_id"]
	var available: int = get_item_count(ammo_id)
	if available <= 0:
		return false
	var needed: int = mini(max_clip - current_clip, available)
	if consume_item(ammo_id, needed):
		st["clip"] = current_clip + needed
		AudioManager.play_synth_sfx("ui_click")
		inventory_updated.emit()
		return true
	return false

func cycle_next_weapon() -> String:
	var owned_weapons: Array[String] = []
	for slot in slots:
		var wid: String = String(slot["id"])
		if weapon_states.has(wid):
			owned_weapons.append(wid)
	if owned_weapons.size() <= 1:
		return ""
	var idx: int = owned_weapons.find(equipped_weapon_id)
	var next_idx: int = (idx + 1) % owned_weapons.size()
	equipped_weapon_id = owned_weapons[next_idx]
	AudioManager.play_synth_sfx("ui_click")
	weapon_equipped.emit(equipped_weapon_id)
	inventory_updated.emit()
	return String(weapon_states[equipped_weapon_id]["name"])

func serialize_inventory() -> Dictionary:
	return {
		"equipped": equipped_weapon_id,
		"slots": slots.duplicate(true),
		"storage": storage_box.duplicate(true),
		"weapons": weapon_states.duplicate(true)
	}

func deserialize_inventory(data: Dictionary) -> void:
	equipped_weapon_id = String(data.get("equipped", "weapon_vp9_pistol"))
	slots.clear()
	for s in data.get("slots", []):
		slots.append({"id": String(s["id"]), "qty": int(s["qty"])})
	inventory_updated.emit()
