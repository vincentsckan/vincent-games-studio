class_name ItemData
extends Resource
## ItemData.gd
## Data structure for Weapons, Ammo, Consumables, Key Items, and 3D Inspectable Clues.

enum ItemCategory {
	WEAPON = 0,
	AMMO = 1,
	CONSUMABLE = 2,
	KEY_ITEM = 3,
	COMBINABLE = 4
}

@export var item_id: String = ""
@export var display_name: String = ""
@export_multiline var description: String = ""
@export var category: ItemCategory = ItemCategory.KEY_ITEM
@export var stackable: bool = false
@export var max_stack: int = 1
@export var heal_amount: float = 0.0
@export var cures_ichor: bool = false
@export var inspect_secret_flag: String = ""
@export_multiline var inspect_secret_text: String = ""
@export var accent_color: Color = Color(0.75, 0.68, 0.52)

static func create(
	p_id: String,
	p_name: String,
	p_desc: String,
	p_cat: ItemCategory,
	p_stackable: bool = false,
	p_max_stack: int = 1,
	p_heal: float = 0.0,
	p_cures: bool = false,
	p_secret_flag: String = "",
	p_secret_text: String = "",
	p_color: Color = Color(0.75, 0.68, 0.52)
) -> ItemData:
	var item := ItemData.new()
	item.item_id = p_id
	item.display_name = p_name
	item.description = p_desc
	item.category = p_cat
	item.stackable = p_stackable
	item.max_stack = p_max_stack
	item.heal_amount = p_heal
	item.cures_ichor = p_cures
	item.inspect_secret_flag = p_secret_flag
	item.inspect_secret_text = p_secret_text
	item.accent_color = p_color
	return item
