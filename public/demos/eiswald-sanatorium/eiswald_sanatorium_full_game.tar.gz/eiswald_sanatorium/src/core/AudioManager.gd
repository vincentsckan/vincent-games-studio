extends Node
## AudioManager.gd
## Commercial Indie-AAA Procedural Spatial Sound Synthesizer, Ambient Blizzard/Sanatorium Drone Generator,
## and Proximity Heartbeat Tension Mixer.

var _sfx_player: AudioStreamPlayer
var _ambient_player: AudioStreamPlayer
var _heartbeat_player: AudioStreamPlayer
var _sample_rate: float = 22050.0
var _heartbeat_timer: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_sfx_player = AudioStreamPlayer.new()
	_sfx_player.bus = "Master"
	add_child(_sfx_player)

	_ambient_player = AudioStreamPlayer.new()
	_ambient_player.bus = "Master"
	_ambient_player.volume_db = -16.5
	add_child(_ambient_player)

	_heartbeat_player = AudioStreamPlayer.new()
	_heartbeat_player.bus = "Master"
	_heartbeat_player.volume_db = -10.0
	add_child(_heartbeat_player)

	_start_procedural_ambient_drone()

func _process(delta: float) -> void:
	if get_tree().paused or GameManager.current_mode == GameManager.GameMode.EXPLORATION_ONLY:
		return

	var player: Node3D = get_tree().get_first_node_in_group("player") as Node3D
	if player == null:
		return

	var nearest_dist: float = 999.0
	for e in get_tree().get_nodes_in_group("enemies"):
		if e is Node3D and not bool(e.get("is_dead")):
			var d: float = player.global_position.distance_to(e.global_position)
			if d < nearest_dist:
				nearest_dist = d

	if nearest_dist <= 7.5:
		var interval: float = clampf(nearest_dist / 7.5, 0.38, 1.1)
		_heartbeat_timer -= delta
		if _heartbeat_timer <= 0.0:
			_heartbeat_timer = interval
			_play_heartbeat_thump()

func _start_procedural_ambient_drone() -> void:
	var gen := AudioStreamWAV.new()
	gen.format = AudioStreamWAV.FORMAT_16_BITS
	gen.mix_rate = int(_sample_rate)
	gen.stereo = false
	var dur: float = 4.0
	var samples: int = int(_sample_rate * dur)
	gen.loop_mode = AudioStreamWAV.LOOP_FORWARD
	gen.loop_begin = 0
	gen.loop_end = samples - 1

	var bytes := PackedByteArray()
	bytes.resize(samples * 2)
	for i in range(samples):
		var t: float = float(i) / _sample_rate
		# Minor chord atmospheric drone (A1 + C2 + E2 + subtle blizzard wind hiss)
		var drone: float = (
			sin(TAU * 55.0 * t) * 0.35 +
			sin(TAU * 65.41 * t) * 0.25 +
			sin(TAU * 82.41 * t) * 0.20 +
			randf_range(-0.12, 0.12)
		)
		var pcm16: int = clampi(int(drone * 12000.0), -32768, 32767)
		bytes.encode_s16(i * 2, pcm16)

	gen.data = bytes
	_ambient_player.stream = gen
	_ambient_player.play()

func _play_heartbeat_thump() -> void:
	var gen := AudioStreamWAV.new()
	gen.format = AudioStreamWAV.FORMAT_16_BITS
	gen.mix_rate = int(_sample_rate)
	var dur: float = 0.22
	var total: int = int(_sample_rate * dur)
	var bytes := PackedByteArray()
	bytes.resize(total * 2)
	for i in range(total):
		var t: float = float(i) / _sample_rate
		var env: float = clampf(1.0 - (t / dur), 0.0, 1.0)
		var thump: float = sin(TAU * 52.0 * t) * pow(env, 2.0) * 0.65
		bytes.encode_s16(i * 2, clampi(int(thump * 32760.0), -32768, 32767))
	gen.data = bytes
	_heartbeat_player.stream = gen
	_heartbeat_player.play()

func play_synth_sfx(effect_name: String) -> void:
	var gen := AudioStreamWAV.new()
	gen.format = AudioStreamWAV.FORMAT_16_BITS
	gen.mix_rate = int(_sample_rate)
	gen.stereo = false

	var duration: float = 0.18
	match effect_name:
		"gunshot_pistol":
			duration = 0.24
		"gunshot_shotgun":
			duration = 0.38
		"laser_aim_on":
			duration = 0.08
		"ui_click", "camera_snap":
			duration = 0.06
		"item_pickup", "puzzle_solved":
			duration = 0.35
		"door_locked":
			duration = 0.20
		"tape_save":
			duration = 0.45

	var total_samples: int = int(_sample_rate * duration)
	var bytes := PackedByteArray()
	bytes.resize(total_samples * 2)

	for i in range(total_samples):
		var t: float = float(i) / _sample_rate
		var env: float = clampf(1.0 - (t / duration), 0.0, 1.0)
		var sample_val: float = 0.0

		match effect_name:
			"gunshot_pistol":
				var noise: float = randf_range(-1.0, 1.0) * pow(env, 2.2)
				var punch: float = sin(TAU * (160.0 - t * 420.0) * t) * pow(env, 1.8)
				sample_val = clampf((noise * 0.7 + punch * 0.6), -1.0, 1.0)
			"gunshot_shotgun":
				var noise2: float = randf_range(-1.0, 1.0) * pow(env, 1.6)
				var boom: float = sin(TAU * (95.0 - t * 180.0) * t) * pow(env, 1.4)
				sample_val = clampf((noise2 * 0.75 + boom * 0.75), -1.0, 1.0)
			"laser_aim_on":
				sample_val = sin(TAU * (880.0 + t * 2400.0) * t) * env * 0.35
			"camera_snap", "ui_click":
				sample_val = sin(TAU * 520.0 * t) * pow(env, 3.0) * 0.3
			"item_pickup":
				var freq: float = 523.25 if t < 0.14 else 659.25
				sample_val = sin(TAU * freq * t) * env * 0.4
			"puzzle_solved":
				var f2: float = 440.0 if t < 0.11 else (554.37 if t < 0.22 else 659.25)
				sample_val = sin(TAU * f2 * t) * env * 0.45
			"door_locked":
				sample_val = (sin(TAU * 130.0 * t) + randf_range(-0.3, 0.3)) * pow(env, 2.0) * 0.5
			"tape_save":
				sample_val = sin(TAU * (320.0 + sin(t * 45.0) * 80.0) * t) * env * 0.35
			_:
				sample_val = sin(TAU * 440.0 * t) * env * 0.25

		var pcm16: int = clampi(int(sample_val * 32760.0), -32768, 32767)
		bytes.encode_s16(i * 2, pcm16)

	gen.data = bytes
	_sfx_player.stream = gen
	_sfx_player.play()
