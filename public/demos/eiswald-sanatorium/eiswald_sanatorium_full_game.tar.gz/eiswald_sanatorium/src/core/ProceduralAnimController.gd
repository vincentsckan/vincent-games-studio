class_name ProceduralAnimController
extends Node
## ProceduralAnimController.gd
## Commercial Indie-AAA procedural animation driver for articulated 3D human and creature characters.
## Animates LeftLegPivot, RightLegPivot, LeftArmPivot, RightArmPivot, HeadPivot, and TorsoPivot
## for realistic human walking stride, counter-arm swing, two-handed tactical aiming stance,
## idle breathing, recoil kickback, and crippled-leg dragging.

@export var target_pivot: Node3D
@export var is_boss_entity: bool = false

var _time_accum: float = 0.0
var _base_y: float = 0.0
var _recoil_offset: float = 0.0

var _left_leg: Node3D
var _right_leg: Node3D
var _left_arm: Node3D
var _right_arm: Node3D
var _head_pivot: Node3D

func _ready() -> void:
	if target_pivot == null and get_parent() is Node3D:
		target_pivot = get_parent().get_node_or_null("VisualPivot")
		if target_pivot == null:
			target_pivot = get_parent().get_node_or_null("MeshPivot")
	if target_pivot:
		_base_y = target_pivot.position.y
		_cache_limb_pivots()
	_time_accum = randf() * 10.0

func _cache_limb_pivots() -> void:
	if target_pivot == null:
		return
	_left_leg = target_pivot.find_child("LeftLegPivot", true, false) as Node3D
	_right_leg = target_pivot.find_child("RightLegPivot", true, false) as Node3D
	_left_arm = target_pivot.find_child("LeftArmPivot", true, false) as Node3D
	_right_arm = target_pivot.find_child("RightArmPivot", true, false) as Node3D
	_head_pivot = target_pivot.find_child("HeadPivot", true, false) as Node3D

func trigger_recoil_kick(strength: float = 0.12) -> void:
	_recoil_offset = strength

func _process(delta: float) -> void:
	if target_pivot == null:
		return
	if _left_leg == null:
		_cache_limb_pivots()

	var parent_body := get_parent() as CharacterBody3D
	if parent_body == null:
		return
	if parent_body.get("is_dead") == true:
		return

	_time_accum += delta
	var horiz_vel := Vector2(parent_body.velocity.x, parent_body.velocity.z)
	var speed: float = horiz_vel.length()
	var is_aiming: bool = (parent_body.get("is_aiming") == true)

	if _recoil_offset > 0.001:
		_recoil_offset = move_toward(_recoil_offset, 0.0, delta * 0.85)

	if speed > 0.20:
		var freq: float = 10.5 if not is_boss_entity else 7.2
		var bob_amp: float = 0.038 if not is_boss_entity else 0.065
		var sway_amp_deg: float = 2.0 if not is_boss_entity else 3.8
		var stride_deg: float = 32.0 if not is_aiming else 18.0
		if parent_body.get("is_leg_crippled") == true:
			freq = 5.8
			sway_amp_deg = 8.0
			stride_deg = 16.0

		var phase: float = _time_accum * freq
		target_pivot.position.y = _base_y + abs(sin(phase)) * bob_amp
		target_pivot.rotation_degrees.z = sin(phase * 0.5) * sway_amp_deg
		target_pivot.rotation_degrees.x = -2.5 + _recoil_offset * 35.0

		if _left_leg:
			_left_leg.rotation_degrees.x = sin(phase) * stride_deg
		if _right_leg:
			_right_leg.rotation_degrees.x = -sin(phase) * stride_deg

		if is_aiming:
			_apply_aim_arm_pose(delta)
		else:
			if _left_arm:
				_left_arm.rotation_degrees.x = lerpf(_left_arm.rotation_degrees.x, -sin(phase) * 24.0, delta * 12.0)
				_left_arm.rotation_degrees.y = lerpf(_left_arm.rotation_degrees.y, 0.0, delta * 12.0)
			if _right_arm:
				_right_arm.rotation_degrees.x = lerpf(_right_arm.rotation_degrees.x, sin(phase) * 24.0, delta * 12.0)
				_right_arm.rotation_degrees.y = lerpf(_right_arm.rotation_degrees.y, 0.0, delta * 12.0)
	else:
		# Subtle idle breathing animation
		var breath_freq: float = 2.2 if not is_boss_entity else 3.2
		var breath_amp: float = 0.012 if not is_boss_entity else 0.03
		target_pivot.position.y = lerpf(target_pivot.position.y, _base_y + sin(_time_accum * breath_freq) * breath_amp, delta * 6.0)
		target_pivot.rotation_degrees.z = lerpf(target_pivot.rotation_degrees.z, 0.0, delta * 8.0)
		target_pivot.rotation_degrees.x = lerpf(target_pivot.rotation_degrees.x, _recoil_offset * 35.0, delta * 10.0)

		if _left_leg:
			_left_leg.rotation_degrees.x = lerpf(_left_leg.rotation_degrees.x, 0.0, delta * 10.0)
		if _right_leg:
			_right_leg.rotation_degrees.x = lerpf(_right_leg.rotation_degrees.x, 0.0, delta * 10.0)

		if is_aiming:
			_apply_aim_arm_pose(delta)
		else:
			if _left_arm:
				_left_arm.rotation_degrees.x = lerpf(_left_arm.rotation_degrees.x, sin(_time_accum * breath_freq) * 2.5, delta * 8.0)
				_left_arm.rotation_degrees.y = lerpf(_left_arm.rotation_degrees.y, 0.0, delta * 8.0)
			if _right_arm:
				_right_arm.rotation_degrees.x = lerpf(_right_arm.rotation_degrees.x, -sin(_time_accum * breath_freq) * 2.5, delta * 8.0)
				_right_arm.rotation_degrees.y = lerpf(_right_arm.rotation_degrees.y, 0.0, delta * 8.0)

func _apply_aim_arm_pose(delta: float) -> void:
	var recoil_deg: float = _recoil_offset * 95.0
	if _right_arm:
		_right_arm.rotation_degrees.x = lerpf(_right_arm.rotation_degrees.x, 74.0 - recoil_deg, delta * 16.0)
		_right_arm.rotation_degrees.y = lerpf(_right_arm.rotation_degrees.y, 10.0, delta * 16.0)
	if _left_arm:
		_left_arm.rotation_degrees.x = lerpf(_left_arm.rotation_degrees.x, 70.0 - recoil_deg * 0.8, delta * 16.0)
		_left_arm.rotation_degrees.y = lerpf(_left_arm.rotation_degrees.y, -24.0, delta * 16.0)
