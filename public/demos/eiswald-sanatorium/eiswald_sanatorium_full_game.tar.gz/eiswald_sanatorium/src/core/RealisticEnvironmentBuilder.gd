class_name RealisticEnvironmentBuilder
extends RefCounted
## RealisticEnvironmentBuilder.gd
## Replaces all primitive box/cylinder environment placeholders with high-detail, multi-part,
## architecturally & organically sculpted 3D environment models and realistic PBR shaders.

static var _mat_stone: Material
static var _mat_timber: Material
static var _mat_roof_red: Material
static var _mat_roof_slate: Material
static var _mat_wrought_iron: StandardMaterial3D
static var _mat_brass: StandardMaterial3D
static var _mat_stucco: StandardMaterial3D
static var _mat_warm_window: StandardMaterial3D
static var _mat_pine_needle: StandardMaterial3D
static var _mat_snow_cap: StandardMaterial3D

static func _ensure_materials() -> void:
	if _mat_stone != null:
		return

	var sh_stone := load("res://assets/shaders/realistic_alpine_stone.gdshader") as Shader
	if sh_stone:
		var sm := ShaderMaterial.new()
		sm.shader = sh_stone
		_mat_stone = sm
	else:
		var std := StandardMaterial3D.new()
		std.albedo_color = Color(0.22, 0.23, 0.27)
		_mat_stone = std

	var sh_wood := load("res://assets/shaders/realistic_aged_timber.gdshader") as Shader
	if sh_wood:
		var sm := ShaderMaterial.new()
		sm.shader = sh_wood
		_mat_timber = sm
	else:
		var std := StandardMaterial3D.new()
		std.albedo_color = Color(0.22, 0.14, 0.09)
		_mat_timber = std

	var sh_roof := load("res://assets/shaders/realistic_roof_tiles.gdshader") as Shader
	if sh_roof:
		var sm_red := ShaderMaterial.new()
		sm_red.shader = sh_roof
		_mat_roof_red = sm_red

		var sm_slate := ShaderMaterial.new()
		sm_slate.shader = sh_roof
		sm_slate.set_shader_parameter("tile_color_a", Color(0.18, 0.21, 0.27, 1.0))
		sm_slate.set_shader_parameter("tile_color_b", Color(0.11, 0.13, 0.18, 1.0))
		_mat_roof_slate = sm_slate
	else:
		_mat_roof_red = StandardMaterial3D.new()
		_mat_roof_slate = StandardMaterial3D.new()

	_mat_wrought_iron = StandardMaterial3D.new()
	_mat_wrought_iron.albedo_color = Color(0.12, 0.13, 0.15)
	_mat_wrought_iron.metallic = 0.85
	_mat_wrought_iron.roughness = 0.38

	_mat_brass = StandardMaterial3D.new()
	_mat_brass.albedo_color = Color(0.84, 0.67, 0.26)
	_mat_brass.metallic = 0.88
	_mat_brass.roughness = 0.24

	_mat_stucco = StandardMaterial3D.new()
	_mat_stucco.albedo_color = Color(0.76, 0.72, 0.64)
	_mat_stucco.roughness = 0.85

	_mat_warm_window = StandardMaterial3D.new()
	_mat_warm_window.albedo_color = Color(1.0, 0.78, 0.42)
	_mat_warm_window.emission_enabled = true
	_mat_warm_window.emission = Color(0.98, 0.68, 0.28)
	_mat_warm_window.emission_energy_multiplier = 1.35
	_mat_warm_window.roughness = 0.15

	_mat_pine_needle = StandardMaterial3D.new()
	_mat_pine_needle.albedo_color = Color(0.07, 0.18, 0.13)
	_mat_pine_needle.roughness = 0.82

	_mat_snow_cap = StandardMaterial3D.new()
	_mat_snow_cap.albedo_color = Color(0.28, 0.34, 0.43)
	_mat_snow_cap.roughness = 0.80


# ==============================================================================
# 1. REALISTIC 1980s EUROPEAN INVESTIGATOR SEDAN (MULTI-PART SCULPTED VEHICLE)
# ==============================================================================
static func build_realistic_sedan() -> Node3D:
	_ensure_materials()
	var root := Node3D.new()
	root.name = "RealisticInvestigatorSedan"

	var mat_paint := StandardMaterial3D.new()
	mat_paint.albedo_color = Color(0.09, 0.15, 0.24)
	mat_paint.metallic = 0.78
	mat_paint.roughness = 0.22

	var mat_glass := StandardMaterial3D.new()
	mat_glass.albedo_color = Color(0.12, 0.18, 0.25)
	mat_glass.metallic = 0.90
	mat_glass.roughness = 0.08

	var mat_tire := StandardMaterial3D.new()
	mat_tire.albedo_color = Color(0.07, 0.07, 0.08)
	mat_tire.roughness = 0.85

	var mat_chrome := StandardMaterial3D.new()
	mat_chrome.albedo_color = Color(0.82, 0.85, 0.88)
	mat_chrome.metallic = 0.95
	mat_chrome.roughness = 0.15

	var mat_headlight := StandardMaterial3D.new()
	mat_headlight.albedo_color = Color(1.0, 0.94, 0.76)
	mat_headlight.emission_enabled = true
	mat_headlight.emission = Color(1.0, 0.88, 0.62)
	mat_headlight.emission_energy_multiplier = 2.0

	var mat_taillight := StandardMaterial3D.new()
	mat_taillight.albedo_color = Color(0.92, 0.12, 0.14)
	mat_taillight.emission_enabled = true
	mat_taillight.emission = Color(0.88, 0.10, 0.12)
	mat_taillight.emission_energy_multiplier = 1.4

	# Lower aerodynamic body shell, sloped hood, and trunk deck
	_add_box(root, "MainBodyLower", Vector3(1.82, 0.52, 4.35), Vector3(0, 0.48, 0), Vector3.ZERO, mat_paint)
	_add_box(root, "SlopedHood", Vector3(1.74, 0.16, 1.35), Vector3(0, 0.74, -1.42), Vector3(5, 0, 0), mat_paint)
	_add_box(root, "TrunkDeck", Vector3(1.74, 0.14, 1.05), Vector3(0, 0.75, 1.55), Vector3(-3, 0, 0), mat_paint)

	# Greenhouse Cabin with Sloped Windshield, Rear Glass, A/B/C Pillars & Roof
	_add_box(root, "CabinRoof", Vector3(1.48, 0.08, 1.65), Vector3(0, 1.28, 0.12), Vector3.ZERO, mat_paint)
	_add_box(root, "Windshield", Vector3(1.46, 0.56, 0.08), Vector3(0, 1.02, -0.82), Vector3(-36, 0, 0), mat_glass)
	_add_box(root, "RearWindow", Vector3(1.44, 0.54, 0.08), Vector3(0, 1.02, 1.04), Vector3(38, 0, 0), mat_glass)
	_add_box(root, "SideWindowsBlock", Vector3(1.52, 0.44, 1.68), Vector3(0, 1.02, 0.12), Vector3.ZERO, mat_glass)

	# A, B, C Roof Pillars & Side Mirrors
	for side in [-1.0, 1.0]:
		_add_box(root, "APillar", Vector3(0.07, 0.58, 0.09), Vector3(side * 0.74, 1.02, -0.80), Vector3(-36, 0, side * 8.0), mat_paint)
		_add_box(root, "BPillar", Vector3(0.06, 0.48, 0.10), Vector3(side * 0.77, 1.02, 0.05), Vector3(0, 0, side * 7.0), _mat_wrought_iron)
		_add_box(root, "CPillar", Vector3(0.08, 0.56, 0.18), Vector3(side * 0.73, 1.02, 0.98), Vector3(38, 0, side * 8.0), mat_paint)
		_add_box(root, "SideMirror", Vector3(0.16, 0.10, 0.12), Vector3(side * 0.94, 0.84, -0.68), Vector3.ZERO, mat_paint)
		_add_box(root, "DoorHandleFront", Vector3(0.04, 0.04, 0.16), Vector3(side * 0.92, 0.72, -0.10), Vector3.ZERO, mat_chrome)
		_add_box(root, "DoorHandleRear", Vector3(0.04, 0.04, 0.16), Vector3(side * 0.92, 0.72, 0.62), Vector3.ZERO, mat_chrome)

	# Front & Rear Chrome Bumpers, Grille, Dual Round Headlights & Tail Lights
	_add_box(root, "FrontBumper", Vector3(1.88, 0.18, 0.22), Vector3(0, 0.34, -2.18), Vector3.ZERO, _mat_wrought_iron)
	_add_box(root, "RearBumper", Vector3(1.88, 0.18, 0.22), Vector3(0, 0.36, 2.18), Vector3.ZERO, _mat_wrought_iron)
	_add_box(root, "FrontGrille", Vector3(0.88, 0.22, 0.06), Vector3(0, 0.56, -2.18), Vector3.ZERO, mat_chrome)

	for side in [-1.0, 1.0]:
		_add_cyl(root, "OuterHeadlamp", 0.11, 0.11, 0.08, Vector3(side * 0.66, 0.58, -2.17), Vector3(90, 0, 0), mat_headlight)
		_add_cyl(root, "InnerHeadlamp", 0.09, 0.09, 0.08, Vector3(side * 0.44, 0.58, -2.17), Vector3(90, 0, 0), mat_headlight)
		_add_box(root, "TailLightCluster", Vector3(0.38, 0.16, 0.08), Vector3(side * 0.62, 0.60, 2.17), Vector3.ZERO, mat_taillight)

	# 4 Detailed Wheels (Rubber Tire + Chrome Rim + 5 Alloy Spokes)
	for wx in [-0.88, 0.88]:
		for wz in [-1.32, 1.32]:
			_add_cyl(root, "Tire", 0.34, 0.34, 0.24, Vector3(wx, 0.34, wz), Vector3(0, 0, 90), mat_tire)
			_add_cyl(root, "AlloyRim", 0.21, 0.21, 0.25, Vector3(wx, 0.34, wz), Vector3(0, 0, 90), mat_chrome)
			_add_cyl(root, "WheelHub", 0.08, 0.08, 0.27, Vector3(wx, 0.34, wz), Vector3(0, 0, 90), _mat_wrought_iron)

	return root


# ==============================================================================
# 2. GRAND WROUGHT-IRON & CUT-STONE SANATORIUM ENTRANCE GATES & PERIMETER
# ==============================================================================
static func build_grand_entrance_gates() -> Node3D:
	_ensure_materials()
	var root := Node3D.new()
	root.name = "GrandSanatoriumEntranceGates"

	# Left & Right Cut-Stone Plinth Walls + Wrought-Iron Fence Spears
	for side in [-1.0, 1.0]:
		var wall_cx: float = side * 7.8
		# Lower stone masonry base wall
		_add_box(root, "StoneWallBase", Vector3(9.2, 1.15, 0.65), Vector3(wall_cx, 0.58, 5.0), Vector3.ZERO, _mat_stone)
		_add_box(root, "StoneCopingLedge", Vector3(9.4, 0.16, 0.78), Vector3(wall_cx, 1.22, 5.0), Vector3.ZERO, _mat_snow_cap)
		# Horizontal wrought-iron rails
		_add_box(root, "IronRailBottom", Vector3(8.8, 0.07, 0.08), Vector3(wall_cx, 1.55, 5.0), Vector3.ZERO, _mat_wrought_iron)
		_add_box(root, "IronRailTop", Vector3(8.8, 0.07, 0.08), Vector3(wall_cx, 2.85, 5.0), Vector3.ZERO, _mat_wrought_iron)
		# 14 Wrought-iron vertical bars with brass spear finials
		for bi in range(14):
			var bx: float = wall_cx - 4.0 + float(bi) * 0.62
			_add_cyl(root, "IronFenceBar", 0.028, 0.028, 1.85, Vector3(bx, 2.18, 5.0), Vector3.ZERO, _mat_wrought_iron)
			_add_cyl(root, "SpearFinial", 0.004, 0.048, 0.18, Vector3(bx, 3.18, 5.0), Vector3.ZERO, _mat_brass)

		# Monumental Stone Gate Pier at X = +/- 3.1
		var pier_x: float = side * 3.1
		_add_box(root, "GatePierPlinth", Vector3(1.28, 0.65, 1.28), Vector3(pier_x, 0.32, 5.0), Vector3.ZERO, _mat_stone)
		_add_box(root, "GatePierShaft", Vector3(1.06, 3.4, 1.06), Vector3(pier_x, 2.32, 5.0), Vector3.ZERO, _mat_stone)
		_add_box(root, "GatePierCornice", Vector3(1.34, 0.28, 1.34), Vector3(pier_x, 4.12, 5.0), Vector3.ZERO, _mat_stone)
		_add_cyl(root, "GatePierCap", 0.08, 0.75, 0.55, Vector3(pier_x, 4.52, 5.0), Vector3.ZERO, _mat_roof_slate)
		# Warm Carriage Lantern mounted on front of each Gate Pier
		_add_box(root, "PierLanternBracket", Vector3(0.10, 0.10, 0.36), Vector3(pier_x, 2.85, 5.65), Vector3.ZERO, _mat_wrought_iron)
		_add_cyl(root, "PierLanternGlass", 0.16, 0.12, 0.38, Vector3(pier_x, 3.10, 5.78), Vector3.ZERO, _mat_warm_window)
		_add_cyl(root, "PierLanternRoof", 0.02, 0.22, 0.18, Vector3(pier_x, 3.38, 5.78), Vector3.ZERO, _mat_wrought_iron)

	# Ornate Wrought-Iron Overhead Archway spanning between the two Gate Piers
	_add_box(root, "OverheadIronArchLower", Vector3(6.2, 0.14, 0.18), Vector3(0, 4.05, 5.0), Vector3.ZERO, _mat_wrought_iron)
	_add_box(root, "OverheadIronArchUpper", Vector3(5.6, 0.14, 0.18), Vector3(0, 4.58, 5.0), Vector3.ZERO, _mat_wrought_iron)
	_add_box(root, "CrestSignboard", Vector3(2.8, 0.46, 0.12), Vector3(0, 4.32, 5.0), Vector3.ZERO, _mat_brass)
	for ai in range(9):
		var ax: float = -2.4 + float(ai) * 0.60
		_add_cyl(root, "ArchScrollBar", 0.024, 0.024, 0.52, Vector3(ax, 4.31, 5.0), Vector3.ZERO, _mat_brass)

	return root


# ==============================================================================
# 3. HALF-TIMBERED ALPINE GUARDHOUSE & FAIRYTALE CHALET ARCHITECTURE
# ==============================================================================
static func build_alpine_chalet(width: float, height: float, depth: float, is_red_roof: bool = true) -> Node3D:
	_ensure_materials()
	var root := Node3D.new()
	root.name = "AlpineHalfTimberChalet"

	# 1. Cut-Stone Foundation Plinth
	_add_box(root, "StonePlinth", Vector3(width + 0.24, 0.75, depth + 0.24), Vector3(0, 0.375, 0), Vector3.ZERO, _mat_stone)

	# 2. Half-Timbered Stucco Upper Walls
	var wall_h: float = height - 0.75
	_add_box(root, "StuccoCore", Vector3(width, wall_h, depth), Vector3(0, 0.75 + wall_h * 0.5, 0), Vector3.ZERO, _mat_stucco)

	# 3. Exposed Dark Oak Timber Framing (Corner Posts, Horizontal Beams & Cross-Braces)
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			_add_box(root, "CornerPost", Vector3(0.18, wall_h + 0.05, 0.18), Vector3(sx * width * 0.5, 0.75 + wall_h * 0.5, sz * depth * 0.5), Vector3.ZERO, _mat_timber)
		_add_box(root, "FrontBackBeamMid", Vector3(width + 0.12, 0.16, 0.14), Vector3(0, 0.75 + wall_h * 0.52, sx * depth * 0.5), Vector3.ZERO, _mat_timber)
		_add_box(root, "FrontBackBeamTop", Vector3(width + 0.16, 0.18, 0.16), Vector3(0, 0.75 + wall_h, sx * depth * 0.5), Vector3.ZERO, _mat_timber)
		_add_box(root, "SideBeamMid", Vector3(0.14, 0.16, depth + 0.12), Vector3(sx * width * 0.5, 0.75 + wall_h * 0.52, 0), Vector3.ZERO, _mat_timber)

	# 4. Recessed Mullioned Windows with Warm Interior Glow & Wooden Shutters
	for side_z in [-1.0, 1.0]:
		var wz: float = side_z * (depth * 0.5 + 0.02)
		var wy: float = 0.75 + wall_h * 0.55
		_add_box(root, "WindowFrame", Vector3(0.92, 1.12, 0.10), Vector3(0, wy, wz), Vector3.ZERO, _mat_timber)
		_add_box(root, "WindowGlassWarm", Vector3(0.76, 0.96, 0.12), Vector3(0, wy, wz), Vector3.ZERO, _mat_warm_window)
		_add_box(root, "WindowMullionV", Vector3(0.05, 0.98, 0.14), Vector3(0, wy, wz), Vector3.ZERO, _mat_timber)
		_add_box(root, "WindowMullionH", Vector3(0.78, 0.05, 0.14), Vector3(0, wy, wz), Vector3.ZERO, _mat_timber)
		for sh_side in [-1.0, 1.0]:
			_add_box(root, "WoodenShutter", Vector3(0.34, 1.08, 0.08), Vector3(sh_side * 0.66, wy, wz), Vector3.ZERO, _mat_timber)

	# 5. Pitched Overhanging Alpine Gable Roof with Overlapping Roof Tiles & Chimney
	var roof_mat: Material = _mat_roof_red if is_red_roof else _mat_roof_slate
	var slope_w: float = width * 0.68
	for side_x in [-1.0, 1.0]:
		_add_box(
			root, "PitchedRoofSlope",
			Vector3(slope_w, 0.18, depth + 0.75),
			Vector3(side_x * (width * 0.27), height + 0.58, 0),
			Vector3(0, 0, side_x * -32.0),
			roof_mat
		)
	# Gable triangle fill & ridge beam
	_add_box(root, "RoofRidgeBeam", Vector3(0.24, 0.24, depth + 0.85), Vector3(0, height + 1.15, 0), Vector3.ZERO, _mat_timber)
	_add_box(root, "StoneChimney", Vector3(0.68, 1.85, 0.68), Vector3(width * 0.28, height + 0.85, -depth * 0.25), Vector3.ZERO, _mat_stone)

	return root


# ==============================================================================
# 4. GRAND FAIRYTALE CAROUSEL (12-RIBBED CANOPY + 6 SCULPTED PRANCING HORSES)
# ==============================================================================
static func build_grand_carousel() -> Node3D:
	_ensure_materials()
	var root := Node3D.new()
	root.name = "GrandFairytaleCarousel"

	# 1. Two-Tiered Octagonal Platform with Brass Rim & Wooden Deck
	_add_cyl(root, "CarouselStepOuter", 3.45, 3.55, 0.22, Vector3(0, 0.11, 0), Vector3.ZERO, _mat_stone)
	_add_cyl(root, "CarouselDeck", 3.10, 3.18, 0.28, Vector3(0, 0.34, 0), Vector3.ZERO, _mat_timber)
	_add_cyl(root, "CarouselBrassRim", 3.15, 3.15, 0.08, Vector3(0, 0.46, 0), Vector3.ZERO, _mat_brass)

	# 2. Central Carved Column with Warm Festival Bulbs
	_add_cyl(root, "CentralColumnBase", 0.68, 0.78, 0.65, Vector3(0, 0.75, 0), Vector3.ZERO, _mat_brass)
	_add_cyl(root, "CentralColumnShaft", 0.46, 0.52, 2.65, Vector3(0, 2.15, 0), Vector3.ZERO, _mat_stucco)
	for ring_y in [1.35, 2.15, 2.95]:
		_add_cyl(root, "GoldBand", 0.54, 0.54, 0.12, Vector3(0, ring_y, 0), Vector3.ZERO, _mat_brass)

	# 3. Scalloped Pavilion Canopy Roof & Spire Finial
	_add_cyl(root, "CanopyValance", 3.32, 3.25, 0.36, Vector3(0, 3.45, 0), Vector3.ZERO, _mat_brass)
	_add_cyl(root, "CanopyCone", 0.18, 3.35, 1.65, Vector3(0, 4.42, 0), Vector3.ZERO, _mat_roof_red)
	_add_cyl(root, "CrownSpire", 0.03, 0.14, 0.75, Vector3(0, 5.55, 0), Vector3.ZERO, _mat_brass)

	# 4. 6 Brass Poles & 6 Sculpted 3D Prancing Carousel Horses + Warm Carnival Lights
	var mat_horse_white := StandardMaterial3D.new()
	mat_horse_white.albedo_color = Color(0.92, 0.90, 0.86)
	mat_horse_white.roughness = 0.32

	for i in range(6):
		var ang: float = float(i) * TAU / 6.0
		var px: float = sin(ang) * 2.15
		var pz: float = cos(ang) * 2.15
		var gallop_y: float = 1.25 + (0.28 if (i % 2 == 0) else 0.0)

		_add_cyl(root, "BrassPole", 0.045, 0.045, 3.05, Vector3(px, 1.95, pz), Vector3.ZERO, _mat_brass)
		_add_sphere(root, "CarnivalBulb", 0.09, Vector3(sin(ang) * 2.95, 3.28, cos(ang) * 2.95), _mat_warm_window)

		# Sculpted Carousel Horse at (px, gallop_y, pz) facing tangent direction
		var horse := Node3D.new()
		horse.position = Vector3(px, gallop_y, pz)
		horse.rotation.y = ang + PI * 0.5
		root.add_child(horse)

		_add_capsule(horse, "HorseBarrel", 0.18, 0.68, Vector3(0, 0, 0), Vector3(90, 0, 0), mat_horse_white)
		_add_capsule(horse, "HorseSaddle", 0.195, 0.28, Vector3(0, 0.05, 0), Vector3(90, 0, 0), _mat_roof_red)
		_add_capsule(horse, "HorseNeck", 0.11, 0.42, Vector3(0, 0.22, -0.26), Vector3(-32, 0, 0), mat_horse_white)
		_add_capsule(horse, "HorseHead", 0.09, 0.30, Vector3(0, 0.36, -0.40), Vector3(55, 0, 0), mat_horse_white)
		_add_capsule(horse, "HorseTail", 0.06, 0.38, Vector3(0, -0.05, 0.38), Vector3(38, 0, 0), _mat_brass)
		for lx in [-0.10, 0.10]:
			_add_capsule(horse, "FrontLeg", 0.045, 0.38, Vector3(lx, -0.18, -0.24), Vector3(-28, 0, 0), mat_horse_white)
			_add_capsule(horse, "HindLeg", 0.050, 0.40, Vector3(lx, -0.20, 0.24), Vector3(26, 0, 0), mat_horse_white)

	return root


# ==============================================================================
# 5. ORGANIC TOADSTOOL MUSHROOM COTTAGE (AMANITA MUSCARIA FAIRYTALE HOUSE)
# ==============================================================================
static func build_toadstool_cottage() -> Node3D:
	_ensure_materials()
	var root := Node3D.new()
	root.name = "SculptedToadstoolCottage"

	# 1. Stone Cobble Foundation Ring & Curved Organic Stucco Stalk Wall
	_add_cyl(root, "StoneFoundation", 2.35, 2.55, 0.55, Vector3(0, 0.27, 0), Vector3.ZERO, _mat_stone)
	_add_cyl(root, "MushroomStalkLower", 1.95, 2.25, 1.55, Vector3(0, 1.25, 0), Vector3.ZERO, _mat_stucco)
	_add_cyl(root, "MushroomStalkUpper", 2.15, 1.95, 1.45, Vector3(0, 2.65, 0), Vector3.ZERO, _mat_stucco)

	# 2. Under-Cap Radiating Mushroom Gill Skirt
	_add_cyl(root, "MushroomGillUnderside", 3.45, 2.10, 0.45, Vector3(0, 3.42, 0), Vector3.ZERO, _mat_timber)

	# 3. Massive Dome Cap with Raised White/Cream Amanita Dots & Chimney
	var mat_cap_red := StandardMaterial3D.new()
	mat_cap_red.albedo_color = Color(0.74, 0.13, 0.15)
	mat_cap_red.roughness = 0.48

	var cap_mi := _add_sphere(root, "MushroomRedDome", 3.55, Vector3(0, 3.75, 0), mat_cap_red)
	cap_mi.scale = Vector3(1.0, 0.52, 1.0)

	# 16 Raised Cream Spots across the Mushroom Cap
	for i in range(16):
		var ring_r: float = 1.35 if i < 6 else 2.55
		var ring_y: float = 4.95 if i < 6 else 4.25
		var ang: float = float(i) * 1.15
		var spot := _add_sphere(root, "AmanitaSpot", 0.34, Vector3(sin(ang) * ring_r, ring_y, cos(ang) * ring_r), _mat_stucco)
		spot.scale = Vector3(1.0, 0.38, 1.0)

	# Hobbit-Style Round Windows, Arched Timber Doorframe & Crooked Stone Chimney
	for side_x in [-1.0, 1.0]:
		_add_cyl(root, "RoundWindowFrame", 0.52, 0.52, 0.18, Vector3(side_x * 1.65, 1.85, -1.15), Vector3(90, side_x * -35.0, 0), _mat_timber)
		_add_cyl(root, "RoundWindowGlow", 0.40, 0.40, 0.20, Vector3(side_x * 1.65, 1.85, -1.15), Vector3(90, side_x * -35.0, 0), _mat_warm_window)

	_add_box(root, "CottageDoorArch", Vector3(1.25, 2.15, 0.28), Vector3(0, 1.15, -2.12), Vector3.ZERO, _mat_timber)
	_add_cyl(root, "CrookedChimneyLower", 0.34, 0.42, 1.65, Vector3(1.55, 4.65, 0.85), Vector3(0, 0, -12), _mat_stone)
	_add_cyl(root, "CrookedChimneyTop", 0.38, 0.32, 0.55, Vector3(1.72, 5.55, 0.85), Vector3(0, 0, 8), _mat_stone)

	return root


# ==============================================================================
# 6. MULTI-BRANCH SNOW-LADEN ALPINE PINE TREES & VICTORIAN STREETLAMPS
# ==============================================================================
static func build_realistic_pine_tree(height_scale: float = 1.0) -> Node3D:
	_ensure_materials()
	var root := Node3D.new()
	root.name = "RealisticAlpinePineTree"
	root.scale = Vector3.ONE * height_scale

	# Tapered Furrowed Bark Trunk + Root Buttresses
	_add_cyl(root, "PineTrunk", 0.08, 0.32, 5.6, Vector3(0, 2.8, 0), Vector3.ZERO, _mat_timber)
	for ri in range(4):
		var rang: float = float(ri) * PI * 0.5
		_add_capsule(root, "RootButtress", 0.12, 0.75, Vector3(sin(rang) * 0.22, 0.25, cos(rang) * 0.22), Vector3(0, rang * 57.3, 35), _mat_timber)

	# 6 Whorls of Layered Drooping Boughs + Snow Cushions (24 branches total)
	for tier in range(6):
		var tf: float = float(tier) / 5.0
		var ty: float = lerpf(1.45, 5.15, tf)
		var bough_len: float = lerpf(1.85, 0.55, tf)
		var branches_in_tier: int = 5 if tier < 3 else 4

		# Central foliage tier skirt
		_add_cyl(root, "FoliageCoreTier", 0.12, bough_len * 0.92, 1.15, Vector3(0, ty + 0.25, 0), Vector3.ZERO, _mat_pine_needle)
		_add_cyl(root, "SnowDrapeTier", 0.14, bough_len * 0.78, 0.35, Vector3(0, ty + 0.52, 0), Vector3.ZERO, _mat_snow_cap)

		for bi in range(branches_in_tier):
			var bang: float = float(bi) * TAU / float(branches_in_tier) + float(tier) * 0.55
			var bx: float = sin(bang) * (bough_len * 0.52)
			var bz: float = cos(bang) * (bough_len * 0.52)
			_add_capsule(
				root, "DroopingBough",
				0.26 * (1.0 - tf * 0.45),
				bough_len,
				Vector3(bx, ty, bz),
				Vector3(72, bang * 57.2958, 0),
				_mat_pine_needle
			)

	return root


static func build_victorian_streetlamp() -> Node3D:
	_ensure_materials()
	var root := Node3D.new()
	root.name = "VictorianStreetlamp"

	_add_cyl(root, "FlutedBasePlinth", 0.18, 0.26, 0.45, Vector3(0, 0.225, 0), Vector3.ZERO, _mat_wrought_iron)
	_add_cyl(root, "LowerColumn", 0.11, 0.16, 0.85, Vector3(0, 0.85, 0), Vector3.ZERO, _mat_wrought_iron)
	_add_cyl(root, "DecorativeCollar", 0.15, 0.15, 0.10, Vector3(0, 1.30, 0), Vector3.ZERO, _mat_brass)
	_add_cyl(root, "UpperPost", 0.065, 0.095, 1.85, Vector3(0, 2.22, 0), Vector3.ZERO, _mat_wrought_iron)
	_add_box(root, "CrossLadderBar", Vector3(0.58, 0.045, 0.045), Vector3(0, 2.92, 0), Vector3.ZERO, _mat_brass)

	# Hexagonal Glass Lantern Cage, 4 Corner Struts, Pitched Copper Cap & Finial
	_add_cyl(root, "LanternBottomTray", 0.18, 0.08, 0.12, Vector3(0, 3.16, 0), Vector3.ZERO, _mat_wrought_iron)
	_add_cyl(root, "LanternWarmGlass", 0.22, 0.16, 0.42, Vector3(0, 3.42, 0), Vector3.ZERO, _mat_warm_window)
	_add_cyl(root, "LanternRoofCap", 0.03, 0.28, 0.22, Vector3(0, 3.74, 0), Vector3.ZERO, _mat_wrought_iron)
	_add_sphere(root, "LanternFinial", 0.045, Vector3(0, 3.88, 0), _mat_brass)

	return root


# ==============================================================================
# 7. ORNATE DOORS, SAFE ROOM CAMPFIRE, PUZZLE TERMINALS & GALLEON SHIP
# ==============================================================================
static func build_ornate_door(is_locked: bool, req_key_id: String, is_one_way: bool) -> Node3D:
	_ensure_materials()
	var root := Node3D.new()
	root.name = "OrnateArchitecturalDoor"

	# Stone Arch Jambs & Lintel Header
	_add_box(root, "StoneJambLeft", Vector3(0.32, 2.55, 0.52), Vector3(-0.78, 0.0, 0), Vector3.ZERO, _mat_stone)
	_add_box(root, "StoneJambRight", Vector3(0.32, 2.55, 0.52), Vector3(0.78, 0.0, 0), Vector3.ZERO, _mat_stone)
	_add_box(root, "StoneLintelTop", Vector3(2.02, 0.38, 0.58), Vector3(0, 1.32, 0), Vector3.ZERO, _mat_stone)

	# Heavy Recessed Double Oak Door Panels with Iron Studs & Brass Handles
	_add_box(root, "OakDoorLeafLeft", Vector3(0.62, 2.38, 0.22), Vector3(-0.31, -0.05, 0), Vector3.ZERO, _mat_timber)
	_add_box(root, "OakDoorLeafRight", Vector3(0.62, 2.38, 0.22), Vector3(0.31, -0.05, 0), Vector3.ZERO, _mat_timber)
	_add_box(root, "CenterDoorSeam", Vector3(0.05, 2.38, 0.26), Vector3(0, -0.05, 0), Vector3.ZERO, _mat_wrought_iron)

	for sy in [-0.75, 0.0, 0.75]:
		_add_box(root, "IronStrapHingeL", Vector3(0.48, 0.08, 0.26), Vector3(-0.38, sy, 0), Vector3.ZERO, _mat_wrought_iron)
		_add_box(root, "IronStrapHingeR", Vector3(0.48, 0.08, 0.26), Vector3(0.38, sy, 0), Vector3.ZERO, _mat_wrought_iron)

	_add_sphere(root, "BrassDoorRingL", 0.065, Vector3(-0.12, -0.08, -0.15), _mat_brass)
	_add_sphere(root, "BrassDoorRingR", 0.065, Vector3(0.12, -0.08, 0.15), _mat_brass)

	# If boarded up by planks (Crowbar door), add crossed wooden planks nailed across the door!
	if req_key_id == "tool_crowbar":
		_add_box(root, "NailedPlank1", Vector3(1.55, 0.22, 0.34), Vector3(0, 0.25, 0), Vector3(0, 0, 14), _mat_timber)
		_add_box(root, "NailedPlank2", Vector3(1.55, 0.22, 0.34), Vector3(0, -0.35, 0), Vector3(0, 0, -12), _mat_timber)

	# Status Lantern above lintel (Amber/Red if locked, Emerald Green if unlocked/shortcut)
	var mat_status := StandardMaterial3D.new()
	var col: Color = Color(0.95, 0.22, 0.18) if is_locked else Color(0.22, 0.92, 0.48)
	if is_one_way and is_locked:
		col = Color(0.95, 0.68, 0.18)
	mat_status.albedo_color = col
	mat_status.emission_enabled = true
	mat_status.emission = col
	mat_status.emission_energy_multiplier = 1.6
	_add_sphere(root, "DoorStatusLantern", 0.11, Vector3(0, 1.56, 0), mat_status)

	return root


static func build_campfire_hearth() -> Node3D:
	_ensure_materials()
	var root := Node3D.new()
	root.name = "SafeRoomCampfireHearth"

	# Circle of 10 River Stones
	for i in range(10):
		var ang: float = float(i) * TAU / 10.0
		_add_sphere(root, "HearthStone", 0.22, Vector3(sin(ang) * 0.65, -0.38, cos(ang) * 0.65), _mat_stone)

	# Crossed Charred Firewood Logs
	for i in range(4):
		var ang: float = float(i) * PI * 0.25
		_add_cyl(root, "FirewoodLog", 0.08, 0.09, 1.05, Vector3(0, -0.32, 0), Vector3(78, ang * 57.3, 0), _mat_timber)

	# Glowing Ember Bed & Multi-Layered Flame Cones
	var mat_flame := StandardMaterial3D.new()
	mat_flame.albedo_color = Color(1.0, 0.55, 0.12)
	mat_flame.emission_enabled = true
	mat_flame.emission = Color(1.0, 0.45, 0.08)
	mat_flame.emission_energy_multiplier = 2.4

	_add_cyl(root, "FlameOuter", 0.03, 0.34, 0.72, Vector3(0, -0.02, 0), Vector3.ZERO, mat_flame)
	_add_cyl(root, "FlameInner", 0.02, 0.22, 0.55, Vector3(0.08, -0.06, -0.06), Vector3(8, 0, -10), _mat_warm_window)

	# Cast-Iron Kettle Tripod over the fire
	for i in range(3):
		var ang: float = float(i) * TAU / 3.0
		_add_cyl(root, "TripodLeg", 0.022, 0.028, 1.45, Vector3(sin(ang) * 0.38, 0.18, cos(ang) * 0.38), Vector3(-22 * cos(ang), 0, 22 * sin(ang)), _mat_wrought_iron)
	_add_sphere(root, "HangingKettle", 0.18, Vector3(0, 0.18, 0), _mat_wrought_iron)

	return root


static func build_pirate_galleon_ship() -> Node3D:
	_ensure_materials()
	var root := Node3D.new()
	root.name = "SculptedPirateGalleon"

	# Curved Timber Hull, Raised Stern Poop Deck, Bow Bowsprit, 2 Tall Masts & Billowing Sails
	_add_box(root, "GalleonHullMain", Vector3(2.8, 1.45, 6.8), Vector3(0, -0.4, 0), Vector3.ZERO, _mat_timber)
	_add_box(root, "SternCastleDeck", Vector3(2.6, 1.15, 2.2), Vector3(0, 0.65, 2.3), Vector3.ZERO, _mat_timber)
	_add_cyl(root, "BowspritSpar", 0.05, 0.12, 2.4, Vector3(0, 0.45, -4.1), Vector3(65, 0, 0), _mat_timber)

	for mz in [-1.2, 1.4]:
		_add_cyl(root, "ShipMast", 0.08, 0.14, 4.4, Vector3(0, 1.8, mz), Vector3.ZERO, _mat_timber)
		_add_cyl(root, "YardarmCross", 0.05, 0.05, 2.8, Vector3(0, 2.8, mz), Vector3(0, 0, 90), _mat_timber)
		_add_box(root, "BillowingSail", Vector3(2.5, 1.65, 0.14), Vector3(0, 2.0, mz - 0.12), Vector3(6, 0, 0), _mat_stucco)

	return root


# ==============================================================================
# 8. 1:1 CROW COUNTRY FIRESIDE LOUNGE DIORAMA ROOM (MATCHING REFERENCE IMAGE)
# ==============================================================================
static func build_crow_country_fireside_lounge_diorama(center: Vector3) -> Node3D:
	_ensure_materials()
	var root := Node3D.new()
	root.name = "CrowCountryFiresideLoungeDiorama"
	root.position = center

	# Specialized Crow Country Shaders & Materials
	var mat_wood_floor: Material = _mat_timber
	var sh_floor := load("res://assets/shaders/crow_country_wood_floor.gdshader") as Shader
	if sh_floor:
		var sm := ShaderMaterial.new()
		sm.shader = sh_floor
		mat_wood_floor = sm

	var mat_persian_rug: Material = _mat_roof_red
	var sh_rug := load("res://assets/shaders/crow_country_carpet.gdshader") as Shader
	if sh_rug:
		var sm := ShaderMaterial.new()
		sm.shader = sh_rug
		mat_persian_rug = sm

	var mat_wallpaper: Material = _mat_stucco
	var sh_wall := load("res://assets/shaders/crow_country_wallpaper.gdshader") as Shader
	if sh_wall:
		var sm := ShaderMaterial.new()
		sm.shader = sh_wall
		mat_wallpaper = sm

	var mat_mahogany := StandardMaterial3D.new()
	mat_mahogany.albedo_color = Color(0.28, 0.08, 0.05)
	mat_mahogany.roughness = 0.42

	var mat_sofa_brown := StandardMaterial3D.new()
	mat_sofa_brown.albedo_color = Color(0.20, 0.11, 0.07)
	mat_sofa_brown.roughness = 0.78

	var mat_sofa_throw := StandardMaterial3D.new()
	mat_sofa_throw.albedo_color = Color(0.36, 0.06, 0.07)
	mat_sofa_throw.roughness = 0.75

	var mat_cream_marble := StandardMaterial3D.new()
	mat_cream_marble.albedo_color = Color(0.76, 0.70, 0.56)
	mat_cream_marble.roughness = 0.45

	var mat_fire_glow := StandardMaterial3D.new()
	mat_fire_glow.albedo_color = Color(0.98, 0.32, 0.08)
	mat_fire_glow.emission_enabled = true
	mat_fire_glow.emission = Color(0.98, 0.30, 0.06)
	mat_fire_glow.emission_energy_multiplier = 2.6

	var mat_lampshade := StandardMaterial3D.new()
	mat_lampshade.albedo_color = Color(0.88, 0.82, 0.58)
	mat_lampshade.emission_enabled = true
	mat_lampshade.emission = Color(0.95, 0.82, 0.45)
	mat_lampshade.emission_energy_multiplier = 0.85

	var mat_lamp_stand := StandardMaterial3D.new()
	mat_lamp_stand.albedo_color = Color(0.46, 0.56, 0.58)
	mat_lamp_stand.roughness = 0.45

	var mat_emerald_bottle := StandardMaterial3D.new()
	mat_emerald_bottle.albedo_color = Color(0.12, 0.58, 0.22)
	mat_emerald_bottle.roughness = 0.18
	mat_emerald_bottle.metallic = 0.25

	var mat_mint_glow := StandardMaterial3D.new()
	mat_mint_glow.albedo_color = Color(0.55, 0.98, 0.75)
	mat_mint_glow.emission_enabled = true
	mat_mint_glow.emission = Color(0.45, 0.95, 0.68)
	mat_mint_glow.emission_energy_multiplier = 1.8

	var mat_orange_table := StandardMaterial3D.new()
	mat_orange_table.albedo_color = Color(0.78, 0.34, 0.10)
	mat_orange_table.roughness = 0.42

	var mat_paper_white := StandardMaterial3D.new()
	mat_paper_white.albedo_color = Color(0.95, 0.92, 0.82)
	mat_paper_white.roughness = 0.65

	# 1. Hardwood Diorama Floor & Ornate Crimson Persian Rug (PlaneMesh for full 0..1 UV mapping)
	_add_box(root, "DioramaHardwoodFloor", Vector3(11.6, 0.12, 9.2), Vector3(0, 0.02, 0), Vector3.ZERO, mat_wood_floor)
	_add_box(root, "CrimsonPersianRugPad", Vector3(6.82, 0.02, 4.52), Vector3(-0.2, 0.09, -0.2), Vector3.ZERO, mat_mahogany)
	var rug_mesh_inst := MeshInstance3D.new()
	rug_mesh_inst.name = "CrimsonPersianRug"
	var rug_plane := PlaneMesh.new()
	rug_plane.size = Vector2(6.8, 4.5)
	rug_mesh_inst.mesh = rug_plane
	rug_mesh_inst.position = Vector3(-0.2, 0.102, -0.2)
	rug_mesh_inst.material_override = mat_persian_rug
	root.add_child(rug_mesh_inst)

	# 2. Cutaway Diorama Box Walls (Back North Wall, Left West Wall, Right East Wall)
	_add_box(root, "BackWallNorth", Vector3(11.6, 3.8, 0.35), Vector3(0, 1.9, -4.45), Vector3.ZERO, mat_wallpaper)
	_add_box(root, "SideWallWest", Vector3(0.35, 3.8, 9.2), Vector3(-5.65, 1.9, 0), Vector3.ZERO, mat_wallpaper)
	_add_box(root, "SideWallEast", Vector3(0.35, 3.8, 9.2), Vector3(5.65, 1.9, 0), Vector3.ZERO, mat_wallpaper)
	# Dark Mahogany Crown Molding along top of walls
	_add_box(root, "CrownMoldingNorth", Vector3(11.8, 0.18, 0.42), Vector3(0, 3.82, -4.45), Vector3.ZERO, mat_mahogany)
	_add_box(root, "CrownMoldingWest", Vector3(0.42, 0.18, 9.4), Vector3(-5.65, 3.82, 0), Vector3.ZERO, mat_mahogany)
	_add_box(root, "CrownMoldingEast", Vector3(0.42, 0.18, 9.4), Vector3(5.65, 3.82, 0), Vector3.ZERO, mat_mahogany)

	# 3. Centerpiece Fluted Cream-Marble Fireplace & Glowing Orange Hearth (at X=-0.35, Z=-3.95)
	var fp := Node3D.new()
	fp.name = "CreamMarbleFireplace"
	fp.position = Vector3(-0.35, 0.08, -3.95)
	root.add_child(fp)

	var mat_soot_brick := StandardMaterial3D.new()
	mat_soot_brick.albedo_color = Color(0.11, 0.06, 0.05)
	mat_soot_brick.roughness = 0.92

	var mat_ember_glow := StandardMaterial3D.new()
	mat_ember_glow.albedo_color = Color(0.96, 0.22, 0.04)
	mat_ember_glow.emission_enabled = true
	mat_ember_glow.emission = Color(1.0, 0.28, 0.04)
	mat_ember_glow.emission_energy_multiplier = 3.2

	var mat_flame_gold := StandardMaterial3D.new()
	mat_flame_gold.albedo_color = Color(1.0, 0.68, 0.14)
	mat_flame_gold.emission_enabled = true
	mat_flame_gold.emission = Color(1.0, 0.62, 0.10)
	mat_flame_gold.emission_energy_multiplier = 2.8

	var mat_charred_log := StandardMaterial3D.new()
	mat_charred_log.albedo_color = Color(0.14, 0.08, 0.06)
	mat_charred_log.roughness = 0.95

	_add_box(fp, "HearthSlab", Vector3(2.65, 0.12, 1.02), Vector3(0, 0.06, 0.14), Vector3.ZERO, mat_cream_marble)
	_add_box(fp, "LeftPilasterBase", Vector3(0.56, 0.22, 0.66), Vector3(-0.92, 0.20, 0.02), Vector3.ZERO, mat_cream_marble)
	_add_box(fp, "RightPilasterBase", Vector3(0.56, 0.22, 0.66), Vector3(0.92, 0.20, 0.02), Vector3.ZERO, mat_cream_marble)
	_add_box(fp, "LeftPilaster", Vector3(0.48, 1.85, 0.58), Vector3(-0.92, 1.15, 0), Vector3.ZERO, mat_cream_marble)
	_add_box(fp, "RightPilaster", Vector3(0.48, 1.85, 0.58), Vector3(0.92, 1.15, 0), Vector3.ZERO, mat_cream_marble)
	# Fluted grooves & carved capitals on pilasters
	for side in [-1.0, 1.0]:
		for fi in [-0.12, 0.0, 0.12]:
			_add_cyl(fp, "PilasterFlute", 0.032, 0.032, 1.48, Vector3(side * 0.92 + fi, 1.12, 0.29), Vector3.ZERO, _mat_stone)
		_add_box(fp, "PilasterCapital", Vector3(0.54, 0.16, 0.64), Vector3(side * 0.92, 1.94, 0.02), Vector3.ZERO, mat_cream_marble)
	_add_box(fp, "FireplaceHeaderLintel", Vector3(2.38, 0.44, 0.58), Vector3(0, 1.88, 0), Vector3.ZERO, mat_cream_marble)
	_add_box(fp, "HeaderCenterKeystone", Vector3(0.46, 0.34, 0.62), Vector3(0, 1.88, 0.04), Vector3.ZERO, mat_cream_marble)
	_add_box(fp, "MantelpieceUnderMolding", Vector3(2.58, 0.10, 0.68), Vector3(0, 2.10, 0.04), Vector3.ZERO, mat_cream_marble)
	_add_box(fp, "MantelpieceShelf", Vector3(2.76, 0.16, 0.78), Vector3(0, 2.22, 0.08), Vector3.ZERO, mat_cream_marble)

	# Deep Recessed Soot Firebox, Glowing Ember Bed, Burning Firewood Logs, Flames & Iron Grate
	_add_box(fp, "SootFireboxBack", Vector3(1.38, 1.52, 0.16), Vector3(0, 0.86, -0.22), Vector3.ZERO, mat_soot_brick)
	_add_box(fp, "SootFireboxLeft", Vector3(0.12, 1.52, 0.52), Vector3(-0.66, 0.86, 0.0), Vector3.ZERO, mat_soot_brick)
	_add_box(fp, "SootFireboxRight", Vector3(0.12, 1.52, 0.52), Vector3(0.66, 0.86, 0.0), Vector3.ZERO, mat_soot_brick)
	_add_box(fp, "GlowingFireboxArchGlow", Vector3(1.20, 0.95, 0.08), Vector3(0, 0.62, -0.14), Vector3.ZERO, mat_fire_glow)
	_add_sphere(fp, "GlowingEmberBed", 0.36, Vector3(0, 0.22, 0.0), mat_ember_glow).scale = Vector3(1.35, 0.35, 0.75)
	_add_cyl(fp, "FirewoodLogL", 0.075, 0.085, 0.68, Vector3(-0.14, 0.28, 0.02), Vector3(0, 18, 78), mat_charred_log)
	_add_cyl(fp, "FirewoodLogR", 0.075, 0.085, 0.68, Vector3(0.12, 0.30, 0.04), Vector3(0, -22, -74), mat_charred_log)
	_add_cyl(fp, "FlameTongueCenter", 0.02, 0.16, 0.52, Vector3(0, 0.54, 0.0), Vector3.ZERO, mat_flame_gold)
	_add_cyl(fp, "FlameTongueLeft", 0.015, 0.11, 0.38, Vector3(-0.18, 0.46, 0.02), Vector3(0, 0, 12), mat_fire_glow)
	_add_cyl(fp, "FlameTongueRight", 0.015, 0.11, 0.40, Vector3(0.18, 0.48, 0.02), Vector3(0, 0, -10), mat_fire_glow)
	# Wrought-iron grate bars & curved fender
	for gi in [-0.32, -0.16, 0.0, 0.16, 0.32]:
		_add_cyl(fp, "IronGrateBar", 0.015, 0.015, 0.28, Vector3(gi, 0.24, 0.22), Vector3.ZERO, _mat_wrought_iron)
	_add_cyl(fp, "CurvedHearthFender", 0.68, 0.72, 0.20, Vector3(0, 0.16, 0.20), Vector3.ZERO, _mat_wrought_iron)
	_add_cyl(fp, "FenderBrassRim", 0.70, 0.70, 0.04, Vector3(0, 0.27, 0.20), Vector3.ZERO, _mat_brass)

	# Mantelpiece Clutter (Clock with Hands, Lit Candlesticks, Green Bottles, Bronze Bust, Brass Tin)
	_add_box(fp, "MantelClockCase", Vector3(0.40, 0.48, 0.24), Vector3(-0.04, 2.52, 0.08), Vector3.ZERO, mat_mahogany)
	_add_box(fp, "MantelClockBase", Vector3(0.46, 0.06, 0.28), Vector3(-0.04, 2.31, 0.08), Vector3.ZERO, _mat_brass)
	_add_cyl(fp, "MantelClockDial", 0.12, 0.12, 0.04, Vector3(-0.04, 2.54, 0.19), Vector3(90, 0, 0), mat_paper_white)
	_add_box(fp, "ClockHandMin", Vector3(0.015, 0.09, 0.01), Vector3(-0.04, 2.57, 0.215), Vector3.ZERO, _mat_wrought_iron)
	_add_box(fp, "ClockHandHr", Vector3(0.06, 0.015, 0.01), Vector3(-0.01, 2.54, 0.215), Vector3.ZERO, _mat_wrought_iron)
	_add_cyl(fp, "CandlestickL", 0.09, 0.12, 0.28, Vector3(-1.05, 2.42, 0.10), Vector3.ZERO, _mat_brass)
	_add_cyl(fp, "CandleL", 0.032, 0.035, 0.26, Vector3(-1.05, 2.68, 0.10), Vector3.ZERO, mat_paper_white)
	_add_sphere(fp, "CandleFlameL", 0.032, Vector3(-1.05, 2.84, 0.10), mat_flame_gold)
	_add_cyl(fp, "CandlestickR", 0.09, 0.12, 0.28, Vector3(1.02, 2.42, 0.10), Vector3.ZERO, _mat_brass)
	_add_cyl(fp, "CandleR", 0.032, 0.035, 0.26, Vector3(1.02, 2.68, 0.10), Vector3.ZERO, mat_paper_white)
	_add_sphere(fp, "CandleFlameR", 0.032, Vector3(1.02, 2.84, 0.10), mat_flame_gold)
	_add_cyl(fp, "GreenBottle1", 0.065, 0.08, 0.36, Vector3(-0.75, 2.46, 0.08), Vector3.ZERO, mat_emerald_bottle)
	_add_cyl(fp, "GreenBottle2", 0.065, 0.08, 0.38, Vector3(0.38, 2.48, 0.06), Vector3.ZERO, mat_emerald_bottle)
	_add_cyl(fp, "BronzeBustPedestal", 0.10, 0.13, 0.14, Vector3(-0.42, 2.35, 0.10), Vector3.ZERO, _mat_wrought_iron)
	_add_sphere(fp, "BronzeBustHead", 0.13, Vector3(-0.42, 2.50, 0.10), _mat_brass)
	_add_cyl(fp, "BrassCanisterTin", 0.18, 0.18, 0.26, Vector3(0.45, 2.42, 0.14), Vector3.ZERO, _mat_brass)

	# 4. Flanking Mahogany Bookcases with Molded Crowns & Gold-Banded Books
	var book_colors: Array[Color] = [
		Color(0.58, 0.12, 0.10), Color(0.14, 0.38, 0.18), Color(0.68, 0.48, 0.16),
		Color(0.16, 0.22, 0.42), Color(0.38, 0.20, 0.12)
	]
	for bx_pos in [-2.25, 1.55]:
		var bc := Node3D.new()
		bc.position = Vector3(bx_pos, 0.08, -3.98)
		root.add_child(bc)
		_add_box(bc, "BookcaseBack", Vector3(1.18, 2.45, 0.10), Vector3(0, 1.22, -0.18), Vector3.ZERO, mat_mahogany)
		_add_box(bc, "BookcaseSideL", Vector3(0.08, 2.45, 0.46), Vector3(-0.55, 1.22, 0), Vector3.ZERO, mat_mahogany)
		_add_box(bc, "BookcaseSideR", Vector3(0.08, 2.45, 0.46), Vector3(0.55, 1.22, 0), Vector3.ZERO, mat_mahogany)
		_add_box(bc, "BookcaseCrownTop", Vector3(1.28, 0.12, 0.54), Vector3(0, 2.48, 0.02), Vector3.ZERO, mat_mahogany)
		_add_box(bc, "BookcaseBasePlinth", Vector3(1.24, 0.10, 0.50), Vector3(0, 0.05, 0.02), Vector3.ZERO, mat_mahogany)
		for sh_i in range(5):
			var sy: float = 0.12 + float(sh_i) * 0.56
			_add_box(bc, "ShelfPlank", Vector3(1.16, 0.06, 0.46), Vector3(0, sy, 0), Vector3.ZERO, mat_mahogany)
			if sh_i < 4:
				for b_idx in range(8):
					var bmat := StandardMaterial3D.new()
					bmat.albedo_color = book_colors[(sh_i * 3 + b_idx) % book_colors.size()]
					bmat.roughness = 0.62
					var bh: float = 0.32 + float((b_idx + sh_i) % 3) * 0.05
					var b_x: float = -0.42 + float(b_idx) * 0.12
					var tilt: float = 8.0 if (sh_i == 2 and b_idx == 7) else 0.0
					_add_box(bc, "BookSpine", Vector3(0.09, bh, 0.28), Vector3(b_x, sy + 0.03 + bh * 0.5, 0.02), Vector3(0, 0, tilt), bmat)
					if b_idx % 2 == 0:
						_add_box(bc, "BookGoldBand", Vector3(0.092, 0.025, 0.02), Vector3(b_x, sy + 0.03 + bh * 0.78, 0.16), Vector3(0, 0, tilt), _mat_brass)

	# Stack of books & brass scroll on floor beside fireplace
	_add_box(root, "FloorBookStack", Vector3(0.45, 0.28, 0.38), Vector3(-1.85, 0.22, -3.25), Vector3(0, 14, 0), mat_mahogany)
	_add_cyl(root, "FloorScrollTube1", 0.06, 0.06, 0.72, Vector3(-3.05, 0.32, -3.35), Vector3(0, 0, -28), _mat_brass)
	_add_cyl(root, "FloorScrollTube2", 0.06, 0.06, 0.68, Vector3(2.55, 0.14, -3.15), Vector3(78, 45, 0), _mat_brass)

	# 5. Framed Wall Portraits with Painted Art & Gold Inner Trim + Upper-Left Tall Cabinet
	_add_box(root, "UpperLeftTallCabinet", Vector3(1.10, 2.15, 1.45), Vector3(-4.85, 1.15, -2.55), Vector3.ZERO, _mat_timber)
	_add_cyl(root, "UpperLeftGreenUrn", 0.16, 0.22, 0.52, Vector3(-4.85, 2.48, -2.85), Vector3.ZERO, mat_emerald_bottle)
	var art_colors: Array[Color] = [
		Color(0.24, 0.32, 0.38), Color(0.45, 0.32, 0.22),
		Color(0.28, 0.24, 0.18), Color(0.18, 0.22, 0.28)
	]
	var f_idx: int = 0
	for frame_pos in [
		Vector3(-3.65, 2.35, -4.24), Vector3(-3.15, 2.35, -4.24),
		Vector3(-3.45, 1.68, -4.24), Vector3(-3.25, 1.05, -4.24)
	]:
		var art_mat := StandardMaterial3D.new()
		art_mat.albedo_color = art_colors[f_idx % art_colors.size()]
		art_mat.roughness = 0.55
		_add_box(root, "PortraitFrame", Vector3(0.46, 0.54, 0.06), frame_pos, Vector3.ZERO, mat_mahogany)
		_add_box(root, "PortraitGoldMat", Vector3(0.38, 0.46, 0.07), frame_pos, Vector3.ZERO, _mat_brass)
		_add_box(root, "PortraitCanvas", Vector3(0.32, 0.40, 0.08), frame_pos, Vector3.ZERO, art_mat)
		f_idx += 1
	_add_sphere(root, "OvalPortraitFace", 0.10, Vector3(-3.25, 1.08, -4.20), mat_paper_white)

	# 6. Pleated Cream Standing Floor Lamp with Vertical Fabric Pleats & Brass Finial
	var flamp := Node3D.new()
	flamp.position = Vector3(1.78, 0.08, -2.65)
	root.add_child(flamp)
	_add_cyl(flamp, "LampBase", 0.28, 0.34, 0.14, Vector3(0, 0.07, 0), Vector3.ZERO, mat_lamp_stand)
	_add_cyl(flamp, "LampBaseBrassRing", 0.20, 0.24, 0.06, Vector3(0, 0.16, 0), Vector3.ZERO, _mat_brass)
	_add_cyl(flamp, "LampPedestal", 0.075, 0.11, 1.45, Vector3(0, 0.88, 0), Vector3.ZERO, mat_lamp_stand)
	_add_cyl(flamp, "LampCollarBrass", 0.11, 0.11, 0.07, Vector3(0, 1.48, 0), Vector3.ZERO, _mat_brass)
	_add_cyl(flamp, "PleatedLampshade", 0.28, 0.48, 0.56, Vector3(0, 1.78, 0), Vector3.ZERO, mat_lampshade)
	for p_i in range(12):
		var pang: float = float(p_i) * TAU / 12.0
		_add_box(flamp, "ShadePleatRib", Vector3(0.024, 0.56, 0.024), Vector3(sin(pang) * 0.38, 1.78, cos(pang) * 0.38), Vector3(-19.65, rad_to_deg(pang), 0), _mat_stucco)
	_add_cyl(flamp, "LampTopInnerRing", 0.22, 0.22, 0.04, Vector3(0, 2.05, 0), Vector3.ZERO, mat_mahogany)
	_add_sphere(flamp, "LampBrassFinial", 0.055, Vector3(0, 2.12, 0), _mat_brass)

	# 7. Central Plush Tufted Velvet Sofa, 4-Legged Oak Coffee Table & Ornate Props
	var sofa := Node3D.new()
	sofa.name = "CentralPlushSofa"
	sofa.position = Vector3(-0.12, 0.08, 1.62)
	root.add_child(sofa)
	_add_box(sofa, "SofaFrameBase", Vector3(2.38, 0.20, 0.96), Vector3(0, 0.18, 0), Vector3.ZERO, mat_mahogany)
	for foot_x in [-1.05, 1.05]:
		for foot_z in [-0.38, 0.38]:
			_add_cyl(sofa, "SofaWoodFoot", 0.055, 0.04, 0.10, Vector3(foot_x, 0.05, foot_z), Vector3.ZERO, mat_mahogany)
	for ci in [-0.74, 0.0, 0.74]:
		_add_box(sofa, "SofaSeatCushion", Vector3(0.72, 0.22, 0.88), Vector3(ci, 0.36, -0.02), Vector3.ZERO, mat_sofa_brown)
		_add_box(sofa, "SofaBackCushion", Vector3(0.72, 0.56, 0.28), Vector3(ci, 0.68, 0.32), Vector3(-7, 0, 0), mat_sofa_brown)
	_add_box(sofa, "SofaBackFrame", Vector3(2.38, 0.88, 0.18), Vector3(0, 0.58, 0.42), Vector3(-6, 0, 0), mat_sofa_brown)
	_add_box(sofa, "SofaThrowBlanket", Vector3(1.18, 0.42, 0.32), Vector3(0.05, 0.82, 0.38), Vector3(-6, 0, 0), mat_sofa_throw)
	for arm_side in [-1.0, 1.0]:
		_add_cyl(sofa, "RolledArmrest", 0.22, 0.22, 0.98, Vector3(arm_side * 1.18, 0.52, 0.02), Vector3(90, 0, 0), mat_sofa_brown)
		_add_cyl(sofa, "ArmrestTrim", 0.18, 0.18, 0.04, Vector3(arm_side * 1.18, 0.52, -0.47), Vector3(90, 0, 0), mat_mahogany)

	var mat_honey_oak := StandardMaterial3D.new()
	mat_honey_oak.albedo_color = Color(0.56, 0.28, 0.11)
	mat_honey_oak.roughness = 0.42

	var mat_bright_green_ashtray := StandardMaterial3D.new()
	mat_bright_green_ashtray.albedo_color = Color(0.16, 0.82, 0.24)
	mat_bright_green_ashtray.roughness = 0.22

	var mat_red_box := StandardMaterial3D.new()
	mat_red_box.albedo_color = Color(0.86, 0.16, 0.12)
	mat_red_box.roughness = 0.42

	# 4-Legged Oak Coffee Table (X=-0.38, Z=0.02) with Lower Shelf, Brass Pulls, Parchment Ink Lines & Stemmed Chalice
	var ctable := Node3D.new()
	ctable.position = Vector3(-0.38, 0.08, 0.02)
	ctable.rotation_degrees.y = -8.0
	root.add_child(ctable)
	_add_box(ctable, "CoffeeTableTop", Vector3(1.46, 0.08, 0.82), Vector3(0, 0.42, 0), Vector3.ZERO, mat_honey_oak)
	_add_box(ctable, "CoffeeTableApron", Vector3(1.32, 0.14, 0.68), Vector3(0, 0.32, 0), Vector3.ZERO, mat_honey_oak)
	_add_box(ctable, "CoffeeTableLowerShelf", Vector3(1.26, 0.05, 0.62), Vector3(0, 0.12, 0), Vector3.ZERO, mat_honey_oak)
	for lx in [-0.62, 0.62]:
		for lz in [-0.30, 0.30]:
			_add_box(ctable, "CoffeeTableLeg", Vector3(0.08, 0.40, 0.08), Vector3(lx, 0.20, lz), Vector3.ZERO, mat_honey_oak)
	_add_box(ctable, "CoffeeTableDrawerFront", Vector3(0.48, 0.10, 0.04), Vector3(-0.30, 0.32, 0.35), Vector3.ZERO, mat_mahogany)
	_add_sphere(ctable, "DrawerBrassKnob", 0.022, Vector3(-0.30, 0.32, 0.38), _mat_brass)
	_add_box(ctable, "ScatteredPaper1", Vector3(0.48, 0.015, 0.38), Vector3(0.14, 0.468, -0.04), Vector3(0, 10, 0), mat_paper_white)
	_add_box(ctable, "ScatteredPaper2", Vector3(0.42, 0.015, 0.34), Vector3(-0.14, 0.468, 0.05), Vector3(0, -18, 0), mat_lampshade)
	_add_cyl(ctable, "FountainPen", 0.01, 0.006, 0.18, Vector3(0.32, 0.48, 0.14), Vector3(90, 32, 0), _mat_brass)
	# Stemmed Mint-Green Glass Chalice (Foot + Stem + Flared Cup)
	_add_cyl(ctable, "ChaliceFoot", 0.05, 0.08, 0.03, Vector3(-0.46, 0.475, -0.14), Vector3.ZERO, mat_mint_glow)
	_add_cyl(ctable, "ChaliceStem", 0.018, 0.022, 0.12, Vector3(-0.46, 0.54, -0.14), Vector3.ZERO, mat_mint_glow)
	_add_cyl(ctable, "ChaliceCup", 0.105, 0.045, 0.14, Vector3(-0.46, 0.65, -0.14), Vector3.ZERO, mat_mint_glow)
	# Small white chalk/cigarette sticks on the rug between coffee table and sofa
	_add_box(root, "RugStick1", Vector3(0.03, 0.02, 0.12), Vector3(-0.52, 0.11, 0.78), Vector3(0, 28, 0), mat_paper_white)
	_add_box(root, "RugStick2", Vector3(0.03, 0.02, 0.11), Vector3(-0.22, 0.11, 0.72), Vector3(0, -15, 0), mat_paper_white)

	# Round Orange Side Table with Carved Edge & Bright Green Ashtray (X=+1.22, Z=+0.78)
	var otable := Node3D.new()
	otable.position = Vector3(1.22, 0.08, 0.78)
	root.add_child(otable)
	_add_cyl(otable, "OrangeTableTop", 0.44, 0.44, 0.07, Vector3(0, 0.48, 0), Vector3.ZERO, mat_orange_table)
	_add_cyl(otable, "OrangeTableRim", 0.46, 0.46, 0.03, Vector3(0, 0.46, 0), Vector3.ZERO, mat_mahogany)
	_add_cyl(otable, "OrangeTablePedestal", 0.075, 0.11, 0.42, Vector3(0, 0.24, 0), Vector3.ZERO, mat_orange_table)
	_add_cyl(otable, "OrangeTableBase", 0.22, 0.28, 0.06, Vector3(0, 0.03, 0), Vector3.ZERO, mat_orange_table)
	_add_cyl(otable, "GreenAshtray", 0.18, 0.15, 0.07, Vector3(0, 0.54, 0), Vector3.ZERO, mat_bright_green_ashtray)

	# Left End Table next to Sofa (X=-1.45, Z=+1.28)
	var ltable := Node3D.new()
	ltable.position = Vector3(-1.45, 0.08, 1.28)
	root.add_child(ltable)
	_add_box(ltable, "LeftEndTable", Vector3(0.65, 0.52, 0.65), Vector3(0, 0.26, 0), Vector3(0, 12, 0), mat_honey_oak)
	_add_box(ltable, "EndTableBooks", Vector3(0.34, 0.14, 0.28), Vector3(0, 0.57, 0), Vector3(0, -15, 0), mat_emerald_bottle)
	_add_cyl(ltable, "EndTableRedBottle", 0.055, 0.065, 0.18, Vector3(0.02, 0.72, 0), Vector3.ZERO, mat_red_box)

	# 8. Left & Right Wall Sideboards with Brass Drawer Pulls, Globes with Meridian Rings & Arcade Machine
	_add_box(root, "LeftWallSideboard", Vector3(1.15, 0.88, 3.2), Vector3(-4.65, 0.48, 0.45), Vector3.ZERO, mat_mahogany)
	for s_z in [-0.55, 0.45, 1.45]:
		_add_sphere(root, "SideboardBrassPull", 0.035, Vector3(-4.06, 0.68, s_z), _mat_brass)
	_add_box(root, "LeftRedAmmoBox", Vector3(0.42, 0.08, 0.34), Vector3(-4.55, 0.94, 0.35), Vector3(0, 8, 0), mat_red_box)
	_add_box(root, "LeftYellowLabel", Vector3(0.18, 0.09, 0.28), Vector3(-4.42, 0.94, 0.35), Vector3(0, 8, 0), mat_lampshade)
	_add_cyl(root, "LeftGlobeStand", 0.12, 0.18, 0.14, Vector3(-4.45, 0.98, 1.45), Vector3.ZERO, _mat_brass)
	_add_sphere(root, "LeftSideboardGlobe", 0.30, Vector3(-4.45, 1.28, 1.45), mat_sofa_brown)
	_add_cyl(root, "LeftGreenBottleA", 0.07, 0.07, 0.52, Vector3(-4.55, 0.95, -0.85), Vector3(0, 0, 52), mat_emerald_bottle)
	_add_cyl(root, "LeftGreenBottleB", 0.07, 0.07, 0.52, Vector3(-4.25, 0.95, -0.55), Vector3(58, 0, -32), mat_emerald_bottle)
	# Bottom-Left Foreground Potted Planter
	_add_box(root, "LeftForegroundStand", Vector3(0.95, 0.55, 0.95), Vector3(-4.45, 0.32, 2.55), Vector3.ZERO, mat_honey_oak)
	_add_cyl(root, "LeftPlanterBowl", 0.36, 0.26, 0.22, Vector3(-4.45, 0.68, 2.55), Vector3.ZERO, mat_emerald_bottle)
	_add_sphere(root, "LeftPlanterFoliage", 0.26, Vector3(-4.45, 0.86, 2.55), mat_sofa_brown)

	_add_box(root, "UpperRightBookcase", Vector3(1.10, 2.55, 1.25), Vector3(4.55, 1.35, -3.55), Vector3.ZERO, mat_mahogany)
	_add_box(root, "RightWallCredenza", Vector3(1.15, 0.85, 3.4), Vector3(4.45, 0.48, -0.55), Vector3.ZERO, mat_mahogany)
	for r_z in [-1.55, -0.55, 0.45]:
		_add_sphere(root, "CredenzaBrassPull", 0.035, Vector3(3.86, 0.68, r_z), _mat_brass)
	_add_cyl(root, "RightDemijohnBottle", 0.20, 0.22, 0.52, Vector3(4.35, 1.15, -1.55), Vector3.ZERO, mat_emerald_bottle)
	_add_cyl(root, "RightDemijohnRedCap", 0.08, 0.08, 0.12, Vector3(4.35, 1.45, -1.55), Vector3.ZERO, mat_red_box)
	_add_cyl(root, "RightBrassTin", 0.16, 0.16, 0.38, Vector3(4.35, 1.10, -1.05), Vector3.ZERO, _mat_brass)
	_add_box(root, "RightGreenLedger", Vector3(0.55, 0.08, 0.45), Vector3(4.35, 0.94, 0.15), Vector3(0, -12, 0), mat_bright_green_ashtray)
	_add_box(root, "RightForegroundCabinet", Vector3(1.15, 1.45, 1.65), Vector3(4.55, 0.78, 1.75), Vector3.ZERO, mat_honey_oak)
	_add_box(root, "RightCabinetRedBox", Vector3(0.38, 0.24, 0.42), Vector3(4.35, 0.55, 1.85), Vector3.ZERO, mat_red_box)
	_add_cyl(root, "RightGlobeStand", 0.12, 0.18, 0.14, Vector3(4.55, 1.56, 1.65), Vector3.ZERO, _mat_brass)
	_add_sphere(root, "RightTerrestrialGlobe", 0.30, Vector3(4.55, 1.85, 1.65), mat_sofa_brown)
	_add_box(root, "CornerGlowingMachine", Vector3(1.10, 2.05, 1.10), Vector3(4.65, 1.08, 2.95), Vector3(0, -12, 0), mat_honey_oak)
	_add_box(root, "CornerMachineScreenGlow", Vector3(0.08, 1.25, 0.72), Vector3(4.08, 1.02, 2.95), Vector3(0, -12, 0), mat_lampshade)

	# 9. Crow Country Dramatic Warm Pools of Light (Fireplace Orange + Floor Lamp Amber + Chalice Mint)
	var fire_light := OmniLight3D.new()
	fire_light.position = Vector3(-0.35, 1.15, -2.85)
	fire_light.light_color = Color(1.0, 0.48, 0.14)
	fire_light.light_energy = 1.85
	fire_light.omni_range = 7.5
	fire_light.shadow_enabled = true
	root.add_child(fire_light)

	var lamp_light := OmniLight3D.new()
	lamp_light.position = Vector3(1.85, 1.65, -2.45)
	lamp_light.light_color = Color(1.0, 0.82, 0.42)
	lamp_light.light_energy = 1.45
	lamp_light.omni_range = 6.5
	lamp_light.shadow_enabled = true
	root.add_child(lamp_light)

	var table_light := OmniLight3D.new()
	table_light.position = Vector3(-0.35, 1.15, 0.25)
	table_light.light_color = Color(0.98, 0.78, 0.42)
	table_light.light_energy = 1.15
	table_light.omni_range = 5.5
	root.add_child(table_light)

	# 10. Solid Physics Colliders for Floor, Walls, Cutaway Boundary & Furniture
	var col_specs: Array = [
		["ColFloor", Vector3(11.6, 0.14, 9.2), Vector3(0, 0.01, 0)],
		["ColWallNorth", Vector3(11.8, 4.2, 0.45), Vector3(0, 2.0, -4.45)],
		["ColWallWest", Vector3(0.45, 4.2, 9.4), Vector3(-5.65, 2.0, 0)],
		["ColWallEast", Vector3(0.45, 4.2, 9.4), Vector3(5.65, 2.0, 0)],
		["ColCutawaySouthGuard", Vector3(11.8, 4.2, 0.50), Vector3(0, 2.0, 4.72)],
		["ColFireplace", Vector3(2.45, 2.6, 0.95), Vector3(-0.35, 1.3, -3.92)],
		["ColBookcaseL", Vector3(1.25, 2.6, 0.54), Vector3(-2.25, 1.3, -3.98)],
		["ColBookcaseR", Vector3(1.25, 2.6, 0.54), Vector3(1.55, 1.3, -3.98)],
		["ColTallCabinet", Vector3(1.15, 2.2, 1.50), Vector3(-4.85, 1.1, -2.55)],
		["ColFloorLamp", Vector3(0.58, 2.1, 0.58), Vector3(1.78, 1.05, -2.65)],
		["ColSofa", Vector3(2.45, 1.15, 0.90), Vector3(-0.12, 0.58, 1.72)],
		["ColCoffeeTable", Vector3(1.38, 0.65, 0.72), Vector3(-0.38, 0.32, -0.05)],
		["ColOrangeTable", Vector3(0.74, 0.65, 0.74), Vector3(1.25, 0.32, 0.65)],
		["ColLeftSideboard", Vector3(1.20, 1.1, 4.25), Vector3(-4.95, 0.55, 1.35)],
		["ColRightSideboard", Vector3(1.20, 1.1, 4.65), Vector3(4.95, 0.55, 0.85)],
		["ColRightCabinet", Vector3(1.20, 1.5, 1.70), Vector3(4.55, 0.75, 1.75)],
		["ColCornerMachine", Vector3(1.15, 2.1, 1.15), Vector3(4.65, 1.05, 2.95)]
	]
	for spec in col_specs:
		var sb := StaticBody3D.new()
		sb.name = spec[0]
		sb.position = spec[2]
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = spec[1]
		cs.shape = bs
		sb.add_child(cs)
		root.add_child(sb)

	return root


static func build_pickup_prop(item_id: String) -> Node3D:
	_ensure_materials()
	var root := Node3D.new()
	root.name = "DetailedPickupProp"

	# Wooden pedestal table / crate underneath pickup so items don't float or sit as raw blocks
	_add_box(root, "SupplyCrateBase", Vector3(0.68, 0.42, 0.52), Vector3(0, -0.22, 0), Vector3.ZERO, _mat_timber)
	_add_box(root, "CrateIronRim", Vector3(0.70, 0.05, 0.54), Vector3(0, -0.02, 0), Vector3.ZERO, _mat_wrought_iron)

	if item_id.contains("shotgun"):
		# Double-barrel Alpine Shotgun resting on crate
		_add_box(root, "ShotgunStock", Vector3(0.06, 0.11, 0.38), Vector3(0, 0.08, 0.18), Vector3(-10, 18, 0), _mat_timber)
		_add_cyl(root, "ShotgunBarrelL", 0.018, 0.018, 0.58, Vector3(-0.02, 0.11, -0.15), Vector3(90, 18, 0), _mat_wrought_iron)
		_add_cyl(root, "ShotgunBarrelR", 0.018, 0.018, 0.58, Vector3(0.02, 0.11, -0.15), Vector3(90, 18, 0), _mat_wrought_iron)
	elif item_id.contains("crossbow"):
		_add_box(root, "CrossbowRail", Vector3(0.06, 0.06, 0.52), Vector3(0, 0.08, 0.02), Vector3(0, 18, 0), _mat_timber)
		_add_box(root, "CrossbowLimb", Vector3(0.50, 0.03, 0.05), Vector3(0, 0.09, -0.16), Vector3(0, 18, 0), _mat_wrought_iron)
	elif item_id.contains("mp5") or item_id.contains("smg"):
		_add_box(root, "SmgBody", Vector3(0.06, 0.10, 0.38), Vector3(0, 0.09, 0.0), Vector3(0, 20, 0), _mat_wrought_iron)
		_add_box(root, "SmgMag", Vector3(0.04, 0.18, 0.05), Vector3(0.02, 0.02, -0.04), Vector3(12, 20, 0), _mat_wrought_iron)
	elif item_id.contains("rifle") or item_id.contains("magnum"):
		_add_box(root, "RifleStock", Vector3(0.06, 0.09, 0.54), Vector3(0, 0.08, 0.04), Vector3(0, 16, 0), _mat_timber)
		_add_cyl(root, "RifleBarrel", 0.018, 0.018, 0.48, Vector3(-0.04, 0.11, -0.14), Vector3(90, 16, 0), _mat_brass if item_id.contains("magnum") else _mat_wrought_iron)
	elif item_id.contains("flamethrower"):
		_add_cyl(root, "FuelTankL", 0.08, 0.08, 0.34, Vector3(-0.08, 0.10, 0.05), Vector3(90, 15, 0), _mat_brass)
		_add_cyl(root, "FlameNozzle", 0.025, 0.025, 0.42, Vector3(0.05, 0.10, -0.10), Vector3(90, 15, 0), _mat_wrought_iron)
	elif item_id.begins_with("collectible_"):
		var mat_velvet := StandardMaterial3D.new()
		mat_velvet.albedo_color = Color(0.45, 0.08, 0.10)
		mat_velvet.roughness = 0.85
		_add_box(root, "VelvetCushion", Vector3(0.38, 0.08, 0.38), Vector3(0, 0.04, 0), Vector3.ZERO, mat_velvet)
		if item_id.contains("snow_globe") or item_id.contains("pearl"):
			var mat_orb := StandardMaterial3D.new()
			mat_orb.albedo_color = Color(0.68, 0.92, 1.0)
			mat_orb.emission_enabled = true
			mat_orb.emission = Color(0.35, 0.78, 0.95)
			mat_orb.emission_energy_multiplier = 0.85
			_add_sphere(root, "CollectibleOrb", 0.14, Vector3(0, 0.22, 0), mat_orb)
		else:
			_add_cyl(root, "CollectibleRelic", 0.12, 0.15, 0.22, Vector3(0, 0.19, 0), Vector3.ZERO, _mat_brass)
	elif item_id.contains("spray") or item_id.contains("antidote") or item_id.contains("medkit"):
		var mat_med := StandardMaterial3D.new()
		mat_med.albedo_color = Color(0.16, 0.62, 0.34) if item_id.contains("spray") else Color(0.86, 0.88, 0.92)
		mat_med.roughness = 0.28
		_add_cyl(root, "MedCanister", 0.09, 0.09, 0.32, Vector3(0, 0.16, 0), Vector3.ZERO, mat_med)
		_add_cyl(root, "SprayNozzle", 0.04, 0.05, 0.08, Vector3(0, 0.35, 0), Vector3.ZERO, _mat_brass)
	elif item_id.contains("watch"):
		_add_cyl(root, "PocketWatchCase", 0.16, 0.16, 0.05, Vector3(0, 0.06, 0), Vector3(25, 0, 0), _mat_brass)
		_add_cyl(root, "PocketWatchFace", 0.13, 0.13, 0.06, Vector3(0, 0.065, 0), Vector3(25, 0, 0), _mat_stucco)
	else:
		# Brass-clasped Ammunition Box
		_add_box(root, "AmmoBox", Vector3(0.38, 0.22, 0.24), Vector3(0, 0.11, 0), Vector3(0, 12, 0), _mat_wrought_iron)
		_add_box(root, "AmmoBrassClasp", Vector3(0.08, 0.10, 0.26), Vector3(0, 0.14, 0), Vector3(0, 12, 0), _mat_brass)

	return root


static func build_document_prop() -> Node3D:
	_ensure_materials()
	var root := Node3D.new()
	root.name = "DetailedDocumentLectern"

	# Carved Wooden Reading Lectern + Leather Folder + Parchment Pages + Brass Desk Lamp
	_add_cyl(root, "LecternBase", 0.26, 0.34, 0.12, Vector3(0, -0.34, 0), Vector3.ZERO, _mat_timber)
	_add_cyl(root, "LecternPillar", 0.07, 0.09, 0.58, Vector3(0, -0.02, 0), Vector3.ZERO, _mat_timber)
	_add_box(root, "LecternDeskTop", Vector3(0.62, 0.06, 0.46), Vector3(0, 0.26, 0), Vector3(22, 0, 0), _mat_timber)
	_add_box(root, "ParchmentPageL", Vector3(0.24, 0.02, 0.34), Vector3(-0.13, 0.30, 0.02), Vector3(22, 0, -4), _mat_stucco)
	_add_box(root, "ParchmentPageR", Vector3(0.24, 0.02, 0.34), Vector3(0.13, 0.30, 0.02), Vector3(22, 0, 4), _mat_stucco)
	_add_sphere(root, "DeskCandleGlow", 0.055, Vector3(0.24, 0.38, -0.12), _mat_warm_window)

	return root


static func build_trap_prop(kind: int) -> Node3D:
	_ensure_materials()
	var root := Node3D.new()
	root.name = "DetailedTrapProp"

	var mat_hazard_red := StandardMaterial3D.new()
	mat_hazard_red.albedo_color = Color(0.76, 0.14, 0.14)
	mat_hazard_red.roughness = 0.42
	mat_hazard_red.metallic = 0.35

	if kind == 0: # EXPLOSIVE_GAS_CANISTER
		_add_cyl(root, "FuelDrumBody", 0.34, 0.34, 1.12, Vector3(0, 0, 0), Vector3.ZERO, mat_hazard_red)
		for ry in [-0.36, 0.0, 0.36]:
			_add_cyl(root, "DrumRib", 0.36, 0.36, 0.06, Vector3(0, ry, 0), Vector3.ZERO, _mat_wrought_iron)
		_add_cyl(root, "PressureValve", 0.08, 0.08, 0.18, Vector3(0.14, 0.62, 0), Vector3.ZERO, _mat_brass)
	elif kind == 1: # ALPINE_BEAR_TRAP
		_add_cyl(root, "BearTrapBaseRing", 0.38, 0.40, 0.06, Vector3(0, -0.05, 0), Vector3.ZERO, _mat_wrought_iron)
		_add_box(root, "JawLeft", Vector3(0.62, 0.08, 0.14), Vector3(0, 0.02, -0.18), Vector3(25, 0, 0), _mat_wrought_iron)
		_add_box(root, "JawRight", Vector3(0.62, 0.08, 0.14), Vector3(0, 0.02, 0.18), Vector3(-25, 0, 0), _mat_wrought_iron)
		_add_cyl(root, "TriggerPlate", 0.16, 0.16, 0.04, Vector3(0, -0.02, 0), Vector3.ZERO, _mat_brass)
	elif kind == 2: # PROXIMITY_LANDMINE
		_add_cyl(root, "MineCasing", 0.28, 0.32, 0.12, Vector3(0, -0.02, 0), Vector3.ZERO, _mat_wrought_iron)
		_add_sphere(root, "MineSensorLED", 0.065, Vector3(0, 0.06, 0), mat_hazard_red)
	elif kind == 3: # TOXIC_GAS_PIPE
		_add_cyl(root, "RupturedPipeVertical", 0.14, 0.14, 1.75, Vector3(0, 0, 0), Vector3.ZERO, _mat_wrought_iron)
		_add_cyl(root, "PipeFlange", 0.22, 0.22, 0.12, Vector3(0, 0.35, 0), Vector3.ZERO, _mat_brass)
		_add_cyl(root, "ValveWheel", 0.24, 0.24, 0.05, Vector3(0, 0.0, -0.18), Vector3(90, 0, 0), mat_hazard_red)
	else: # FRAGILE_CEILING_ICICLE / CHANDELIER
		_add_cyl(root, "ChandelierRing", 0.68, 0.68, 0.14, Vector3(0, 0.25, 0), Vector3.ZERO, _mat_brass)
		for i in range(6):
			var ang: float = float(i) * TAU / 6.0
			_add_cyl(root, "IcicleSpike", 0.12, 0.01, 0.85, Vector3(sin(ang) * 0.48, -0.22, cos(ang) * 0.48), Vector3.ZERO, _mat_snow_cap)

	return root


static func build_puzzle_station(puzzle_type: String) -> Node3D:
	_ensure_materials()
	var root := Node3D.new()
	root.name = "DetailedPuzzleStation_" + puzzle_type

	if puzzle_type == "clock":
		_add_box(root, "ClockBasePedestal", Vector3(0.92, 0.55, 0.62), Vector3(0, -0.95, 0), Vector3.ZERO, _mat_timber)
		_add_box(root, "ClockWaistCase", Vector3(0.72, 1.25, 0.48), Vector3(0, -0.05, 0), Vector3.ZERO, _mat_timber)
		_add_box(root, "ClockHoodCrown", Vector3(0.88, 0.72, 0.58), Vector3(0, 0.92, 0), Vector3.ZERO, _mat_timber)
		_add_cyl(root, "BrassClockDial", 0.30, 0.30, 0.08, Vector3(0, 0.92, -0.28), Vector3(90, 0, 0), _mat_brass)
		_add_cyl(root, "PendulumRod", 0.02, 0.02, 0.75, Vector3(0, 0.05, -0.25), Vector3.ZERO, _mat_brass)
		_add_cyl(root, "PendulumBob", 0.11, 0.11, 0.04, Vector3(0, -0.32, -0.25), Vector3(90, 0, 0), _mat_brass)
	elif puzzle_type == "organ":
		_add_box(root, "OrganConsole", Vector3(2.2, 1.15, 1.05), Vector3(0, -0.38, 0), Vector3.ZERO, _mat_timber)
		_add_box(root, "IvoryKeyboard", Vector3(1.45, 0.12, 0.35), Vector3(0, 0.18, -0.45), Vector3.ZERO, _mat_stucco)
		for pi in range(9):
			var px: float = -0.88 + float(pi) * 0.22
			var ph: float = 1.45 - absf(float(pi - 4)) * 0.16
			_add_cyl(root, "BrassOrganPipe", 0.065, 0.055, ph, Vector3(px, 0.65, 0.22), Vector3.ZERO, _mat_brass)
	elif puzzle_type == "hydro":
		_add_box(root, "HydroSteelFrame", Vector3(1.55, 0.35, 1.05), Vector3(0, -0.92, 0), Vector3.ZERO, _mat_wrought_iron)
		for ci in [-0.48, 0.0, 0.48]:
			_add_cyl(root, "GlassTankChamber", 0.18, 0.18, 1.55, Vector3(ci, 0.0, 0), Vector3.ZERO, _mat_warm_window)
			_add_cyl(root, "TankBrassCap", 0.21, 0.21, 0.14, Vector3(ci, 0.82, 0), Vector3.ZERO, _mat_brass)
			_add_cyl(root, "ValveHandwheel", 0.14, 0.14, 0.05, Vector3(ci, -0.35, -0.28), Vector3(90, 0, 0), _mat_brass)
	elif puzzle_type == "voltage":
		_add_box(root, "SwitchboardCabinet", Vector3(1.48, 2.05, 0.82), Vector3(0, -0.05, 0), Vector3.ZERO, _mat_wrought_iron)
		for gi in [-0.38, 0.0, 0.38]:
			_add_cyl(root, "VoltmeterDial", 0.14, 0.14, 0.06, Vector3(gi, 0.52, -0.42), Vector3(90, 0, 0), _mat_stucco)
			_add_box(root, "KnifeSwitchLever", Vector3(0.08, 0.32, 0.18), Vector3(gi, -0.05, -0.46), Vector3(-28, 0, 0), _mat_brass)
	elif puzzle_type == "cannon":
		_add_box(root, "NavalCarriage", Vector3(0.95, 0.52, 1.25), Vector3(0, -0.55, 0), Vector3.ZERO, _mat_timber)
		_add_cyl(root, "IronCannonBarrel", 0.14, 0.22, 1.45, Vector3(0, -0.12, -0.15), Vector3(78, 0, 0), _mat_wrought_iron)
		_add_cyl(root, "CompassPedestal", 0.24, 0.24, 0.08, Vector3(0, 0.28, 0.32), Vector3.ZERO, _mat_brass)
	else:
		_add_box(root, "TerminalPedestal", Vector3(1.42, 1.65, 0.88), Vector3(0, -0.15, 0), Vector3.ZERO, _mat_stone)
		_add_box(root, "DiagnosticScreen", Vector3(1.05, 0.68, 0.10), Vector3(0, 0.25, -0.44), Vector3.ZERO, _mat_warm_window)
		_add_box(root, "BrassTrimFrame", Vector3(1.18, 0.80, 0.08), Vector3(0, 0.25, -0.43), Vector3.ZERO, _mat_brass)

	return root


static func _add_box(parent: Node3D, node_name: String, size: Vector3, pos: Vector3, rot_deg: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = node_name
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.material_override = mat
	parent.add_child(mi)
	return mi


static func _add_cyl(parent: Node3D, node_name: String, top_r: float, bot_r: float, height: float, pos: Vector3, rot_deg: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = node_name
	var cm := CylinderMesh.new()
	cm.top_radius = top_r
	cm.bottom_radius = bot_r
	cm.height = height
	cm.radial_segments = 24
	mi.mesh = cm
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.material_override = mat
	parent.add_child(mi)
	return mi


static func _add_capsule(parent: Node3D, node_name: String, radius: float, height: float, pos: Vector3, rot_deg: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = node_name
	var cm := CapsuleMesh.new()
	cm.radius = radius
	cm.height = height
	mi.mesh = cm
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.material_override = mat
	parent.add_child(mi)
	return mi


static func _add_sphere(parent: Node3D, node_name: String, radius: float, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = node_name
	var sm := SphereMesh.new()
	sm.radius = radius
	sm.height = radius * 2.0
	sm.radial_segments = 24
	sm.rings = 16
	mi.mesh = sm
	mi.position = pos
	mi.material_override = mat
	parent.add_child(mi)
	return mi
