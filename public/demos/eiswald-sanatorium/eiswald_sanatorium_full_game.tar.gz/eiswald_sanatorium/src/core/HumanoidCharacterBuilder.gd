class_name HumanoidCharacterBuilder
extends RefCounted
## HumanoidCharacterBuilder.gd
## Generates realistic-proportioned (1:7.5 head-to-body ratio), high-polygon, seamless organic
## 3D human and creature characters using periodic welded SurfaceTool parametric lofting,
## analytical/central-difference smooth vertex normals, sculpted facial topology,
## multi-strand curved hair locks, tailored draped cloth folds, 5-finger hands, and curved boots.

static func _load_skin_material(skin_col: Color = Color(0.92, 0.75, 0.66)) -> Material:
	var sh := load("res://assets/shaders/realistic_human_skin.gdshader") as Shader
	if sh:
		var sm := ShaderMaterial.new()
		sm.shader = sh
		sm.set_shader_parameter("skin_base_color", skin_col)
		return sm
	var std := StandardMaterial3D.new()
	std.albedo_color = skin_col
	std.roughness = 0.44
	return std

static func _load_hair_material(root_c: Color, mid_c: Color, tip_c: Color) -> Material:
	var sh := load("res://assets/shaders/realistic_anisotropic_hair.gdshader") as Shader
	if sh:
		var sm := ShaderMaterial.new()
		sm.shader = sh
		sm.set_shader_parameter("hair_root_color", root_c)
		sm.set_shader_parameter("hair_mid_color", mid_c)
		sm.set_shader_parameter("hair_tip_color", tip_c)
		return sm
	var std := StandardMaterial3D.new()
	std.albedo_color = mid_c
	std.roughness = 0.38
	return std

static func _load_cloth_material(base_c: Color, dark_c: Color, sheen_c: Color, rough: float = 0.68) -> Material:
	var sh := load("res://assets/shaders/realistic_wool_cloth.gdshader") as Shader
	if sh:
		var sm := ShaderMaterial.new()
		sm.shader = sh
		sm.set_shader_parameter("cloth_base_color", base_c)
		sm.set_shader_parameter("cloth_fold_dark", dark_c)
		sm.set_shader_parameter("cloth_sheen_color", sheen_c)
		sm.set_shader_parameter("base_roughness", rough)
		return sm
	var std := StandardMaterial3D.new()
	std.albedo_color = base_c
	std.roughness = rough
	return std


static func build_vera_protagonist() -> Node3D:
	var root := Node3D.new()
	root.name = "VeraDioramaModel"

	# Natural, realistic human skin, hair, and tailored clothing materials
	var mat_skin := _load_skin_material(Color(0.93, 0.77, 0.65))
	var mat_hair := _load_hair_material(
		Color(0.34, 0.18, 0.10),
		Color(0.46, 0.26, 0.14),
		Color(0.58, 0.35, 0.19)
	)
	var mat_cream_blouse := _load_cloth_material(
		Color(0.92, 0.87, 0.77),
		Color(0.76, 0.69, 0.58),
		Color(0.98, 0.95, 0.88),
		0.62
	)
	var mat_dark_strap := _load_cloth_material(
		Color(0.18, 0.11, 0.09),
		Color(0.10, 0.06, 0.05),
		Color(0.28, 0.18, 0.15),
		0.58
	)
	var mat_skirt := _load_cloth_material(
		Color(0.24, 0.11, 0.11),
		Color(0.14, 0.06, 0.06),
		Color(0.36, 0.18, 0.18),
		0.68
	)
	var mat_pants := _load_cloth_material(
		Color(0.91, 0.74, 0.62),
		Color(0.78, 0.60, 0.48),
		Color(0.96, 0.82, 0.70),
		0.52
	)
	var mat_leather := _load_cloth_material(
		Color(0.16, 0.09, 0.07),
		Color(0.08, 0.04, 0.03),
		Color(0.32, 0.20, 0.15),
		0.36
	)

	var mat_brass := StandardMaterial3D.new()
	mat_brass.albedo_color = Color(0.86, 0.69, 0.28)
	mat_brass.metallic = 0.88
	mat_brass.roughness = 0.22

	var mat_gunmetal := StandardMaterial3D.new()
	mat_gunmetal.albedo_color = Color(0.18, 0.20, 0.23)
	mat_gunmetal.metallic = 0.85
	mat_gunmetal.roughness = 0.28

	# ==================== 1. REALISTIC HUMAN FEMALE TORSO (TAILORED BLOUSE + SKIRT) ====================
	var torso_pivot := Node3D.new()
	torso_pivot.name = "TorsoPivot"
	torso_pivot.position = Vector3(0, 0.88, 0)
	root.add_child(torso_pivot)

	# Continuous human shoulders/neck/collarbone + fitted cream blouse + pleated skirt
	var upper_skin_mi := MeshInstance3D.new()
	upper_skin_mi.name = "UpperShouldersSkin"
	upper_skin_mi.mesh = _sculpt_upper_shoulders_skin_mesh(mat_skin)
	torso_pivot.add_child(upper_skin_mi)

	var bodice_mi := MeshInstance3D.new()
	bodice_mi.name = "CreamBlouseBodice"
	bodice_mi.mesh = _sculpt_cream_camisole_bodice_mesh(mat_cream_blouse)
	torso_pivot.add_child(bodice_mi)

	var skirt_mi := MeshInstance3D.new()
	skirt_mi.name = "DarkPleatedSkirt"
	skirt_mi.mesh = _sculpt_pleated_skirt_mesh(mat_skirt)
	torso_pivot.add_child(skirt_mi)

	# Contoured Leather Waist Belt & Brass Buckle
	var belt_mi := MeshInstance3D.new()
	belt_mi.name = "SculptedWaistBelt"
	belt_mi.mesh = _sculpt_waist_belt_mesh(mat_leather)
	torso_pivot.add_child(belt_mi)

	_add_smooth_Ellipsoid(torso_pivot, "BeltBuckleBrass", Vector3(0.028, 0.022, 0.010), Vector3(0, 0.14, -0.102), Vector3.ZERO, mat_brass)

	# ==================== 2. REALISTIC HUMAN HEAD, FACE & NATURAL CHESTNUT BOB HAIR ====================
	var head_pivot := Node3D.new()
	head_pivot.name = "HeadPivot"
	head_pivot.position = Vector3(0, 0.375, 0)
	torso_pivot.add_child(head_pivot)
	head_pivot.scale = Vector3(1.16, 1.12, 1.16) # Natural human head-to-shoulder ratio

	var head_mi := MeshInstance3D.new()
	head_mi.name = "SculptedHumanHead"
	head_mi.mesh = _sculpt_realistic_female_head_mesh(mat_skin)
	head_pivot.add_child(head_mi)

	# Detailed Recessed Human Eyes, Eyelids, Eyelashes, Irises, Pupils, Eyebrows & Natural Lips
	_attach_realistic_human_eyes_and_brows(head_pivot, mat_skin, mat_hair)

	# Natural Layered Chestnut Bob Hair (smooth rounded human crown)
	var hair_node := _build_sculpted_blonde_hair(mat_hair)
	head_pivot.add_child(hair_node)

	# ==================== 3. NATURAL HUMAN SHOULDERS, RELAXED ARMS, HANDS & PISTOL ====================
	var left_arm_pivot := Node3D.new()
	left_arm_pivot.name = "LeftArmPivot"
	left_arm_pivot.position = Vector3(-0.140, 0.355, 0.005)
	torso_pivot.add_child(left_arm_pivot)
	_add_smooth_Ellipsoid(left_arm_pivot, "ShoulderDeltoidCapL", Vector3(0.048, 0.048, 0.046), Vector3(0.006, -0.012, 0), Vector3.ZERO, mat_cream_blouse)
	_build_sculpted_arm_and_hand(left_arm_pivot, -1.0, mat_cream_blouse, mat_dark_strap, mat_skin)

	var right_arm_pivot := Node3D.new()
	right_arm_pivot.name = "RightArmPivot"
	right_arm_pivot.position = Vector3(0.140, 0.355, 0.005)
	torso_pivot.add_child(right_arm_pivot)
	_add_smooth_Ellipsoid(right_arm_pivot, "ShoulderDeltoidCapR", Vector3(0.048, 0.048, 0.046), Vector3(-0.006, -0.012, 0), Vector3.ZERO, mat_cream_blouse)
	_build_sculpted_arm_and_hand(right_arm_pivot, 1.0, mat_cream_blouse, mat_dark_strap, mat_skin)

	# Detailed 3D VP-9 Tactical Pistol with Under-Barrel Laser Sight in Right Hand
	var weapon_node := _build_detailed_pistol_model(mat_gunmetal, mat_leather, mat_brass)
	weapon_node.position = Vector3(0.032, -0.45, -0.115)
	right_arm_pivot.add_child(weapon_node)

	# ==================== 4. ANATOMICAL LEGS, KNEES, CALVES & CURVED LEATHER BOOTS ====================
	var left_leg_pivot := Node3D.new()
	left_leg_pivot.name = "LeftLegPivot"
	left_leg_pivot.position = Vector3(-0.082, 0.78, 0.0)
	root.add_child(left_leg_pivot)
	_build_sculpted_leg_and_boot(left_leg_pivot, -1.0, mat_pants, mat_leather, mat_brass)

	var right_leg_pivot := Node3D.new()
	right_leg_pivot.name = "RightLegPivot"
	right_leg_pivot.position = Vector3(0.082, 0.78, 0.0)
	root.add_child(right_leg_pivot)
	_build_sculpted_leg_and_boot(right_leg_pivot, 1.0, mat_pants, mat_leather, mat_brass)

	return root


# ==============================================================================
# REALISTIC ANATOMICAL SCULPTING FUNCTIONS (WELDED PERIODIC PARAMETRIC MESHES)
# ==============================================================================

static func _sculpt_realistic_female_head_mesh(mat_skin: Material) -> ArrayMesh:
	# 44 vertical slices from neck base (y=0.0) to skull crown (y=0.295), 48 radial segments
	# True adult human head proportion: width ~15.2cm (radius 0.076), depth ~18.5cm (radius 0.092)
	var v_steps: int = 44
	var u_steps: int = 48
	var grid: Array = []

	for iv in range(v_steps + 1):
		var v: float = float(iv) / float(v_steps)
		var y: float = v * 0.295
		var ring: Array[Vector3] = []

		for iu in range(u_steps):
			var u: float = float(iu) / float(u_steps)
			# theta = 0 is directly forward (-Z face), +PI/2 is right (+X), PI is back (+Z), -PI/2 is left (-X)
			var theta: float = u * TAU
			var sin_t: float = sin(theta)
			var cos_t: float = cos(theta)
			# Angular distance from front centerline (0 at front face, PI at back of skull)
			var ang_front: float = atan2(sin_t, cos_t)
			var abs_ang: float = absf(ang_front)

			var rx: float = 0.048
			var rz: float = 0.052
			var z_shift: float = 0.0

			if v < 0.28:
				# Graceful cylindrical human neck flaring slightly at base and under-jaw
				var t_neck: float = v / 0.28
				rx = lerpf(0.054, 0.047, sin(t_neck * PI * 0.75))
				rz = lerpf(0.056, 0.050, sin(t_neck * PI * 0.75))
				z_shift = lerpf(0.008, 0.002, t_neck)
			else:
				# Cranium & Facial envelope from chin (v=0.28) to crown (v=1.0)
				var vh: float = (v - 0.28) / 0.72 # 0.0 at chin/under-jaw, 1.0 at top of skull
				# Smooth ovoid skull profile
				var profile: float = sin(pow(clampf(vh, 0.001, 0.999), 0.58) * PI)
				rx = 0.075 * profile
				rz = 0.088 * profile

				# Tapering feminine V-line jaw and chin on the front half (cos_t > 0)
				var jaw_zone: float = smoothstep(0.48, 0.02, vh) * maxf(0.0, cos_t)
				rx *= (1.0 - 0.34 * jaw_zone * absf(sin_t))

				# Forward chin projection at vh ~ 0.08
				var chin_bump: float = exp(-pow((vh - 0.08) / 0.09, 2.0)) * exp(-pow(abs_ang / 0.38, 2.0))
				rz += 0.015 * chin_bump

				# Under-chin / submental contour transition to neck
				var under_chin: float = exp(-pow((vh - 0.01) / 0.06, 2.0)) * maxf(0.0, cos_t)
				rz += 0.018 * under_chin

				# Cheekbones (Zygomatic arch fullness around vh=0.44, abs_ang=0.58)
				var cheek: float = exp(-pow((vh - 0.44) / 0.14, 2.0)) * exp(-pow((abs_ang - 0.56) / 0.28, 2.0))
				rx += 0.007 * cheek
				rz += 0.006 * cheek

				# Recessed Eye Sockets (Orbital hollows at vh=0.56, abs_ang=0.36)
				var eye_socket: float = exp(-pow((vh - 0.56) / 0.085, 2.0)) * exp(-pow((abs_ang - 0.36) / 0.18, 2.0))
				rz -= 0.010 * eye_socket

				# Supraorbital Brow Ridge (gentle arch above eyes at vh=0.64)
				var brow: float = exp(-pow((vh - 0.64) / 0.055, 2.0)) * exp(-pow((abs_ang - 0.32) / 0.26, 2.0))
				rz += 0.005 * brow

				# Sculpted Human Nose (Bridge, Dorsum, Tip at vh=0.40, and Nostrils/Alae)
				var nose_v: float = smoothstep(0.32, 0.40, vh) * (1.0 - smoothstep(0.41, 0.63, vh))
				var nose_tip_peak: float = exp(-pow((vh - 0.40) / 0.065, 2.0))
				var nose_center: float = exp(-pow(abs_ang / 0.13, 2.0))
				var nose_nostrils: float = exp(-pow((vh - 0.38) / 0.045, 2.0)) * exp(-pow((abs_ang - 0.14) / 0.08, 2.0))
				rz += (0.014 * nose_v + 0.010 * nose_tip_peak) * nose_center + 0.006 * nose_nostrils

				# Sculpted Upper & Lower Lips with Mouth Part Line
				var mouth_w: float = exp(-pow(abs_ang / 0.24, 2.0))
				var upper_lip: float = exp(-pow((vh - 0.265) / 0.032, 2.0)) * mouth_w
				var lower_lip: float = exp(-pow((vh - 0.215) / 0.036, 2.0)) * mouth_w
				var mouth_crevice: float = exp(-pow((vh - 0.240) / 0.014, 2.0)) * mouth_w
				rz += 0.008 * upper_lip + 0.009 * lower_lip - 0.005 * mouth_crevice

				# Sculpted Ears on Left & Right sides (abs_ang ~ PI/2, vh ~ 0.48)
				var ear_mask: float = exp(-pow((vh - 0.48) / 0.11, 2.0)) * exp(-pow((abs_ang - 1.52) / 0.14, 2.0))
				rx += 0.013 * ear_mask

				# Back of skull (occipital fullness)
				var occiput: float = exp(-pow((vh - 0.58) / 0.24, 2.0)) * maxf(0.0, -cos_t)
				rz += 0.010 * occiput
				z_shift = -0.006 * smoothstep(0.0, 0.35, vh)

			var px: float = rx * sin_t
			var pz: float = -rz * cos_t + z_shift
			ring.append(Vector3(px, y, pz))

		grid.append(ring)

	return _build_welded_grid_mesh(grid, true, false, true, mat_skin)


static func _attach_realistic_human_eyes_and_brows(head_pivot: Node3D, _mat_skin: Material, mat_hair: Material) -> void:
	var mat_sclera := StandardMaterial3D.new()
	mat_sclera.albedo_color = Color(0.97, 0.97, 0.99)
	mat_sclera.roughness = 0.14
	mat_sclera.specular = 0.75

	var mat_iris := StandardMaterial3D.new()
	mat_iris.albedo_color = Color(0.20, 0.42, 0.60)
	mat_iris.roughness = 0.12
	mat_iris.specular = 0.85

	var mat_pupil := StandardMaterial3D.new()
	mat_pupil.albedo_color = Color(0.04, 0.04, 0.05)
	mat_pupil.roughness = 0.10

	var mat_spec_dot := StandardMaterial3D.new()
	mat_spec_dot.albedo_color = Color(1.0, 1.0, 1.0)
	mat_spec_dot.emission_enabled = true
	mat_spec_dot.emission = Color(1.0, 1.0, 1.0)
	mat_spec_dot.emission_energy_multiplier = 1.2

	var mat_lash := StandardMaterial3D.new()
	mat_lash.albedo_color = Color(0.14, 0.11, 0.09)
	mat_lash.roughness = 0.45

	# Eyes sit recessed in the sculpted orbital sockets at y = 0.202, x = +/- 0.029, z = -0.078
	for side in [-1.0, 1.0]:
		var eye_pos := Vector3(side * 0.028, 0.202, -0.079)
		_add_smooth_Ellipsoid(head_pivot, "EyeballSclera", Vector3(0.013, 0.011, 0.011), eye_pos, Vector3(0, side * -8.0, 0), mat_sclera)
		_add_smooth_Ellipsoid(head_pivot, "EyeIris", Vector3(0.0075, 0.0075, 0.004), eye_pos + Vector3(side * 0.0005, 0.0, -0.0085), Vector3(0, side * -8.0, 0), mat_iris)
		_add_smooth_Ellipsoid(head_pivot, "EyePupil", Vector3(0.0040, 0.0040, 0.003), eye_pos + Vector3(side * 0.0005, 0.0, -0.0102), Vector3(0, side * -8.0, 0), mat_pupil)
		_add_smooth_Ellipsoid(head_pivot, "CorneaCatchlight", Vector3(0.0018, 0.0018, 0.0015), eye_pos + Vector3(side * 0.0025, 0.0022, -0.0115), Vector3.ZERO, mat_spec_dot)

		# Curved upper eyelash arch & eyebrow curve (smooth curved lofted strips, never boxes!)
		var lash_mi := MeshInstance3D.new()
		lash_mi.mesh = _sculpt_curved_strip_mesh(
			Vector3(side * 0.017, 0.205, -0.088),
			Vector3(side * 0.029, 0.210, -0.090),
			Vector3(side * 0.040, 0.204, -0.084),
			0.0032, 0.0022, mat_lash
		)
		head_pivot.add_child(lash_mi)

		var brow_mi := MeshInstance3D.new()
		brow_mi.mesh = _sculpt_curved_strip_mesh(
			Vector3(side * 0.014, 0.222, -0.087),
			Vector3(side * 0.030, 0.228, -0.088),
			Vector3(side * 0.044, 0.220, -0.080),
			0.0048, 0.0028, mat_hair
		)
		head_pivot.add_child(brow_mi)

	# Subtle natural rosy-nude lips
	var mat_lip := StandardMaterial3D.new()
	mat_lip.albedo_color = Color(0.76, 0.44, 0.42)
	mat_lip.roughness = 0.42
	_add_smooth_Ellipsoid(head_pivot, "UpperLip", Vector3(0.017, 0.0042, 0.006), Vector3(0, 0.137, -0.092), Vector3.ZERO, mat_lip)
	_add_smooth_Ellipsoid(head_pivot, "LowerLip", Vector3(0.014, 0.0048, 0.006), Vector3(0, 0.130, -0.091), Vector3.ZERO, mat_lip)


static func _build_sculpted_blonde_hair(mat_hair: Material) -> Node3D:
	var hair_root := Node3D.new()
	hair_root.name = "SculptedHumanBobHair"

	# 1. Smooth Sculpted Human Bob Hair Volume hugging the cranium naturally
	var cap_mi := MeshInstance3D.new()
	cap_mi.name = "HairBaseCap"
	cap_mi.mesh = _sculpt_hair_cap_mesh(mat_hair)
	hair_root.add_child(cap_mi)

	# 2. Soft Side-Swept Forehead Bangs & Cheek-Framing Side Locks
	var bangs_specs: Array[Dictionary] = [
		{
			"p0": Vector3(-0.020, 0.284, -0.032),
			"p1": Vector3(0.014, 0.264, -0.088),
			"p2": Vector3(0.046, 0.236, -0.090),
			"p3": Vector3(0.064, 0.195, -0.068),
			"w": 0.030
		},
		{
			"p0": Vector3(-0.024, 0.282, -0.036),
			"p1": Vector3(-0.005, 0.258, -0.090),
			"p2": Vector3(0.024, 0.234, -0.092),
			"p3": Vector3(0.048, 0.205, -0.078),
			"w": 0.024
		},
		{
			"p0": Vector3(-0.028, 0.280, -0.028),
			"p1": Vector3(-0.052, 0.250, -0.082),
			"p2": Vector3(-0.068, 0.202, -0.072),
			"p3": Vector3(-0.064, 0.125, -0.054),
			"w": 0.028
		},
		{
			"p0": Vector3(0.028, 0.280, -0.028),
			"p1": Vector3(0.056, 0.250, -0.078),
			"p2": Vector3(0.070, 0.200, -0.068),
			"p3": Vector3(0.066, 0.125, -0.050),
			"w": 0.028
		}
	]
	for b in bangs_specs:
		var bmi := MeshInstance3D.new()
		bmi.mesh = _sculpt_tapered_hair_lock(b["p0"], b["p1"], b["p2"], b["p3"], b["w"], 0.007, mat_hair)
		hair_root.add_child(bmi)

	return hair_root


static func _sculpt_hair_cap_mesh(mat_hair: Material) -> ArrayMesh:
	var v_steps: int = 28
	var u_steps: int = 40
	var grid: Array = []

	for iv in range(v_steps + 1):
		var v: float = float(iv) / float(v_steps) # 0.0 at nape/jaw (y=0.075), 1.0 at crown (y=0.302)
		var y: float = lerpf(0.075, 0.302, v)
		var ring: Array[Vector3] = []

		for iu in range(u_steps):
			var u: float = float(iu) / float(u_steps)
			var theta: float = u * TAU
			var sin_t: float = sin(theta)
			var cos_t: float = cos(theta)

			# Smooth rounded human skull-dome hair profile (closes cleanly at v=1.0 without a pointy cone)
			var crown_dome: float = sin(pow(clampf(v, 0.02, 0.9999), 0.58) * PI)
			var strand_wave: float = sin(theta * 18.0) * 0.0012 * (1.0 - v)
			var rx: float = 0.090 * crown_dome + strand_wave
			var rz: float = 0.102 * crown_dome + strand_wave

			# Open up the front face region so the sculpted human face is completely clear
			var front_cut: float = maxf(0.0, cos_t) * smoothstep(0.68, 0.18, v)
			rz -= 0.044 * front_cut
			var py: float = y

			# Taper smoothly into the nape of the human neck (v < 0.20)
			var nape_taper: float = smoothstep(0.20, 0.0, v)
			rx *= (1.0 - 0.18 * nape_taper)
			rz *= (1.0 - 0.16 * nape_taper)

			ring.append(Vector3(rx * sin_t, py, -rz * cos_t + 0.008))
		grid.append(ring)

	return _build_welded_grid_mesh(grid, true, false, true, mat_hair)


static func _sculpt_upper_shoulders_skin_mesh(mat_skin: Material) -> ArrayMesh:
	# Anatomical human collarbone & upper chest (y=0.33..0.39) connecting seamlessly to head neck
	var v_steps: int = 12
	var u_steps: int = 40
	var grid: Array = []

	for iv in range(v_steps + 1):
		var v: float = float(iv) / float(v_steps)
		var y: float = lerpf(0.33, 0.39, v)
		var ring: Array[Vector3] = []
		var shoulder_curve: float = smoothstep(0.0, 0.85, v)
		var rx: float = lerpf(0.148, 0.060, shoulder_curve)
		var rz: float = lerpf(0.096, 0.060, shoulder_curve)
		for iu in range(u_steps):
			var theta: float = (float(iu) / float(u_steps)) * TAU
			ring.append(Vector3(rx * sin(theta), y, -rz * cos(theta)))
		grid.append(ring)

	return _build_welded_grid_mesh(grid, true, false, false, mat_skin)


static func _sculpt_cream_camisole_bodice_mesh(mat_bodice: Material) -> ArrayMesh:
	# Fitted cream-white camisole bodice from waist (y=0.12) to upper chest/back neckline (y=0.36)
	var v_steps: int = 24
	var u_steps: int = 44
	var grid: Array = []

	for iv in range(v_steps + 1):
		var v: float = float(iv) / float(v_steps)
		var y: float = lerpf(0.12, 0.36, v)
		var ring: Array[Vector3] = []
		for iu in range(u_steps):
			var theta: float = (float(iu) / float(u_steps)) * TAU
			var sin_t: float = sin(theta)
			var cos_t: float = cos(theta)
			var ang_front: float = atan2(sin_t, cos_t)

			var rx: float = lerpf(0.114, 0.146, smoothstep(0.0, 0.85, v))
			var rz: float = lerpf(0.090, 0.102, smoothstep(0.0, 0.65, v))

			# Anatomical female bust contour on front chest
			var bust_v: float = exp(-pow((v - 0.68) / 0.22, 2.0))
			var bust_l: float = exp(-pow((ang_front + 0.40) / 0.34, 2.0))
			var bust_r: float = exp(-pow((ang_front - 0.40) / 0.34, 2.0))
			rz += 0.022 * bust_v * (bust_l + bust_r)

			ring.append(Vector3(rx * sin_t, y, -rz * cos_t))
		grid.append(ring)

	return _build_welded_grid_mesh(grid, true, false, false, mat_bodice)


static func _sculpt_pleated_skirt_mesh(mat_skirt: Material) -> ArrayMesh:
	# Flared dark pleated skirt from hem (y=-0.26) up to belted waist (y=0.13)
	var v_steps: int = 24
	var u_steps: int = 44
	var grid: Array = []

	for iv in range(v_steps + 1):
		var v: float = float(iv) / float(v_steps)
		var y: float = lerpf(-0.26, 0.13, v)
		var ring: Array[Vector3] = []
		for iu in range(u_steps):
			var theta: float = (float(iu) / float(u_steps)) * TAU
			var rx: float = lerpf(0.205, 0.114, pow(v, 0.78))
			var rz: float = lerpf(0.168, 0.090, pow(v, 0.78))
			var pleat: float = cos(theta * 10.0) * (1.0 - v) * 0.009
			ring.append(Vector3((rx + pleat) * sin(theta), y, -(rz + pleat) * cos(theta)))
		grid.append(ring)

	return _build_welded_grid_mesh(grid, true, false, false, mat_skirt)


static func _sculpt_waist_belt_mesh_at_height(center_y: float, rx_base: float, rz_base: float, band_h: float, mat_band: Material) -> ArrayMesh:
	var v_steps: int = 6
	var u_steps: int = 36
	var grid: Array = []
	for iv in range(v_steps + 1):
		var v: float = float(iv) / float(v_steps)
		var y: float = lerpf(center_y - band_h * 0.5, center_y + band_h * 0.5, v)
		var profile: float = 1.0 + 0.025 * sin(v * PI)
		var ring: Array[Vector3] = []
		for iu in range(u_steps):
			var theta: float = (float(iu) / float(u_steps)) * TAU
			ring.append(Vector3(rx_base * profile * sin(theta), y, -rz_base * profile * cos(theta)))
		grid.append(ring)
	return _build_welded_grid_mesh(grid, true, false, false, mat_band)


static func _sculpt_tapered_hair_lock(p0: Vector3, p1: Vector3, p2: Vector3, p3: Vector3, max_width: float, max_thick: float, mat_hair: Material) -> ArrayMesh:
	var v_steps: int = 16
	var u_steps: int = 12
	var grid: Array = []

	for iv in range(v_steps + 1):
		var t: float = float(iv) / float(v_steps)
		var center: Vector3 = _cubic_bezier(p0, p1, p2, p3, t)
		var tangent: Vector3 = _cubic_bezier_deriv(p0, p1, p2, p3, t).normalized()
		var radial_out: Vector3 = Vector3(center.x, 0.0, center.z).normalized()
		if radial_out.length_squared() < 0.001:
			radial_out = Vector3.BACK
		var side_vec: Vector3 = tangent.cross(radial_out).normalized()
		var out_vec: Vector3 = side_vec.cross(tangent).normalized()

		# Smooth root-to-tip width and thickness taper (feathered tip at t=1.0)
		var env: float = sin(pow(clampf(t, 0.02, 0.995), 0.65) * PI)
		var w: float = max_width * (0.35 + 0.65 * env) * (1.0 - 0.72 * pow(t, 2.2))
		var th: float = max_thick * (0.4 + 0.6 * env) * (1.0 - 0.75 * pow(t, 2.0))

		var ring: Array[Vector3] = []
		for iu in range(u_steps):
			var ang: float = (float(iu) / float(u_steps)) * TAU
			var local_x: float = sin(ang) * w * 0.5
			var local_z: float = cos(ang) * th * 0.5 + cos(sin(ang) * 1.4) * 0.002
			ring.append(center + side_vec * local_x + out_vec * local_z)
		grid.append(ring)

	return _build_welded_grid_mesh(grid, true, true, true, mat_hair)


static func _sculpt_female_trenchcoat_mesh(mat_coat: Material) -> ArrayMesh:
	# Continuous welded 44 x 48 mesh from collar/neck base (y=0.50) down through shoulders (y=0.43),
	# female bust/chest (y=0.29), belted waist (y=0.14), hips (y=0.0), to flared trenchcoat hem (y=-0.34)
	var v_steps: int = 44
	var u_steps: int = 48
	var grid: Array = []

	for iv in range(v_steps + 1):
		var v: float = float(iv) / float(v_steps) # 0.0 at bottom coat hem (y=-0.34), 1.0 at collar base (y=0.50)
		var y: float = lerpf(-0.34, 0.50, v)
		var ring: Array[Vector3] = []

		for iu in range(u_steps):
			var u: float = float(iu) / float(u_steps)
			var theta: float = u * TAU
			var sin_t: float = sin(theta)
			var cos_t: float = cos(theta)
			var ang_front: float = atan2(sin_t, cos_t)

			# Base anatomical torso & flared skirt radii along v
			var rx: float = 0.14
			var rz: float = 0.10

			if v < 0.56:
				# Lower trenchcoat skirt from hem (v=0.0, y=-0.34) to belted waist (v=0.56, y=0.13)
				var ts: float = v / 0.56 # 0 at hem, 1 at waist
				rx = lerpf(0.215, 0.112, pow(ts, 0.78))
				rz = lerpf(0.175, 0.088, pow(ts, 0.78))

				# Natural vertical wool trenchcoat drapery folds (8 soft pleats fading out at waist)
				var pleat: float = cos(theta * 8.0) * (1.0 - ts) * 0.011
				rx += pleat
				rz += pleat

				# Subtle front coat-tail center overlap parting near bottom hem
				var front_split: float = exp(-pow(ang_front / 0.16, 2.0)) * (1.0 - ts)
				rz -= 0.014 * front_split
			elif v < 0.90:
				# Upper torso from belted waist (v=0.56, y=0.13) through bust (v=0.75, y=0.29) to shoulders (v=0.90, y=0.42)
				var tu: float = (v - 0.56) / 0.34
				rx = lerpf(0.112, 0.172, smoothstep(0.0, 0.85, tu))
				rz = lerpf(0.088, 0.104, smoothstep(0.0, 0.65, tu))

				# Natural anatomical female bust contour on front chest (v ~ 0.74, ang_front ~ +/- 0.42)
				var bust_v: float = exp(-pow((v - 0.74) / 0.095, 2.0))
				var bust_l: float = exp(-pow((ang_front + 0.40) / 0.34, 2.0))
				var bust_r: float = exp(-pow((ang_front - 0.40) / 0.34, 2.0))
				rz += 0.022 * bust_v * (bust_l + bust_r)
			else:
				# Shoulder slope tapering smoothly into the neck/collar base (v=0.90 .. 1.0)
				var tn: float = (v - 0.90) / 0.10
				rx = lerpf(0.172, 0.064, smoothstep(0.0, 1.0, tn))
				rz = lerpf(0.104, 0.062, smoothstep(0.0, 1.0, tn))

			ring.append(Vector3(rx * sin_t, y, -rz * cos_t))
		grid.append(ring)

	return _build_welded_grid_mesh(grid, true, false, false, mat_coat)


static func _sculpt_coat_collar_and_lapels(mat_lapel: Material) -> ArrayMesh:
	# Smoothly curved popped trenchcoat collar & V-neck lapels hugging the chest
	var v_steps: int = 20
	var u_steps: int = 32
	var grid: Array = []

	for iv in range(v_steps + 1):
		var v: float = float(iv) / float(v_steps) # 0.0 at lower chest lapel tip (y=0.20), 1.0 at popped collar rim (y=0.53)
		var y: float = lerpf(0.20, 0.53, v)
		var ring: Array[Vector3] = []

		for iu in range(u_steps):
			var u: float = float(iu) / float(u_steps)
			var theta: float = u * TAU
			var sin_t: float = sin(theta)
			var cos_t: float = cos(theta)
			var abs_ang: float = absf(atan2(sin_t, cos_t))

			var rx: float = lerpf(0.115, 0.088, v)
			var rz: float = lerpf(0.122, 0.086, v)
			# Pop outward slightly at top collar rim
			var flare: float = smoothstep(0.65, 1.0, v) * 0.014
			rx += flare
			rz += flare

			# Fold lapel wings outward on front chest
			var lapel_fold: float = exp(-pow((abs_ang - 0.45) / 0.25, 2.0)) * (1.0 - v * 0.5)
			rz += 0.012 * lapel_fold

			ring.append(Vector3(rx * sin_t, y, -rz * cos_t))
		grid.append(ring)

	return _build_welded_grid_mesh(grid, true, false, false, mat_lapel)


static func _sculpt_waist_belt_mesh(mat_leather: Material) -> ArrayMesh:
	var v_steps: int = 8
	var u_steps: int = 40
	var grid: Array = []

	for iv in range(v_steps + 1):
		var v: float = float(iv) / float(v_steps)
		var y: float = lerpf(0.115, 0.162, v)
		var profile: float = 1.0 + 0.03 * sin(v * PI)
		var ring: Array[Vector3] = []
		for iu in range(u_steps):
			var theta: float = (float(iu) / float(u_steps)) * TAU
			var rx: float = 0.118 * profile
			var rz: float = 0.094 * profile
			ring.append(Vector3(rx * sin(theta), y, -rz * cos(theta)))
		grid.append(ring)

	return _build_welded_grid_mesh(grid, true, false, false, mat_leather)


static func _sculpt_draped_scarf_mesh(mat_scarf: Material) -> ArrayMesh:
	# Soft, organic knitted wool scarf wrapped around the neck with natural wavy folds
	var v_steps: int = 16
	var u_steps: int = 40
	var grid: Array = []

	for iv in range(v_steps + 1):
		var v: float = float(iv) / float(v_steps)
		var y: float = lerpf(0.445, 0.545, v)
		var torus_bulge: float = sin(v * PI)
		var ring: Array[Vector3] = []
		for iu in range(u_steps):
			var theta: float = (float(iu) / float(u_steps)) * TAU
			var wave: float = sin(theta * 5.0 + v * 3.0) * 0.005
			var rx: float = 0.082 + 0.022 * torus_bulge + wave
			var rz: float = 0.080 + 0.024 * torus_bulge + wave
			var drape_y: float = y - 0.018 * maxf(0.0, cos(theta)) * (1.0 - v * 0.5)
			ring.append(Vector3(rx * sin(theta), drape_y, -rz * cos(theta)))
		grid.append(ring)

	return _build_welded_grid_mesh(grid, true, false, false, mat_scarf)


static func _build_sculpted_arm_and_hand(arm_pivot: Node3D, side: float, mat_sleeve: Material, _mat_cuff: Material, mat_skin: Material) -> void:
	# 1. Natural relaxed human arm (deltoid -> upper arm -> slightly bent elbow -> forearm -> wrist)
	var arm_mi := MeshInstance3D.new()
	arm_mi.name = "SculptedHumanArm"
	var p0 := Vector3(0.0, 0.0, 0.0)
	var p1 := Vector3(side * 0.032, -0.14, 0.018)
	var p2 := Vector3(side * 0.044, -0.26, 0.012)
	var p3 := Vector3(side * 0.030, -0.43, -0.048)
	arm_mi.mesh = _sculpt_sleeve_tube_mesh(p0, p1, p2, p3, mat_skin)
	arm_pivot.add_child(arm_mi)

	# 2. Tailored Short Blouse Sleeve covering only the shoulder & upper bicep (t = 0.0 .. 0.36)
	var sleeve_mi := MeshInstance3D.new()
	sleeve_mi.name = "ShortBlouseSleeve"
	var sp1 := p0.lerp(p1, 0.55)
	var sp2 := p1
	var sp3 := p1.lerp(p2, 0.45)
	sleeve_mi.mesh = _sculpt_sleeve_tube_mesh(p0, sp1, sp2, sp3, mat_sleeve, true)
	arm_pivot.add_child(sleeve_mi)

	# 3. Sculpted Human Hand with Palm, Thumb & 4 Articulated Tapered Fingers
	var hand_root := Node3D.new()
	hand_root.name = "SculptedHumanHand"
	hand_root.position = Vector3(side * 0.030, -0.445, -0.060)
	arm_pivot.add_child(hand_root)

	# Sculpted Palm & Metacarpals
	_add_smooth_Ellipsoid(hand_root, "HandPalm", Vector3(0.022, 0.034, 0.014), Vector3(0, -0.015, -0.008), Vector3(18, 0, side * -6.0), mat_skin)

	# Sculpted Thumb (3-point curved bezier digit)
	var thumb_mi := MeshInstance3D.new()
	thumb_mi.mesh = _sculpt_tapered_hair_lock(
		Vector3(-side * 0.014, -0.008, -0.006),
		Vector3(-side * 0.024, -0.022, -0.018),
		Vector3(-side * 0.022, -0.036, -0.028),
		Vector3(-side * 0.016, -0.045, -0.034),
		0.014, 0.013, mat_skin
	)
	hand_root.add_child(thumb_mi)

	# 4 Sculpted Fingers (Index, Middle, Ring, Little) slightly curled in natural human posture
	var finger_offsets: Array[float] = [-0.013, -0.004, 0.005, 0.013]
	var finger_lengths: Array[float] = [0.038, 0.042, 0.039, 0.032]
	for fi in range(4):
		var fx: float = finger_offsets[fi] * side
		var flen: float = finger_lengths[fi]
		var f_mi := MeshInstance3D.new()
		f_mi.mesh = _sculpt_tapered_hair_lock(
			Vector3(fx, -0.038, -0.012),
			Vector3(fx, -0.038 - flen * 0.42, -0.020),
			Vector3(fx * 0.9, -0.038 - flen * 0.78, -0.016),
			Vector3(fx * 0.8, -0.038 - flen * 0.95, -0.006),
			0.011, 0.010, mat_skin
		)
		hand_root.add_child(f_mi)


static func _sculpt_sleeve_tube_mesh(p0: Vector3, p1: Vector3, p2: Vector3, p3: Vector3, mat_coat: Material, is_short_sleeve: bool = false) -> ArrayMesh:
	var v_steps: int = 24
	var u_steps: int = 24
	var grid: Array = []

	# Iterate from bottom (t=1.0) to top (t=0.0) so triangle winding faces OUTWARD
	for iv in range(v_steps + 1):
		var t: float = 1.0 - (float(iv) / float(v_steps))
		var center: Vector3 = _cubic_bezier(p0, p1, p2, p3, t)
		var tangent: Vector3 = _cubic_bezier_deriv(p0, p1, p2, p3, t).normalized()
		var side_vec: Vector3 = tangent.cross(Vector3.FORWARD).normalized()
		if side_vec.length_squared() < 0.001:
			side_vec = Vector3.RIGHT
		var out_vec: Vector3 = side_vec.cross(tangent).normalized()

		var base_r: float
		if is_short_sleeve:
			# Tailored cap/short sleeve tapering smoothly from ShoulderDeltoidCap
			base_r = lerpf(0.044, 0.046, t) + sin(t * PI) * 0.005
		else:
			# Anatomical female arm: deltoid (0.044) -> bicep/tricep -> elbow -> tapered wrist (0.026)
			base_r = lerpf(0.044, 0.026, pow(t, 0.85))

		var ring: Array[Vector3] = []
		for iu in range(u_steps):
			var theta: float = (float(iu) / float(u_steps)) * TAU
			var r: float = base_r
			ring.append(center + side_vec * (sin(theta) * r) + out_vec * (cos(theta) * r * 0.94))
		grid.append(ring)

	return _build_welded_grid_mesh(grid, true, false, false, mat_coat)


static func _build_sculpted_leg_and_boot(leg_pivot: Node3D, _side: float, mat_pants: Material, mat_leather: Material, mat_brass: Material) -> void:
	# 1. Continuous Anatomical Female Leg (Thigh -> Knee -> Gastrocnemius Calf -> Ankle, y = 0.0 down to -0.58)
	var leg_mi := MeshInstance3D.new()
	leg_mi.name = "SculptedAnatomicalLeg"
	leg_mi.mesh = _sculpt_anatomical_leg_mesh(mat_pants)
	leg_pivot.add_child(leg_mi)

	# 2. Continuous Sculpted Curved Leather Winter Boot (Ankle shaft -> Instep arch -> Rounded Toe Box & Heel, y = -0.48 to -0.78)
	var boot_mi := MeshInstance3D.new()
	boot_mi.name = "SculptedCurvedLeatherBoot"
	boot_mi.mesh = _sculpt_curved_winter_boot_mesh(mat_leather)
	leg_pivot.add_child(boot_mi)

	# Brass Boot Buckle Strap at ankle
	_add_smooth_Ellipsoid(leg_pivot, "BootAnkleBuckle", Vector3(0.012, 0.012, 0.006), Vector3(0.0, -0.62, -0.048), Vector3.ZERO, mat_brass)


static func _sculpt_anatomical_leg_mesh(mat_pants: Material) -> ArrayMesh:
	var v_steps: int = 24
	var u_steps: int = 28
	var grid: Array = []

	for iv in range(v_steps + 1):
		var v: float = float(iv) / float(v_steps) # 0.0 at ankle (y=-0.60), 1.0 at upper thigh (y=0.0)
		var y: float = lerpf(-0.60, 0.0, v)
		var ring: Array[Vector3] = []

		for iu in range(u_steps):
			var theta: float = (float(iu) / float(u_steps)) * TAU
			var sin_t: float = sin(theta)
			var cos_t: float = cos(theta)

			# Anatomical thigh taper (v=0.55..1.0), knee narrowing (v=0.48), calf muscle swell (v=0.28), slim ankle (v=0.0)
			var r_base: float = lerpf(0.038, 0.072, pow(v, 0.75))
			var knee_indent: float = exp(-pow((v - 0.48) / 0.09, 2.0)) * 0.006
			var calf_muscle: float = exp(-pow((v - 0.28) / 0.13, 2.0)) * maxf(0.0, -cos_t) * 0.014
			var kneecap: float = exp(-pow((v - 0.49) / 0.07, 2.0)) * maxf(0.0, cos_t) * 0.007

			var rx: float = r_base - knee_indent
			var rz: float = r_base - knee_indent + calf_muscle + kneecap
			var z_off: float = -0.008 * calf_muscle

			ring.append(Vector3(rx * sin_t, y, -rz * cos_t + z_off))
		grid.append(ring)

	return _build_welded_grid_mesh(grid, true, false, true, mat_pants)


static func _sculpt_curved_winter_boot_mesh(mat_leather: Material) -> ArrayMesh:
	# Seamless curved boot lofted from sole (v=0.0, y=-0.78) through rounded toe & instep arch up to mid-calf shaft (v=1.0, y=-0.47)
	var v_steps: int = 24
	var u_steps: int = 28
	var grid: Array = []

	for iv in range(v_steps + 1):
		var v: float = float(iv) / float(v_steps) # 0.0 at boot sole (y=-0.78), 1.0 at top of boot shaft (y=-0.47)
		var y: float = lerpf(-0.78, -0.47, v)
		var ring: Array[Vector3] = []

		# Foot curves forward along -Z for v in [0.0, 0.34]
		var foot_curve: float = exp(-pow((v - 0.10) / 0.14, 2.0))
		var z_center: float = -0.042 * foot_curve

		for iu in range(u_steps):
			var theta: float = (float(iu) / float(u_steps)) * TAU
			var sin_t: float = sin(theta)
			var cos_t: float = cos(theta)

			var rx: float = lerpf(0.048, 0.052, v)
			var rz: float = lerpf(0.048, 0.054, v)

			# Extend the front (-Z, cos_t > 0) smoothly forward to sculpt the anatomical rounded boot toe & sloped instep!
			var toe_extension: float = maxf(0.0, cos_t) * foot_curve * 0.072
			var heel_extension: float = maxf(0.0, -cos_t) * smoothstep(0.32, 0.0, v) * 0.016
			rz += toe_extension + heel_extension

			# Flatten sole at bottom (v < 0.06)
			var py: float = y
			if v < 0.08:
				py = lerpf(-0.78, y, v / 0.08)

			ring.append(Vector3(rx * sin_t, py, -rz * cos_t + z_center))
		grid.append(ring)

	return _build_welded_grid_mesh(grid, true, true, false, mat_leather)


static func _build_detailed_pistol_model(mat_gunmetal: Material, mat_leather: Material, _mat_brass: Material) -> Node3D:
	var gun_node := Node3D.new()
	gun_node.name = "HandWeaponModel"

	var mat_laser_red := StandardMaterial3D.new()
	mat_laser_red.albedo_color = Color(1.0, 0.15, 0.18)
	mat_laser_red.emission_enabled = true
	mat_laser_red.emission = Color(1.0, 0.12, 0.15)
	mat_laser_red.emission_energy_multiplier = 2.2

	# Sculpted ergonomic pistol grip, slide, barrel & under-barrel laser sight
	_add_smooth_Ellipsoid(gun_node, "PistolSlide", Vector3(0.015, 0.020, 0.088), Vector3(0, 0.018, -0.035), Vector3.ZERO, mat_gunmetal)
	_add_smooth_Ellipsoid(gun_node, "PistolGrip", Vector3(0.014, 0.048, 0.022), Vector3(0, -0.025, 0.015), Vector3(16, 0, 0), mat_leather)
	_add_smooth_Ellipsoid(gun_node, "LaserSightHousing", Vector3(0.009, 0.009, 0.042), Vector3(0, -0.002, -0.052), Vector3.ZERO, mat_gunmetal)
	_add_smooth_Ellipsoid(gun_node, "LaserEmitterLens", Vector3(0.006, 0.006, 0.006), Vector3(0, -0.002, -0.095), Vector3.ZERO, mat_laser_red)
	return gun_node


# ==============================================================================
# REALISTIC NPC & MONSTER BUILDERS (USING THE SAME ORGANIC SCULPTED PIPELINE)
# ==============================================================================

static func build_npc_humanoid(coat_color: Color, hair_color: Color, accessory_color: Color, is_mascot: bool = false) -> Node3D:
	var root := Node3D.new()
	root.name = "NPCHumanoidModel"

	var mat_skin := _load_skin_material(Color(0.94, 0.95, 0.98) if is_mascot else Color(0.90, 0.74, 0.64))
	var mat_hair := _load_hair_material(hair_color.darkened(0.35), hair_color, hair_color.lightened(0.2))
	var mat_coat := _load_cloth_material(coat_color, coat_color.darkened(0.45), coat_color.lightened(0.25), 0.66)
	var mat_acc := _load_cloth_material(accessory_color, accessory_color.darkened(0.4), accessory_color.lightened(0.25), 0.55)
	var mat_pants := _load_cloth_material(Color(0.14, 0.15, 0.19), Color(0.06, 0.07, 0.10), Color(0.24, 0.26, 0.32), 0.72)
	var mat_leather := _load_cloth_material(Color(0.13, 0.09, 0.07), Color(0.05, 0.03, 0.02), Color(0.30, 0.22, 0.18), 0.35)
	var mat_brass := StandardMaterial3D.new()
	mat_brass.albedo_color = Color(0.84, 0.68, 0.26)
	mat_brass.metallic = 0.85
	mat_brass.roughness = 0.25

	var torso_pivot := Node3D.new()
	torso_pivot.name = "TorsoPivot"
	torso_pivot.position = Vector3(0, 0.88, 0)
	root.add_child(torso_pivot)

	var body_mi := MeshInstance3D.new()
	body_mi.mesh = _sculpt_female_trenchcoat_mesh(mat_coat)
	body_mi.scale = Vector3(1.12, 1.02, 1.08)
	torso_pivot.add_child(body_mi)

	var scarf_mi := MeshInstance3D.new()
	scarf_mi.mesh = _sculpt_draped_scarf_mesh(mat_acc)
	torso_pivot.add_child(scarf_mi)

	var head_pivot := Node3D.new()
	head_pivot.name = "HeadPivot"
	head_pivot.position = Vector3(0, 0.50, 0)
	torso_pivot.add_child(head_pivot)

	var head_mi := MeshInstance3D.new()
	head_mi.mesh = _sculpt_realistic_female_head_mesh(mat_skin)
	if is_mascot:
		head_mi.scale = Vector3(1.25, 1.18, 1.25)
		var beak_mi := MeshInstance3D.new()
		beak_mi.mesh = _sculpt_tapered_hair_lock(
			Vector3(0, 0.18, -0.09), Vector3(0, 0.175, -0.15), Vector3(0, 0.165, -0.21), Vector3(0, 0.15, -0.26),
			0.075, 0.068, mat_acc
		)
		head_pivot.add_child(beak_mi)
	else:
		_attach_realistic_human_eyes_and_brows(head_pivot, mat_skin, mat_hair)
		var cap_mi := MeshInstance3D.new()
		cap_mi.mesh = _sculpt_hair_cap_mesh(mat_hair)
		head_pivot.add_child(cap_mi)
	head_pivot.add_child(head_mi)

	for side in [-1.0, 1.0]:
		var arm_pivot := Node3D.new()
		arm_pivot.name = "LeftArmPivot" if side < 0.0 else "RightArmPivot"
		arm_pivot.position = Vector3(side * 0.19, 0.44, 0.0)
		torso_pivot.add_child(arm_pivot)
		_build_sculpted_arm_and_hand(arm_pivot, side, mat_coat, mat_acc, mat_skin)

		var leg_pivot := Node3D.new()
		leg_pivot.name = "LeftLegPivot" if side < 0.0 else "RightLegPivot"
		leg_pivot.position = Vector3(side * 0.088, 0.78, 0.0)
		root.add_child(leg_pivot)
		_build_sculpted_leg_and_boot(leg_pivot, side, mat_pants, mat_leather, mat_brass)

	return root


static func build_monster_character(is_boss: bool, title: String) -> Node3D:
	var root := Node3D.new()
	root.name = "MonsterArticulatedModel"

	var flesh_col := Color(0.74, 0.71, 0.78) if not is_boss else Color(0.80, 0.74, 0.85)
	var garb_col := Color(0.42, 0.10, 0.13)
	if title.contains("潛水"):
		garb_col = Color(0.10, 0.24, 0.28)
	elif title.contains("潛行"):
		garb_col = Color(0.15, 0.13, 0.19)

	var mat_flesh := _load_skin_material(flesh_col)
	var mat_garb := _load_cloth_material(garb_col, garb_col.darkened(0.5), garb_col.lightened(0.2), 0.68)
	var mat_crimson_glow := StandardMaterial3D.new()
	mat_crimson_glow.albedo_color = Color(0.95, 0.15, 0.22)
	mat_crimson_glow.emission_enabled = true
	mat_crimson_glow.emission = Color(0.92, 0.12, 0.18)
	mat_crimson_glow.emission_energy_multiplier = 2.2

	if is_boss:
		root.scale = Vector3.ONE * 1.32

	var torso := Node3D.new()
	torso.name = "TorsoPivot"
	torso.position = Vector3(0, 0.88, 0)
	root.add_child(torso)

	var body_mi := MeshInstance3D.new()
	body_mi.mesh = _sculpt_female_trenchcoat_mesh(mat_garb)
	body_mi.rotation_degrees = Vector3(8, 0, 0)
	torso.add_child(body_mi)

	if is_boss:
		_add_smooth_Ellipsoid(torso, "BackPressureValve", Vector3(0.11, 0.11, 0.09), Vector3(0, 0.28, 0.14), Vector3.ZERO, mat_crimson_glow)

	var head := Node3D.new()
	head.name = "HeadPivot"
	head.position = Vector3(0, 0.50, -0.04)
	torso.add_child(head)

	var skull_mi := MeshInstance3D.new()
	skull_mi.mesh = _sculpt_realistic_female_head_mesh(mat_flesh)
	head.add_child(skull_mi)

	for side in [-1.0, 1.0]:
		_add_smooth_Ellipsoid(head, "GlowingEye", Vector3(0.014, 0.010, 0.010), Vector3(side * 0.029, 0.202, -0.082), Vector3.ZERO, mat_crimson_glow)

		var arm := Node3D.new()
		arm.name = "LeftArmPivot" if side < 0.0 else "RightArmPivot"
		arm.position = Vector3(side * 0.19, 0.44, 0)
		arm.rotation_degrees = Vector3(32, 0, side * -6.0)
		torso.add_child(arm)
		_build_sculpted_arm_and_hand(arm, side, mat_garb, mat_garb, mat_flesh)

		var leg := Node3D.new()
		leg.name = "LeftLegPivot" if side < 0.0 else "RightLegPivot"
		leg.position = Vector3(side * 0.088, 0.78, 0)
		root.add_child(leg)
		_build_sculpted_leg_and_boot(leg, side, mat_garb, mat_garb, mat_crimson_glow)

	return root


# ==============================================================================
# PERIODIC SURFACE-TOOL PARAMETRIC WELDED MESH ENGINE (ZERO SEAMS, SMOOTH NORMALS)
# ==============================================================================

static func _build_welded_grid_mesh(grid: Array, periodic_u: bool, cap_bottom: bool, cap_top: bool, mat: Material) -> ArrayMesh:
	var v_count: int = grid.size()
	if v_count < 2:
		return ArrayMesh.new()
	var u_count: int = (grid[0] as Array).size()
	if u_count < 3:
		return ArrayMesh.new()

	# Precompute smooth periodic central-difference outward normals for every vertex (iv, iu)
	var normals: Array = []
	var centers: Array[Vector3] = []
	for iv in range(v_count):
		var ring: Array = grid[iv]
		var c := Vector3.ZERO
		for iu in range(u_count):
			c += ring[iu] as Vector3
		centers.append(c / float(u_count))

	for iv in range(v_count):
		var n_ring: Array[Vector3] = []
		var ring_curr: Array = grid[iv]
		var ring_prev: Array = grid[max(0, iv - 1)]
		var ring_next: Array = grid[min(v_count - 1, iv + 1)]
		var c_pt: Vector3 = centers[iv]

		for iu in range(u_count):
			var iu_prev: int = (iu - 1 + u_count) % u_count if periodic_u else max(0, iu - 1)
			var iu_next: int = (iu + 1) % u_count if periodic_u else min(u_count - 1, iu + 1)

			var p_curr: Vector3 = ring_curr[iu]
			var dp_du: Vector3 = (ring_curr[iu_next] as Vector3) - (ring_curr[iu_prev] as Vector3)
			var dp_dv: Vector3 = (ring_next[iu] as Vector3) - (ring_prev[iu] as Vector3)
			var n: Vector3 = dp_du.cross(dp_dv).normalized()
			var radial: Vector3 = p_curr - c_pt
			if n.length_squared() < 0.0001:
				n = radial.normalized()
			elif n.dot(radial) < 0.0:
				n = -n
			n_ring.append(n)
		normals.append(n_ring)

	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	if mat:
		st.set_material(mat)

	var u_limit: int = u_count if periodic_u else (u_count - 1)
	for iv in range(v_count - 1):
		var v0: float = float(iv) / float(v_count - 1)
		var v1: float = float(iv + 1) / float(v_count - 1)
		var r0: Array = grid[iv]
		var r1: Array = grid[iv + 1]
		var n0: Array = normals[iv]
		var n1: Array = normals[iv + 1]

		for iu in range(u_limit):
			var iu1: int = (iu + 1) % u_count
			var u0: float = float(iu) / float(u_count)
			var u1: float = float(iu + 1) / float(u_count)

			var p00: Vector3 = r0[iu]
			var p10: Vector3 = r0[iu1]
			var p01: Vector3 = r1[iu]
			var p11: Vector3 = r1[iu1]

			var nm00: Vector3 = n0[iu]
			var nm10: Vector3 = n0[iu1]
			var nm01: Vector3 = n1[iu]
			var nm11: Vector3 = n1[iu1]

			# Triangle 1: (p00, p11, p01) - Clockwise outward-facing in Godot 4
			st.set_normal(nm00)
			st.set_uv(Vector2(u0, 1.0 - v0))
			st.add_vertex(p00)

			st.set_normal(nm11)
			st.set_uv(Vector2(u1, 1.0 - v1))
			st.add_vertex(p11)

			st.set_normal(nm01)
			st.set_uv(Vector2(u0, 1.0 - v1))
			st.add_vertex(p01)

			# Triangle 2: (p00, p10, p11) - Clockwise outward-facing in Godot 4
			st.set_normal(nm00)
			st.set_uv(Vector2(u0, 1.0 - v0))
			st.add_vertex(p00)

			st.set_normal(nm10)
			st.set_uv(Vector2(u1, 1.0 - v0))
			st.add_vertex(p10)

			st.set_normal(nm11)
			st.set_uv(Vector2(u1, 1.0 - v1))
			st.add_vertex(p11)

	if cap_bottom:
		var r_bot: Array = grid[0]
		var c_bot: Vector3 = centers[0]
		var n_bot := Vector3.DOWN
		for iu in range(u_limit):
			var iu1: int = (iu + 1) % u_count
			st.set_normal(n_bot)
			st.set_uv(Vector2(0.5, 0.5))
			st.add_vertex(c_bot)
			st.set_normal(n_bot)
			st.set_uv(Vector2(0.0, 1.0))
			st.add_vertex(r_bot[iu1])
			st.set_normal(n_bot)
			st.set_uv(Vector2(1.0, 1.0))
			st.add_vertex(r_bot[iu])

	if cap_top:
		var r_top: Array = grid[v_count - 1]
		var c_top: Vector3 = centers[v_count - 1]
		var n_top := Vector3.UP
		for iu in range(u_limit):
			var iu1: int = (iu + 1) % u_count
			st.set_normal(n_top)
			st.set_uv(Vector2(0.5, 0.5))
			st.add_vertex(c_top)
			st.set_normal(n_top)
			st.set_uv(Vector2(0.0, 0.0))
			st.add_vertex(r_top[iu])
			st.set_normal(n_top)
			st.set_uv(Vector2(1.0, 0.0))
			st.add_vertex(r_top[iu1])

	return st.commit()


static func _sculpt_curved_strip_mesh(p0: Vector3, p1: Vector3, p2: Vector3, max_w: float, max_th: float, mat: Material) -> ArrayMesh:
	var p_a: Vector3 = p0.lerp(p1, 0.66)
	var p_b: Vector3 = p2.lerp(p1, 0.66)
	return _sculpt_tapered_hair_lock(p0, p_a, p_b, p2, max_w, max_th, mat)


static func _add_smooth_Ellipsoid(parent: Node3D, node_name: String, radii: Vector3, pos: Vector3, rot_deg: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = node_name
	var sm := SphereMesh.new()
	sm.radius = 1.0
	sm.height = 2.0
	sm.radial_segments = 24
	sm.rings = 16
	mi.mesh = sm
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.scale = radii
	mi.material_override = mat
	parent.add_child(mi)
	return mi


static func _cubic_bezier(p0: Vector3, p1: Vector3, p2: Vector3, p3: Vector3, t: float) -> Vector3:
	var u: float = 1.0 - t
	return (u * u * u) * p0 + (3.0 * u * u * t) * p1 + (3.0 * u * t * t) * p2 + (t * t * t) * p3


static func _cubic_bezier_deriv(p0: Vector3, p1: Vector3, p2: Vector3, p3: Vector3, t: float) -> Vector3:
	var u: float = 1.0 - t
	return (3.0 * u * u) * (p1 - p0) + (6.0 * u * t) * (p2 - p1) + (3.0 * t * t) * (p3 - p2)
