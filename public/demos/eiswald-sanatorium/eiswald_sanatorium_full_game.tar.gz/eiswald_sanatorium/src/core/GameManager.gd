extends Node
## GameManager.gd
## Global state machine for "Eiswald Sanatorium: Winter of the White Crow".
## Implements Crow Country's 3 difficulty tiers (Survival, Exploration, Murder of Crows),
## Dual Control Schemes (Modern Direct vs. Classic Tank Controls),
## Radial Metroidvania Hub & Shortcut flags, Progressive Fortune Teller tiers, and S-Rank evaluation.

signal game_mode_changed(new_mode: int)
signal control_scheme_changed(new_scheme: int)
signal world_flag_changed(flag_name: String, value: Variant)
signal room_state_updated(room_id: String)
signal edelweiss_collected(total_collected: int, max_count: int)
signal player_vitals_changed(hp: float, max_hp: float, status_effect: String)

enum GameMode {
	SURVIVAL_HORROR = 0,  # 標準生存模式：平衡資源、怪物與陷阱
	EXPLORATION_ONLY = 1, # 純探索模式：怪物不攻擊，專注體驗四大主題區解謎與劇情
	MURDER_OF_CROWS = 2   # 謀殺之鴉模式 (Murder of Crows)：敵人速度/血量+40%、必帶劇毒、極限生存
}

enum ControlScheme {
	MODERN_DIRECT = 0,    # 現代全方向直接移動 (相對攝影機視角)
	TANK_CONTROLS = 1     # 經典坦克式操作 (W/S 前進後退、A/D 原地轉向)
}

enum RoomStatus {
	UNVISITED = 0,
	VISITED_ITEMS_REMAIN = 1, # Red on Map
	VISITED_CLEARED = 2,      # Blue on Map
	SAFE_ROOM = 3             # Green Campfire Sanctuary on Map
}

const MAX_EDELWEISS_COUNT: int = 15

var current_mode: GameMode = GameMode.SURVIVAL_HORROR
var control_scheme: ControlScheme = ControlScheme.MODERN_DIRECT
var retro_filter_active: bool = false

# Player Vitals
var player_hp: float = 100.0
var player_max_hp: float = 100.0
var player_status: String = "FINE" # FINE, CAUTION, DANGER, ICHOR_INFECTED
var _poison_tick_timer: float = 0.0

# S-Rank Evaluation Telemetry
var play_time_seconds: float = 0.0
var heals_used: int = 0
var oracle_hints_used: int = 0
var times_saved: int = 0
var enemies_neutralized: int = 0
var shots_fired: int = 0
var shots_hit: int = 0
var collected_edelweiss_ids: Array[String] = []

# Progressive Fortune Teller Hint Tiers (tracks 0 -> 1 -> 2 -> 3 per puzzle topic)
var oracle_hint_tiers: Dictionary = {}

# World Progression & Shortcut Flags
var world_flags: Dictionary = {
	"car_trunk_inspected": false,
	"met_arthur_hub": false,
	"crowbar_obtained": false,
	"pocket_watch_found": false,
	"pocket_watch_secret_revealed": false,
	"fairytale_clock_solved": false,
	"bronze_wing_key_obtained": false,
	"haunted_hilltop_unlocked": false,
	"constellation_piano_solved": false,
	"silver_seahorse_key_obtained": false,
	"shortcut_haunted_to_hub_opened": false,
	"ocean_kingdom_unlocked": false,
	"aquarium_pressure_solved": false,
	"pirate_compass_solved": false,
	"acid_vial_obtained": false,
	"shortcut_ocean_to_hub_opened": false,
	"underground_roots_unlocked": false,
	"geothermal_voltage_restored": false,
	"sanctum_lab_opened": false
}

# 4 Radial Themed Zones around the Fairytale Town Central Hub (16 Core Rooms)
var room_database: Dictionary = {
	# Zone 1: 童話鎮中央樞紐 (Fairytale Town Central Hub)
	"Z1_R01_ArrivalGates": {"name": "【童話鎮】01. 暴風雪山門與停車場", "zone": 1, "status": RoomStatus.VISITED_ITEMS_REMAIN, "remaining_items": 2},
	"Z1_R02_FairytaleHub": {"name": "【童話鎮】02. 雪絨花童話中央廣場 (旋轉木馬樞紐)", "zone": 1, "status": RoomStatus.UNVISITED, "remaining_items": 3},
	"Z1_R03_ToadstoolCottage": {"name": "【童話鎮】03. 巨型毒蠅傘蘑菇屋與女巫藥草坊", "zone": 1, "status": RoomStatus.UNVISITED, "remaining_items": 3},
	"Z1_R04_CampfireSafeRoom": {"name": "【安全屋】04. 童話木屋壁爐營火休息室", "zone": 1, "status": RoomStatus.SAFE_ROOM, "remaining_items": 3},
	# Zone 2: 鬧鬼山丘 (Haunted Hilltop)
	"Z2_R05_GothicCemetery": {"name": "【鬧鬼山丘】05. 霧嶺哥德墓園與假鬼屋驚魂廊", "zone": 2, "status": RoomStatus.UNVISITED, "remaining_items": 2},
	"Z2_R06_HauntedChapel": {"name": "【鬧鬼山丘】06. 古堡星座靈廟與自動鋼琴廳", "zone": 2, "status": RoomStatus.UNVISITED, "remaining_items": 3},
	# Zone 3: 海洋王國 (Ocean Kingdom)
	"Z3_R07_AbyssalAquarium": {"name": "【海洋王國】07. 冰川深海圓頂水族館 (水壓調節廳)", "zone": 3, "status": RoomStatus.UNVISITED, "remaining_items": 3},
	"Z3_R08_PirateGalleon": {"name": "【海洋王國】08. 『破冰船號』海盜船主題餐廳", "zone": 3, "status": RoomStatus.UNVISITED, "remaining_items": 2},
	# Zone 4: 地下挖掘場與秘密設施 (The Roots / Underground)
	"Z4_R09_SubterraneanQuarry": {"name": "【地下挖掘場】09. 太古白髓鐘乳石礦坑與鑽探機", "zone": 4, "status": RoomStatus.UNVISITED, "remaining_items": 3},
	"Z4_R10_SecretBioLab": {"name": "【秘密設施】10. 范斯地底基因實驗室與白髓母體池", "zone": 4, "status": RoomStatus.UNVISITED, "remaining_items": 2}
}

var discovered_door_notes: Dictionary = {}
var current_room_id: String = "Z1_R01_ArrivalGates"

func _process(delta: float) -> void:
	if get_tree().paused:
		return
	play_time_seconds += delta

	# Poison DoT in Survival / Murder of Crows mode
	if player_status == "ICHOR_INFECTED" and current_mode != GameMode.EXPLORATION_ONLY:
		_poison_tick_timer += delta
		if _poison_tick_timer >= 3.5:
			_poison_tick_timer = 0.0
			var dot_dmg: float = 4.0 if current_mode == GameMode.MURDER_OF_CROWS else 2.0
			player_hp = maxf(1.0, player_hp - dot_dmg)
			player_vitals_changed.emit(player_hp, player_max_hp, player_status)

func cycle_game_mode() -> GameMode:
	var next_int: int = (int(current_mode) + 1) % 3
	set_game_mode(next_int as GameMode)
	return current_mode

func set_game_mode(mode: GameMode) -> void:
	current_mode = mode
	game_mode_changed.emit(current_mode)

func toggle_control_scheme() -> ControlScheme:
	control_scheme = (
		ControlScheme.TANK_CONTROLS
		if control_scheme == ControlScheme.MODERN_DIRECT
		else ControlScheme.MODERN_DIRECT
	)
	control_scheme_changed.emit(control_scheme)
	return control_scheme

func get_difficulty_enemy_multiplier() -> float:
	if current_mode == GameMode.MURDER_OF_CROWS:
		return 1.4
	return 1.0

func set_flag(flag_name: String, value: Variant) -> void:
	world_flags[flag_name] = value
	world_flag_changed.emit(flag_name, value)

func get_flag(flag_name: String, default_value: Variant = false) -> Variant:
	return world_flags.get(flag_name, default_value)

func mark_room_visited(room_id: String) -> void:
	current_room_id = room_id
	if room_database.has(room_id):
		var r: Dictionary = room_database[room_id]
		if r["status"] == RoomStatus.UNVISITED:
			r["status"] = RoomStatus.VISITED_ITEMS_REMAIN if r["remaining_items"] > 0 else RoomStatus.VISITED_CLEARED
		room_state_updated.emit(room_id)

func register_room_item_picked(room_id: String) -> void:
	if room_database.has(room_id):
		var r: Dictionary = room_database[room_id]
		r["remaining_items"] = maxi(0, int(r["remaining_items"]) - 1)
		if r["status"] != RoomStatus.SAFE_ROOM:
			r["status"] = RoomStatus.VISITED_CLEARED if r["remaining_items"] == 0 else RoomStatus.VISITED_ITEMS_REMAIN
		room_state_updated.emit(room_id)

func record_door_lock_note(door_id: String, note_text: String) -> void:
	discovered_door_notes[door_id] = note_text
	room_state_updated.emit(current_room_id)

func collect_edelweiss(crystal_id: String) -> void:
	if not collected_edelweiss_ids.has(crystal_id):
		collected_edelweiss_ids.append(crystal_id)
		edelweiss_collected.emit(collected_edelweiss_ids.size(), MAX_EDELWEISS_COUNT)

func apply_player_damage(amount: float, inflicts_ichor: bool = false) -> void:
	if current_mode == GameMode.EXPLORATION_ONLY:
		return
	var mult: float = 1.45 if current_mode == GameMode.MURDER_OF_CROWS else 1.0
	player_hp = clampf(player_hp - amount * mult, 0.0, player_max_hp)
	if (inflicts_ichor or current_mode == GameMode.MURDER_OF_CROWS) and player_hp > 0.0:
		player_status = "ICHOR_INFECTED"
	else:
		_recalculate_vitals_status()
	player_vitals_changed.emit(player_hp, player_max_hp, player_status)

func heal_player(amount: float, cures_infection: bool = false) -> void:
	heals_used += 1
	player_hp = clampf(player_hp + amount, 0.0, player_max_hp)
	if cures_infection and player_status == "ICHOR_INFECTED":
		player_status = "FINE"
	_recalculate_vitals_status()
	player_vitals_changed.emit(player_hp, player_max_hp, player_status)

func _recalculate_vitals_status() -> void:
	if player_status == "ICHOR_INFECTED":
		return
	if player_hp >= 65.0:
		player_status = "FINE"
	elif player_hp >= 30.0:
		player_status = "CAUTION"
	else:
		player_status = "DANGER"

func calculate_survival_rank() -> Dictionary:
	var penalty_points: int = heals_used * 5 + oracle_hints_used * 8 + maxi(0, int(play_time_seconds / 60.0) - 90)
	var edelweiss_bonus: int = collected_edelweiss_ids.size() * 2
	var mode_bonus: int = 15 if current_mode == GameMode.MURDER_OF_CROWS else 0
	var net_score: int = maxi(0, 100 - penalty_points + edelweiss_bonus + mode_bonus)

	var rank_letter: String = "B"
	var unlock_reward: String = "調查員復古風衣造型"
	if current_mode == GameMode.EXPLORATION_ONLY:
		rank_letter = "EXPLORER"
		unlock_reward = "霧嶺四大主題園區設定集"
	elif net_score >= 108 and oracle_hints_used == 0 and heals_used <= 1:
		rank_letter = "S+"
		unlock_reward = "無限白鴉電磁軌道砲 + 『群鴉盛宴』金鴉皇冠"
	elif net_score >= 95:
		rank_letter = "S"
		unlock_reward = "無限燃料地熱火焰噴射器 (Infinite Flamethrower)"
	elif net_score >= 80:
		rank_letter = "A"
		unlock_reward = "白鴉 .44 馬格南無限彈藥配件"

	var accuracy: float = (float(shots_hit) / float(shots_fired)) * 100.0 if shots_fired > 0 else 0.0
	return {
		"rank": rank_letter,
		"score": net_score,
		"play_time_formatted": "%02d:%02d" % [int(play_time_seconds / 60.0), int(play_time_seconds) % 60],
		"heals_used": heals_used,
		"oracle_hints_used": oracle_hints_used,
		"edelweiss_found": "%d / %d" % [collected_edelweiss_ids.size(), MAX_EDELWEISS_COUNT],
		"accuracy": "%.1f%%" % accuracy,
		"reward": unlock_reward
	}
