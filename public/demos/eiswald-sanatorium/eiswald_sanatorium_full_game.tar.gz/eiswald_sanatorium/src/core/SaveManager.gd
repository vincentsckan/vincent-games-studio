extends Node
## SaveManager.gd
## Handles Safe Room Reel-to-Reel Magnetic Tape Recording saves and loads.

signal game_saved(slot_index: int, timestamp: String)
signal game_loaded(slot_index: int)

const SAVE_DIR: String = "user://saves/"

func _ready() -> void:
	DirAccess.make_dir_recursive_absolute(SAVE_DIR)

func get_save_path(slot_index: int) -> String:
	return SAVE_DIR + "eiswald_tape_slot_%d.json" % slot_index

func save_to_tape(slot_index: int, player_position: Vector3, player_rotation_y: float) -> bool:
	GameManager.times_saved += 1
	var timestamp: String = Time.get_datetime_string_from_system(false, true)
	var save_payload: Dictionary = {
		"version": "0.9.0",
		"timestamp": timestamp,
		"room_id": GameManager.current_room_id,
		"room_name": GameManager.room_database.get(GameManager.current_room_id, {}).get("name", "霧嶺療養院"),
		"game_mode": int(GameManager.current_mode),
		"play_time_seconds": GameManager.play_time_seconds,
		"player": {
			"hp": GameManager.player_hp,
			"max_hp": GameManager.player_max_hp,
			"status": GameManager.player_status,
			"pos": [player_position.x, player_position.y, player_position.z],
			"rot_y": player_rotation_y
		},
		"stats": {
			"heals_used": GameManager.heals_used,
			"oracle_hints_used": GameManager.oracle_hints_used,
			"times_saved": GameManager.times_saved,
			"enemies_neutralized": GameManager.enemies_neutralized,
			"shots_fired": GameManager.shots_fired,
			"shots_hit": GameManager.shots_hit,
			"edelweiss": GameManager.collected_edelweiss_ids
		},
		"world_flags": GameManager.world_flags.duplicate(true),
		"room_database": GameManager.room_database.duplicate(true),
		"discovered_door_notes": GameManager.discovered_door_notes.duplicate(true),
		"inventory": InventoryManager.serialize_inventory()
	}

	var file := FileAccess.open(get_save_path(slot_index), FileAccess.WRITE)
	if file == null:
		push_error("Failed to write save tape at slot %d" % slot_index)
		return false

	file.store_string(JSON.stringify(save_payload, "\t"))
	file.close()
	game_saved.emit(slot_index, timestamp)
	return true

func load_from_tape(slot_index: int) -> Dictionary:
	var path: String = get_save_path(slot_index)
	if not FileAccess.file_exists(path):
		return {}

	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return {}

	var raw_text: String = file.get_as_text()
	file.close()

	var parsed: Variant = JSON.parse_string(raw_text)
	if typeof(parsed) != TYPE_DICTIONARY:
		return {}

	var data: Dictionary = parsed
	GameManager.current_mode = data.get("game_mode", 0) as GameManager.GameMode
	GameManager.play_time_seconds = float(data.get("play_time_seconds", 0.0))
	GameManager.current_room_id = String(data.get("room_id", "R04_TeaSafeRoom"))

	var p: Dictionary = data.get("player", {})
	GameManager.player_hp = float(p.get("hp", 100.0))
	GameManager.player_max_hp = float(p.get("max_hp", 100.0))
	GameManager.player_status = String(p.get("status", "FINE"))

	var st: Dictionary = data.get("stats", {})
	GameManager.heals_used = int(st.get("heals_used", 0))
	GameManager.oracle_hints_used = int(st.get("oracle_hints_used", 0))
	GameManager.times_saved = int(st.get("times_saved", 1))
	GameManager.enemies_neutralized = int(st.get("enemies_neutralized", 0))
	GameManager.shots_fired = int(st.get("shots_fired", 0))
	GameManager.shots_hit = int(st.get("shots_hit", 0))

	GameManager.world_flags = data.get("world_flags", GameManager.world_flags)
	GameManager.discovered_door_notes = data.get("discovered_door_notes", {})
	InventoryManager.deserialize_inventory(data.get("inventory", {}))

	GameManager.player_vitals_changed.emit(GameManager.player_hp, GameManager.player_max_hp, GameManager.player_status)
	game_loaded.emit(slot_index)
	return data
