extends Node
## DialogueManager.gd
## Manages investigator monologues, branching NPC dialogues, lore documents across all 4 themed zones, and puzzle modals.

signal dialogue_started(speaker_name: String, lines: Array[String])
signal dialogue_line_advanced(speaker_name: String, line_text: String, line_index: int, total_lines: int)
signal dialogue_finished()
signal document_opened(doc_title: String, doc_date: String, doc_body: String)
signal document_closed()
signal puzzle_modal_requested(puzzle_id: String, puzzle_title: String, puzzle_hint: String)

var is_dialogue_active: bool = false
var is_document_active: bool = false
var _current_speaker: String = ""
var _current_lines: Array[String] = []
var _current_index: int = 0
var _on_complete_callback: Callable = Callable()

var lore_documents: Dictionary = {
	"doc_01_summons": {
		"title": "【調查卷宗 #01】四大主題園區與地底的秘密",
		"date": "1991 年 11 月 14 日",
		"body": "致 特別調查員 薇拉·林德奎斯特：\n\n整座霧嶺渡假村是以『雪絨花童話村 (Fairytale Village)』為中央樞紐，向外放射連接：西翼的『霧嶺鬧鬼山丘 (Haunted Hilltop)』、東翼的『冰川海洋王國 (Ocean Kingdom)』，以及深藏地底的『白髓挖掘場與秘密實驗室 (The Pale Roots)』。\n\n切記：園區內設有許多單向插銷鐵門，當你從分區內部打開它們時，就能打通直達中央廣場與壁爐營火安全屋的捷徑！\n\n—— 總建築師 亞瑟·范斯"
	},
	"doc_02_TeaRoomMemo": {
		"title": "【安全屋指南】壁爐營火與漸進式算命機",
		"date": "1989 年 12 月 02 日",
		"body": "致園區巡邏員：\n\n1. 設有『壁爐營火』的安全屋是絕對安全的喘息空間，可在此使用錄音機存檔並整理急救噴霧與解毒劑。\n2. 屋內的『雪山神諭算命機 (Fortune Teller)』具備三階段漸進式提示功能：第 1 次詢問給予方向指引，第 2 次解釋謎題邏輯，第 3 次直接給出答案密碼，避免破壞解謎樂趣。\n3. 舉槍瞄準時請保持站立不動 1 秒，待『準星完全收縮』後射擊頭部弱點，可造成巨額暴擊！"
	},
	"doc_03_CuratorJournal": {
		"title": "【童話鎮日誌】毒蠅傘蘑菇屋與女巫時鐘",
		"date": "1989 年 12 月 19 日",
		"body": "誰能想到充滿可愛蘑菇屋與旋轉木馬的『雪絨花童話村』，居然成了怪物的巢穴？\n\n我把通往西翼『鬧鬼山丘古堡』的【銅翼鑰匙】鎖進了蘑菇屋的老爺鐘暗格裡。開啟時間就刻在桌上那枚『停擺的銅製懷錶』背面——在手提箱點擊【3D 翻轉檢視背面】就能看到刻著 04:15。"
	},
	"doc_04_HauntedNotes": {
		"title": "【鬧鬼山丘手札】真假鬼屋與烏鴉座星盤",
		"date": "1990 年 01 月 03 日",
		"body": "古堡墓園原本只是用彈出式木偶嚇唬遊客的假鬼屋，但現在真正的白髓怪物混進了棺木裡！\n\n若要打開靈廟取得通往東翼『海洋王國』的【銀冠海馬鑰匙】與【白鴉 .44 馬格南】，必須在古堡自動鋼琴彈奏烏鴉座星盤對應的五音聖詠序列：『1 - 3 - 5 - 4 - 2』（輸入 13542）。別忘了拉開古堡南側的單向鐵插銷門，打通回童話鎮的捷徑！"
	},
	"doc_05_OceanKingdomLog": {
		"title": "【海洋王國日誌】水下展廳水壓與海盜船酸液",
		"date": "1990 年 01 月 11 日",
		"body": "冰川湖底的『海洋王國』分為水下展示廳與『破冰船號』海盜船餐廳。深海巨型水母槽的強化玻璃後藏著能腐蝕地底礦坑鐵鎖的【地熱強酸液瓶 (Acid Vial)】。\n\n必須將三座水下平衡艙的壓力總和調至【85 PSI】（左艙+35、中艙+30、右艙+20），才能安全取出強酸液瓶，融化中央廣場北側通往『地下挖掘場 (The Roots)』的鏽蝕鐵鍊！"
	},
	"doc_06_UndergroundRootsReport": {
		"title": "【最高機密】地下挖掘場與愛德華·范斯的白髓計畫",
		"date": "1990 年 02 月 01 日",
		"body": "這座主題樂園從頭到尾都是幌子！范斯在樂園地底 300 公尺處發現了太古有機體『白髓根脈 (The Pale Roots)』。\n\n只要將礦坑發電機調至額定【440】伏特，就能解鎖【地熱火焰噴射器】並開啟最深處的基因培養實驗室。唯有高溫火焰與 .44 馬格南能徹底終結母體池裡的畸變核心！"
	}
}

func start_dialogue(speaker: String, lines: Array[String], on_complete: Callable = Callable()) -> void:
	if lines.is_empty():
		return
	is_dialogue_active = true
	_current_speaker = speaker
	_current_lines = lines
	_current_index = 0
	_on_complete_callback = on_complete
	AudioManager.play_synth_sfx("ui_click")
	dialogue_started.emit(_current_speaker, _current_lines)
	dialogue_line_advanced.emit(_current_speaker, _current_lines[0], 0, _current_lines.size())

func advance_dialogue() -> void:
	if not is_dialogue_active:
		return
	_current_index += 1
	AudioManager.play_synth_sfx("ui_click")
	if _current_index >= _current_lines.size():
		is_dialogue_active = false
		dialogue_finished.emit()
		if _on_complete_callback.is_valid():
			_on_complete_callback.call()
			_on_complete_callback = Callable()
	else:
		dialogue_line_advanced.emit(_current_speaker, _current_lines[_current_index], _current_index, _current_lines.size())

func open_lore_document(doc_id: String) -> void:
	if not lore_documents.has(doc_id):
		return
	var doc: Dictionary = lore_documents[doc_id]
	is_document_active = true
	AudioManager.play_synth_sfx("item_pickup")
	document_opened.emit(String(doc["title"]), String(doc["date"]), String(doc["body"]))

func close_lore_document() -> void:
	if not is_document_active:
		return
	is_document_active = false
	AudioManager.play_synth_sfx("ui_click")
	document_closed.emit()

func request_puzzle_modal(puzzle_id: String, puzzle_title: String, puzzle_hint: String) -> void:
	puzzle_modal_requested.emit(puzzle_id, puzzle_title, puzzle_hint)
