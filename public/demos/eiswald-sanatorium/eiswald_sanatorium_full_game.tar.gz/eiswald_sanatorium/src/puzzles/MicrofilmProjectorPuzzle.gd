class_name MicrofilmProjectorPuzzle
extends StaticBody3D
## MicrofilmProjectorPuzzle.gd
## Room 18 (The Roots — Subterranean Cryo-Specimen Morgue) Microfilm Slide Projector Puzzle ("824").
##Focusing the 1978 mining survey microfilm to frame #824 unlocks the Napalm Pressurizer Tank
## for the Geothermal Flamethrower and High-Grade Antidotes!

@export var puzzle_id: String = "puzzle_microfilm_projector"
@export var target_slide_code: String = "824"
@export var room_id: String = "Z4_R09_SubterraneanQuarry"

var is_solved: bool = false

func get_interaction_prompt() -> String:
	if is_solved or bool(GameManager.get_flag("microfilm_solved")):
		return "【微縮膠卷投影機】已校準至第 #824 號底片"
	return "按 [F] 操作【冷凍標本庫微縮膠卷投影機】(輸入 3 位數焦距刻度)"

func interact(_player: Node) -> void:
	if is_solved or bool(GameManager.get_flag("microfilm_solved")):
		DialogueManager.start_dialogue("微縮膠卷投影機", ["投影幕上清晰顯示著 1978 年白髓泉源地質圖（#824），高壓凝固汽油改裝件已取走。"])
		return

	DialogueManager.request_puzzle_modal(
		puzzle_id,
		"【地下挖掘場】冷凍標本庫 — 1978 地質微縮膠卷投影機",
		"提示：地質勘探日誌記載：『深度 800 公尺(8)、第 2 斷層(2)、4 號母體鑽孔(4)』→ 輸入：824"
	)

func verify_code_submission(submitted_code: String) -> bool:
	if submitted_code.strip_edges() == target_slide_code:
		is_solved = true
		GameManager.set_flag("microfilm_solved", true)
		if InventoryManager.weapon_states.has("weapon_geothermal_flamethrower"):
			InventoryManager.weapon_states["weapon_geothermal_flamethrower"]["damage"] = 68.0
			InventoryManager.weapon_states["weapon_geothermal_flamethrower"]["max_clip"] = 40
			InventoryManager.weapon_states["weapon_geothermal_flamethrower"]["clip"] = 40
		InventoryManager.add_item("ammo_fuel_tank", 60)
		InventoryManager.add_item("medkit_compound", 2)
		GameManager.register_room_item_picked(room_id)
		AudioManager.play_synth_sfx("puzzle_solved")
		DialogueManager.start_dialogue("微縮膠卷投影機", [
			"微縮膠卷對焦成功！標本庫暗門開啟！",
			"獲得了【火焰噴射器白磷增壓噴嘴（傷害提升至 68、燃料槽擴充至 40）】、【高壓燃料 x60】與【聖裘德複合急救包 x2】！"
		])
		return true
	AudioManager.play_synth_sfx("door_locked")
	return false
