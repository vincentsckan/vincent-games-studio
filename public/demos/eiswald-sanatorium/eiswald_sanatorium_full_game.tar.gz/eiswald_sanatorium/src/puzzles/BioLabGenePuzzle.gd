class_name BioLabGenePuzzle
extends StaticBody3D
## BioLabGenePuzzle.gd
## Zone 4 (The Roots / Secret Bio-Lab) Final Genetic Sequence Terminal ("1989").
## Unseals Clara Vance's Cryo-Spire and triggers the climax / final truth revelation.

@export var puzzle_id: String = "puzzle_biolab_gene"
@export var target_sequence: String = "1989"
@export var room_id: String = "Z4_R10_SecretBioLab"

signal final_cryo_spire_unsealed()

var is_solved: bool = false

func get_interaction_prompt() -> String:
	if is_solved or bool(GameManager.get_flag("clara_sanctum_opened")):
		return "按 [F] 啟動【克拉拉白髓冷凍艙】揭曉最終結局與通關評級"
	return "按 [F] 操作【范斯基因實驗室 — 白髓母體終端機】"

func interact(_player: Node) -> void:
	if is_solved or bool(GameManager.get_flag("clara_sanctum_opened")):
		final_cryo_spire_unsealed.emit()
		return

	DialogueManager.request_puzzle_modal(
		puzzle_id,
		"【秘密設施】范斯地底基因實驗室 — 白髓冷凍艙終端機",
		"提示：輸入霧嶺渡假村發生慘劇並封山的年份（4 位數年份：1989）以解除冷凍艙封鎖"
	)

func verify_code_submission(submitted_code: String) -> bool:
	if submitted_code.strip_edges() == target_sequence:
		is_solved = true
		GameManager.set_flag("clara_sanctum_opened", true)
		GameManager.register_room_item_picked(room_id)
		AudioManager.play_synth_sfx("puzzle_solved")
		DialogueManager.start_dialogue("白髓母體終端機", [
			"『授權通過：1989 — 克拉拉·范斯白髓再生計畫最終階段解除封鎖。』",
			"整座地底母體池劇烈沸騰！擊敗守衛母體池的最終頭目後，再次調查此終端機即可完成任務並結算 S-Rank 通關評價！"
		])
		return true
	AudioManager.play_synth_sfx("door_locked")
	return false
