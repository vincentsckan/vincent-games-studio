class_name SteamValvePuzzle
extends StaticBody3D
## SteamValvePuzzle.gd
## Zone 3 (Ocean Kingdom — Abyssal Aquarium & Pirate Ship) Three-Chamber Hydro Pressure Puzzle.
## Balancing the water pressure to 85 PSI unlocks the Concentrated Acid Vial (dissolves chains to Zone 4: The Roots).

@export var puzzle_id: String = "puzzle_hydro_steam"
@export var target_psi: String = "85"
@export var reward_item_id: String = "acid_vial"
@export var room_id: String = "Z3_R07_AbyssalAquarium"

var is_solved: bool = false

func get_interaction_prompt() -> String:
	if is_solved or bool(GameManager.get_flag("aquarium_pressure_solved")):
		return "【深海水族館水壓調節閥】穩定維持於 85 PSI"
	return "按 [F] 操作【海洋王國三艙水壓調節盤】"

func interact(_player: Node) -> void:
	if is_solved or bool(GameManager.get_flag("aquarium_pressure_solved")):
		DialogueManager.start_dialogue("水下展廳水壓調節盤", ["三座深海展示艙水壓已平衡於 85 PSI，防爆玻璃櫃已開啟。"])
		return

	DialogueManager.request_puzzle_modal(
		puzzle_id,
		"【海洋王國】深海水下展示廳 — 三艙水壓平衡盤",
		"提示：根據《海洋王國日誌》，左艙(+35)、中艙(+30)、右艙(+20) 總和目標水壓為多少 PSI？（輸入：85）"
	)

func verify_code_submission(submitted_code: String) -> bool:
	if submitted_code.strip_edges() == target_psi:
		is_solved = true
		GameManager.set_flag("aquarium_pressure_solved", true)
		GameManager.set_flag("acid_vial_obtained", true)
		InventoryManager.add_item(reward_item_id, 1)
		GameManager.register_room_item_picked(room_id)
		AudioManager.play_synth_sfx("puzzle_solved")
		DialogueManager.start_dialogue("水下展廳水壓調節盤", [
			"深海圓頂水族館的藍綠色水流平穩下來，水壓指針鎖定於【85 PSI】！",
			"海盜船長展示櫃自動解鎖——獲得了【高濃度強酸液瓶 (Acid Vial)】！",
			"現在可以返回中央廣場北側，用強酸溶解通往第四分區『地下挖掘場與秘密設施 (The Roots)』的鏽蝕鐵鍊了！"
		])
		return true
	AudioManager.play_synth_sfx("door_locked")
	return false
