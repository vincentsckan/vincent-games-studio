class_name OrganMelodyPuzzle
extends StaticBody3D
## OrganMelodyPuzzle.gd
## Zone 2 (Haunted Hilltop — Gothic Crypt & Constellation Chapel) Corvus Constellation Piano Puzzle.
## Playing the 5-note sequence "13542" unlocks the Silver Seahorse Key (to Ocean Kingdom) and the .44 Magnum!

@export var puzzle_id: String = "puzzle_organ_melody"
@export var target_melody_code: String = "13542"
@export var room_id: String = "Z2_R06_HauntedChapel"

var is_solved: bool = false

func get_interaction_prompt() -> String:
	if is_solved or bool(GameManager.get_flag("constellation_piano_solved")):
		return "【古堡星座自動鋼琴】密室暗格已開啟"
	return "按 [F] 彈奏【鬧鬼古堡星座鋼琴】(輸入烏鴉座五音序列)"

func interact(_player: Node) -> void:
	if is_solved or bool(GameManager.get_flag("constellation_piano_solved")):
		DialogueManager.start_dialogue("古堡星座鋼琴", ["烏鴉座星盤閃耀著銀光，【銀冠海馬鑰匙】與【白鴉 .44 馬格南】已取走。"])
		return

	DialogueManager.request_puzzle_modal(
		puzzle_id,
		"【鬧鬼山丘】古堡靈廟 — 烏鴉座星盤與自動鋼琴",
		"提示：根據《鬧鬼山丘手札》，烏鴉座五顆主星對應的琴鍵順序為：1 - 3 - 5 - 4 - 2（輸入：13542）"
	)

func verify_code_submission(submitted_code: String) -> bool:
	if submitted_code.strip_edges() == target_melody_code:
		is_solved = true
		GameManager.set_flag("constellation_piano_solved", true)
		GameManager.set_flag("silver_seahorse_key_obtained", true)
		InventoryManager.add_item("key_silver_seahorse", 1)
		InventoryManager.add_item("weapon_white_crow_magnum", 1)
		InventoryManager.add_item("ammo_44magnum", 6)
		GameManager.register_room_item_picked(room_id)
		AudioManager.play_synth_sfx("puzzle_solved")
		DialogueManager.start_dialogue("古堡星座鋼琴", [
			"低沉優雅的五音聖詠在哥德古堡迴盪，牆上的烏鴉座星盤完全對齊！",
			"獲得了通往東翼『海洋王國 (Ocean Kingdom)』的【銀冠海馬鑰匙】，以及高威力武器【白鴉 .44 馬格南左輪】！",
			"（提示：別忘了拉開古堡南側的『單向鐵插銷門』，打通直接返回童話鎮中央廣場的捷徑！）"
		])
		return true
	AudioManager.play_synth_sfx("door_locked")
	return false
