class_name XRayDiagnosticsPuzzle
extends StaticBody3D
## XRayDiagnosticsPuzzle.gd
## Room 13 (Ocean Kingdom — Deep-Sea Jellyfish & X-Ray Diagnostics Room) Skeleton Radiograph Puzzle ("509").
## Aligning the 3 X-Ray lightboxes reveals the ribcage implant code "509" and unlocks the
## White Crow .44 Magnum Long-Barrel High-Velocity Upgrade!

@export var puzzle_id: String = "puzzle_xray_diagnostics"
@export var target_xray_code: String = "509"
@export var room_id: String = "Z3_R07_AbyssalAquarium"

var is_solved: bool = false

func get_interaction_prompt() -> String:
	if is_solved or bool(GameManager.get_flag("xray_code_discovered")):
		return "【放射線 X 光觀片燈箱】已解鎖馬格南強化槍管"
	return "按 [F] 檢查【深海醫療室 X 光骨骼觀片燈箱】(輸入 3 位數骨骼編號)"

func interact(_player: Node) -> void:
	if is_solved or bool(GameManager.get_flag("xray_code_discovered")):
		DialogueManager.start_dialogue("X 光骨骼觀片燈箱", ["三張 X 光片顯示出受試者胸腔內的編號『5 - 0 - 9』，強化槍管套件已取走。"])
		return

	DialogueManager.request_puzzle_modal(
		puzzle_id,
		"【海洋王國醫療室】X 光骨骼觀片燈箱謎題",
		"提示：三張受試者 X 光片重疊後，可見『第5根肋骨(5)、零號頭骨裂痕(0)、第9節脊椎白髓結晶(9)』→ 輸入：509"
	)

func verify_code_submission(submitted_code: String) -> bool:
	if submitted_code.strip_edges() == target_xray_code:
		is_solved = true
		GameManager.set_flag("xray_code_discovered", true)
		if InventoryManager.weapon_states.has("weapon_white_crow_magnum"):
			InventoryManager.weapon_states["weapon_white_crow_magnum"]["damage"] = 195.0
			InventoryManager.weapon_states["weapon_white_crow_magnum"]["max_clip"] = 8
			InventoryManager.weapon_states["weapon_white_crow_magnum"]["clip"] = 8
		InventoryManager.add_item("first_aid_spray", 1)
		GameManager.register_room_item_picked(room_id)
		AudioManager.play_synth_sfx("puzzle_solved")
		DialogueManager.start_dialogue("X 光骨骼觀片燈箱", [
			"X 光燈箱下方的精密武器櫃彈開！",
			"獲得了【白鴉 .44 馬格南加長膛線槍管（基礎傷害由 145 提升至 195、彈巢擴充至 8 發）】與【急救噴霧 x1】！"
		])
		return true
	AudioManager.play_synth_sfx("door_locked")
	return false
