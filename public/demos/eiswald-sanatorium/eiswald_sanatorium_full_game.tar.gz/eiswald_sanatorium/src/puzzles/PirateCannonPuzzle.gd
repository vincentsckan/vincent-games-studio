class_name PirateCannonPuzzle
extends StaticBody3D
## PirateCannonPuzzle.gd
## Zone 3 (Ocean Kingdom — "The Icebreaker Galleon" Pirate Ship Restaurant) Compass & Cannon Puzzle.
## Aligning the Ship Captain's Compass to "2486" (North-East-South-West) fires the decorative deck cannon
## to blast open the Captain's Treasure Locker containing .44 Magnum & Shotgun shells!

@export var puzzle_id: String = "puzzle_pirate_compass"
@export var target_compass_code: String = "2486"
@export var room_id: String = "Z3_R08_PirateGalleon"

var is_solved: bool = false

func get_interaction_prompt() -> String:
	if is_solved or bool(GameManager.get_flag("pirate_compass_solved")):
		return "【海盜船長羅盤與甲板砲】寶藏艙已轟開"
	return "按 [F] 轉動【破冰船號海盜船長羅盤】(對準四海航向)"

func interact(_player: Node) -> void:
	if is_solved or bool(GameManager.get_flag("pirate_compass_solved")):
		DialogueManager.start_dialogue("破冰船號海盜羅盤", ["甲板大砲已經轟開了船長寶藏櫃，物資已全數取得。"])
		return

	DialogueManager.request_puzzle_modal(
		puzzle_id,
		"【海洋王國】破冰船號餐廳 — 海盜船長羅盤與甲板砲",
		"提示：航海日誌記載『北(2) → 西(4) → 南(8) → 東(6)』四海航向刻度（輸入：2486）"
	)

func verify_code_submission(submitted_code: String) -> bool:
	if submitted_code.strip_edges() == target_compass_code:
		is_solved = true
		GameManager.set_flag("pirate_compass_solved", true)
		InventoryManager.add_item("ammo_44magnum", 8)
		InventoryManager.add_item("ammo_12gauge", 8)
		GameManager.register_room_item_picked(room_id)
		AudioManager.play_synth_sfx("gunshot_shotgun")
		DialogueManager.start_dialogue("破冰船號海盜羅盤", [
			"羅盤指針鎖定於【2 - 4 - 8 - 6】！海盜船甲板上的模型主砲轟然擊發，震碎了船長室的強化玻璃櫃！",
			"獲得了【.44 馬格南高爆彈 x8】與【12號霰彈槍彈藥 x8】！"
		])
		return true
	AudioManager.play_synth_sfx("door_locked")
	return false
