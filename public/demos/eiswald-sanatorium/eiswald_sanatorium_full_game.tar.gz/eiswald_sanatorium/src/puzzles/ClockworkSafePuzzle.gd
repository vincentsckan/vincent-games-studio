class_name ClockworkSafePuzzle
extends StaticBody3D
## ClockworkSafePuzzle.gd
## Zone 1 (Fairytale Town — Toadstool Mushroom Cottage) Grandfather Clock Puzzle.
## Requires inspecting the Brass Pocket Watch in 3D to read "04:15", then entering "0415"
## to obtain the Bronze Wing Key (unlocks Zone 2: Haunted Hilltop).

@export var puzzle_id: String = "puzzle_grandfather_clock"
@export var target_code: String = "0415"
@export var reward_item_id: String = "key_bronze_wing"
@export var room_id: String = "Z1_R03_ToadstoolCottage"

var is_solved: bool = false

func get_interaction_prompt() -> String:
	if is_solved or bool(GameManager.get_flag("fairytale_clock_solved")):
		return "【蘑菇屋老爺鐘暗格】已開啟"
	return "按 [F] 操作【毒蠅傘蘑菇屋老爺鐘】(輸入 4 位數時間)"

func interact(_player: Node) -> void:
	if is_solved or bool(GameManager.get_flag("fairytale_clock_solved")):
		DialogueManager.start_dialogue("蘑菇屋老爺鐘", ["老爺鐘的鐘擺平穩擺動，暗格內的【銅翼雙鴉鑰匙】已經取走。"])
		return

	if not InventoryManager.has_item("brass_pocket_watch"):
		DialogueManager.start_dialogue("蘑菇屋老爺鐘", [
			"這座童話風格的彩繪老爺鐘停在午夜時分，鐘盤下方有一道需要【黃銅發條齒輪】與『四位數時刻』才能開啟的暗格。",
			"先在毒蠅傘蘑菇屋內搜索看看有沒有關於時間的線索吧。"
		])
		return

	DialogueManager.request_puzzle_modal(
		puzzle_id,
		"【童話鎮】毒蠅傘蘑菇屋 — 老爺鐘報時轉盤",
		"提示：在手提箱 [Tab / I] 對【停擺的銅製懷錶】點擊【🔍 3D 翻轉檢視背面】查看內蓋刻字（格式：0415）"
	)

func verify_code_submission(submitted_code: String) -> bool:
	if submitted_code.strip_edges() == target_code:
		is_solved = true
		GameManager.set_flag("fairytale_clock_solved", true)
		GameManager.set_flag("bronze_wing_key_obtained", true)
		InventoryManager.add_item(reward_item_id, 1)
		GameManager.register_room_item_picked(room_id)
		AudioManager.play_synth_sfx("puzzle_solved")
		DialogueManager.start_dialogue("蘑菇屋老爺鐘", [
			"你將老爺鐘的指針撥至【04 : 15】，鑲入懷錶的黃銅齒輪！",
			"伴隨清脆的八音盒鐘聲，暗格彈開——獲得了通往西翼『鬧鬼山丘 (Haunted Hilltop)』的【銅翼雙鴉鑰匙】！"
		])
		return true
	AudioManager.play_synth_sfx("door_locked")
	return false
