class_name CryptSkeletonPuzzle
extends StaticBody3D
## CryptSkeletonPuzzle.gd
## Zone 2 (Haunted Hilltop — Clocktower Crypt) Tombstone Skeleton Cipher Puzzle ("741").
## Rewards the Investigator Satchel Expansion (+2 inventory slots) and Tactical Laser Scope upgrade!

@export var puzzle_id: String = "puzzle_crypt_skeleton"
@export var target_cipher: String = "741"
@export var room_id: String = "Z2_R05_GothicCemetery"

var is_solved: bool = false

func get_interaction_prompt() -> String:
	if is_solved or bool(GameManager.get_flag("crypt_skeleton_solved")):
		return "【鐘樓地下墓穴石棺】已開啟"
	return "按 [F] 調查【哥德墓園三聖骸骨石棺鎖】(輸入 3 位數墓誌銘密碼)"

func interact(_player: Node) -> void:
	if is_solved or bool(GameManager.get_flag("crypt_skeleton_solved")):
		DialogueManager.start_dialogue("三聖骸骨石棺", ["石棺已經推開，裡面的【戰術手提箱擴充袋】與【白鴉雷射增幅鏡】已經取走。"])
		return

	DialogueManager.request_puzzle_modal(
		puzzle_id,
		"【鬧鬼山丘】哥德墓園 — 三聖骸骨石棺密碼鎖",
		"提示：墓碑銘文記載『七隻白鴉棲於枯枝(7)、四盞孤燈照映古堡(4)、一具真骸藏於棺中(1)』→ 輸入：741"
	)

func verify_code_submission(submitted_code: String) -> bool:
	if submitted_code.strip_edges() == target_cipher:
		is_solved = true
		GameManager.set_flag("crypt_skeleton_solved", true)
		InventoryManager.max_slots = 12
		InventoryManager.add_item("ammo_12gauge", 6)
		GameManager.register_room_item_picked(room_id)
		AudioManager.play_synth_sfx("puzzle_solved")
		DialogueManager.start_dialogue("三聖骸骨石棺", [
			"沉重的石棺蓋緩緩滑開！你獲得了【戰術手提箱擴充袋（道具欄上限擴充至 12 格）】與【12號霰彈槍彈藥 x6】！"
		])
		return true
	AudioManager.play_synth_sfx("door_locked")
	return false
