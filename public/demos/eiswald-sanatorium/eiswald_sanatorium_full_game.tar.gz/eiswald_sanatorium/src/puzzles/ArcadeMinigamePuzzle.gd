class_name ArcadeMinigamePuzzle
extends StaticBody3D
## ArcadeMinigamePuzzle.gd
## Zone 1 (Fairytale Town) Retro 1990 CRT Arcade Cabinet Mini-game: "NUTCRACKER CROW HUNTER".
## Mirrors Crow Country's signature playable arcade cabinets in the theme park.
## Scoring 1991 points dispenses Silver Resort Tokens and a High-Capacity Pistol Magazine upgrade!

@export var puzzle_id: String = "puzzle_arcade_nutcracker"
@export var high_score_code: String = "1991"
@export var room_id: String = "Z1_R02_FairytaleHub"

var is_solved: bool = false

func get_interaction_prompt() -> String:
	if is_solved or bool(GameManager.get_flag("arcade_minigame_cleared")):
		return "【復古街機：胡桃鉗獵鴉行動】最高分紀錄：1991 (已破關)"
	return "按 [F] 遊玩【復古街機小遊戲：胡桃鉗獵鴉行動】"

func interact(_player: Node) -> void:
	if is_solved or bool(GameManager.get_flag("arcade_minigame_cleared")):
		DialogueManager.start_dialogue("復古街機《胡桃鉗獵鴉行動》", [
			"CRT 螢幕閃爍著 8-bit 像素煙火：『HIGH SCORE: 1991 - VERA LINDQVIST』。",
			"獎品槽內的【VP-9 擴容彈匣改裝套件】與急救噴霧已經領取完畢。"
		])
		return

	DialogueManager.request_puzzle_modal(
		puzzle_id,
		"【童話鎮街機小遊戲】《胡桃鉗獵鴉行動 1991》",
		"街機規則：依序擊落螢幕上的『第1波(1隻)、第9波(9隻)、第9波(9隻)、頭目(1隻)』白鴉即可刷新最高分紀錄（輸入高分通關指令：1991）"
	)

func verify_code_submission(submitted_code: String) -> bool:
	if submitted_code.strip_edges() == high_score_code:
		is_solved = true
		GameManager.set_flag("arcade_minigame_cleared", true)
		# Upgrade VP-9 Pistol magazine capacity from 12 to 18!
		if InventoryManager.weapon_states.has("weapon_vp9_pistol"):
			InventoryManager.weapon_states["weapon_vp9_pistol"]["max_clip"] = 18
			InventoryManager.weapon_states["weapon_vp9_pistol"]["clip"] = 18
			InventoryManager.weapon_states["weapon_vp9_pistol"]["damage"] = 36.0
		InventoryManager.add_item("first_aid_spray", 1)
		GameManager.register_room_item_picked(room_id)
		AudioManager.play_synth_sfx("puzzle_solved")
		DialogueManager.start_dialogue("復古街機《胡桃鉗獵鴉行動》", [
			"8-Bit 勝利音樂響起！你成功刷新了街機最高分【1991】！",
			"街機下方獎品槽彈出獎勵：【VP-9 手槍擴容強化套件（彈匣容量提升至 18 發、威力提升）】與【急救噴霧 x1】！"
		])
		return true
	AudioManager.play_synth_sfx("door_locked")
	return false
