class_name VoltageGridPuzzle
extends StaticBody3D
## VoltageGridPuzzle.gd
## Zone 4 (The Roots / Underground Quarry & Secret Lab) 440V Mining Generator Puzzle.
## Restores power to the subterranean lab and unlocks the Geothermal Flamethrower!

@export var puzzle_id: String = "puzzle_voltage_grid"
@export var target_voltage: String = "440"
@export var reward_item_id: String = "weapon_geothermal_flamethrower"
@export var room_id: String = "Z4_R09_SubterraneanQuarry"

var is_solved: bool = false

func get_interaction_prompt() -> String:
	if is_solved or bool(GameManager.get_flag("geothermal_voltage_restored")):
		return "【地下挖掘場主配電盤】440V 實驗室電力運作中"
	return "按 [F] 操作【地下挖掘場礦坑高壓配電盤】"

func interact(_player: Node) -> void:
	if is_solved or bool(GameManager.get_flag("geothermal_voltage_restored")):
		DialogueManager.start_dialogue("礦坑高壓配電盤", ["440V 電力已接通至最深處的范斯基因培養實驗室。"])
		return

	DialogueManager.request_puzzle_modal(
		puzzle_id,
		"【地下挖掘場】太古白髓礦坑 — 鑽探機高壓配電盤",
		"提示：根據《最高機密：白髓計畫》，礦坑發電機額定電壓為 440 伏特（輸入：440）"
	)

func verify_code_submission(submitted_code: String) -> bool:
	if submitted_code.strip_edges() == target_voltage:
		is_solved = true
		GameManager.set_flag("geothermal_voltage_restored", true)
		GameManager.set_flag("sanctum_lab_opened", true)
		InventoryManager.add_item(reward_item_id, 1)
		InventoryManager.add_item("ammo_fuel_tank", 50)
		GameManager.register_room_item_picked(room_id)
		AudioManager.play_synth_sfx("puzzle_solved")
		DialogueManager.start_dialogue("礦坑高壓配電盤", [
			"地底鑽探機與基因實驗室的照明全面亮起，電壓穩定鎖定於【440V】！",
			"重型武器櫃應聲開啟——獲得了【地熱高壓火焰噴射器 (Flamethrower)】與高壓燃料罐！"
		])
		return true
	AudioManager.play_synth_sfx("door_locked")
	return false
