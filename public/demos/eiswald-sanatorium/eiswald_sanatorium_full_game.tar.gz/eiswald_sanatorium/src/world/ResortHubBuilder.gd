class_name ResortHubBuilder
extends Node3D
## ResortHubBuilder.gd
## Constructs the complete radial Metroidvania 3D world across all 4 themed zones:
## 1. Fairytale Town Central Hub (雪絨花童話村 — 旋轉木馬樞紐、毒蠅傘蘑菇屋、壁爐營火安全屋)
## 2. Haunted Hilltop (霧嶺鬧鬼山丘 — 哥德古堡、真假鬼屋墓園、星座自動鋼琴謎題、.44馬格南、單向捷徑門)
## 3. Ocean Kingdom (冰川海洋王國 — 藍綠深海水族館、海盜船餐廳、85 PSI 水壓謎題、強酸液瓶、單向捷徑門)
## 4. The Roots / Underground (地下挖掘場與秘密設施 — 陰暗礦坑、440V 配電謎題、火焰噴射器、白髓母體池頭目戰)

var mat_snow_stone: Material
var mat_pale_ichor: Material
var mat_dark_timber: Material
var mat_fairytale_red: Material
var mat_gothic_slate: Material
var mat_ocean_aqua: Material
var mat_rusted_steel: Material
var mat_brass_gold: Material

func _ready() -> void:
	_init_pbr_materials()
	_build_zone1_fairytale_hub()
	_build_zone2_haunted_hilltop()
	_build_zone3_ocean_kingdom()
	_build_zone4_underground_roots()
	_build_radial_doors_and_shortcuts()
	_build_campfire_safe_room_facilities()
	_build_npcs_and_progression_items()
	_build_four_zone_puzzles()
	_build_enemies_and_five_trap_types()
	_build_crystal_edelweiss_targets()
	var furnisher := SubRoomFurnisher.new()
	add_child(furnisher)
	furnisher.populate_commercial_details(self)
	print("[Eiswald] ResortHubBuilder initialized! Total 3D world nodes: ", get_child_count())

func _init_pbr_materials() -> void:
	var snow_sh := load("res://assets/shaders/snow_accumulation.gdshader") as Shader
	if snow_sh:
		mat_snow_stone = ShaderMaterial.new()
		mat_snow_stone.shader = snow_sh

	var ichor_sh := load("res://assets/shaders/pale_ichor_fluid.gdshader") as Shader
	if ichor_sh:
		mat_pale_ichor = ShaderMaterial.new()
		mat_pale_ichor.shader = ichor_sh

	var wood_sh := load("res://assets/shaders/realistic_aged_timber.gdshader") as Shader
	if wood_sh:
		var sm_wood := ShaderMaterial.new()
		sm_wood.shader = wood_sh
		mat_dark_timber = sm_wood as Variant
	else:
		mat_dark_timber = StandardMaterial3D.new()
		mat_dark_timber.albedo_color = Color(0.20, 0.13, 0.09)
		mat_dark_timber.roughness = 0.72

	var roof_sh := load("res://assets/shaders/realistic_roof_tiles.gdshader") as Shader
	if roof_sh:
		var sm_roof := ShaderMaterial.new()
		sm_roof.shader = roof_sh
		mat_fairytale_red = sm_roof as Variant
	else:
		mat_fairytale_red = StandardMaterial3D.new()
		mat_fairytale_red.albedo_color = Color(0.76, 0.16, 0.18)
		mat_fairytale_red.roughness = 0.45

	var stone_sh := load("res://assets/shaders/realistic_alpine_stone.gdshader") as Shader
	if stone_sh:
		var sm_stone := ShaderMaterial.new()
		sm_stone.shader = stone_sh
		mat_gothic_slate = sm_stone as Variant
	else:
		mat_gothic_slate = StandardMaterial3D.new()
		mat_gothic_slate.albedo_color = Color(0.16, 0.15, 0.22)
		mat_gothic_slate.roughness = 0.65

	mat_ocean_aqua = StandardMaterial3D.new()
	mat_ocean_aqua.albedo_color = Color(0.08, 0.34, 0.42)
	mat_ocean_aqua.roughness = 0.22
	mat_ocean_aqua.metallic = 0.25

	mat_rusted_steel = StandardMaterial3D.new()
	mat_rusted_steel.albedo_color = Color(0.32, 0.25, 0.22)
	mat_rusted_steel.metallic = 0.78
	mat_rusted_steel.roughness = 0.55

	mat_brass_gold = StandardMaterial3D.new()
	mat_brass_gold.albedo_color = Color(0.85, 0.68, 0.26)
	mat_brass_gold.metallic = 0.88
	mat_brass_gold.roughness = 0.24

func _build_zone1_fairytale_hub() -> void:
	# Starting Room: 1:1 Crow Country Fireside Lounge & Reception Diorama (Center X=0, Z=16.5)
	_spawn_static_box("ArrivalFloor", Vector3(0, -0.25, 16.5), Vector3(12.2, 0.5, 9.8), mat_dark_timber)
	var lounge_diorama: Node3D = RealisticEnvironmentBuilder.build_crow_country_fireside_lounge_diorama(Vector3(0, 0, 16.5))
	add_child(lounge_diorama)

	# Fairytale Town Central Hub (Center X=0, Z=-8) — Grand Carousel & Half-Timbered Chalets
	_spawn_static_box("FairytaleHubFloor", Vector3(0, -0.25, -8.0), Vector3(26, 0.5, 22), mat_snow_stone)
	_spawn_perimeter_bounds("FairytaleHubBounds", Vector3(0, 0, -8.0), Vector3(26, 4.5, 22))
	var carousel_body := StaticBody3D.new()
	carousel_body.name = "GrandCarouselBody"
	carousel_body.position = Vector3(0.0, 0.0, -7.5)
	_attach_collider_with_custom_node(carousel_body, Vector3(6.2, 4.8, 6.2), RealisticEnvironmentBuilder.build_grand_carousel())
	add_child(carousel_body)
	_spawn_omni_light(Vector3(0, 4.2, -7.5), Color(1.0, 0.68, 0.34), 1.45, 14.0)

	# Toadstool Mushroom Cottage (South-West Alcove: X=-22, Z=8)
	_spawn_static_box("MushroomCottageFloor", Vector3(-22.0, -0.25, 8.0), Vector3(14.0, 0.5, 14.0), mat_dark_timber)
	_spawn_perimeter_bounds("MushroomCottageBounds", Vector3(-22.0, 0, 8.0), Vector3(14.0, 4.5, 14.0))
	var mushroom_body := StaticBody3D.new()
	mushroom_body.name = "ToadstoolCottageBody"
	mushroom_body.position = Vector3(-22.0, 0.0, 12.2)
	_attach_collider_with_custom_node(mushroom_body, Vector3(5.2, 4.8, 4.8), RealisticEnvironmentBuilder.build_toadstool_cottage())
	add_child(mushroom_body)
	_spawn_omni_light(Vector3(-22.0, 3.4, 8.0), Color(0.98, 0.62, 0.42), 1.15, 11.0)

	# Campfire Safe Room (North-West Sanctuary: X=-17.5, Z=-8) — Also built as a warm Crow Country Diorama Box
	_spawn_static_box("SafeRoomFloor", Vector3(-17.5, -0.25, -8.0), Vector3(12.0, 0.5, 10.0), mat_dark_timber)
	var safe_diorama: Node3D = RealisticEnvironmentBuilder.build_crow_country_fireside_lounge_diorama(Vector3(-17.5, 0, -8.0))
	add_child(safe_diorama)

	_build_alpine_architecture_and_trees()

func _build_alpine_architecture_and_trees() -> void:
	# 1. Grand Wrought-Iron & Cut-Stone Sanatorium Entrance Gates & Fence (at Z = +3.5, north edge of Fairytale Courtyard)
	var gates := RealisticEnvironmentBuilder.build_grand_entrance_gates()
	gates.position = Vector3(0, 0, -1.5)
	add_child(gates)

	# 2. Surrounding Half-Timbered Fairytale Village Chalet Facades framing the Hub Plaza
	var chalet_nw := StaticBody3D.new()
	chalet_nw.position = Vector3(-9.5, 0.0, -16.8)
	_attach_collider_with_custom_node(chalet_nw, Vector3(5.6, 4.4, 4.2), RealisticEnvironmentBuilder.build_alpine_chalet(5.6, 4.0, 4.2, true))
	add_child(chalet_nw)

	var chalet_ne := StaticBody3D.new()
	chalet_ne.position = Vector3(9.5, 0.0, -16.8)
	_attach_collider_with_custom_node(chalet_ne, Vector3(5.6, 4.4, 4.2), RealisticEnvironmentBuilder.build_alpine_chalet(5.6, 4.0, 4.2, false))
	add_child(chalet_ne)

	# 3. Detailed Victorian Cast-Iron Streetlamps in the Fairytale Courtyard
	for lamp_pos in [
		Vector3(-4.2, 0.0, 1.2), Vector3(4.2, 0.0, 1.2),
		Vector3(-5.8, 0.0, -11.5), Vector3(5.8, 0.0, -11.5)
	]:
		var lamp: Node3D = RealisticEnvironmentBuilder.build_victorian_streetlamp()
		lamp.position = lamp_pos
		add_child(lamp)

	# 4. Multi-Branch Snow-Laden Alpine Pine Forest framing the Fairytale Village Courtyard
	var tree_placements: Array[Dictionary] = [
		{"pos": Vector3(-11.2, 0.0, -1.8), "scale": 1.18},
		{"pos": Vector3(11.2, 0.0, -1.8), "scale": 1.05},
		{"pos": Vector3(-12.5, 0.0, -12.5), "scale": 1.22},
		{"pos": Vector3(12.5, 0.0, -12.5), "scale": 1.10}
	]
	for tp in tree_placements:
		var pine: Node3D = RealisticEnvironmentBuilder.build_realistic_pine_tree(float(tp["scale"]))
		pine.position = tp["pos"]
		add_child(pine)

func _build_zone2_haunted_hilltop() -> void:
	# West Radial Zone (X = -38, Z = -8): Gothic Crypt, Fake-Ghost Corridor & Constellation Piano Chapel
	_spawn_static_box("HauntedHilltopFloor", Vector3(-38.0, -0.25, -8.0), Vector3(20.0, 0.5, 20.0), mat_gothic_slate)
	_spawn_perimeter_bounds("HauntedHilltopBounds", Vector3(-38.0, 0, -8.0), Vector3(20.0, 4.5, 20.0))
	var crypt_chapel := StaticBody3D.new()
	crypt_chapel.position = Vector3(-45.5, 0.0, -14.5)
	_attach_collider_with_custom_node(crypt_chapel, Vector3(5.2, 4.6, 3.8), RealisticEnvironmentBuilder.build_alpine_chalet(5.2, 4.2, 3.8, false))
	add_child(crypt_chapel)
	_spawn_omni_light(Vector3(-38.0, 4.0, -8.0), Color(0.68, 0.42, 0.95), 1.35, 16.0)

func _build_zone3_ocean_kingdom() -> void:
	# East Radial Zone (X = +26, Z = -8): Abyssal Aquarium Dome & Pirate Ship Restaurant
	_spawn_static_box("OceanKingdomFloor", Vector3(26.0, -0.25, -8.0), Vector3(22.0, 0.5, 20.0), mat_ocean_aqua)
	_spawn_perimeter_bounds("OceanKingdomBounds", Vector3(26.0, 0, -8.0), Vector3(22.0, 4.5, 20.0))
	_spawn_static_box("AbyssalWaterTank", Vector3(26.0, 0.12, -13.0), Vector3(9.0, 0.25, 5.0), mat_pale_ichor)
	var galleon_body := StaticBody3D.new()
	galleon_body.position = Vector3(31.5, 1.2, -4.0)
	_attach_collider_with_custom_node(galleon_body, Vector3(3.2, 4.5, 7.2), RealisticEnvironmentBuilder.build_pirate_galleon_ship())
	add_child(galleon_body)
	_spawn_omni_light(Vector3(26.0, 4.2, -8.0), Color(0.15, 0.88, 0.92), 1.40, 17.0)

func _build_zone4_underground_roots() -> void:
	# North/Subterranean Radial Zone (X = 0, Z = -32): The Pale Roots Mining Quarry & Vance's Bio-Lab
	_spawn_static_box("UndergroundQuarryFloor", Vector3(0.0, -0.25, -32.0), Vector3(26.0, 0.5, 20.0), mat_rusted_steel)
	_spawn_perimeter_bounds("UndergroundQuarryBounds", Vector3(0.0, 0, -32.0), Vector3(26.0, 4.5, 20.0))
	_spawn_static_box("PaleIchorMotherPool", Vector3(0.0, 0.15, -38.0), Vector3(8.0, 0.3, 4.5), mat_pale_ichor)
	_spawn_omni_light(Vector3(0.0, 4.0, -32.0), Color(0.95, 0.28, 0.22), 4.0, 17.0)

func _build_radial_doors_and_shortcuts() -> void:
	# 0. Starting Fireside Lounge Diorama <-> Fairytale Town Central Hub (South-West exit doorway)
	_spawn_door(
		"door_lounge_to_hub", "前往【雪絨花童話中央廣場】", "Z1_R02_FairytaleHub",
		Vector3(-3.4, 1.2, 20.9), Vector3(0.0, 0.2, -2.5), 0.0,
		false, "", "", "", false, false
	)
	_spawn_omni_light(Vector3(-3.4, 1.8, 20.4), Color(1.0, 0.78, 0.40), 0.95, 4.5)
	_spawn_door(
		"door_hub_to_lounge", "返回【壁爐迎賓休息室 (Fireside Lounge)】", "Z1_R01_ArrivalGates",
		Vector3(0.0, 1.2, 1.5), Vector3(0.05, 0.15, 17.25), -4.5,
		false, "", "", "", false, false
	)

	# 1. Fairytale Hub <-> Campfire Safe Room (Always open sanctuary)
	_spawn_door(
		"door_safe_enter", "童話村壁爐營火安全屋", "Z1_R04_CampfireSafeRoom",
		Vector3(-11.2, 1.2, -8.0), Vector3(-14.2, 0.2, -8.0), 45.0,
		false, "", "", "", false, false
	)
	_spawn_door(
		"door_safe_exit", "返回雪絨花童話中央廣場", "Z1_R02_FairytaleHub",
		Vector3(-14.0, 1.2, -4.2), Vector3(-8.5, 0.2, -8.0), 45.0,
		false, "", "", "", false, false
	)

	# 2. Fairytale Hub <-> Toadstool Mushroom Cottage (Blocked by wooden planks -> Requires Steel Crowbar!)
	_spawn_door(
		"door_mushroom_enter", "木板封死的毒蠅傘蘑菇屋門", "Z1_R03_ToadstoolCottage",
		Vector3(-9.5, 1.2, -1.5), Vector3(-18.5, 0.2, 8.0), 45.0,
		true, "tool_crowbar", "精鋼撬棍 (Crowbar)", "mushroom_cottage_pried", false, false
	)
	_spawn_door(
		"door_mushroom_exit", "返回雪絨花童話中央廣場", "Z1_R02_FairytaleHub",
		Vector3(-16.5, 1.2, 5.0), Vector3(-7.5, 0.2, -3.5), 45.0,
		false, "", "", "", false, false
	)

	# 3. Fairytale Hub <-> Zone 2: Haunted Hilltop (Requires Bronze Wing Key!)
	_spawn_door(
		"door_haunted_enter", "【鬧鬼山丘】哥德古堡鐵門", "Z2_R06_HauntedChapel",
		Vector3(-11.2, 1.2, -13.5), Vector3(-31.0, 0.2, -8.0), 45.0,
		true, "key_bronze_wing", "銅翼雙鴉鑰匙", "haunted_hilltop_unlocked", false, false
	)
	# One-Way Shortcut from Haunted Hilltop directly back to Campfire Safe Room / Hub!
	_spawn_door(
		"door_haunted_shortcut_inside", "【單向捷徑鐵門】拉開插銷直通童話鎮安全屋", "Z1_R04_CampfireSafeRoom",
		Vector3(-29.5, 1.2, -3.5), Vector3(-16.0, 0.2, -5.0), 45.0,
		true, "", "", "shortcut_haunted_to_hub_opened", true, true
	)

	# 4. Fairytale Hub <-> Zone 3: Ocean Kingdom (Requires Silver Seahorse Key!)
	_spawn_door(
		"door_ocean_enter", "【海洋王國】深海圓頂水族館大門", "Z3_R07_AbyssalAquarium",
		Vector3(11.2, 1.2, -8.0), Vector3(17.5, 0.2, -8.0), -45.0,
		true, "key_silver_seahorse", "銀冠海馬鑰匙", "ocean_kingdom_unlocked", false, false
	)
	# One-Way Shortcut from Ocean Kingdom back to Fairytale Hub!
	_spawn_door(
		"door_ocean_shortcut_inside", "【單向捷徑鐵門】拉開插銷返回童話中央廣場", "Z1_R02_FairytaleHub",
		Vector3(16.2, 1.2, -3.0), Vector3(8.5, 0.2, -5.0), 45.0,
		true, "", "", "shortcut_ocean_to_hub_opened", true, true
	)

	# 5. Fairytale Hub <-> Zone 4: The Underground Roots (Locked by rusted chains -> Requires Acid Vial!)
	_spawn_door(
		"door_roots_enter", "【地下挖掘場】重型鏽蝕鐵鍊升降梯門", "Z4_R09_SubterraneanQuarry",
		Vector3(0.0, 1.2, -17.2), Vector3(0.0, 0.2, -24.0), 0.0,
		true, "acid_vial", "高濃度強酸液瓶 (Acid Vial)", "underground_roots_unlocked", false, false
	)
	_spawn_door(
		"door_roots_exit", "搭乘礦坑升降梯返回童話中央廣場", "Z1_R02_FairytaleHub",
		Vector3(0.0, 1.2, -22.2), Vector3(0.0, 0.2, -14.0), 45.0,
		false, "", "", "", false, false
	)

func _build_campfire_safe_room_facilities() -> void:
	# 1. Warm Hearth Campfire in Safe Room
	var campfire := SafeRoomTerminal.new()
	campfire.terminal_kind = SafeRoomTerminal.TerminalKind.CAMPFIRE_HEARTH
	campfire.position = Vector3(-17.5, 0.5, -12.5)
	_attach_collider_with_custom_node(campfire, Vector3(1.5, 1.2, 1.5), RealisticEnvironmentBuilder.build_campfire_hearth())
	add_child(campfire)

	# 2. Reel-to-Reel Tape Recorder (Save Game)
	var tape := SafeRoomTerminal.new()
	tape.terminal_kind = SafeRoomTerminal.TerminalKind.TAPE_RECORDER_SAVE
	tape.position = Vector3(-20.5, 0.8, -11.5)
	_attach_collider_and_mesh(tape, Vector3(1.1, 1.0, 0.9), mat_brass_gold, "res://assets/models/reel_tape_recorder.glb")
	add_child(tape)

	# 3. Progressive 3-Tier Fortune Teller ("The Alpine Oracle")
	var oracle := SafeRoomTerminal.new()
	oracle.terminal_kind = SafeRoomTerminal.TerminalKind.ALPINE_ORACLE_FORTUNE
	oracle.position = Vector3(-14.5, 1.1, -11.5)
	_attach_collider_and_mesh(oracle, Vector3(1.1, 2.2, 1.1), mat_brass_gold, "res://assets/models/alpine_oracle_machine.glb")
	add_child(oracle)

func _build_npcs_and_progression_items() -> void:
	# Starting Fireside Lounge: Summons Document #01 on Coffee Table & Sideboard Ammo + Early Crossbow & 2 Collectibles
	_spawn_doc("doc_01_summons", "調查卷宗 #01：四大主題園區與地底秘密", "Z1_R01_ArrivalGates", Vector3(-0.35, 0.52, 16.55), false)
	_spawn_pickup("ammo_9mm", 15, "迎賓室胡桃木邊櫃 9mm 彈藥盒", "Z1_R01_ArrivalGates", Vector3(-4.55, 0.92, 16.85), "car_trunk_inspected", "", false)
	_spawn_pickup("weapon_hunting_crossbow", 1, "雪山精鋼連弩 (Crossbow)", "Z1_R01_ArrivalGates", Vector3(3.1, 0.55, 17.8))
	_spawn_pickup("ammo_bolts", 12, "精鋼弩箭組 (12 支)", "Z1_R01_ArrivalGates", Vector3(3.1, 0.55, 16.7))
	_spawn_pickup("collectible_snow_globe", 1, "【珍藏 1/6】白鴉雪花水晶球", "Z1_R01_ArrivalGates", Vector3(-3.2, 0.55, 14.8))
	_spawn_pickup("collectible_golden_crow_crest", 1, "【珍藏 2/6】純金雙鴉徽章", "Z1_R01_ArrivalGates", Vector3(2.8, 0.55, 14.6))

	# Fairytale Hub: Architect Arthur Vance (Gives Steel Crowbar!) + Shotgun
	var arthur := Interactable.new()
	arthur.interact_type = Interactable.InteractType.NPC_DIALOGUE
	arthur.npc_name = "總建築師 亞瑟·范斯 (Arthur Vance)"
	arthur.object_title = "總建築師 亞瑟·范斯"
	arthur.room_id = "Z1_R02_FairytaleHub"
	arthur.sets_world_flag = "crowbar_obtained"
	arthur.gives_item_on_dialogue = "tool_crowbar"
	arthur.dialogue_lines = [
		"「薇拉！這座『雪絨花童話村』是整座樂園的放射狀中央樞紐，通往西翼『鬧鬼山丘』、東翼『海洋王國』與北側『地下挖掘場』的大門都在這裡！」",
		"「拿著這把【精鋼撬棍 (Crowbar)】，先去撬開廣場南側被木板封死的『毒蠅傘蘑菇屋』，找出裡面的懷錶與【銅翼雙鴉鑰匙】！」",
		"「如果卡關了，隨時去西側的『壁爐營火安全屋』向算命機索取三階段漸進式提示。」"
	]
	arthur.position = Vector3(-3.8, 0.0, -13.2)
	var arthur_col := CollisionShape3D.new()
	var arthur_shape := BoxShape3D.new()
	arthur_shape.size = Vector3(0.9, 1.9, 0.9)
	arthur_col.shape = arthur_shape
	arthur_col.position = Vector3(0, 0.95, 0)
	arthur.add_child(arthur_col)
	arthur.add_child(HumanoidCharacterBuilder.build_npc_humanoid(Color(0.28, 0.19, 0.13), Color(0.75, 0.75, 0.78), Color(0.72, 0.54, 0.20), false))
	add_child(arthur)

	_spawn_pickup("weapon_alpine_shotgun", 1, "阿爾卑斯雙管霰彈槍", "Z1_R02_FairytaleHub", Vector3(3.8, 0.55, -13.2))
	_spawn_pickup("ammo_12gauge", 8, "12號霰彈槍彈藥 (8 發)", "Z1_R02_FairytaleHub", Vector3(4.9, 0.55, -13.2))
	_spawn_pickup("weapon_mp5_smg", 1, "MP-91 特種衝鋒槍 (SMG)", "Z1_R02_FairytaleHub", Vector3(-6.2, 0.55, -13.0))
	_spawn_pickup("ammo_9mm", 30, "9mm 衝鋒槍備用彈匣 (30 發)", "Z1_R02_FairytaleHub", Vector3(-5.1, 0.55, -13.0))
	_spawn_pickup("collectible_carousel_horse_figurine", 1, "【珍藏 3/6】雕花木馬微縮像", "Z1_R02_FairytaleHub", Vector3(4.2, 0.55, -5.2))

	# Safe Room: Memo #02, First-Aid Spray, Antidote & Collectible #4
	_spawn_doc("doc_02_TeaRoomMemo", "安全屋指南：壁爐營火與漸進式算命機", "Z1_R04_CampfireSafeRoom", Vector3(-16.5, 0.8, -5.5))
	_spawn_pickup("first_aid_spray", 1, "急救噴霧 (First-Aid Spray)", "Z1_R04_CampfireSafeRoom", Vector3(-20.2, 0.7, -6.5))
	_spawn_pickup("ichor_antidote", 2, "白髓解毒血清 (Antidote)", "Z1_R04_CampfireSafeRoom", Vector3(-20.2, 0.7, -8.5))
	_spawn_pickup("collectible_cassette_1991", 1, "【珍藏 4/6】1991 療養院機密錄音帶", "Z1_R04_CampfireSafeRoom", Vector3(-16.2, 0.55, -7.8))

	# Toadstool Mushroom Cottage: Stopped Brass Pocket Watch + Journal #03
	_spawn_pickup("brass_pocket_watch", 1, "停擺的銅製懷錶", "Z1_R03_ToadstoolCottage", Vector3(-21.5, 0.85, 8.0), "pocket_watch_found", "res://assets/models/brass_pocket_watch.glb")
	_spawn_doc("doc_03_CuratorJournal", "童話鎮日誌：毒蠅傘蘑菇屋與女巫時鐘", "Z1_R03_ToadstoolCottage", Vector3(-24.0, 0.85, 8.0))

	# Haunted Hilltop: Lore #04 + Magnum + Porcelain Mask Collectible #5
	_spawn_doc("doc_04_HauntedNotes", "鬧鬼山丘手札：真假鬼屋與烏鴉座星盤", "Z2_R06_HauntedChapel", Vector3(-35.0, 0.85, -12.0))
	_spawn_pickup("weapon_white_crow_magnum", 1, "白鴉 .44 馬格南左輪", "Z2_R06_HauntedChapel", Vector3(-35.5, 0.55, -10.5))
	_spawn_pickup("ammo_44magnum", 12, ".44 馬格南高爆彈 (12 發)", "Z2_R06_HauntedChapel", Vector3(-34.3, 0.55, -10.5))
	_spawn_pickup("collectible_porcelain_mask", 1, "【珍藏 5/6】白鴉歌劇陶瓷面具", "Z2_R06_HauntedChapel", Vector3(-41.0, 0.55, -6.5))

	# Ocean Kingdom: Lore #05 + Bolt-Action Rifle + Abyssal Pearl Collectible #6
	_spawn_doc("doc_05_OceanKingdomLog", "海洋王國日誌：水下展廳水壓與海盜船強酸", "Z3_R07_AbyssalAquarium", Vector3(22.5, 0.85, -12.0))
	_spawn_pickup("weapon_sanatorium_rifle", 1, "瑞士毛瑟栓動步槍", "Z3_R07_AbyssalAquarium", Vector3(24.0, 0.55, -4.5))
	_spawn_pickup("ammo_rifle", 10, "7.5mm 瑞士步槍彈 (10 發)", "Z3_R07_AbyssalAquarium", Vector3(25.2, 0.55, -4.5))
	_spawn_pickup("collectible_abyssal_pearl", 1, "【珍藏 6/6】深海發光珍珠匣", "Z3_R07_AbyssalAquarium", Vector3(28.5, 0.55, -11.5))

	# Underground Roots: Lore #06 + Geothermal Flamethrower
	_spawn_doc("doc_06_UndergroundRootsReport", "最高機密：地下挖掘場與白髓計畫", "Z4_R09_SubterraneanQuarry", Vector3(-4.5, 0.85, -28.0))
	_spawn_pickup("weapon_geothermal_flamethrower", 1, "地熱高壓火焰噴射器", "Z4_R09_SubterraneanQuarry", Vector3(4.5, 0.55, -30.5))
	_spawn_pickup("ammo_fuel_tank", 50, "高壓濃縮燃料罐 (50)", "Z4_R09_SubterraneanQuarry", Vector3(5.6, 0.55, -30.5))

func _build_four_zone_puzzles() -> void:
	# Zone 1 Puzzle: Toadstool Cottage Grandfather Clock ("0415" -> Bronze Wing Key)
	var clock_puzzle := ClockworkSafePuzzle.new()
	clock_puzzle.add_to_group("puzzles")
	clock_puzzle.position = Vector3(-26.0, 1.3, 8.0)
	_attach_collider_with_custom_node(clock_puzzle, Vector3(1.2, 2.6, 1.2), RealisticEnvironmentBuilder.build_puzzle_station("clock"))
	add_child(clock_puzzle)

	# Zone 2 Puzzle: Haunted Hilltop Corvus Constellation Piano ("13542" -> Silver Seahorse Key + .44 Magnum)
	var piano_puzzle := OrganMelodyPuzzle.new()
	piano_puzzle.add_to_group("puzzles")
	piano_puzzle.position = Vector3(-42.5, 1.3, -8.5)
	_attach_collider_with_custom_node(piano_puzzle, Vector3(2.4, 2.0, 1.4), RealisticEnvironmentBuilder.build_puzzle_station("organ"))
	add_child(piano_puzzle)

	# Zone 3 Puzzle: Ocean Kingdom 3-Chamber Hydro Pressure ("85" -> Acid Vial)
	var hydro_puzzle := SteamValvePuzzle.new()
	hydro_puzzle.add_to_group("puzzles")
	hydro_puzzle.position = Vector3(32.0, 1.2, -11.5)
	_attach_collider_with_custom_node(hydro_puzzle, Vector3(1.6, 2.2, 1.4), RealisticEnvironmentBuilder.build_puzzle_station("hydro"))
	add_child(hydro_puzzle)

	# Zone 4 Puzzle: Underground Quarry 440V Mining Generator ("440" -> Geothermal Flamethrower)
	var voltage_puzzle := VoltageGridPuzzle.new()
	voltage_puzzle.add_to_group("puzzles")
	voltage_puzzle.position = Vector3(-7.5, 1.2, -33.0)
	_attach_collider_with_custom_node(voltage_puzzle, Vector3(1.5, 2.2, 1.2), RealisticEnvironmentBuilder.build_puzzle_station("voltage"))
	add_child(voltage_puzzle)

	# Zone 1 Bonus Puzzle: Fairytale Town Retro Arcade Cabinet ("1991" -> VP-9 Mag Upgrade + First-Aid Spray)
	var arcade_puzzle := ArcadeMinigamePuzzle.new()
	arcade_puzzle.add_to_group("puzzles")
	arcade_puzzle.position = Vector3(7.2, 1.2, -13.0)
	_attach_collider_and_mesh(arcade_puzzle, Vector3(1.1, 2.2, 1.1), mat_fairytale_red, "res://assets/models/arcade_cabinet_retro.glb")
	add_child(arcade_puzzle)

	# Zone 3 Bonus Puzzle: Pirate Ship Captain's Compass & Deck Cannon ("2486" -> .44 Magnum & Shotgun Ammo)
	var pirate_puzzle := PirateCannonPuzzle.new()
	pirate_puzzle.add_to_group("puzzles")
	pirate_puzzle.position = Vector3(29.5, 1.2, -4.0)
	_attach_collider_with_custom_node(pirate_puzzle, Vector3(1.2, 1.8, 1.4), RealisticEnvironmentBuilder.build_puzzle_station("cannon"))
	add_child(pirate_puzzle)

	# Zone 2 Crypt Skeleton Cipher Puzzle ("741" -> Satchel 12-Slot Expansion + Shotgun Ammo)
	var crypt_puzzle := CryptSkeletonPuzzle.new()
	crypt_puzzle.add_to_group("puzzles")
	crypt_puzzle.position = Vector3(-44.0, 1.2, -13.5)
	_attach_collider_with_custom_node(crypt_puzzle, Vector3(1.8, 1.8, 1.2), RealisticEnvironmentBuilder.build_puzzle_station("crypt"))
	add_child(crypt_puzzle)

	# Zone 4 Bio-Lab Final Genetic Sequence Terminal ("1989" -> Unseals Clara's Cryo-Spire & Victory S-Rank Report)
	var biolab_puzzle := BioLabGenePuzzle.new()
	biolab_puzzle.add_to_group("puzzles")
	biolab_puzzle.position = Vector3(0.0, 1.3, -39.5)
	_attach_collider_with_custom_node(biolab_puzzle, Vector3(1.8, 2.4, 1.2), RealisticEnvironmentBuilder.build_puzzle_station("biolab"))
	biolab_puzzle.final_cryo_spire_unsealed.connect(func():
		var hud := get_tree().current_scene.get_node_or_null("HUDController")
		if hud and hud.has_method("open_ending_report"):
			hud.call("open_ending_report")
	)
	add_child(biolab_puzzle)

	# Haunted Hilltop Fake vs Real Spooky Coffins (Crow Country Haunted Hilltop signature feature)
	var fake_coffin := HauntedFakeGhostProp.new()
	fake_coffin.coffin_title = "哥德驚魂屋彩繪棺木 #1"
	fake_coffin.is_fake_theme_park_prop = true
	fake_coffin.hides_item_id = "ammo_9mm"
	fake_coffin.hides_item_qty = 10
	fake_coffin.position = Vector3(-33.5, 1.1, -12.5)
	_attach_collider_and_mesh(fake_coffin, Vector3(1.1, 2.1, 0.9), mat_dark_timber, "res://assets/models/haunted_coffin_prop.glb")
	add_child(fake_coffin)

	var real_coffin := HauntedFakeGhostProp.new()
	real_coffin.coffin_title = "滲出白髓的古老石棺 #2"
	real_coffin.is_fake_theme_park_prop = false
	real_coffin.position = Vector3(-39.5, 1.1, -13.5)
	_attach_collider_and_mesh(real_coffin, Vector3(1.1, 2.1, 0.9), mat_gothic_slate, "res://assets/models/haunted_coffin_prop.glb")
	add_child(real_coffin)

func _build_enemies_and_five_trap_types() -> void:
	var trap_red := StandardMaterial3D.new()
	trap_red.albedo_color = Color(0.92, 0.22, 0.18)

	# 1. Explosive Fuel Barrel in Fairytale Courtyard
	_spawn_trap(EnvironmentalTrap.TrapKind.EXPLOSIVE_GAS_CANISTER, "高壓易爆油桶", Vector3(4.5, 0.7, -2.5), Vector3(0.75, 1.35, 0.75), trap_red)
	# 2. Alpine Bear Trap in Fairytale Hub East Path
	_spawn_trap(EnvironmentalTrap.TrapKind.ALPINE_BEAR_TRAP, "雪山捕熊夾", Vector3(6.5, 0.15, -6.5), Vector3(0.85, 0.25, 0.85), mat_rusted_steel)
	# 3. Proximity Landmine in Haunted Hilltop Cemetery
	_spawn_trap(EnvironmentalTrap.TrapKind.PROXIMITY_LANDMINE, "感應地雷 (Proximity Mine)", Vector3(-35.5, 0.15, -6.5), Vector3(0.65, 0.2, 0.65), trap_red)
	# 4. Toxic Ichor Gas Pipe in Ocean Kingdom
	_spawn_trap(EnvironmentalTrap.TrapKind.TOXIC_GAS_PIPE, "破裂白髓毒氣管線", Vector3(24.5, 1.0, -5.5), Vector3(0.6, 1.8, 0.6), mat_pale_ichor)
	# 5. Fragile Ceiling Chandelier / Icicle in Underground Quarry (Shoot overhead to crush enemies below!)
	_spawn_trap(EnvironmentalTrap.TrapKind.FRAGILE_CEILING_ICICLE, "脆弱鐘乳石吊燈 (可射落砸毀下方敵人)", Vector3(0.0, 3.8, -32.0), Vector3(1.5, 0.9, 1.5), mat_brass_gold)

	# Enemies across the 4 zones with full articulated 3D creature models
	_spawn_enemy_with_hitboxes("童話村異變木偶師 #01", Vector3(6.8, 0.1, -3.5), false, "res://assets/models/monster_fairytale_puppet.glb")
	_spawn_enemy_with_hitboxes("鬧鬼山丘棺木潛行者 #02", Vector3(-37.0, 0.1, -6.5), false, "res://assets/models/monster_haunted_stalker.glb")
	_spawn_enemy_with_hitboxes("海洋王國深水潛水夫畸變體 #03", Vector3(26.5, 0.1, -6.5), false, "res://assets/models/monster_ocean_diver.glb")
	_spawn_enemy_with_hitboxes("【最終頭目】白髓母體君王 克羅爾", Vector3(0.0, 0.1, -34.0), true, "res://assets/models/boss_pale_sovereign.glb")

func _build_crystal_edelweiss_targets() -> void:
	var positions: Array[Dictionary] = [
		{"id": "edelweiss_01", "pos": Vector3(0.0, 3.6, 1.8), "hint": "童話鎮大門拱廊上方"},
		{"id": "edelweiss_02", "pos": Vector3(-4.2, 3.5, 1.2), "hint": "山門廣場路燈頂端"},
		{"id": "edelweiss_03", "pos": Vector3(0.0, 3.9, -7.5), "hint": "童話中央廣場旋轉木馬尖頂"},
		{"id": "edelweiss_04", "pos": Vector3(8.5, 3.5, -13.5), "hint": "童話廣場復古街機上方樑柱"},
		{"id": "edelweiss_05", "pos": Vector3(-17.5, 3.3, -12.5), "hint": "壁爐營火安全屋煙囪口"},
		{"id": "edelweiss_06", "pos": Vector3(-25.5, 3.5, 4.0), "hint": "毒蠅傘蘑菇屋閣樓"},
		{"id": "edelweiss_07", "pos": Vector3(-22.0, 4.4, 12.0), "hint": "毒蠅傘巨型紅傘頂冠"},
		{"id": "edelweiss_08", "pos": Vector3(-33.5, 3.6, -12.5), "hint": "鬧鬼山丘假鬼屋棺木廊上方"},
		{"id": "edelweiss_09", "pos": Vector3(-42.0, 3.8, -13.0), "hint": "鬧鬼山丘哥德靈廟尖塔"},
		{"id": "edelweiss_10", "pos": Vector3(-44.0, 3.5, -4.5), "hint": "鬧鬼山丘三聖骸骨石棺後方"},
		{"id": "edelweiss_11", "pos": Vector3(26.0, 3.9, -13.0), "hint": "海洋王國深海水族館圓頂"},
		{"id": "edelweiss_12", "pos": Vector3(31.5, 4.0, -4.0), "hint": "海洋王國破冰船號主桅杆"},
		{"id": "edelweiss_13", "pos": Vector3(20.0, 3.4, -2.5), "hint": "海洋王國單向捷徑門上方"},
		{"id": "edelweiss_14", "pos": Vector3(-7.5, 3.8, -33.0), "hint": "地下挖掘場 440V 發電機頂端"},
		{"id": "edelweiss_15", "pos": Vector3(0.0, 4.1, -38.0), "hint": "秘密設施白髓母體池穹頂"}
	]
	var crystal_mat := StandardMaterial3D.new()
	crystal_mat.albedo_color = Color(0.55, 0.95, 1.0)
	crystal_mat.emission_enabled = true
	crystal_mat.emission = Color(0.35, 0.85, 1.0)
	crystal_mat.emission_energy_multiplier = 2.4

	for info in positions:
		var ce := CrystalEdelweiss.new()
		ce.crystal_id = String(info["id"])
		ce.location_hint = String(info["hint"])
		ce.position = info["pos"]
		_attach_collider_and_mesh(ce, Vector3(0.45, 0.45, 0.45), crystal_mat)
		add_child(ce)

func _spawn_trap(kind: EnvironmentalTrap.TrapKind, t_name: String, pos: Vector3, size: Vector3, _mat: Material) -> void:
	var trap := EnvironmentalTrap.new()
	trap.trap_kind = kind
	trap.trap_name = t_name
	trap.position = pos
	_attach_collider_with_custom_node(trap, size, RealisticEnvironmentBuilder.build_trap_prop(int(kind)))
	add_child(trap)

func _spawn_pickup(item_id: String, qty: int, title: String, room: String, pos: Vector3, flag: String = "", _glb: String = "", spawn_visual: bool = true) -> void:
	var p := Interactable.new()
	p.interact_type = Interactable.InteractType.ITEM_PICKUP
	p.object_title = title
	p.item_id = item_id
	p.item_quantity = qty
	p.room_id = room
	p.sets_world_flag = flag
	p.position = pos
	var vis: Node3D = RealisticEnvironmentBuilder.build_pickup_prop(item_id) if spawn_visual else null
	_attach_collider_with_custom_node(p, Vector3(0.75, 0.75, 0.75), vis)
	add_child(p)

func _spawn_doc(doc_id: String, title: String, room: String, pos: Vector3, spawn_visual: bool = true) -> void:
	var d := Interactable.new()
	d.interact_type = Interactable.InteractType.LORE_DOCUMENT
	d.object_title = title
	d.document_id = doc_id
	d.room_id = room
	d.position = pos
	var vis: Node3D = RealisticEnvironmentBuilder.build_document_prop() if spawn_visual else null
	_attach_collider_with_custom_node(d, Vector3(0.85, 0.85, 0.85), vis)
	add_child(d)

func _spawn_enemy_with_hitboxes(title: String, pos: Vector3, is_boss: bool, _optional_glb: String = "") -> void:
	var enemy: EnemyBase = BossHelenaAI.new() if is_boss else EnemyBase.new()
	enemy.enemy_title = title
	enemy.position = pos

	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.42
	cap.height = 1.85
	col.shape = cap
	col.position = Vector3(0, 0.92, 0)
	enemy.add_child(col)

	var pivot := Node3D.new()
	pivot.name = "MeshPivot"
	enemy.add_child(pivot)

	var articulated_monster := HumanoidCharacterBuilder.build_monster_character(is_boss, title)
	pivot.add_child(articulated_monster)

	var head_hb := HitboxComponent.new()
	head_hb.body_zone = HitboxComponent.BodyZone.HEAD_WEAKPOINT
	head_hb.damage_multiplier = 2.2
	head_hb.zone_display_name = "頭部弱點 (準星收縮 2.2x 暴擊)"
	head_hb.parent_enemy = enemy
	head_hb.position = Vector3(0, 1.68, 0)
	var h_col := CollisionShape3D.new()
	var h_sphere := SphereShape3D.new()
	h_sphere.radius = 0.34
	h_col.shape = h_sphere
	head_hb.add_child(h_col)
	enemy.add_child(head_hb)

	var leg_hb := HitboxComponent.new()
	leg_hb.body_zone = HitboxComponent.BodyZone.LEG_CRIPPLE
	leg_hb.damage_multiplier = 0.9
	leg_hb.zone_display_name = "膝蓋關節 (射擊致殘減速)"
	leg_hb.parent_enemy = enemy
	leg_hb.position = Vector3(0, 0.42, 0)
	var l_col := CollisionShape3D.new()
	var l_box := BoxShape3D.new()
	l_box.size = Vector3(0.65, 0.65, 0.65)
	l_col.shape = l_box
	leg_hb.add_child(l_col)
	enemy.add_child(leg_hb)

	if is_boss:
		var valve_hb := HitboxComponent.new()
		valve_hb.body_zone = HitboxComponent.BodyZone.PRESSURE_VALVE_CRITICAL
		valve_hb.damage_multiplier = 2.6
		valve_hb.zone_display_name = "背後高壓氣閥／核心弱點 (2.6x 超高暴擊)"
		valve_hb.parent_enemy = enemy
		valve_hb.position = Vector3(0, 1.35, 0.42)
		var v_col := CollisionShape3D.new()
		var v_sphere := SphereShape3D.new()
		v_sphere.radius = 0.36
		v_col.shape = v_sphere
		valve_hb.add_child(v_col)
		enemy.add_child(valve_hb)

	add_child(enemy)

func _spawn_door(
	id: String, title: String, target_room: String,
	door_pos: Vector3, dest_pos: Vector3, dest_yaw: float,
	locked: bool, req_key_id: String, req_key_name: String, flag_name: String,
	one_way_bolt: bool, can_unbolt: bool
) -> void:
	var door := DoorTransition.new()
	door.door_id = id
	door.door_title = title
	door.target_room_id = target_room
	door.position = door_pos
	door.destination_position = dest_pos
	door.destination_camera_yaw = dest_yaw
	door.is_locked = locked
	door.required_key_item_id = req_key_id
	door.required_key_display_name = req_key_name
	door.unlocked_by_world_flag = flag_name
	door.is_one_way_bolt = one_way_bolt
	door.can_unbolt_from_this_side = can_unbolt
	_attach_collider_with_custom_node(door, Vector3(1.6, 2.5, 0.55), RealisticEnvironmentBuilder.build_ornate_door(locked, req_key_id, one_way_bolt))
	add_child(door)

func _attach_collider_with_custom_node(body: CollisionObject3D, size: Vector3, visual_node: Node3D) -> void:
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	col.shape = shape
	body.add_child(col)
	if visual_node:
		body.add_child(visual_node)

func _spawn_static_box(node_name: String, pos: Vector3, size: Vector3, mat: Material) -> StaticBody3D:
	var sb := StaticBody3D.new()
	sb.name = node_name
	sb.position = pos
	_attach_collider_and_mesh(sb, size, mat)
	add_child(sb)
	return sb

func _spawn_perimeter_bounds(bounds_name: String, center: Vector3, floor_size: Vector3) -> void:
	var root := Node3D.new()
	root.name = bounds_name
	add_child(root)
	var hx: float = floor_size.x * 0.5
	var hz: float = floor_size.z * 0.5
	var h: float = floor_size.y
	var t: float = 0.6
	var walls: Array = [
		[Vector3(center.x, h * 0.5, center.z - hz - t * 0.5), Vector3(floor_size.x + t * 2.0, h, t)],
		[Vector3(center.x, h * 0.5, center.z + hz + t * 0.5), Vector3(floor_size.x + t * 2.0, h, t)],
		[Vector3(center.x - hx - t * 0.5, h * 0.5, center.z), Vector3(t, h, floor_size.z + t * 2.0)],
		[Vector3(center.x + hx + t * 0.5, h * 0.5, center.z), Vector3(t, h, floor_size.z + t * 2.0)]
	]
	for w in walls:
		var sb := StaticBody3D.new()
		sb.position = w[0]
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = w[1]
		cs.shape = bs
		sb.add_child(cs)
		root.add_child(sb)

func _attach_collider_and_mesh(body: CollisionObject3D, size: Vector3, mat: Material, optional_glb_path: String = "") -> void:
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	col.shape = shape
	body.add_child(col)

	if not optional_glb_path.is_empty() and ResourceLoader.exists(optional_glb_path):
		var packed := load(optional_glb_path) as PackedScene
		if packed:
			var inst := packed.instantiate()
			body.add_child(inst)
			return

	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	body.add_child(mi)

func _spawn_glb_or_fallback(glb_path: String, pos: Vector3, fallback_size: Vector3, mat: Material) -> void:
	var sb := StaticBody3D.new()
	sb.position = pos
	_attach_collider_and_mesh(sb, fallback_size, mat, glb_path)
	add_child(sb)

func _spawn_omni_light(pos: Vector3, col: Color, energy: float, radius: float) -> void:
	var light := OmniLight3D.new()
	light.position = pos
	light.light_color = col
	light.light_energy = minf(energy, 1.45)
	light.omni_range = radius
	light.shadow_enabled = true
	add_child(light)
