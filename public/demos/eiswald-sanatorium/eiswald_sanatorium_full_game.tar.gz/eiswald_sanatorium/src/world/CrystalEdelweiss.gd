class_name CrystalEdelweiss
extends StaticBody3D
## CrystalEdelweiss.gd
## Hidden shootable collectible (equivalent to Crow Country's Silver Crows / Crystal targets).
## Requires using the 3D laser sight and vertical elevation aiming to shoot in rafters/corners.

@export var crystal_id: String = "edelweiss_01"
@export var location_hint: String = "迎賓大堂鹿角吊燈上方"

var _collected: bool = false

func _ready() -> void:
	if GameManager.collected_edelweiss_ids.has(crystal_id):
		_collected = true
		visible = false

func _process(delta: float) -> void:
	if not _collected:
		rotate_y(delta * 1.6)

func get_aim_label() -> String:
	return "" if _collected else "【隱藏收集】水晶雪絨花 (%s)" % crystal_id

func is_weakpoint_hitbox() -> bool:
	return true

func on_laser_shot_hit(_damage: float, _hit_pos: Vector3, _is_incendiary: bool) -> void:
	if _collected:
		return
	_collected = true
	AudioManager.play_synth_sfx("puzzle_solved")
	GameManager.collect_edelweiss(crystal_id)
	visible = false
	set_collision_layer_value(1, false)
	set_collision_layer_value(5, false)
