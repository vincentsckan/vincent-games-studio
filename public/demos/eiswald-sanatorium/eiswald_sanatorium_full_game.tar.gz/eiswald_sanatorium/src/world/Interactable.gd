class_name Interactable
extends StaticBody3D
## Interactable.gd
## Universal interactive object for item pickups, lore documents, NPC encounters, and searchable props.

enum InteractType {
	ITEM_PICKUP = 0,
	LORE_DOCUMENT = 1,
	NPC_DIALOGUE = 2,
	SEARCH_CONTAINER = 3,
	CUSTOM_EXAMINE = 4
}

@export var interact_type: InteractType = InteractType.ITEM_PICKUP
@export var object_title: String = "可疑物件"
@export var room_id: String = "R01_ParkingLot"
@export var item_id: String = ""
@export var item_quantity: int = 1
@export var document_id: String = ""
@export var npc_name: String = ""
@export var dialogue_lines: Array[String] = []
@export var sets_world_flag: String = ""
@export var gives_item_on_dialogue: String = ""
@export var one_time_use: bool = true

var is_consumed: bool = false

func get_interaction_prompt() -> String:
	if is_consumed:
		return ""
	match interact_type:
		InteractType.ITEM_PICKUP:
			return "按 [F] 拾取【%s】" % object_title
		InteractType.LORE_DOCUMENT:
			return "按 [F] 閱讀【%s】" % object_title
		InteractType.NPC_DIALOGUE:
			return "按 [F] 與【%s】交談" % npc_name
		InteractType.SEARCH_CONTAINER:
			return "按 [F] 搜索【%s】" % object_title
		_:
			return "按 [F] 調查【%s】" % object_title

func interact(_player: Node) -> void:
	if is_consumed:
		return

	match interact_type:
		InteractType.ITEM_PICKUP, InteractType.SEARCH_CONTAINER:
			if not item_id.is_empty():
				if InventoryManager.add_item(item_id, item_quantity):
					AudioManager.play_synth_sfx("item_pickup")
					GameManager.register_room_item_picked(room_id)
					if not sets_world_flag.is_empty():
						GameManager.set_flag(sets_world_flag, true)
					var def: ItemData = InventoryManager.item_catalog.get(item_id)
					var d_name: String = def.display_name if def else object_title
					var lines: Array[String] = ["獲得了【%s】 x%d。" % [d_name, item_quantity]]
					if item_id == "brass_pocket_watch":
						lines.append("這枚銅製懷錶相當沉重，打開道具欄 [Tab / I] 點擊【3D 翻轉檢視】看看背面吧。")
					DialogueManager.start_dialogue("調查紀錄", lines)
					if one_time_use:
						is_consumed = true
						if interact_type == InteractType.ITEM_PICKUP:
							visible = false
							set_collision_layer_value(1, false)
				else:
					AudioManager.play_synth_sfx("door_locked")
					var full_lines: Array[String] = ["手提箱空間已滿，請先前往『茶歇安全屋』整理或使用消耗品。"]
					DialogueManager.start_dialogue("調查紀錄", full_lines)

		InteractType.LORE_DOCUMENT:
			if not sets_world_flag.is_empty():
				GameManager.set_flag(sets_world_flag, true)
			DialogueManager.open_lore_document(document_id)

		InteractType.NPC_DIALOGUE:
			var spk: String = npc_name if not npc_name.is_empty() else object_title
			var lines_copy: Array[String] = dialogue_lines.duplicate()
			if not gives_item_on_dialogue.is_empty() and not GameManager.get_flag(sets_world_flag):
				if InventoryManager.add_item(gives_item_on_dialogue, 1):
					var g_def: ItemData = InventoryManager.item_catalog.get(gives_item_on_dialogue)
					var g_name: String = g_def.display_name if g_def else gives_item_on_dialogue
					lines_copy.append("（獲得了關鍵物品：【%s】！）" % g_name)
					GameManager.register_room_item_picked(room_id)
			if not sets_world_flag.is_empty():
				GameManager.set_flag(sets_world_flag, true)
			DialogueManager.start_dialogue(spk, lines_copy)

		InteractType.CUSTOM_EXAMINE:
			if not sets_world_flag.is_empty():
				GameManager.set_flag(sets_world_flag, true)
			DialogueManager.start_dialogue(object_title, dialogue_lines)
