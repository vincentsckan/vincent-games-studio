class_name HauntedFakeGhostProp
extends StaticBody3D
## HauntedFakeGhostProp.gd
## Implements Crow Country's signature "Haunted Hilltop" mechanic where fake theme-park spooky props
## (spring-loaded cardboard ghosts & mechanical coffins) are mixed with genuine lethal monsters!

@export var coffin_title: String = "哥德驚魂屋彈出式棺木"
@export var is_fake_theme_park_prop: bool = true
@export var hides_item_id: String = "ammo_9mm"
@export var hides_item_qty: int = 8
@export var room_id: String = "Z2_R05_GothicCemetery"

var _triggered: bool = false

func get_interaction_prompt() -> String:
	if _triggered:
		return "【%s】已彈開" % coffin_title
	return "按 [F] 檢查【%s】(小心真假鬼屋機關！)" % coffin_title

func interact(_player: Node) -> void:
	if _triggered:
		return
	_triggered = true

	if is_fake_theme_park_prop:
		AudioManager.play_synth_sfx("camera_snap")
		# Pop out a harmless spring-loaded cardboard cutout ghost + reward hidden ammo!
		var lines: Array[String] = [
			"『嘎吱——砰！』棺木猛然彈開，一具塗著螢光漆的【假鬼屋彈簧紙板幽靈】伴隨著滑稽的遊樂園音效跳了出來！",
			"幸好只是當初設計給遊客驚嚇用的機械假道具……你在棺木底座發現了隱藏補給！"
		]
		if not hides_item_id.is_empty():
			InventoryManager.add_item(hides_item_id, hides_item_qty)
			var def: ItemData = InventoryManager.item_catalog.get(hides_item_id)
			var d_name: String = def.display_name if def else hides_item_id
			lines.append("（獲得了【%s】x%d！）" % [d_name, hides_item_qty])
		DialogueManager.start_dialogue("假鬼屋驚嚇機關", lines)
	else:
		AudioManager.play_synth_sfx("gunshot_shotgun")
		DialogueManager.start_dialogue("棺木突襲警告", [
			"棺木蓋被慘白的手掌從內部震碎——這不是遊樂園的假道具，是真正的白髓畸變體！"
		])
		GameManager.apply_player_damage(12.0, false)
