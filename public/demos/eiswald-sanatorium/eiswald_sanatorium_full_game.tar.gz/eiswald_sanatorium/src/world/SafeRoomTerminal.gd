class_name SafeRoomTerminal
extends StaticBody3D
## SafeRoomTerminal.gd
## Implements the 3 core Safe Room facilities:
## 1. Warm Hearth Campfire (壁爐營火 — Rest, warm up, review clues)
## 2. Reel-to-Reel Magnetic Tape Recorder (盤式磁帶錄音存檔機)
## 3. "The Alpine Oracle" Progressive 3-Tier Fortune Teller (三階段漸進式算命提示機)

enum TerminalKind {
	TAPE_RECORDER_SAVE = 0,
	ALPINE_ORACLE_FORTUNE = 1,
	CAMPFIRE_HEARTH = 2
}

@export var terminal_kind: TerminalKind = TerminalKind.TAPE_RECORDER_SAVE
@export var save_slot_index: int = 1

func get_interaction_prompt() -> String:
	match terminal_kind:
		TerminalKind.TAPE_RECORDER_SAVE:
			return "按 [F] 使用【盤式磁帶錄音機】保存進度"
		TerminalKind.CAMPFIRE_HEARTH:
			return "按 [F] 在【安全屋壁爐營火】旁取暖喘息"
		_:
			return "按 [F] 詢問【雪山神諭算命機】(獲取 3 階段漸進式解謎提示)"

func interact(player: Node) -> void:
	match terminal_kind:
		TerminalKind.TAPE_RECORDER_SAVE:
			var pos: Vector3 = player.global_position if player is Node3D else Vector3.ZERO
			var rot_y: float = player.rotation.y if player is Node3D else 0.0
			if SaveManager.save_to_tape(save_slot_index, pos, rot_y):
				AudioManager.play_synth_sfx("tape_save")
				DialogueManager.start_dialogue("盤式磁帶錄音機", [
					"盤式磁帶緩緩轉動，將四大園區的調查進度寫入第 #%d 號磁帶。" % save_slot_index,
					"【進度已成功保存】（累計存檔次數：%d 次）" % GameManager.times_saved
				])

		TerminalKind.CAMPFIRE_HEARTH:
			AudioManager.play_synth_sfx("item_pickup")
			DialogueManager.start_dialogue("安全屋壁爐營火", [
				"溫暖的松木營火驅散了暴風雪的寒意。外面的怪物無法靠近這間安全屋。",
				"（提示：可按 [Tab] 整理手提箱合成藥草與急救包，或按 [F2] 切換生存／探索／謀殺之鴉難度，按 [F4] 切換現代／經典坦克操作。）"
			])

		TerminalKind.ALPINE_ORACLE_FORTUNE:
			GameManager.oracle_hints_used += 1
			AudioManager.play_synth_sfx("puzzle_solved")
			var hint_lines: Array[String] = _get_progressive_3tier_hint()
			DialogueManager.start_dialogue("雪山神諭算命機 (Progressive Fortune Teller)", hint_lines)

func _get_progressive_3tier_hint() -> Array[String]:
	var topic_key: String = _determine_current_puzzle_topic()
	var current_tier: int = clampi(int(GameManager.oracle_hint_tiers.get(topic_key, 0)) + 1, 1, 3)
	GameManager.oracle_hint_tiers[topic_key] = current_tier

	var tier_badge: String = "【漸進式提示 — 第 %d / 3 階段】" % current_tier
	match topic_key:
		"topic_crowbar":
			if current_tier == 1:
				return [tier_badge, "『方向指引：在雪絨花童話村中央廣場北側，有位受困於柵欄後的建築師正等著你。』"]
			elif current_tier == 2:
				return [tier_badge, "『解謎邏輯：與總建築師亞瑟·范斯交談，他會交給你撬開毒蠅傘蘑菇屋木板門的工具。』"]
			else:
				return [tier_badge, "『直接解答：前往童話中央廣場與亞瑟交談取得【精鋼撬棍】，再用它開啟廣場南側的【毒蠅傘蘑菇屋】。』"]

		"topic_fairytale_clock":
			if current_tier == 1:
				return [tier_badge, "『方向指引：毒蠅傘蘑菇屋的老爺鐘停擺了，時間線索就藏在同一間屋子的紅木抽屜裡。』"]
			elif current_tier == 2:
				return [tier_badge, "『解謎邏輯：拾取【停擺的銅製懷錶】後，按 [Tab] 打開手提箱，點擊【🔍 3D 翻轉檢視背面】即可看見內蓋刻字。』"]
			else:
				return [tier_badge, "『直接解答：懷錶背面刻著破曉時刻，在蘑菇屋老爺鐘輸入【0415】即可獲得通往鬧鬼山丘的【銅翼雙鴉鑰匙】！』"]

		"topic_haunted_piano":
			if current_tier == 1:
				return [tier_badge, "『方向指引：使用銅翼鑰匙進入西翼【鬧鬼山丘】，注意墓園裡的假鬼屋棺木與真怪物，深入古堡靈廟調查自動鋼琴。』"]
			elif current_tier == 2:
				return [tier_badge, "『解謎邏輯：閱讀古堡內的《鬧鬼山丘手札》，對照烏鴉座星盤的五顆主星順序彈奏五音聖詠。』"]
			else:
				return [tier_badge, "『直接解答：在古堡自動鋼琴輸入五音序列【13542】，即可取得【銀冠海馬鑰匙】與【白鴉 .44 馬格南】！別忘了拉開南側單向捷徑門。』"]

		"topic_ocean_aquarium":
			if current_tier == 1:
				return [tier_badge, "『方向指引：持銀冠海馬鑰匙開啟中央廣場東側大門，進入藍綠色調的【冰川海洋王國】水下展示廳。』"]
			elif current_tier == 2:
				return [tier_badge, "『解謎邏輯：根據《海洋王國日誌》，將左艙(+35)、中艙(+30)、右艙(+20) 的水壓加總以平衡深海展示槽。』"]
			else:
				return [tier_badge, "『直接解答：在水下展示廳壓力控制盤輸入【85】，即可取得【高濃度強酸液瓶 (Acid Vial)】以溶解通往地下挖掘場的鐵鍊！』"]

		_:
			if current_tier == 1:
				return [tier_badge, "『方向指引：使用強酸液瓶溶解中央廣場北側的礦坑鐵鍊，深入地底【白髓挖掘場與秘密實驗室】。』"]
			elif current_tier == 2:
				return [tier_badge, "『解謎邏輯：啟動地底礦坑的三相高壓渦輪配電盤，恢復實驗室的工業額定電壓。』"]
			else:
				return [tier_badge, "『直接解答：在地下挖掘場配電盤輸入【440】，取得【地熱火焰噴射器】並摧毀白髓母體核心！』"]

func _determine_current_puzzle_topic() -> String:
	if not bool(GameManager.get_flag("crowbar_obtained")):
		return "topic_crowbar"
	if not bool(GameManager.get_flag("fairytale_clock_solved")):
		return "topic_fairytale_clock"
	if not bool(GameManager.get_flag("constellation_piano_solved")):
		return "topic_haunted_piano"
	if not bool(GameManager.get_flag("aquarium_pressure_solved")):
		return "topic_ocean_aquarium"
	return "topic_underground_roots"
