class_name EnvironmentalTrap
extends StaticBody3D
## EnvironmentalTrap.gd
## Implements Crow Country's 5 interactive environmental hazards:
## 1. Explosive Fuel Barrel (高壓易爆油桶)
## 2. Alpine Bear Trap (雪山捕熊夾 — proximity snap on player OR monsters, shootable)
## 3. Proximity Landmine (感應地雷 — proximity blast, shootable from afar)
## 4. Toxic Ichor Gas Pipe (破裂毒氣管線 — inflicts Ichor poison, shootable valve)
## 5. Fragile Ceiling / Chandelier (脆弱冰柱天花板／古堡吊燈 — shoot overhead to crush monsters below)

enum TrapKind {
	EXPLOSIVE_GAS_CANISTER = 0,
	ALPINE_BEAR_TRAP = 1,
	PROXIMITY_LANDMINE = 2,
	TOXIC_GAS_PIPE = 3,
	FRAGILE_CEILING_ICICLE = 4
}

@export var trap_kind: TrapKind = TrapKind.EXPLOSIVE_GAS_CANISTER
@export var trap_name: String = "高壓易爆油桶"
@export var blast_radius: float = 4.6
@export var blast_damage: float = 125.0
@export var proximity_trigger_radius: float = 1.35

var is_detonated: bool = false

func _physics_process(_delta: float) -> void:
	if is_detonated or GameManager.current_mode == GameManager.GameMode.EXPLORATION_ONLY:
		return

	# Bear traps, landmines, and toxic pipes can trigger when player or monster steps too close
	if trap_kind in [TrapKind.ALPINE_BEAR_TRAP, TrapKind.PROXIMITY_LANDMINE, TrapKind.TOXIC_GAS_PIPE]:
		var player: Node3D = get_tree().get_first_node_in_group("player") as Node3D
		if player and player.global_position.distance_to(global_position) <= proximity_trigger_radius:
			_trigger_on_actor(player, true)
			return

		for e in get_tree().get_nodes_in_group("enemies"):
			if e is Node3D and not bool(e.get("is_dead")) and e.global_position.distance_to(global_position) <= proximity_trigger_radius:
				_trigger_on_actor(e, false)
				return

func _trigger_on_actor(actor: Node3D, is_player: bool) -> void:
	if trap_kind == TrapKind.ALPINE_BEAR_TRAP:
		is_detonated = true
		AudioManager.play_synth_sfx("door_locked")
		if is_player:
			GameManager.apply_player_damage(24.0, false)
		elif actor.has_method("apply_damage"):
			actor.call("apply_damage", 65.0, false, "LEG")
		visible = false
		set_collision_layer_value(1, false)
	elif trap_kind == TrapKind.PROXIMITY_LANDMINE or trap_kind == TrapKind.TOXIC_GAS_PIPE:
		detonate_trap()

func get_aim_label() -> String:
	return "" if is_detonated else "【環境陷阱】%s (可射擊觸發)" % trap_name

func is_weakpoint_hitbox() -> bool:
	return true

func on_laser_shot_hit(_damage: float, _hit_pos: Vector3, _is_incendiary: bool) -> void:
	if is_detonated:
		return
	detonate_trap()

func detonate_trap() -> void:
	is_detonated = true
	AudioManager.play_synth_sfx("gunshot_shotgun")

	# For overhead Fragile Ceiling / Chandelier, drop impact point to floor (Y = 0)
	var impact_center: Vector3 = global_position
	if trap_kind == TrapKind.FRAGILE_CEILING_ICICLE:
		impact_center.y = 0.2

	var enemies: Array[Node] = get_tree().get_nodes_in_group("enemies")
	for e in enemies:
		if e is Node3D and e.global_position.distance_to(impact_center) <= blast_radius:
			if e.has_method("apply_damage"):
				var is_fire: bool = (trap_kind == TrapKind.EXPLOSIVE_GAS_CANISTER or trap_kind == TrapKind.PROXIMITY_LANDMINE)
				e.call("apply_damage", blast_damage, is_fire, "TRAP_BLAST")

	var player: Node3D = get_tree().get_first_node_in_group("player") as Node3D
	if player and player.global_position.distance_to(impact_center) <= blast_radius * 0.75:
		var inflicts_poison: bool = (trap_kind == TrapKind.TOXIC_GAS_PIPE)
		GameManager.apply_player_damage(28.0, inflicts_poison)

	var flash := OmniLight3D.new()
	flash.light_color = Color(0.65, 0.25, 0.95) if trap_kind == TrapKind.TOXIC_GAS_PIPE else Color(1.0, 0.48, 0.12)
	flash.light_energy = 8.0
	flash.omni_range = blast_radius * 1.4
	get_parent().add_child(flash)
	flash.global_position = impact_center + Vector3(0, 0.6, 0)

	var tw := create_tween()
	tw.tween_property(flash, "light_energy", 0.0, 0.45)
	tw.tween_callback(flash.queue_free)

	visible = false
	set_collision_layer_value(1, false)
	set_collision_layer_value(6, false)
