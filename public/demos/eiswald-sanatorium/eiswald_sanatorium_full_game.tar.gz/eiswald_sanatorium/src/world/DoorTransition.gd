class_name DoorTransition
extends StaticBody3D
## DoorTransition.gd
## Handles radial Metroidvania doors: Key-locked doors, Tool-blocked doors (Crowbar / Acid Vial),
## and One-Way Deadbolt Shortcut gates that connect Haunted Hilltop, Ocean Kingdom, and The Roots
## directly back to the Fairytale Town Central Hub.

@export var door_id: String = "door_hub_main"
@export var door_title: String = "童話村木門"
@export var target_room_id: String = "Z1_R02_FairytaleHub"
@export var destination_position: Vector3 = Vector3.ZERO
@export var destination_camera_yaw: float = 45.0
@export var is_locked: bool = false
@export var required_key_item_id: String = ""
@export var required_key_display_name: String = ""
@export var is_one_way_bolt: bool = false
@export var can_unbolt_from_this_side: bool = false
@export var unlocked_by_world_flag: String = ""

func get_interaction_prompt() -> String:
	var effectively_unlocked: bool = _check_unlocked_by_flag()
	if is_locked and not effectively_unlocked:
		if is_one_way_bolt and can_unbolt_from_this_side:
			return "按 [F] 拉開內側鐵插銷，打通【%s】捷徑！" % door_title
		elif is_one_way_bolt:
			return "按 [F] 檢查【%s】(從另一側反鎖的捷徑門)" % door_title
		return "按 [F] 嘗試開啟【%s】(需要：%s)" % [door_title, required_key_display_name]
	return "按 [F] 進入【%s】" % door_title

func _check_unlocked_by_flag() -> bool:
	if not unlocked_by_world_flag.is_empty() and bool(GameManager.get_flag(unlocked_by_world_flag)):
		is_locked = false
		return true
	return not is_locked

func interact(player: Node) -> void:
	if not _check_unlocked_by_flag():
		if is_one_way_bolt:
			if can_unbolt_from_this_side:
				is_locked = false
				if not unlocked_by_world_flag.is_empty():
					GameManager.set_flag(unlocked_by_world_flag, true)
				GameManager.record_door_lock_note(door_id, "【捷徑已打通】%s" % door_title)
				AudioManager.play_synth_sfx("puzzle_solved")
				DialogueManager.start_dialogue("捷徑系統", [
					"你用盡全力拉開了門後的重型單向鐵插銷！",
					"【%s】捷徑已永久打通，現在可以隨時快速往返中央廣場與壁爐安全屋了！" % door_title
				], func(): _perform_transition(player))
				return
			else:
				AudioManager.play_synth_sfx("door_locked")
				GameManager.record_door_lock_note(door_id, "【單向捷徑門】%s（需從區域內部開啟）" % door_title)
				DialogueManager.start_dialogue("單向捷徑門", [
					"【%s】從另一側插上了重型鐵插銷，無法從廣場這一側推開。" % door_title,
					"必須先繞道進入該主題分區內部，才能從門後拉開插銷打通這條捷徑。"
				])
				return

		if not required_key_item_id.is_empty() and InventoryManager.has_item(required_key_item_id):
			is_locked = false
			if not unlocked_by_world_flag.is_empty():
				GameManager.set_flag(unlocked_by_world_flag, true)
			GameManager.record_door_lock_note(door_id, "【%s】：已使用『%s』解鎖" % [door_title, required_key_display_name])
			AudioManager.play_synth_sfx("puzzle_solved")
			var unlock_msg: Array[String] = [
				"使用了【%s】，成功破除障礙並開啟【%s】！" % [required_key_display_name, door_title]
			]
			DialogueManager.start_dialogue("門鎖與障礙系統", unlock_msg, func(): _perform_transition(player))
			return
		else:
			AudioManager.play_synth_sfx("door_locked")
			var note: String = "【%s】：需要『%s』" % [door_title, required_key_display_name]
			GameManager.record_door_lock_note(door_id, note)
			var lock_msg: Array[String] = [
				"【%s】被牢牢封鎖著。" % door_title,
				"必須先取得關鍵道具【%s】才能開啟此處。（已自動標記於調查地圖 [M]）" % required_key_display_name
			]
			DialogueManager.start_dialogue("門鎖與障礙系統", lock_msg)
			return

	_perform_transition(player)

func _perform_transition(player: Node) -> void:
	AudioManager.play_synth_sfx("ui_click")
	if player is Node3D:
		player.global_position = destination_position
		if player.get("camera_rig") != null:
			player.camera_rig.target_yaw_deg = destination_camera_yaw
	GameManager.mark_room_visited(target_room_id)
