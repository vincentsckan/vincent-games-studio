class_name SubRoomFurnisher
extends Node3D
## SubRoomFurnisher.gd
## Populates the expanded 20-room Commercial Indie-AAA world with:
## - Additional NPCs: Mascot "Hans the White Crow" (漢斯) and Wounded Chief Engineer Lukas Brandt (盧卡斯)
## - Additional Safe Rooms (#2 in Haunted Hilltop, #3 in Ocean Kingdom)
## - Puzzles #9 (X-Ray Diagnostics "509") and #10 (Microfilm Projector "824")
## - Atmospheric Volumetric Point Lights, Glowing Cryo-Spire, and Interior Architectural Details

func populate_commercial_details(builder: Node3D) -> void:
	var mat_gold := StandardMaterial3D.new()
	mat_gold.albedo_color = Color(0.88, 0.72, 0.28)
	mat_gold.metallic = 0.85
	mat_gold.roughness = 0.25

	var mat_cyan_glow := StandardMaterial3D.new()
	mat_cyan_glow.albedo_color = Color(0.35, 0.92, 1.0)
	mat_cyan_glow.emission_enabled = true
	mat_cyan_glow.emission = Color(0.22, 0.82, 0.98)
	mat_cyan_glow.emission_energy_multiplier = 2.2

	# 1. NPC "Hans the White Crow" Mascot in Fairytale Village Gift Pavilion (X=+8.5, Z=-4.0)
	var hans := Interactable.new()
	hans.interact_type = Interactable.InteractType.NPC_DIALOGUE
	hans.npc_name = "『白鴉吉祥物』員工 漢斯 (Mascot Hans)"
	hans.object_title = "白鴉吉祥物 漢斯"
	hans.room_id = "Z1_R02_FairytaleHub"
	hans.sets_world_flag = "met_mascot_hans"
	hans.gives_item_on_dialogue = "first_aid_spray"
	hans.dialogue_lines = [
		"（身穿巨大白鴉布偶裝的員工坐在糖果屋長椅上，布偶頭套下傳出沙啞卻清醒的聲音：）",
		"「嘎——歡迎來到霧嶺童話村，調查員小姐！別開槍，我還沒變成那些白瓷怪物……這身厚重的吉祥物布偶裝剛好擋住了白髓毒氣。」",
		"「告訴你一個秘密：『海洋王國』醫療室的 X 光片密碼是【509】，能升級你的 .44 馬格南；而『地下挖掘場』標本庫的微縮膠卷密碼是【824】，能強化火焰噴射器！」",
		"「這罐【急救噴霧】送給你，祝你在『謀殺之鴉』的寒冬裡活下來！」"
	]
	hans.position = Vector3(8.2, 0.0, -3.5)
	var hans_col := CollisionShape3D.new()
	var hans_shape := BoxShape3D.new()
	hans_shape.size = Vector3(1.0, 2.0, 1.0)
	hans_col.shape = hans_shape
	hans_col.position = Vector3(0, 1.0, 0)
	hans.add_child(hans_col)
	hans.add_child(HumanoidCharacterBuilder.build_npc_humanoid(Color(0.88, 0.90, 0.94), Color(0.94, 0.95, 0.98), Color(0.92, 0.68, 0.16), true))
	builder.add_child(hans)

	# 2. NPC Chief Engineer Lukas Brandt in Underground Quarry Entrance (X=+6.5, Z=-24.5)
	var lukas := Interactable.new()
	lukas.interact_type = Interactable.InteractType.NPC_DIALOGUE
	lukas.npc_name = "前首席地熱工程師 盧卡斯·布蘭特 (Lukas Brandt)"
	lukas.object_title = "地熱工程師 盧卡斯"
	lukas.room_id = "Z4_R09_SubterraneanQuarry"
	lukas.sets_world_flag = "met_engineer_lukas"
	lukas.gives_item_on_dialogue = "medkit_compound"
	lukas.dialogue_lines = [
		"「咳咳……你是亞瑟派來的調查員薇拉嗎？你哥哥當年發現范斯把地底『白髓』混進溫泉水療池，才被他們鎖進地下礦坑……」",
		"「先去西側配電盤輸入【440】伏特重啟電力，就能拿到我的【地熱高壓火焰噴射器】；接著去北側冷凍艙終端輸入封山年份【1989】！」",
		"「小心母體池裡的最終頭目，用激光瞄準射落天花板的鐘乳石吊燈能重創牠！」"
	]
	lukas.position = Vector3(6.5, 0.0, -24.5)
	var lukas_col := CollisionShape3D.new()
	var lukas_shape := BoxShape3D.new()
	lukas_shape.size = Vector3(0.95, 1.85, 0.95)
	lukas_col.shape = lukas_shape
	lukas_col.position = Vector3(0, 0.92, 0)
	lukas.add_child(lukas_col)
	lukas.add_child(HumanoidCharacterBuilder.build_npc_humanoid(Color(0.18, 0.32, 0.26), Color(0.88, 0.62, 0.14), Color(0.75, 0.35, 0.15), false))
	builder.add_child(lukas)

	# 3. Puzzle #9: Ocean Kingdom X-Ray Skeleton Diagnostics ("509" -> Magnum Upgrade)
	var xray_puzzle := XRayDiagnosticsPuzzle.new()
	xray_puzzle.add_to_group("puzzles")
	xray_puzzle.position = Vector3(20.5, 1.3, -14.5)
	builder.call("_attach_collider_with_custom_node", xray_puzzle, Vector3(1.6, 2.0, 0.8), RealisticEnvironmentBuilder.build_puzzle_station("xray"))
	builder.add_child(xray_puzzle)

	# 4. Puzzle #10: Underground Cryo-Morgue Microfilm Projector ("824" -> Flamethrower Upgrade)
	var microfilm_puzzle := MicrofilmProjectorPuzzle.new()
	microfilm_puzzle.add_to_group("puzzles")
	microfilm_puzzle.position = Vector3(8.5, 1.2, -33.0)
	builder.call("_attach_collider_with_custom_node", microfilm_puzzle, Vector3(1.2, 1.8, 1.2), RealisticEnvironmentBuilder.build_puzzle_station("microfilm"))
	builder.add_child(microfilm_puzzle)

	# 5. Secondary Campfire & Tape Save Terminals in Haunted Hilltop & Ocean Kingdom
	var haunted_tape := SafeRoomTerminal.new()
	haunted_tape.terminal_kind = SafeRoomTerminal.TerminalKind.TAPE_RECORDER_SAVE
	haunted_tape.save_slot_index = 2
	haunted_tape.position = Vector3(-31.0, 0.8, -14.5)
	builder.call("_attach_collider_and_mesh", haunted_tape, Vector3(1.0, 1.0, 0.8), mat_gold, "res://assets/models/reel_tape_recorder.glb")
	builder.add_child(haunted_tape)

	var ocean_tape := SafeRoomTerminal.new()
	ocean_tape.terminal_kind = SafeRoomTerminal.TerminalKind.TAPE_RECORDER_SAVE
	ocean_tape.save_slot_index = 3
	ocean_tape.position = Vector3(19.0, 0.8, -3.5)
	builder.call("_attach_collider_and_mesh", ocean_tape, Vector3(1.0, 1.0, 0.8), mat_gold, "res://assets/models/reel_tape_recorder.glb")
	builder.add_child(ocean_tape)

	# 6. Clara's Crystalline Spire Hero Monument in Zone 4 Bio-Lab
	builder.call("_spawn_glb_or_fallback", "res://assets/models/clara_cryo_spire.glb", Vector3(0.0, 2.2, -40.5), Vector3(2.4, 4.4, 2.4), mat_cyan_glow)
