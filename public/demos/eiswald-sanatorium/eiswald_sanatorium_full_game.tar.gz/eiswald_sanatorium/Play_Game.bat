@echo off
cd /d "%~dp0"
taskkill /F /IM Godot_v4.3-stable_win64.exe >nul 2>&1
start "" "%~dp0.engine\Godot_v4.3-stable_win64.exe" --path "%~dp0."
