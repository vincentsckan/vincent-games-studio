#!/usr/bin/env bash
set -e
tar -xzf /home/vincentsc_kan/eiswald_sanatorium.tar.gz -C /home/vincentsc_kan
rm -f /home/vincentsc_kan/eiswald_sanatorium.tar.gz
cd /home/vincentsc_kan/eiswald_sanatorium
blender -b -P tools/generate_3d_assets_blender.py
ls -lh /home/vincentsc_kan/eiswald_sanatorium/assets/models/
