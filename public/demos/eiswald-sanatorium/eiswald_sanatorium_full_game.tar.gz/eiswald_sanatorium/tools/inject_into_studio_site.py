#!/usr/bin/env python3
"""
inject_into_studio_site.py
Injects the "Eiswald Sanatorium: Winter of the White Crow" (《霧嶺療養院：白鴉之冬》)
Game Icon Card into the root index.html of the vincent-games-studio repository
so that clicking the game icon on https://vincentsckan.github.io/vincent-games-studio/
immediately launches the game on the player's local machine via vincentgame://launch/eiswald-sanatorium
and opens the launch hub ./eiswald-sanatorium/?autolaunch=1!
"""

import os
import sys

CARD_HTML = """
<!-- EISWALD_SANATORIUM_CARD_START -->
<div class="game-card eiswald-3d-featured" onclick="window.location.href='vincentgame://launch/eiswald-sanatorium'; setTimeout(function(){ window.location.href='./eiswald-sanatorium/?autolaunch=1'; }, 400);" style="cursor:pointer; background:linear-gradient(145deg, #131b2e 0%, #0a0f1a 100%); border:2px solid #f5d061; border-radius:16px; overflow:hidden; box-shadow:0 12px 32px rgba(0,0,0,0.65); transition:transform 0.25s ease; max-width:380px; margin:16px auto;">
  <div style="position:relative;">
    <img src="./eiswald-sanatorium/scene_fairytale_hub.png" alt="《霧嶺療養院：白鴉之冬》Eiswald Sanatorium" style="width:100%; height:220px; object-fit:cover; display:block;" />
    <span style="position:absolute; top:12px; left:12px; background:#e63946; color:#fff; font-size:12px; font-weight:700; padding:4px 10px; border-radius:999px; box-shadow:0 4px 12px rgba(0,0,0,0.5);">🔥 3A級 3D 生存恐怖 (Godot 4.3)</span>
  </div>
  <div style="padding:18px 20px; color:#eef2f7; font-family:'Segoe UI','Microsoft JhengHei',sans-serif;">
    <h3 style="color:#f5d061; font-size:21px; margin:0 0 8px 0;">《霧嶺療養院：白鴉之冬》<br/><small style="font-size:13px; color:#9fb1c9;">Eiswald Sanatorium: Winter of the White Crow</small></h3>
    <p style="font-size:14px; color:#c5d1e0; line-height:1.5; margin:0 0 16px 0;">參照《Crow Country》箱庭架構之原創 3D 生存恐怖大作。探索童話鎮、鬧鬼山丘、海洋王國與地下挖掘場四大主題區。</p>
    <div style="display:flex; gap:10px;">
      <a href="vincentgame://launch/eiswald-sanatorium" onclick="event.stopPropagation(); setTimeout(function(){ window.location.href='./eiswald-sanatorium/?autolaunch=1'; }, 400);" style="flex:1; text-align:center; background:linear-gradient(135deg,#e63946,#b51724); color:#fff; font-weight:700; padding:11px 14px; border-radius:10px; text-decoration:none; font-size:15px;">🎮 點擊即玩 (本機啟動)</a>
      <a href="./eiswald-sanatorium/" onclick="event.stopPropagation();" style="padding:11px 14px; border:1px solid #48cae4; color:#48cae4; border-radius:10px; text-decoration:none; font-size:14px; font-weight:600;">詳情 / 安裝</a>
    </div>
  </div>
</div>
<!-- EISWALD_SANATORIUM_CARD_END -->
"""


def main():
    if len(sys.argv) < 2:
        print("Usage: inject_into_studio_site.py <path_to_repo_root>")
        sys.exit(1)

    repo_root = sys.argv[1]
    index_path = os.path.join(repo_root, "index.html")

    if not os.path.isfile(index_path):
        # Create a clean studio portal index.html if none exists yet
        html = f"""<!DOCTYPE html>
<html lang="zh-Hant">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Vincent Games Studio — 官方遊戲大廳</title>
</head>
<body style="background:#070a10; color:#fff; font-family:'Segoe UI','Microsoft JhengHei',sans-serif; padding:40px 20px; text-align:center;">
  <h1 style="color:#f5d061; margin-bottom:24px;">🎮 Vincent Games Studio</h1>
  <div id="games-grid" style="display:flex; flex-wrap:wrap; justify-content:center; gap:24px; max-width:1200px; margin:0 auto;">
    {CARD_HTML}
  </div>
</body>
</html>
"""
        with open(index_path, "w", encoding="utf-8") as f:
            f.write(html)
        print("[OK] Created studio index.html with Eiswald Sanatorium game card.")
        return

    with open(index_path, "r", encoding="utf-8") as f:
        content = f.read()

    if "EISWALD_SANATORIUM_CARD_START" in content:
        import re
        content = re.sub(
            r"<!-- EISWALD_SANATORIUM_CARD_START -->.*?<!-- EISWALD_SANATORIUM_CARD_END -->",
            CARD_HTML.strip(),
            content,
            flags=re.DOTALL,
        )
    elif "</main>" in content:
        content = content.replace("</main>", CARD_HTML + "\n</main>", 1)
    elif "</body>" in content:
        content = content.replace("</body>", CARD_HTML + "\n</body>", 1)
    else:
        content += "\n" + CARD_HTML

    with open(index_path, "w", encoding="utf-8") as f:
        f.write(content)
    print("[OK] Injected Eiswald Sanatorium game card into existing index.html.")


if __name__ == "__main__":
    main()
