﻿# sync_to_vm.ps1
# 一鍵同步腳本：
# 1. 將最新遊戲專案備份並推送至雲端電腦 vincentkan-vm-20260921-000319
# 2. 呼叫雲端電腦的 Blender 5.3 自動生成全部 18 個 3D .glb 模型資產
# 3. 自動將雲端生成的 18 個 .glb 模型下載回本機 assets/models/ 供本機直接遊玩！
$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$ScratchRoot = Split-Path -Parent $ProjectRoot
$ArchivePath = Join-Path $ScratchRoot "eiswald_sanatorium.tar.gz"
$LocalModelsDir = Join-Path $ProjectRoot "assets\models"
$GcloudBin = "C:\Users\vincent sc kan\AppData\Local\Google\Cloud SDK\google-cloud-sdk\bin\gcloud.cmd"

Write-Host "[Step 1/4] 正在打包本機專案..." -ForegroundColor Cyan
tar -czf $ArchivePath -C $ScratchRoot eiswald_sanatorium

Write-Host "[Step 2/4] 正在上傳專案至雲端電腦 vincentkan-vm-20260921-000319..." -ForegroundColor Cyan
& $GcloudBin compute scp $ArchivePath vincentkan-vm-20260921-000319:/home/vincentsc_kan/eiswald_sanatorium.tar.gz --zone=asia-east2-c --tunnel-through-iap

Write-Host "[Step 3/4] 正在雲端電腦解壓並執行 Blender 5.3 生成 18 個 3D (.glb) 模型..." -ForegroundColor Cyan
& $GcloudBin compute ssh vincentkan-vm-20260921-000319 --zone=asia-east2-c --tunnel-through-iap --command="tar -xzf /home/vincentsc_kan/eiswald_sanatorium.tar.gz -C /home/vincentsc_kan && rm -f /home/vincentsc_kan/eiswald_sanatorium.tar.gz && cd /home/vincentsc_kan/eiswald_sanatorium && blender -b -P tools/generate_3d_assets_blender.py && tar -czf /home/vincentsc_kan/models_bundle.tar.gz -C /home/vincentsc_kan/eiswald_sanatorium/assets models"

Write-Host "[Step 4/4] 正在將雲端生成的 18 個 3D 模型同步回本機..." -ForegroundColor Cyan
$ModelsTar = Join-Path $ScratchRoot "models_bundle.tar.gz"
& $GcloudBin compute scp vincentkan-vm-20260921-000319:/home/vincentsc_kan/models_bundle.tar.gz $ModelsTar --zone=asia-east2-c --tunnel-through-iap
tar -xzf $ModelsTar -C (Join-Path $ProjectRoot "assets")
Remove-Item -Path $ArchivePath, $ModelsTar -Force -ErrorAction SilentlyContinue

Write-Host "==========================================================" -ForegroundColor Green
Write-Host " 雲端儲存與 18 個 3D 模型雙向同步完成！" -ForegroundColor Yellow
Write-Host "==========================================================" -ForegroundColor Green
