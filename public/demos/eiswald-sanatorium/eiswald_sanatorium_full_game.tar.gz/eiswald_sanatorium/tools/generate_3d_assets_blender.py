#!/usr/bin/env python3
"""
generate_3d_assets_blender.py
Runs inside Blender headless (`blender -b -P tools/generate_3d_assets_blender.py`)
to procedurally model, assign PBR materials, and export 9 glTF 2.0 (.glb) 3D assets
for the 4 themed zones of "Eiswald Sanatorium: Winter of the White Crow" (Godot 4 3D).
"""

import os
import math
import bpy

OUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "models")
os.makedirs(OUT_DIR, exist_ok=True)


def clear_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)


def make_pbr_mat(name, rgba, metallic=0.2, roughness=0.5, emission=None, emission_strength=0.0):
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = rgba
        bsdf.inputs["Metallic"].default_value = metallic
        bsdf.inputs["Roughness"].default_value = roughness
        if emission and "Emission Color" in bsdf.inputs:
            bsdf.inputs["Emission Color"].default_value = emission
            bsdf.inputs["Emission Strength"].default_value = emission_strength
    return mat


def export_glb(filename):
    out_path = os.path.join(OUT_DIR, filename)
    bpy.ops.export_scene.gltf(
        filepath=out_path,
        export_format="GLB",
        export_apply=True,
    )
    print(f"[Exported GLB] -> {out_path}")


def build_investigator_sedan():
    clear_scene()
    mat_body = make_pbr_mat("SedanNavy", (0.10, 0.16, 0.24, 1.0), metallic=0.75, roughness=0.28)
    mat_glass = make_pbr_mat("SedanGlass", (0.18, 0.28, 0.35, 1.0), metallic=0.9, roughness=0.1)
    mat_tire = make_pbr_mat("TireRubber", (0.06, 0.06, 0.06, 1.0), metallic=0.05, roughness=0.85)
    mat_lamp = make_pbr_mat("Headlamp", (1.0, 0.9, 0.65, 1.0), metallic=0.2, roughness=0.1, emission=(1.0, 0.85, 0.55, 1.0), emission_strength=3.0)

    bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0, 0, 0.45))
    chassis = bpy.context.active_object
    chassis.scale = (1.95, 4.3, 0.65)
    chassis.data.materials.append(mat_body)

    bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0, -0.15, 0.98))
    cabin = bpy.context.active_object
    cabin.scale = (1.65, 2.2, 0.55)
    cabin.data.materials.append(mat_glass)

    for wx in (-0.95, 0.95):
        for wy in (-1.35, 1.35):
            bpy.ops.mesh.primitive_cylinder_add(radius=0.36, depth=0.28, location=(wx, wy, 0.36), rotation=(0, math.pi / 2, 0))
            wheel = bpy.context.active_object
            wheel.data.materials.append(mat_tire)

    for hx in (-0.65, 0.65):
        bpy.ops.mesh.primitive_cube_add(size=1.0, location=(hx, -2.16, 0.52))
        hl = bpy.context.active_object
        hl.scale = (0.32, 0.08, 0.18)
        hl.data.materials.append(mat_lamp)

    export_glb("investigator_sedan.glb")


def build_fairytale_carousel():
    clear_scene()
    mat_canopy = make_pbr_mat("CarouselRed", (0.82, 0.14, 0.18, 1.0), metallic=0.25, roughness=0.38)
    mat_gold = make_pbr_mat("CarouselGold", (0.95, 0.78, 0.25, 1.0), metallic=0.92, roughness=0.2)

    bpy.ops.mesh.primitive_cylinder_add(radius=2.1, depth=0.3, location=(0, 0, -1.2))
    base = bpy.context.active_object
    base.data.materials.append(mat_gold)

    bpy.ops.mesh.primitive_cone_add(radius1=2.3, radius2=0.1, depth=1.6, location=(0, 0, 1.1))
    roof = bpy.context.active_object
    roof.data.materials.append(mat_canopy)

    bpy.ops.mesh.primitive_cylinder_add(radius=0.22, depth=2.4, location=(0, 0, -0.1))
    pole = bpy.context.active_object
    pole.data.materials.append(mat_gold)

    export_glb("fairytale_carousel.glb")


def build_toadstool_cottage():
    clear_scene()
    mat_stem = make_pbr_mat("MushroomStem", (0.92, 0.88, 0.78, 1.0), metallic=0.05, roughness=0.7)
    mat_cap = make_pbr_mat("ToadstoolCap", (0.85, 0.12, 0.14, 1.0), metallic=0.1, roughness=0.45)

    bpy.ops.mesh.primitive_cylinder_add(radius=1.6, depth=2.2, location=(0, 0, -0.4))
    stem = bpy.context.active_object
    stem.data.materials.append(mat_stem)

    bpy.ops.mesh.primitive_uv_sphere_add(radius=2.4, location=(0, 0, 1.1))
    cap = bpy.context.active_object
    cap.scale = (1.0, 1.0, 0.55)
    cap.data.materials.append(mat_cap)

    export_glb("toadstool_cottage.glb")


def build_pirate_galleon_ship():
    clear_scene()
    mat_hull = make_pbr_mat("GalleonTimber", (0.24, 0.14, 0.08, 1.0), metallic=0.1, roughness=0.68)
    mat_sail = make_pbr_mat("GhostSail", (0.75, 0.88, 0.92, 1.0), metallic=0.1, roughness=0.5)

    bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0, 0, 0))
    hull = bpy.context.active_object
    hull.scale = (2.2, 5.2, 1.4)
    hull.data.materials.append(mat_hull)

    bpy.ops.mesh.primitive_cylinder_add(radius=0.14, depth=3.8, location=(0, 0, 2.0))
    mast = bpy.context.active_object
    mast.data.materials.append(mat_hull)

    bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0, 0, 2.2))
    sail = bpy.context.active_object
    sail.scale = (2.4, 0.12, 1.8)
    sail.data.materials.append(mat_sail)

    export_glb("pirate_galleon_ship.glb")


def build_cable_car_gondola():
    clear_scene()
    mat_red = make_pbr_mat("GondolaAlpineRed", (0.58, 0.12, 0.10, 1.0), metallic=0.55, roughness=0.48)
    mat_steel = make_pbr_mat("RustedSteel", (0.28, 0.25, 0.22, 1.0), metallic=0.85, roughness=0.55)

    bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0, 0, 0))
    cabin = bpy.context.active_object
    cabin.scale = (2.2, 2.8, 2.4)
    cabin.data.materials.append(mat_red)

    bpy.ops.mesh.primitive_cylinder_add(radius=0.12, depth=2.0, location=(0, 0, 2.1))
    arm = bpy.context.active_object
    arm.data.materials.append(mat_steel)

    export_glb("cable_car_gondola.glb")


def build_reel_tape_recorder():
    clear_scene()
    mat_case = make_pbr_mat("VintageSteel", (0.22, 0.24, 0.26, 1.0), metallic=0.75, roughness=0.35)
    mat_brass = make_pbr_mat("ReelBrass", (0.85, 0.68, 0.28, 1.0), metallic=0.88, roughness=0.25)

    bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0, 0, 0.35))
    deck = bpy.context.active_object
    deck.scale = (0.95, 0.72, 0.65)
    deck.data.materials.append(mat_case)

    for rx in (-0.25, 0.25):
        bpy.ops.mesh.primitive_cylinder_add(radius=0.20, depth=0.06, location=(rx, -0.36, 0.52), rotation=(math.pi / 2, 0, 0))
        reel = bpy.context.active_object
        reel.data.materials.append(mat_brass)

    export_glb("reel_tape_recorder.glb")


def build_alpine_oracle_machine():
    clear_scene()
    mat_wood = make_pbr_mat("WalnutCabinet", (0.22, 0.13, 0.08, 1.0), metallic=0.1, roughness=0.62)
    mat_gold = make_pbr_mat("OracleGold", (0.92, 0.74, 0.28, 1.0), metallic=0.92, roughness=0.22, emission=(0.45, 0.32, 0.08, 1.0), emission_strength=0.6)

    bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0, 0, 0))
    booth = bpy.context.active_object
    booth.scale = (1.05, 0.95, 2.15)
    booth.data.materials.append(mat_wood)

    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.26, location=(0, -0.25, 0.45))
    head = bpy.context.active_object
    head.data.materials.append(mat_gold)

    export_glb("alpine_oracle_machine.glb")


def build_brass_pocket_watch():
    clear_scene()
    mat_gold = make_pbr_mat("PocketWatchBrass", (0.90, 0.72, 0.26, 1.0), metallic=0.94, roughness=0.18)

    bpy.ops.mesh.primitive_cylinder_add(radius=0.38, depth=0.12, location=(0, 0, 0.1))
    case = bpy.context.active_object
    case.data.materials.append(mat_gold)

    export_glb("brass_pocket_watch.glb")


def build_grandfather_clock_safe():
    clear_scene()
    mat_walnut = make_pbr_mat("ClockWalnut", (0.18, 0.10, 0.06, 1.0), metallic=0.12, roughness=0.58)
    mat_dial = make_pbr_mat("ClockDialBrass", (0.92, 0.78, 0.34, 1.0), metallic=0.9, roughness=0.2)

    bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0, 0, 0))
    tower = bpy.context.active_object
    tower.scale = (0.95, 0.75, 2.55)
    tower.data.materials.append(mat_walnut)

    bpy.ops.mesh.primitive_cylinder_add(radius=0.34, depth=0.08, location=(0, -0.39, 0.78), rotation=(math.pi / 2, 0, 0))
    dial = bpy.context.active_object
    dial.data.materials.append(mat_dial)

    export_glb("grandfather_clock_safe.glb")


def build_arcade_cabinet_retro():
    clear_scene()
    mat_cab = make_pbr_mat("ArcadeCabinetPurple", (0.28, 0.12, 0.42, 1.0), metallic=0.2, roughness=0.45)
    mat_screen = make_pbr_mat("CRTScreenGlow", (0.15, 0.95, 0.65, 1.0), metallic=0.1, roughness=0.1, emission=(0.15, 0.95, 0.65, 1.0), emission_strength=2.2)

    bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0, 0, 0))
    cab = bpy.context.active_object
    cab.scale = (0.95, 0.85, 2.05)
    cab.data.materials.append(mat_cab)

    bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0, -0.44, 0.35))
    scr = bpy.context.active_object
    scr.scale = (0.72, 0.05, 0.58)
    scr.data.materials.append(mat_screen)

    export_glb("arcade_cabinet_retro.glb")


def build_haunted_coffin_prop():
    clear_scene()
    mat_coffin = make_pbr_mat("GothicCoffinWood", (0.16, 0.09, 0.12, 1.0), metallic=0.15, roughness=0.65)
    mat_cross = make_pbr_mat("CoffinSilverCross", (0.82, 0.85, 0.90, 1.0), metallic=0.9, roughness=0.25)

    bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0, 0, 0))
    body = bpy.context.active_object
    body.scale = (0.95, 0.72, 2.05)
    body.data.materials.append(mat_coffin)

    bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0, -0.38, 0.25))
    cross_v = bpy.context.active_object
    cross_v.scale = (0.12, 0.05, 0.75)
    cross_v.data.materials.append(mat_cross)

    export_glb("haunted_coffin_prop.glb")


def build_monster_models():
    # 1. Fairytale Clockwork Puppet Monster
    clear_scene()
    mat_porcelain = make_pbr_mat("PalePorcelain", (0.88, 0.86, 0.92, 1.0), metallic=0.15, roughness=0.25)
    mat_coat = make_pbr_mat("PuppetCoatRed", (0.68, 0.12, 0.15, 1.0), metallic=0.2, roughness=0.55)
    bpy.ops.mesh.primitive_cylinder_add(radius=0.36, depth=1.25, location=(0, 0, 0.75))
    torso = bpy.context.active_object
    torso.data.materials.append(mat_coat)
    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.30, location=(0, 0, 1.62))
    head = bpy.context.active_object
    head.data.materials.append(mat_porcelain)
    export_glb("monster_fairytale_puppet.glb")

    # 2. Haunted Hilltop Coffin Stalker
    clear_scene()
    mat_bone = make_pbr_mat("CryptBone", (0.78, 0.76, 0.82, 1.0), metallic=0.1, roughness=0.4)
    bpy.ops.mesh.primitive_cylinder_add(radius=0.34, depth=1.35, location=(0, 0, 0.8))
    stalker_body = bpy.context.active_object
    stalker_body.data.materials.append(mat_bone)
    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.32, location=(0, 0, 1.68))
    stalker_head = bpy.context.active_object
    stalker_head.data.materials.append(mat_bone)
    export_glb("monster_haunted_stalker.glb")

    # 3. Ocean Kingdom Abyssal Diver Mutant
    clear_scene()
    mat_brass = make_pbr_mat("DivingHelmBrass", (0.75, 0.58, 0.22, 1.0), metallic=0.88, roughness=0.32)
    mat_suit = make_pbr_mat("AbyssalSuit", (0.12, 0.32, 0.36, 1.0), metallic=0.3, roughness=0.6)
    bpy.ops.mesh.primitive_cylinder_add(radius=0.42, depth=1.35, location=(0, 0, 0.8))
    diver_body = bpy.context.active_object
    diver_body.data.materials.append(mat_suit)
    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.38, location=(0, 0, 1.68))
    diver_helm = bpy.context.active_object
    diver_helm.data.materials.append(mat_brass)
    export_glb("monster_ocean_diver.glb")

    # 4. Final Boss: Pale Ichor Sovereign
    clear_scene()
    mat_ichor = make_pbr_mat("BossPaleIchor", (0.92, 0.88, 0.96, 1.0), metallic=0.25, roughness=0.18, emission=(0.65, 0.12, 0.22, 1.0), emission_strength=1.5)
    bpy.ops.mesh.primitive_cylinder_add(radius=0.58, depth=1.85, location=(0, 0, 1.05))
    boss_body = bpy.context.active_object
    boss_body.data.materials.append(mat_ichor)
    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.44, location=(0, 0, 2.15))
    boss_head = bpy.context.active_object
    boss_head.data.materials.append(mat_ichor)
    export_glb("boss_pale_sovereign.glb")


def build_npc_and_climax_models():
    # 1. Mascot "Hans the White Crow"
    clear_scene()
    mat_feathers = make_pbr_mat("MascotWhitePlush", (0.94, 0.95, 0.98, 1.0), metallic=0.05, roughness=0.75)
    mat_beak = make_pbr_mat("MascotGoldBeak", (0.95, 0.72, 0.18, 1.0), metallic=0.6, roughness=0.35)
    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.55, location=(0, 0, 0.95))
    belly = bpy.context.active_object
    belly.scale = (1.0, 0.9, 1.35)
    belly.data.materials.append(mat_feathers)
    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.42, location=(0, 0, 1.85))
    head = bpy.context.active_object
    head.data.materials.append(mat_feathers)
    bpy.ops.mesh.primitive_cone_add(radius1=0.18, radius2=0.02, depth=0.45, location=(0, -0.48, 1.85), rotation=(math.pi / 2, 0, 0))
    beak = bpy.context.active_object
    beak.data.materials.append(mat_beak)
    export_glb("npc_mascot_hans.glb")

    # 2. Chief Engineer Lukas Brandt
    clear_scene()
    mat_suit = make_pbr_mat("EngineerCoverall", (0.22, 0.34, 0.28, 1.0), metallic=0.2, roughness=0.65)
    mat_helm = make_pbr_mat("SafetyHelmet", (0.92, 0.65, 0.15, 1.0), metallic=0.4, roughness=0.3)
    bpy.ops.mesh.primitive_cylinder_add(radius=0.38, depth=1.3, location=(0, 0, 0.75))
    eng_body = bpy.context.active_object
    eng_body.data.materials.append(mat_suit)
    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.32, location=(0, 0, 1.62))
    eng_head = bpy.context.active_object
    eng_head.data.materials.append(mat_helm)
    export_glb("npc_lukas_brandt.glb")

    # 3. Clara's Crystalline Stasis Spire
    clear_scene()
    mat_crystal = make_pbr_mat("CryoSpireCrystal", (0.38, 0.88, 0.98, 1.0), metallic=0.35, roughness=0.12, emission=(0.25, 0.78, 0.98, 1.0), emission_strength=2.4)
    bpy.ops.mesh.primitive_cone_add(radius1=1.25, radius2=0.18, depth=4.2, location=(0, 0, 0))
    spire = bpy.context.active_object
    spire.data.materials.append(mat_crystal)
    export_glb("clara_cryo_spire.glb")


if __name__ == "__main__":
    build_investigator_sedan()
    build_fairytale_carousel()
    build_toadstool_cottage()
    build_pirate_galleon_ship()
    build_cable_car_gondola()
    build_reel_tape_recorder()
    build_alpine_oracle_machine()
    build_brass_pocket_watch()
    build_grandfather_clock_safe()
    build_arcade_cabinet_retro()
    build_haunted_coffin_prop()
    build_monster_models()
    build_npc_and_climax_models()
    print("All 18 glTF 2.0 (.glb) 3D assets generated successfully!")
