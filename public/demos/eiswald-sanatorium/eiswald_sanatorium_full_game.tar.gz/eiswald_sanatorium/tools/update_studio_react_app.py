#!/usr/bin/env python3
"""
Updates the Vite + React + TypeScript repository (vincentsckan/vincent-games-studio)
so that 《霧嶺療養院：白鴉之冬》(Eiswald Sanatorium: Winter of the White Crow)
appears as the #1 featured game icon on https://vincentsckan.github.io/vincent-games-studio/
and clicking the game icon or "立即試玩" immediately launches the local 3D game
via vincentgame://launch/eiswald-sanatorium (with fallback to /demos/eiswald-sanatorium/).
"""
import os
import re
import shutil
import sys

repo_dir = sys.argv[1] if len(sys.argv) > 1 else "/home/vincentsc_kan/vincent-games-studio"
game_portal_src = "/home/vincentsc_kan/eiswald_sanatorium/web_portal/eiswald-sanatorium"

# 1. Copy cover image and public/demos/eiswald-sanatorium/
covers_dir = os.path.join(repo_dir, "public", "covers")
os.makedirs(covers_dir, exist_ok=True)
shutil.copyfile(
    os.path.join(game_portal_src, "scene_fairytale_hub.png"),
    os.path.join(covers_dir, "eiswald-sanatorium.png"),
)

demo_dest = os.path.join(repo_dir, "public", "demos", "eiswald-sanatorium")
os.makedirs(demo_dest, exist_ok=True)
for fname in os.listdir(game_portal_src):
    s = os.path.join(game_portal_src, fname)
    d = os.path.join(demo_dest, fname)
    if os.path.isfile(s):
        shutil.copy2(s, d)

print("[OK] Copied cover to public/covers/eiswald-sanatorium.png and demo files to public/demos/eiswald-sanatorium/")

# 2. Update src/lib/demoPlay.ts
demo_play_path = os.path.join(repo_dir, "src", "lib", "demoPlay.ts")
with open(demo_play_path, "r", encoding="utf-8") as f:
    dp_code = f.read()

if "'eiswald-sanatorium'" not in dp_code:
    dp_code = dp_code.replace(
        "const DEMO_SLUGS = [\n",
        "const DEMO_SLUGS = [\n  'eiswald-sanatorium',\n",
        1,
    )
    with open(demo_play_path, "w", encoding="utf-8") as f:
        f.write(dp_code)
    print("[OK] Added 'eiswald-sanatorium' to DEMO_SLUGS in src/lib/demoPlay.ts")

# 3. Update src/data/games.ts
games_ts_path = os.path.join(repo_dir, "src", "data", "games.ts")
with open(games_ts_path, "r", encoding="utf-8") as f:
    games_code = f.read()

eiswald_entry = """  {
    id: 'eiswald-sanatorium',
    slug: 'eiswald-sanatorium',
    titleZh: '霧嶺療養院：白鴉之冬',
    titleEn: 'Eiswald Sanatorium: Winter of the White Crow',
    taglineZh: '1991 年阿爾卑斯雪山孤立療養院——箱庭式立體解謎生存恐怖。點擊即啟動本機 3D 遊戲。',
    taglineEn: '1991 Alpine sanatorium—Metroidvania-lite 3D survival horror. Click to launch native 3D game.',
    dimension: '3D',
    status: 'demo',
    year: 2026,
    genres: ['生存恐怖', '箱庭解謎', '3D'],
    hookZh:
      '1991 年冬，奧地利阿爾卑斯山脈深處的「霧嶺溫泉療養院」突遭封院，院長愛德華·克勞失蹤。特別調查員薇拉·林德奎斯特（Vera Lindqvist）獨自駕車穿過暴風雪抵達童話鎮中庭，卻發現整座渡假村已被詭異的「蒼白靈液」與機械傀儡吞噬。',
    hookEn:
      'Winter 1991. Investigator Vera Lindqvist arrives at the snowbound Eiswald Sanatorium in the Austrian Alps, only to find the fairytale resort overrun by Pale Ichor monstrosities and clockwork automata.',
    gameplayZh:
      '致敬《Crow Country》箱庭式互聯結構（童話鎮中庭、鬧鬼山丘、海洋王國、地底挖掘場四大分區）。支援 45° 自由旋轉微縮視角、3D 雷射瞄準弱點暴擊、現代直覺與經典坦克雙操作（F4 切換）、算命機三階段提示與三大難度模式。點擊遊戲 Icon 即可透過 vincentgame:// 協定直接啟動本機 Godot 4.3 Forward+ 3D 遊戲！',
    gameplayEn:
      'Crow Country-inspired interconnected Metroidvania-lite hub across 4 themed zones. 45° rotatable diorama camera, laser-sight weakpoint crits, Modern/Tank controls, Fortune Teller hints, and 3 difficulty modes. Click to launch directly on your PC!',
    features: [
      {
        titleZh: '箱庭式四大分區與捷徑',
        titleEn: 'Interconnected 4-Zone Hub',
        bodyZh: '童話鎮中庭放射連接哥德墓園、深海展示廳與地下實驗室，解鎖單向鐵門捷徑與營火安全屋。',
        bodyEn: 'Fairytale Courtyard radiating into Gothic Crypt, Ocean Kingdom, and Underground Bio-Lab with shortcuts and safe rooms.',
      },
      {
        titleZh: '45° 旋轉視角與雷射弱點瞄準',
        titleEn: 'Rotatable Diorama & Laser Aim',
        bodyZh: 'Q/E 自由旋轉 3D 鏡頭，右鍵舉槍觸發體積雷射紅線與準星收縮（最高 +55% 弱點暴擊）。',
        bodyEn: 'Free 3D camera rotation and over-the-shoulder volumetric laser aiming with reticle focus criticals.',
      },
      {
        titleZh: '點擊 Icon 本機即時啟動',
        titleEn: 'One-Click Native PC Launch',
        bodyZh: '點擊網頁 Icon 自動喚醒本機 Godot 4.3 Forward+ 3D 引擎視窗，享受原生 3A 級光影與暴風雪粒子。',
        bodyEn: 'Clicking the game icon launches the native Godot 4.3 Forward+ 3D engine directly on your computer.',
      },
    ],
    coverImage: 'covers/eiswald-sanatorium.png',
    palette: {
      from: '#0b1320',
      via: '#1b2a42',
      to: '#8ecae6',
      accent: '#e63946',
      pattern: 'void',
    },
    links: {
      play: '/vincent-games-studio/demos/eiswald-sanatorium/',
      download: '/vincent-games-studio/demos/eiswald-sanatorium/EiswaldSanatorium_ClickToPlay_Setup.bat',
    },
  },
"""

if "slug: 'eiswald-sanatorium'" not in games_code:
    games_code = games_code.replace(
        "export const games: Game[] = [\n",
        "export const games: Game[] = [\n" + eiswald_entry,
        1,
    )
    with open(games_ts_path, "w", encoding="utf-8") as f:
        f.write(games_code)
    print("[OK] Injected Eiswald Sanatorium as #1 game in src/data/games.ts")

# 4. Update src/lib/gamesCatalog.ts so eiswald-sanatorium is always sorted first even when Supabase is active
catalog_path = os.path.join(repo_dir, "src", "lib", "gamesCatalog.ts")
with open(catalog_path, "r", encoding="utf-8") as f:
    cat_code = f.read()

if "eiswald-sanatorium" not in cat_code:
    old_return = "  const merged = Array.from(bySlug.values()).filter(isPublicGame)\n  return (merged.length > 0 ? merged : localGames.filter(isPublicGame)).map(withBustedPlay)"
    new_return = """  const merged = Array.from(bySlug.values()).filter(isPublicGame)
  merged.sort((a, b) => (a.slug === 'eiswald-sanatorium' ? -1 : b.slug === 'eiswald-sanatorium' ? 1 : 0))
  return (merged.length > 0 ? merged : localGames.filter(isPublicGame)).map(withBustedPlay)"""
    if old_return in cat_code:
        cat_code = cat_code.replace(old_return, new_return, 1)
        with open(catalog_path, "w", encoding="utf-8") as f:
            f.write(cat_code)
        print("[OK] Updated src/lib/gamesCatalog.ts to pin eiswald-sanatorium at #1")

# 5. Update src/components/GameCard.tsx so clicking the Game Icon or Play button on eiswald-sanatorium immediately triggers vincentgame://launch/eiswald-sanatorium
card_path = os.path.join(repo_dir, "src", "components", "GameCard.tsx")
with open(card_path, "r", encoding="utf-8") as f:
    card_code = f.read()

if "vincentgame://launch/eiswald-sanatorium" not in card_code:
    helper_fn = """function launchEiswaldNative(e: React.MouseEvent, fallbackHref: string) {
  e.preventDefault()
  let blurred = false
  const onBlur = () => { blurred = true }
  window.addEventListener('blur', onBlur, { once: true })
  window.location.href = 'vincentgame://launch/eiswald-sanatorium'
  setTimeout(() => {
    window.removeEventListener('blur', onBlur)
    if (!blurred) {
      window.location.href = fallbackHref
    }
  }, 1200)
}
"""
    card_code = card_code.replace(
        "const statusLabel:",
        helper_fn + "\nconst statusLabel:",
        1,
    )
    # Make clicking the cover icon on eiswald-sanatorium launch the game immediately
    card_code = card_code.replace(
        "<Link\n        to={`/games/${game.slug}`}\n        className=\"group relative block focus-visible:outline-none\"\n      >",
        "<Link\n        to={`/games/${game.slug}`}\n        onClick={game.slug === 'eiswald-sanatorium' && playHref ? (e) => launchEiswaldNative(e, playHref) : undefined}\n        className=\"group relative block focus-visible:outline-none\"\n      >",
        1,
    )
    # Make clicking 立即試玩 on eiswald-sanatorium launch the game immediately
    card_code = card_code.replace(
        "<a\n              href={playHref}\n              className=\"inline-flex min-h-11 items-center justify-center rounded-full bg-gold px-5 text-sm font-bold text-ink hover:bg-gold-dim\"",
        "<a\n              href={game.slug === 'eiswald-sanatorium' ? 'vincentgame://launch/eiswald-sanatorium' : playHref}\n              onClick={game.slug === 'eiswald-sanatorium' ? (e) => launchEiswaldNative(e, playHref) : undefined}\n              className=\"inline-flex min-h-11 items-center justify-center rounded-full bg-gold px-5 text-sm font-bold text-ink hover:bg-gold-dim\"",
        1,
    )
    with open(card_path, "w", encoding="utf-8") as f:
        f.write(card_code)
    print("[OK] Updated src/components/GameCard.tsx with instant vincentgame:// click-to-launch handler")
