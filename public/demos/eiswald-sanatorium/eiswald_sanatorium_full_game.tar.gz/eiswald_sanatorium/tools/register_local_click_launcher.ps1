﻿# register_local_click_launcher.ps1
# 在本機 Windows 註冊自訂通訊協定 "vincentgame://"
# 註冊完成後，玩家在網站 https://vincentsckan.github.io/vincent-games-studio/ 點擊《霧嶺療養院：白鴉之冬》Icon 時，
# 瀏覽器會自動喚醒本機的 Godot 4.3 3D 引擎並立即啟動遊戲視窗！

$ErrorActionPreference = "Stop"
$ProjectDir = Split-Path -Parent $PSScriptRoot
$PlayScript = Join-Path $ProjectDir "play_game_windows.ps1"

$ProtocolKey = "HKCU:\Software\Classes\vincentgame"
$CommandKey = "$ProtocolKey\shell\open\command"

New-Item -Path $ProtocolKey -Force | Out-Null
Set-ItemProperty -Path $ProtocolKey -Name "(Default)" -Value "URL:Vincent Games Studio Native 3D Launcher"
Set-ItemProperty -Path $ProtocolKey -Name "URL Protocol" -Value ""

New-Item -Path $CommandKey -Force | Out-Null
$CmdString = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$PlayScript`""
Set-ItemProperty -Path $CommandKey -Name "(Default)" -Value $CmdString

Write-Host "[OK] 已成功註冊本機一鍵啟動協定 (vincentgame://)！" -ForegroundColor Green
Write-Host "現在只要在 https://vincentsckan.github.io/vincent-games-studio/ 點擊遊戲 Icon，即可直接啟動本機 3D 遊戲！" -ForegroundColor Yellow
