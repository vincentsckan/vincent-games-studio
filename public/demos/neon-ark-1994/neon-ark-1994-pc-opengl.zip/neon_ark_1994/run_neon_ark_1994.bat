@echo off
chcp 65001 >nul
echo Starting NEON ARK: 1994 (3D OpenGL Survival Horror)...
python "%~dp0main.py"
pause
