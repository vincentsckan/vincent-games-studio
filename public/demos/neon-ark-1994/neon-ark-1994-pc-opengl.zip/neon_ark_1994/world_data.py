# -*- coding: utf-8 -*-
"""
NEON ARK: 1994 - Interconnected Diorama World, Puzzles, Lore Documents & NPC Data
Inspired by Crow Country's theme-park Metroidvania structure, color-coded map completion,
Fortune Teller hint machines, and dual narrative twists.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


@dataclass
class PropDef:
    kind: str          # "fountain", "pillar", "statue_dolphin", "oracle", "save_terminal", "storage_box",
                       # "organ_console", "keypad_terminal", "coral_plaque", "valve_wheel", "safe_vault",
                       # "astral_pedestal", "desk", "arcade", "crate", "vending", "cryo_tank", "vein_crystal"
    x: float
    z: float
    rot_y: float = 0.0
    scale: float = 1.0
    label: str = ""
    interact_id: str = ""
    solid: bool = True
    radius: float = 1.0


@dataclass
class HazardDef:
    kind: str          # "explosive_barrel", "electric_puddle", "laser_tripwire"
    x: float
    z: float
    radius: float = 1.4
    active: bool = True
    hp: int = 20


@dataclass
class PickupDef:
    uid: str
    kind: str          # "ammo_pistol", "ammo_shotgun", "ammo_flamer", "ammo_magnum", "medkit", "antidote",
                       # "grenade", "key_item", "weapon", "note", "secret", "upgrade"
    name: str
    x: float
    z: float
    amount: int = 1
    item_id: str = ""
    note_id: str = ""
    collected: bool = False
    is_secret: bool = False
    hidden_in_prop: bool = False


@dataclass
class EnemySpawnDef:
    uid: str
    kind: str          # "echo_walker", "coral_hound", "mascot_brute", "acid_spitter", "boss_swan"
    name: str
    x: float
    z: float
    hp: int
    max_hp: int
    speed: float
    damage: int
    alive: bool = True
    phase: int = 1


@dataclass
class NPCDef:
    uid: str
    name: str
    role: str
    x: float
    z: float
    rot_y: float
    color: Tuple[float, float, float]
    dialogues: List[str]
    talk_index: int = 0


@dataclass
class DoorDef:
    direction: str     # "north", "south", "east", "west"
    target_room: str
    target_spawn: Tuple[float, float]
    lock_id: Optional[str] = None     # None, "keypad_1986", "bronze_key", "silver_key", "gold_key",
                                      # "one_way_from_east", "flooded_valve", "astral_seal"
    lock_name: str = ""
    unlocked: bool = False
    pos_offset: float = 0.0


@dataclass
class RoomDef:
    room_id: str
    name: str
    zone: str
    subtitle: str
    map_grid: Tuple[int, int]         # (col, row) on the 2D smart map
    width: float                      # X half-extent * 2
    depth: float                      # Z half-extent * 2
    floor_color: Tuple[float, float, float]
    wall_color: Tuple[float, float, float]
    ambient_light: Tuple[float, float, float]
    is_save_room: bool = False
    visited: bool = False
    doors: Dict[str, DoorDef] = field(default_factory=dict)
    props: List[PropDef] = field(default_factory=list)
    hazards: List[HazardDef] = field(default_factory=list)
    pickups: List[PickupDef] = field(default_factory=list)
    enemies: List[EnemySpawnDef] = field(default_factory=list)
    npcs: List[NPCDef] = field(default_factory=list)
    puzzles_solved: Dict[str, bool] = field(default_factory=dict)


# ============================================================================
# LORE DOCUMENTS (12 Memos uncovering the 2142 Refugee Twist & Vera's Identity)
# ============================================================================
LORE_NOTES: Dict[str, Dict[str, str]] = {
    "note_01_gate": {
        "title": "【文獻 01】太陽神穹頂・安檢亭值班日誌",
        "date": "1992年10月14日",
        "body": (
            "致夜班保全：\n"
            "斯旺博士下令今晚起全面封鎖『太陽神穹頂海洋博覽館』。\n"
            "如果有人忘記北側旋轉閘門的電子鎖密碼，請記住：\n"
            "密碼就是本博覽館盛大開幕的年份——【1986】。\n\n"
            "另外，新星廣場東側的維修鐵門從內部卡死了，除非從『星際明日世界』那一側把門栓踢開，"
            "否則正面絕對打不開。切勿靠近海豚劇場傳來的怪聲！"
        ),
    },
    "note_02_plaza": {
        "title": "【文獻 02】博覽館導覽手冊（染血殘頁）",
        "date": "1986年 紀念印刷版",
        "body": (
            "歡迎來到維克多·斯旺博士打造的明日烏托邦——《太陽神穹頂 SOLARIS DOME》！\n\n"
            "・西翼【仿生海豚劇場】：需持有『青銅海豚徽章』方可進入貴賓席。\n"
            "・東翼【星際明日世界】：需持有『白銀星光徽章』方可啟動太空走廊。\n"
            "・北側【行政與深海電梯】：唯有斯旺博士本人的『黃金日冕徽章』能開啟。\n\n"
            "若您在園區迷路，請尋找發光的『星象神諭機 (ASTRO-ORACLE)』，海豚星靈將為您指引方向！"
        ),
    },
    "note_03_lounge": {
        "title": "【文獻 03】員工安全室・錄音帶轉譯稿",
        "date": "1992年10月12日",
        "body": (
            "「……這根本不是什麼主題樂園。我們在員工休息室底下聽見高壓鑽頭日夜不停的轟鳴。\n"
            "馬庫斯主管說斯旺博士在海床下三千公尺挖到了『活著的黃金』——他們稱之為【逆熵銥金】。\n"
            "每當深海採掘層提高抽吸功率，園區裡的機械吉祥物就會流出溫熱的組織液……\n"
            "我把一把備用的『青銅海豚徽章』藏在廣場噴泉旁邊，誰看到這捲錄音帶，快逃！」"
        ),
    },
    "note_04_dolphin": {
        "title": "【文獻 04】仿生海豚調音師的樂譜筆記",
        "date": "1992年09月28日",
        "body": (
            "巨型機械海豚『波塞頓號』嘴裡的保險匣卡住了，裡面放著通往東翼的【白銀星光徽章】。\n"
            "只有用舞台旁的諧波管風琴彈奏正確的四音符『深海搖籃曲』，機械顎骨才會張開：\n\n"
            "  第一音：C（深海之底 - 低音 Do）\n"
            "  第二音：E（珊瑚微光 - 中音 Mi）\n"
            "  第三音：G（潮汐湧動 - 五度 Sol）\n"
            "  第四音：B（星辰倒影 - 高音 Si）\n\n"
            "依序輸入【 C - E - G - B 】即可解鎖顎骨機關。"
        ),
    },
    "note_05_VIP_incident": {
        "title": "【文獻 05】1992年貴賓館「零號咬傷事件」機密報告",
        "date": "1992年10月13日 醫療部",
        "body": (
            "【最高機密：接觸者 #09 號檔案】\n"
            "受害者姓名：林克拉拉（Clara Lin），14歲，博覽館青少年海洋科學營實習生。\n"
            "事發經過：第一隻從深海裂隙爬出的『迴響體（Echo）』闖入海豚劇場，咬傷了少女的左前臂。\n\n"
            "異常症狀：傷口並未腐爛，而是長出了帶有時間逆流特性的螢光深海珊瑚結晶。\n"
            "處置：斯旺博士對外宣稱瓦斯外洩並永久關閉太陽神穹頂，將少女秘密送離人工島。"
        ),
    },
    "note_06_astro": {
        "title": "【文獻 06】星際明日世界・化學家遺言",
        "date": "1992年10月15日",
        "body": (
            "那些怪物身上的鈣化時間珊瑚刀槍難入！普通子彈只能打碎它們的外殼。\n"
            "我們在『深海生物實驗室』調配了一瓶高濃度的【深海強酸試劑 (Abyssal Acid)】。\n"
            "如果展示廳牆上的珊瑚結塊把武器櫃和星象部件封死了，只要淋上強酸就能瞬間溶解！\n"
            "另外，我已經把通往新星中央廣場的東側單向門栓鬆開了。"
        ),
    },
    "note_07_biolab": {
        "title": "【文獻 07】「迴響體」解剖與訊號破譯報告（第一重真相）",
        "date": "1992年11月02日 斯旺首席科學家",
        "body": (
            "上帝啊，我們終於破譯了第一具『迴響體』胸腔內殘留的鈦合金銘牌與腦波編碼。\n"
            "它們不是海底變異生物，也不是失控的仿生人……\n\n"
            "【它們是來自西元 2142 年的人類難民！】\n"
            "2142年的地球因極端暖化與海平面暴漲被稱為『淹沒世紀』，人類幾近滅絕。\n"
            "未來人發現了一條能將肉體逆時空傳送回 1992 年的『深海時間脈絡』。\n"
            "但因為斯旺博士為了暴利，用高壓鑽頭日夜抽取脈絡中的『逆熵銥金』，導致時空接收端嚴重扭曲——\n"
            "所有傳送過來的 2142 年難民在抵達瞬間發生座標重疊，活生生與深海珊瑚及園區吉祥物融合成了怪物！"
        ),
    },
    "note_08_maintenance": {
        "title": "【文獻 08】地下冷卻水道・工程師手札",
        "date": "1992年10月16日",
        "body": (
            "通往『深海零號採掘層』的升降梯走廊被帶電的冷卻廢水淹沒了，直接涉水必定觸電身亡。\n"
            "我把【液壓搖柄 (Hydraulic Crank)】留在了仿生海豚劇場後台。\n"
            "只要用液壓搖柄轉動冷卻水道中央的紅色排水閥門，就能排乾積水、切斷漏電！"
        ),
    },
    "note_09_director": {
        "title": "【文獻 09】維克多·斯旺館長私人日記（保險箱線索）",
        "date": "1993年04月19日",
        "body": (
            "投資人馬庫斯以為我瘋了，連我女兒艾蕾娜也罵我是屠夫。\n"
            "但我怎麼捨得停下？每開採一公克『逆熵銥金』，就能在黑市換取上億美金！\n"
            "管他什麼未来難民的求救訊號？未來人的死活與 1994 年的我何干？\n\n"
            "我把威力最強的防身武器【脈衝麥格農 .44】鎖在館長室的鈦金保險箱裡。\n"
            "密碼就設為那些可悲未來人逃離的毀滅年份——【2142】。"
        ),
    },
    "note_10_vera_truth": {
        "title": "【文獻 10】林薇拉口袋裡的偽造證件與診斷書（第二重真相）",
        "date": "1994年11月17日 隨身私人物品",
        "body": (
            "（你低頭看著自己左臂繃帶下隱隱發光的藍紫色珊瑚結晶，翻開藏在大衣內袋的真實病歷）：\n\n"
            "患者原名：林克拉拉（化名：林薇拉 Vera Lin）。\n"
            "1992年太陽神穹頂『零號接觸者』。體內時間珊瑚結晶化已達 78%，預計剩餘壽命不足 48 小時。\n"
            "你根本不是什麼海事保險調查員——你偽造證件獨自駕船潛入這座人間煉獄，\n"
            "只為了在自己徹底變成無意識的『迴響體』之前，找到維克多·斯旺與【逆熵穩定血清】！"
        ),
    },
    "note_11_astral": {
        "title": "【文獻 11】深海聖所・三曜星盤銘文",
        "date": "無年份記載",
        "body": (
            "「欲開啟零號時間晶簇之門，須集齊三枚星象印記：\n"
            "  其一【黃金日冕徽章】，藏於館長私密頂層；\n"
            "  其二【深海新月浮雕】，封於生物實驗室鈣化珊瑚之下；\n"
            "  將兩者嵌合於深海升降梯前的三曜祭壇，時間裂隙之門方為汝敞開。」"
        ),
    },
    "note_12_swan_final": {
        "title": "【文獻 12】零號採掘層・斯旺博士最後的實驗記錄",
        "date": "1994年11月18日 凌晨",
        "body": (
            "「09號女孩……克拉拉，我知道妳終究會順著血液裡的共鳴找來這裡。\n"
            "桌上那支藍色的【逆熵穩定血清】是我提煉出的唯一一劑完美解藥，足以治癒妳與外面的生還者。\n"
            "至於我？區區人類壽命太短暫了——我要親自跳進『零號時間晶簇池』，跨越到 2142 年的彼岸成為永恆之神！」"
        ),
    },
}


# ============================================================================
# FORTUNE TELLER ("ASTRO-ORACLE 86") CONTEXT-AWARE HINTS
# ============================================================================
def get_oracle_hint(inventory_ids: set, solved_puzzles: set) -> Tuple[str, str]:
    """Returns (Title, Hint Text) based on current progression, just like Crow Country's Fortune Teller."""
    if "door_keypad_1986" not in solved_puzzles:
        return (
            "星象神諭籤 #01：『初生之門』",
            "北側旋轉閘門緊閉。閱讀門口的安檢日誌吧——太陽神穹頂誕生於【1986】年，那是開啟新星廣場的密語。"
        )
    if "bronze_key" not in inventory_ids and "door_bronze" not in solved_puzzles:
        return (
            "星象神諭籤 #02：『青銅海豚的嘆息』",
            "新星中央廣場西側的【員工安全室】裡，海豚噴泉與儲物櫃旁似乎遺落了通往西翼劇場的【青銅海豚徽章】。"
        )
    if "organ_solved" not in solved_puzzles:
        return (
            "星象神諭籤 #03：『四音符的深海搖籃曲』",
            "前往西翼【仿生海豚劇場】，在諧波管風琴上彈奏【 C - E - G - B 】，巨型機械海豚將吐出白銀星光徽章與液壓搖柄。"
        )
    if "acid_vial" not in inventory_ids and "coral_melted" not in solved_puzzles:
        return (
            "星象神諭籤 #04：『明日世界的腐蝕之水』",
            "用白銀徽章開啟新星廣場東側的【星際明日世界】，深入北邊的【深海生物實驗室】取得強酸試劑。"
        )
    if "coral_melted" not in solved_puzzles:
        return (
            "星象神諭籤 #05：『溶解時間的甲殼』",
            "將【深海強酸試劑】淋在深海生物實驗室北牆的鈣化珊瑚結塊上，即可取出【極光熱熔噴射器】與【深海新月浮雕】。"
        )
    if "gold_key" not in inventory_ids:
        return (
            "星象神諭籤 #06：『館長的傲慢與2142』",
            "從星際明日世界進入【館長私人貴賓室】，桌上放著【黃金日冕徽章】；而角落保險箱密碼是未來毀滅之年【2142】。"
        )
    if "flooded_drained" not in solved_puzzles:
        return (
            "星象神諭籤 #07：『乾涸的雷霆水道』",
            "用黃金日冕徽章打開新星廣場北門進入【地下冷卻水道】，使用海豚劇場取得的【液壓搖柄】轉動排水閥排乾漏電積水！"
        )
    if "astral_unlocked" not in solved_puzzles:
        return (
            "星象神諭籤 #08：『三曜祭壇的共鳴』",
            "在【深海升降梯前廳】調查三曜星盤祭壇，嵌入黃金日冕徽章與深海新月浮雕，開啟通往零號採掘層的大門。"
        )
    return (
        "星象神諭籤 #09：『直面零號時間晶簇』",
        "一切謎底皆已揭曉。踏入北方的【零號時間晶簇核心】，擊潰與時間裂隙融合的維克多·斯旺，奪取逆熵穩定血清！"
    )


# ============================================================================
# WORLD BUILDER: 10 INTERCONNECTED DIORAMA ROOMS
# ============================================================================
def build_world() -> Dict[str, RoomDef]:
    rooms: Dict[str, RoomDef] = {}

    # ------------------------------------------------------------------------
    # ROOM 1: Entrance Pier & Security Gate (入口棧橋與安檢亭) - Map (1, 3)
    # ------------------------------------------------------------------------
    r_gate = RoomDef(
        room_id="entrance_gate",
        name="入口棧橋與安檢亭",
        zone="外圍海堤區 (Outer Pier)",
        subtitle="1994年11月18日 00:40 - 東海人工島・太陽神穹頂正門",
        map_grid=(1, 3),
        width=18.0,
        depth=16.0,
        floor_color=(0.14, 0.17, 0.22),
        wall_color=(0.20, 0.25, 0.32),
        ambient_light=(0.45, 0.55, 0.70),
        visited=True,
        doors={
            "north": DoorDef(
                direction="north",
                target_room="nova_plaza",
                target_spawn=(0.0, 7.2),
                lock_id="keypad_1986",
                lock_name="1986開幕年份電子密碼鎖",
                unlocked=False,
            )
        },
        props=[
            PropDef("keypad_terminal", 1.8, -7.2, 0.0, 1.0, "北側安檢電子鎖 [密碼輸入]", "puzzle_keypad_1986", True, 0.8),
            PropDef("oracle", -5.8, -4.5, 35.0, 1.0, "星象神諭機 ASTRO-ORACLE", "use_oracle", True, 1.0),
            PropDef("desk", 5.2, -3.5, -20.0, 1.0, "安檢值班桌", "", True, 1.1),
            PropDef("vending", -6.5, 3.5, 90.0, 1.0, "1986海豚汽水販賣機 (調查可搜尋零錢槽)", "secret_trash_gate", True, 1.0),
            PropDef("pillar", -4.0, -1.0, 0.0, 1.0, "霓虹燈柱", "", True, 0.7),
            PropDef("pillar", 4.0, -1.0, 0.0, 1.0, "霓虹燈柱", "", True, 0.7),
        ],
        pickups=[
            PickupDef("p_gate_note1", "note", "安檢亭值班日誌", 4.8, -2.5, 1, note_id="note_01_gate"),
            PickupDef("p_gate_note10", "note", "林薇拉隨身病歷檔案", -2.2, 4.5, 1, note_id="note_10_vera_truth"),
            PickupDef("p_gate_ammo1", "ammo_pistol", "9mm 手槍彈藥 x12", -4.8, 1.8, 12),
            PickupDef("p_gate_secret1", "secret", "【秘密 #1】黃金海豚紀念幣 (販賣機退幣口)", -5.2, 3.5, 1,
                      item_id="secret_1", is_secret=True),
        ],
    )
    rooms[r_gate.room_id] = r_gate

    # ------------------------------------------------------------------------
    # ROOM 2: Nova Central Plaza (新星中央廣場 - Central Hub) - Map (1, 2)
    # ------------------------------------------------------------------------
    r_plaza = RoomDef(
        room_id="nova_plaza",
        name="新星中央廣場",
        zone="中央樞紐 (Central Hub)",
        subtitle="太陽神穹頂核心大廳 - 通往四大主題展區與安全屋",
        map_grid=(1, 2),
        width=24.0,
        depth=22.0,
        floor_color=(0.16, 0.14, 0.24),
        wall_color=(0.24, 0.20, 0.36),
        ambient_light=(0.55, 0.45, 0.75),
        doors={
            "south": DoorDef("south", "entrance_gate", (0.0, -5.8), None, "", True),
            "west": DoorDef("west", "staff_save_room", (5.5, 0.0), None, "員工安全室 (無鎖)", True, pos_offset=-3.5),
            "east": DoorDef("east", "astro_tomorrow", (-8.5, 0.0), "silver_key", "白銀星光徽章之門", False),
            "north": DoorDef("north", "coolant_tunnel", (0.0, 7.2), "gold_key", "黃金日冕徽章大門", False),
        },
        props=[
            PropDef("fountain", 0.0, 0.0, 0.0, 1.35, "太陽神海豚紀念噴泉", "examine_fountain", True, 2.3),
            PropDef("statue_dolphin", -6.5, -6.5, 45.0, 1.1, "西翼劇場入口雕像 [進入仿生海豚劇場]", "door_to_dolphinarium", True, 1.2),
            PropDef("oracle", 7.5, 6.2, -35.0, 1.0, "星象神諭機 ASTRO-ORACLE", "use_oracle", True, 1.0),
            PropDef("arcade", -8.5, 5.8, 65.0, 1.0, "80年代復古街機『CRONOS-86』", "secret_arcade_plaza", True, 1.0),
            PropDef("pillar", -5.5, 4.5, 0.0, 1.0, "穹頂支撐柱", "", True, 0.8),
            PropDef("pillar", 5.5, 4.5, 0.0, 1.0, "穹頂支撐柱", "", True, 0.8),
            PropDef("pillar", 5.5, -5.5, 0.0, 1.0, "穹頂支撐柱", "", True, 0.8),
        ],
        hazards=[
            HazardDef("explosive_barrel", -3.8, -3.5, 1.3, True, 15),
            HazardDef("explosive_barrel", 4.5, -2.0, 1.3, True, 15),
        ],
        pickups=[
            PickupDef("p_plaza_note2", "note", "博覽館導覽手冊", 2.5, 2.2, 1, note_id="note_02_plaza"),
            PickupDef("p_plaza_ammo1", "ammo_pistol", "9mm 手槍彈藥 x15", 8.2, -6.5, 15),
            PickupDef("p_plaza_med1", "medkit", "急救噴霧罐", -8.0, -2.0, 1),
            PickupDef("p_plaza_secret2", "secret", "【秘密 #2】限量版海豚星靈徽章 (街機下方)", -7.5, 5.8, 1,
                      item_id="secret_2", is_secret=True),
        ],
        enemies=[
            EnemySpawnDef("e_plaza_1", "echo_walker", "迴響體・漫遊者", -4.5, -4.2, 45, 45, 2.3, 14),
            EnemySpawnDef("e_plaza_2", "echo_walker", "迴響體・漫遊者", 5.2, -3.5, 45, 45, 2.4, 14),
        ],
        npcs=[
            NPCDef(
                uid="npc_elena",
                name="艾蕾娜·斯旺 (Elena Swan)",
                role="創辦人之女・反企業吹哨者",
                x=3.2,
                z=5.5,
                rot_y=160.0,
                color=(0.3, 0.85, 0.95),
                dialogues=[
                    "艾蕾娜：「別開槍！我是維克多·斯旺的女兒艾蕾娜……妳也是來找我父親算帳的嗎？」",
                    "艾蕾娜：「西邊的『員工安全室』沒有怪物，我在那裡的儲物台放了通往海豚劇場的【青銅海豚徽章】。」",
                    "艾蕾娜：「小心那些『迴響體』！按住【滑鼠右鍵】或【空白鍵】停步瞄準，等雷射準星收束成亮紅點再射擊頭部，能造成雙倍暴擊！」",
                    "艾蕾娜：「妳的手臂……為什麼纏著滲出藍光的繃帶？算了，活下去要緊，快去西邊安全室整備吧。」",
                ],
            )
        ],
    )
    rooms[r_plaza.room_id] = r_plaza

    # ------------------------------------------------------------------------
    # ROOM 3: Staff Lounge Save Room (員工安全室 - Save & Upgrade Hub) - Map (0, 2)
    # ------------------------------------------------------------------------
    r_save = RoomDef(
        room_id="staff_save_room",
        name="員工安全室 (SAVE ROOM)",
        zone="後勤安全區 (Safe Haven)",
        subtitle="溫暖的磁帶合成器音樂迴盪著——怪物無法踏入此處",
        map_grid=(0, 2),
        width=14.0,
        depth=12.0,
        floor_color=(0.12, 0.22, 0.20),
        wall_color=(0.18, 0.32, 0.28),
        ambient_light=(0.45, 0.85, 0.72),
        is_save_room=True,
        doors={
            "east": DoorDef("east", "nova_plaza", (-9.5, -3.5), None, "", True),
        },
        props=[
            PropDef("save_terminal", -4.2, -3.8, 25.0, 1.1, "CRT 存檔終端機 [紀錄進度與狀態]", "save_game", True, 1.0),
            PropDef("storage_box", 0.0, -4.2, 0.0, 1.1, "戰術補給醫療站 [免費恢復體力一次]", "heal_station", True, 1.1),
            PropDef("desk", 4.0, -3.5, -15.0, 1.0, "值班工程師長桌", "", True, 1.1),
            PropDef("vending", -5.0, 3.2, 90.0, 1.0, "熱咖啡自動販賣機", "", True, 0.9),
        ],
        pickups=[
            PickupDef("p_save_bronze", "key_item", "【鑰匙】青銅海豚徽章", -1.5, 1.2, 1, item_id="bronze_key"),
            PickupDef("p_save_shotgun", "weapon", "【武器】M90 鎮暴霰彈槍", 3.2, -1.8, 1, item_id="shotgun"),
            PickupDef("p_save_sgammo", "ammo_shotgun", "12號霰彈 x8", 4.5, 1.5, 8),
            PickupDef("p_save_note3", "note", "員工安全室錄音帶轉譯稿", -3.2, 2.5, 1, note_id="note_03_lounge"),
            PickupDef("p_save_upgrade1", "upgrade", "【改裝零件】高精度雷射收束器 (提升手槍暴擊率)", 2.2, 3.5, 1,
                      item_id="upgrade_laser", is_secret=True),
        ],
    )
    rooms[r_save.room_id] = r_save

    # ------------------------------------------------------------------------
    # ROOM 4: Bionic Dolphinarium (仿生海豚劇場 - West Wing) - Map (0, 1)
    # ------------------------------------------------------------------------
    r_dolphin = RoomDef(
        room_id="dolphinarium",
        name="仿生海豚劇場",
        zone="西翼海洋館 (West Wing)",
        subtitle="80年代機械海豚『波塞頓號』懸浮於乾涸的水池中央",
        map_grid=(0, 1),
        width=22.0,
        depth=20.0,
        floor_color=(0.10, 0.20, 0.30),
        wall_color=(0.14, 0.28, 0.42),
        ambient_light=(0.35, 0.65, 0.90),
        doors={
            "south": DoorDef("south", "nova_plaza", (-5.5, -5.0), None, "返回新星中央廣場", True),
            "north": DoorDef("north", "backstage_vip", (0.0, 5.5), None, "通往海豚劇場貴賓後台", True),
        },
        props=[
            PropDef("statue_dolphin", 0.0, -2.0, 0.0, 1.9, "巨型機械海豚『波塞頓號』", "examine_giant_dolphin", True, 2.2),
            PropDef("organ_console", -6.5, -3.5, 35.0, 1.15, "諧波管風琴控制台 [彈奏四音符謎題]", "puzzle_organ", True, 1.2),
            PropDef("pillar", -6.0, 4.0, 0.0, 1.0, "海洋浮雕柱", "", True, 0.8),
            PropDef("pillar", 6.0, 4.0, 0.0, 1.0, "海洋浮雕柱", "", True, 0.8),
            PropDef("crate", 7.2, -5.0, 15.0, 1.0, "音響器材箱", "", True, 1.0),
        ],
        hazards=[
            HazardDef("electric_puddle", 3.5, 1.5, 2.2, True, 999),
            HazardDef("explosive_barrel", -3.5, 2.5, 1.3, True, 15),
        ],
        pickups=[
            PickupDef("p_dol_note4", "note", "仿生海豚調音師的樂譜筆記", -5.2, 2.2, 1, note_id="note_04_dolphin"),
            PickupDef("p_dol_ammo1", "ammo_shotgun", "12號霰彈 x6", 6.5, -2.5, 6),
            PickupDef("p_dol_med1", "medkit", "急救噴霧罐", 6.8, 5.5, 1),
            PickupDef("p_dol_grenade1", "grenade", "高爆破片手榴彈 x2", -7.8, -6.2, 2),
        ],
        enemies=[
            EnemySpawnDef("e_dol_1", "coral_hound", "深海珊瑚獵犬", 4.2, -3.5, 35, 35, 3.6, 12),
            EnemySpawnDef("e_dol_2", "mascot_brute", "失控吉祥物・海豚隊長", -2.8, 3.8, 85, 85, 1.9, 22),
        ],
    )
    rooms[r_dolphin.room_id] = r_dolphin

    # ------------------------------------------------------------------------
    # ROOM 5: VIP Backstage & Observation Deck (劇場貴賓後台) - Map (0, 0)
    # ------------------------------------------------------------------------
    r_vip = RoomDef(
        room_id="backstage_vip",
        name="海豚劇場・貴賓後台",
        zone="西翼海洋館 (West Wing)",
        subtitle="1992年『零號咬傷事件』第一現場——玻璃窗外是幽暗的深海",
        map_grid=(0, 0),
        width=16.0,
        depth=14.0,
        floor_color=(0.18, 0.14, 0.22),
        wall_color=(0.26, 0.18, 0.30),
        ambient_light=(0.60, 0.45, 0.65),
        doors={
            "south": DoorDef("south", "dolphinarium", (0.0, -7.2), None, "返回仿生海豚劇場", True),
        },
        props=[
            PropDef("desk", -4.2, -3.5, 10.0, 1.0, "染血的貴賓接待桌", "", True, 1.1),
            PropDef("cryo_tank", 4.5, -3.2, -25.0, 1.1, "破裂的零號標本培養槽", "", True, 1.2),
            PropDef("oracle", -5.2, 3.2, 45.0, 1.0, "星象神諭機 ASTRO-ORACLE", "use_oracle", True, 1.0),
        ],
        pickups=[
            PickupDef("p_vip_crank", "key_item", "【工具】液壓搖柄 (Hydraulic Crank)", 0.0, -2.5, 1, item_id="hydraulic_crank"),
            PickupDef("p_vip_note5", "note", "1992年貴賓館「零號咬傷事件」報告", -3.5, -2.0, 1, note_id="note_05_VIP_incident"),
            PickupDef("p_vip_ammo", "ammo_pistol", "9mm 手槍彈藥 x15", 4.2, 2.8, 15),
            PickupDef("p_vip_secret3", "secret", "【秘密 #3】1992科學營實習生名牌『林克拉拉』", 3.5, -4.2, 1,
                      item_id="secret_3", is_secret=True),
        ],
        npcs=[
            NPCDef(
                uid="npc_arthur",
                name="陳亞瑟 (Arthur 'Lens' Chen)",
                role="超自然現象獨立記者",
                x=-1.8,
                z=2.8,
                rot_y=145.0,
                color=(0.95, 0.75, 0.30),
                dialogues=[
                    "陳亞瑟：「別晃動手電筒！我正在用紅外線底片拍攝這個培養槽……妳看這上面的抓痕！」",
                    "陳亞瑟：「兩年前一個叫林克拉拉的14歲女孩在這裡被第一隻怪物咬傷，斯旺為了掩蓋醜聞才封鎖了整座人工島。」",
                    "陳亞瑟：「等等……妳的眼神跟當年報紙上那個倖存女孩一模一樣！妳拿走桌上的【液壓搖柄】吧，地下冷卻水道用得上。」",
                ],
            )
        ],
    )
    rooms[r_vip.room_id] = r_vip

    # ------------------------------------------------------------------------
    # ROOM 6: Astro-Tomorrow Pavilion (星際明日世界 - East Wing) - Map (2, 2)
    # ------------------------------------------------------------------------
    r_astro = RoomDef(
        room_id="astro_tomorrow",
        name="星際明日世界展館",
        zone="東翼太空館 (East Wing)",
        subtitle="復古合成波霓虹與失落的80年代太空殖民幻想",
        map_grid=(2, 2),
        width=22.0,
        depth=20.0,
        floor_color=(0.15, 0.12, 0.26),
        wall_color=(0.24, 0.18, 0.38),
        ambient_light=(0.65, 0.42, 0.85),
        doors={
            "west": DoorDef("west", "nova_plaza", (9.2, 0.0), None, "返回新星中央廣場", True),
            "north": DoorDef("north", "marine_biolab", (0.0, 6.2), None, "進入深海生物實驗室", True),
            "south": DoorDef("south", "director_suite", (0.0, -5.8), None, "進入館長私人貴賓室", True),
        },
        props=[
            PropDef("pillar", -4.5, -3.5, 0.0, 1.1, "星環全息投影柱", "", True, 0.9),
            PropDef("pillar", 4.5, -3.5, 0.0, 1.1, "星環全息投影柱", "", True, 0.9),
            PropDef("arcade", 7.5, 5.2, -45.0, 1.0, "太空射擊街機『GALAXY-90』", "", True, 1.0),
            PropDef("crate", -7.2, 4.8, 20.0, 1.0, "太空艙模型零件箱", "", True, 1.0),
        ],
        hazards=[
            HazardDef("explosive_barrel", 0.0, 0.5, 1.4, True, 15),
            HazardDef("electric_puddle", -4.8, 2.0, 2.0, True, 999),
        ],
        pickups=[
            PickupDef("p_ast_note6", "note", "星際明日世界・化學家遺言", -6.5, -4.5, 1, note_id="note_06_astro"),
            PickupDef("p_ast_sgammo", "ammo_shotgun", "12號霰彈 x8", 6.8, -4.8, 8),
            PickupDef("p_ast_pistol", "ammo_pistol", "9mm 手槍彈藥 x15", -7.5, 2.5, 15),
            PickupDef("p_ast_secret4", "secret", "【秘密 #4】復古太空人黃金模型", 7.8, 3.2, 1,
                      item_id="secret_4", is_secret=True),
        ],
        enemies=[
            EnemySpawnDef("e_ast_1", "acid_spitter", "迴響體・強酸噴吐者", -3.2, -1.5, 55, 55, 2.2, 16),
            EnemySpawnDef("e_ast_2", "echo_walker", "迴響體・太空服漫遊者", 4.0, 2.5, 50, 50, 2.5, 15),
            EnemySpawnDef("e_ast_3", "coral_hound", "深海珊瑚獵犬", 1.5, -4.2, 38, 38, 3.7, 13),
        ],
    )
    rooms[r_astro.room_id] = r_astro

    # ------------------------------------------------------------------------
    # ROOM 7: Marine Bio-Lab (深海生物實驗室) - Map (2, 1)
    # ------------------------------------------------------------------------
    r_biolab = RoomDef(
        room_id="marine_biolab",
        name="深海生物與時間珊瑚實驗室",
        zone="東翼太空館 (East Wing)",
        subtitle="解剖台上的銘牌揭開了『迴響體』來自西元 2142 年的駭人真相",
        map_grid=(2, 1),
        width=18.0,
        depth=16.0,
        floor_color=(0.12, 0.22, 0.24),
        wall_color=(0.16, 0.30, 0.34),
        ambient_light=(0.40, 0.82, 0.78),
        doors={
            "south": DoorDef("south", "astro_tomorrow", (0.0, -7.2), None, "返回星際明日世界", True),
        },
        props=[
            PropDef("coral_plaque", 0.0, -6.8, 0.0, 1.3, "鈣化時間珊瑚封死展示櫃 [需使用深海強酸試劑]", "puzzle_melt_coral", True, 1.3),
            PropDef("cryo_tank", -5.5, -2.5, 20.0, 1.1, "2142年難民遺骸保存槽", "", True, 1.2),
            PropDef("cryo_tank", 5.5, -2.5, -20.0, 1.1, "時間珊瑚增殖槽", "", True, 1.2),
            PropDef("desk", -3.8, 3.2, 0.0, 1.0, "化學合成實驗台", "", True, 1.1),
        ],
        pickups=[
            PickupDef("p_bio_acid", "key_item", "【化學品】深海強酸試劑 (Abyssal Acid)", -3.5, 1.8, 1, item_id="acid_vial"),
            PickupDef("p_bio_note7", "note", "「迴響體」解剖與訊號破譯報告 (2142真相)", 3.8, 2.2, 1, note_id="note_07_biolab"),
            PickupDef("p_bio_med", "medkit", "濃縮急救噴霧罐", 5.8, 4.5, 1),
            PickupDef("p_bio_flamer_ammo", "ammo_flamer", "極光熱熔燃料罐 x40", -6.2, 4.8, 40),
            PickupDef("p_bio_secret5", "secret", "【秘密 #5】2142年難民的懷錶殘骸", -5.8, -4.8, 1,
                      item_id="secret_5", is_secret=True),
        ],
        enemies=[
            EnemySpawnDef("e_bio_1", "acid_spitter", "迴響體・實驗體零肆號", 2.5, -1.8, 60, 60, 2.3, 16),
        ],
    )
    rooms[r_biolab.room_id] = r_biolab

    # ------------------------------------------------------------------------
    # ROOM 8: Director Swan's Private Suite (館長私人貴賓室) - Map (2, 3)
    # ------------------------------------------------------------------------
    r_director = RoomDef(
        room_id="director_suite",
        name="維克多·斯旺館長私人貴賓室",
        zone="東翼行政區 (Executive Suite)",
        subtitle="奢華的紅絲絨地毯與藏著脈衝麥格農的 2142 鈦金保險箱",
        map_grid=(2, 3),
        width=16.0,
        depth=14.0,
        floor_color=(0.24, 0.12, 0.16),
        wall_color=(0.34, 0.16, 0.22),
        ambient_light=(0.80, 0.48, 0.55),
        doors={
            "north": DoorDef("north", "astro_tomorrow", (0.0, 7.2), None, "返回星際明日世界", True),
        },
        props=[
            PropDef("safe_vault", 5.2, -4.5, -30.0, 1.15, "館長室鈦金保險箱 [4位數密碼鎖]", "puzzle_safe_2142", True, 1.1),
            PropDef("desk", 0.0, -3.2, 0.0, 1.2, "斯旺館長紅木辦公桌", "", True, 1.3),
            PropDef("save_terminal", -5.2, -4.2, 30.0, 1.0, "館長專用備份終端機 [可存檔]", "save_game", True, 1.0),
        ],
        pickups=[
            PickupDef("p_dir_goldkey", "key_item", "【鑰匙】黃金日冕徽章 (Gold Corona Key)", 0.0, -1.5, 1, item_id="gold_key"),
            PickupDef("p_dir_note9", "note", "維克多·斯旺館長私人日記", 1.8, -2.8, 1, note_id="note_09_director"),
            PickupDef("p_dir_magammo", "ammo_magnum", ".44 脈衝麥格農子彈 x6", -4.5, 3.2, 6),
            PickupDef("p_dir_secret6", "secret", "【秘密 #6】純逆熵銥金原石樣本", 5.5, 3.8, 1,
                      item_id="secret_6", is_secret=True),
        ],
        npcs=[
            NPCDef(
                uid="npc_marcus",
                name="馬庫斯·范斯 (Marcus Vance)",
                role="太陽神企業保全總監",
                x=-3.2,
                z=1.5,
                rot_y=120.0,
                color=(0.85, 0.35, 0.35),
                dialogues=[
                    "馬庫斯：「咳咳……別過來！斯旺那個瘋子騙了所有股東，他把整座博覽館當成他提煉『逆熵銥金』的私人礦場！」",
                    "馬庫斯：「桌上的【黃金日冕徽章】妳儘管拿去，可以打開中央廣場北邊通往地下冷卻水道的大門。」",
                    "馬庫斯：「如果妳想打開牆角那個鈦金保險箱拿【脈衝麥格農 .44】，密碼是【2142】——那是未來人滅亡的年份！」",
                ],
            )
        ],
    )
    rooms[r_director.room_id] = r_director

    # ------------------------------------------------------------------------
    # ROOM 9: Sub-Level Coolant Tunnel & Astral Gate (地下冷卻水道與三曜祭壇) - Map (1, 1)
    # ------------------------------------------------------------------------
    r_tunnel = RoomDef(
        room_id="coolant_tunnel",
        name="地下冷卻水道與三曜祭壇",
        zone="深海連接層 (Sub-Level Trench)",
        subtitle="通往海底三千公尺『零號時間晶簇核心』的最後關卡",
        map_grid=(1, 1),
        width=20.0,
        depth=20.0,
        floor_color=(0.12, 0.16, 0.20),
        wall_color=(0.18, 0.22, 0.28),
        ambient_light=(0.42, 0.60, 0.78),
        doors={
            "south": DoorDef("south", "nova_plaza", (0.0, -8.2), None, "返回新星中央廣場", True),
            "north": DoorDef("north", "pelagic_core", (0.0, 8.0), "astral_seal", "三曜星盤封印大門", False),
        },
        props=[
            PropDef("valve_wheel", -5.2, 2.5, 40.0, 1.2, "主排水液壓閥門 [需使用液壓搖柄]", "puzzle_drain_flood", True, 1.1),
            PropDef("astral_pedestal", 2.2, -7.2, 0.0, 1.2, "深海三曜星盤祭壇 [需黃金日冕徽章 + 深海新月浮雕]", "puzzle_astral_gate", True, 1.1),
            PropDef("oracle", 6.5, 4.5, -35.0, 1.0, "星象神諭機 ASTRO-ORACLE", "use_oracle", True, 1.0),
            PropDef("storage_box", -6.5, -5.5, 20.0, 1.0, "決戰前緊急醫療補給箱 [免費恢復體力]", "heal_station", True, 1.0),
        ],
        hazards=[
            HazardDef("electric_puddle", 0.0, 0.5, 3.8, True, 999),  # Drained when valve puzzle solved!
            HazardDef("explosive_barrel", 4.5, -2.5, 1.3, True, 15),
            HazardDef("explosive_barrel", -3.8, -2.0, 1.3, True, 15),
        ],
        pickups=[
            PickupDef("p_tun_note8", "note", "地下冷卻水道・工程師手札", -6.2, 5.8, 1, note_id="note_08_maintenance"),
            PickupDef("p_tun_note11", "note", "深海聖所・三曜星盤銘文", 4.5, -5.8, 1, note_id="note_11_astral"),
            PickupDef("p_tun_sgammo", "ammo_shotgun", "12號霰彈 x8", 6.2, -1.5, 8),
            PickupDef("p_tun_magammo", "ammo_magnum", ".44 脈衝麥格農子彈 x6", -6.2, -2.5, 6),
            PickupDef("p_tun_med", "medkit", "急救噴霧罐", 5.8, 6.8, 1),
            PickupDef("p_tun_secret7", "secret", "【秘密 #7】深海潛水鐘純金銘牌", -7.5, -7.2, 1,
                      item_id="secret_7", is_secret=True),
        ],
        enemies=[
            EnemySpawnDef("e_tun_1", "mascot_brute", "重裝吉祥物・深海守衛", -3.0, -3.5, 95, 95, 2.0, 24),
            EnemySpawnDef("e_tun_2", "acid_spitter", "迴響體・強酸噴吐者", 3.8, -3.2, 58, 58, 2.3, 16),
        ],
    )
    rooms[r_tunnel.room_id] = r_tunnel

    # ------------------------------------------------------------------------
    # ROOM 10: Pelagic Vein Core (零號時間晶簇核心 - Final Boss Chamber) - Map (1, 0)
    # ------------------------------------------------------------------------
    r_core = RoomDef(
        room_id="pelagic_core",
        name="零號時間晶簇核心 (FINAL CHAMBER)",
        zone="海底三千公尺・時間裂隙 (The Pelagic Vein)",
        subtitle="跨越 1994 與 2142 的深海奇點——維克多·斯旺與時間晶簇的融合之地",
        map_grid=(1, 0),
        width=24.0,
        depth=22.0,
        floor_color=(0.10, 0.08, 0.18),
        wall_color=(0.18, 0.12, 0.30),
        ambient_light=(0.75, 0.35, 0.90),
        doors={
            "south": DoorDef("south", "coolant_tunnel", (0.0, -7.2), None, "返回地下冷卻水道", True),
        },
        props=[
            PropDef("vein_crystal", 0.0, -3.5, 0.0, 2.2, "零號時間晶簇母體 (The Pelagic Vein)", "", True, 2.4),
            PropDef("desk", -6.5, 5.2, 25.0, 1.1, "斯旺博士的最終實驗台 [擺放著逆熵穩定血清]", "claim_serum_ending", True, 1.2),
            PropDef("pillar", -6.5, -2.5, 0.0, 1.2, "逆熵銥金導流柱", "", True, 0.9),
            PropDef("pillar", 6.5, -2.5, 0.0, 1.2, "逆熵銥金導流柱", "", True, 0.9),
        ],
        hazards=[
            HazardDef("explosive_barrel", -4.8, 1.5, 1.4, True, 15),
            HazardDef("explosive_barrel", 4.8, 1.5, 1.4, True, 15),
            HazardDef("explosive_barrel", 0.0, 3.8, 1.4, True, 15),
        ],
        pickups=[
            PickupDef("p_core_note12", "note", "斯旺博士最後的實驗記錄", -5.2, 5.5, 1, note_id="note_12_swan_final"),
            PickupDef("p_core_med1", "medkit", "急救噴霧罐", 7.2, 6.2, 1),
            PickupDef("p_core_mag1", "ammo_magnum", ".44 脈衝麥格農子彈 x8", -7.5, -6.2, 8),
            PickupDef("p_core_sg1", "ammo_shotgun", "12號霰彈 x8", 7.5, -6.2, 8),
            PickupDef("p_core_secret8", "secret", "【秘密 #8】2142年時間方舟核心晶片", 0.0, -8.5, 1,
                      item_id="secret_8", is_secret=True),
        ],
        enemies=[
            EnemySpawnDef(
                uid="boss_victor_swan",
                kind="boss_swan",
                name="【最終首領】時空融合體・維克多·斯旺",
                x=0.0,
                z=-0.5,
                hp=320,
                max_hp=320,
                speed=2.25,
                damage=26,
                alive=True,
                phase=1,
            ),
        ],
    )
    rooms[r_core.room_id] = r_core

    return rooms
