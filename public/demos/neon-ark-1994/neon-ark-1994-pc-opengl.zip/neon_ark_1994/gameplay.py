# -*- coding: utf-8 -*-
"""
NEON ARK: 1994 - Core Survival Horror Gameplay, Combat, Puzzles, AI & S-Rank Engine
Implements Crow Country's signature systems:
- Dual Controls (Modern 360° Camera-Relative vs. Classic Tank Controls)
- Deliberate Laser-Sight Aiming (stop-and-aim, charge focus for headshot crits)
- 4 Weapons + Grenades + Shootable Environmental Traps
- Context-sensitive Fortune Teller ("ASTRO-ORACLE") hints (10 tokens max)
- Color-coded Smart Map room completion tracking
- Save/Load JSON persistence & Final S-Rank evaluation
"""

import json
import math
import os
import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from world_data import (
    LORE_NOTES,
    DoorDef,
    EnemySpawnDef,
    HazardDef,
    NPCDef,
    PickupDef,
    PropDef,
    RoomDef,
    build_world,
    get_oracle_hint,
)


@dataclass
class Projectile:
    x: float
    y: float
    z: float
    vx: float
    vy: float
    vz: float
    kind: str          # "acid_orb", "grenade", "flame"
    damage: int
    from_player: bool
    life: float = 2.2


@dataclass
class Particle3D:
    x: float
    y: float
    z: float
    vx: float
    vy: float
    vz: float
    color: Tuple[float, float, float]
    size: float
    life: float
    max_life: float


@dataclass
class FloatingText:
    text: str
    x: float
    y: float
    z: float
    color: Tuple[int, int, int]
    life: float = 1.2


WEAPON_SPECS = {
    "pistol": {
        "name": "88式警用手槍 (9mm)",
        "ammo_key": "ammo_pistol",
        "damage": 18,
        "crit_mult": 2.2,
        "cooldown": 0.34,
        "range": 18.0,
        "pellets": 1,
        "spread_deg": 1.5,
        "sound": "pistol",
        "laser_color": (1.0, 0.15, 0.20),
    },
    "shotgun": {
        "name": "M90 鎮暴霰彈槍 (12G)",
        "ammo_key": "ammo_shotgun",
        "damage": 13,
        "crit_mult": 1.6,
        "cooldown": 0.78,
        "range": 10.5,
        "pellets": 6,
        "spread_deg": 14.0,
        "sound": "shotgun",
        "laser_color": (1.0, 0.55, 0.15),
    },
    "flamer": {
        "name": "極光熱熔噴射器 (Plasma)",
        "ammo_key": "ammo_flamer",
        "damage": 7,
        "crit_mult": 1.3,
        "cooldown": 0.11,
        "range": 7.2,
        "pellets": 1,
        "spread_deg": 8.0,
        "sound": "flamer",
        "laser_color": (0.20, 0.90, 1.0),
    },
    "magnum": {
        "name": "脈衝麥格農 (.44 Magnum)",
        "ammo_key": "ammo_magnum",
        "damage": 68,
        "crit_mult": 2.5,
        "cooldown": 0.85,
        "range": 22.0,
        "pellets": 1,
        "spread_deg": 0.5,
        "sound": "magnum",
        "laser_color": (0.95, 0.25, 1.0),
    },
}


class GameSession:
    def __init__(self, audio_engine):
        self.audio = audio_engine
        self.save_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "savegame_1994.json")
        self.reset_new_game()

    def reset_new_game(self):
        self.rooms: Dict[str, RoomDef] = build_world()
        self.current_room_id: str = "entrance_gate"

        # Player state (Vera Lin / Clara Lin #09)
        self.px: float = 0.0
        self.pz: float = 5.5
        self.py: float = 0.0
        self.p_yaw: float = 180.0          # Facing North (-Z is 180 deg in our sin/cos convention)
        self.hp: int = 100
        self.max_hp: int = 100
        self.poisoned: bool = False
        self.invuln_timer: float = 0.0
        self.walk_anim: float = 0.0
        self.step_timer: float = 0.0

        # Camera & Retro settings
        self.cam_yaw: float = 45.0         # Rotatable isometric camera angle (deg)
        self.cam_target_yaw: float = 45.0
        self.cam_pitch: float = 36.0
        self.cam_dist: float = 17.5
        self.ps1_filter: bool = True       # CRT scanlines + retro dithering overlay
        self.tank_controls: bool = False   # False = Modern 360°, True = Classic Tank Controls
        self.exploration_mode: bool = False  # True = Enemies don't attack (Crow Country Exploration Mode)

        # Combat & Laser-Sight Aiming
        self.is_aiming: bool = False
        self.aim_focus: float = 0.0        # 0.0 -> 1.0 steady aim charge for headshots
        self.fire_cooldown: float = 0.0
        self.muzzle_flash_timer: float = 0.0
        self.laser_hit_point: Tuple[float, float, float] = (0.0, 1.0, 0.0)
        self.laser_target_enemy: Optional[EnemySpawnDef] = None
        self.laser_target_hazard: Optional[HazardDef] = None

        # Weapons & Inventory
        self.weapons_owned: List[str] = ["pistol"]
        self.current_weapon: str = "pistol"
        self.ammo: Dict[str, int] = {
            "ammo_pistol": 24,
            "ammo_shotgun": 0,
            "ammo_flamer": 0,
            "ammo_magnum": 0,
        }
        self.medkits: int = 2
        self.grenades: int = 1
        self.key_items: set = set()
        self.key_item_names: Dict[str, str] = {}
        self.notes_read: List[str] = ["note_10_vera_truth"]
        self.secrets_found: set = set()
        self.total_secrets: int = 8
        self.solved_puzzles: set = set()
        self.has_laser_upgrade: bool = False

        # Crow Country Metrics for S-Rank
        self.oracle_tokens_left: int = 10
        self.oracle_uses: int = 0
        self.play_time_sec: float = 0.0
        self.total_damage_taken: int = 0
        self.heals_used: int = 0
        self.saves_count: int = 0
        self.enemies_defeated: int = 0

        # Active 3D effects
        self.projectiles: List[Projectile] = []
        self.particles: List[Particle3D] = []
        self.floating_texts: List[FloatingText] = []
        self.last_shot_line: Optional[Tuple[Tuple[float, float, float], Tuple[float, float, float], float]] = None

        # UI Modal States
        # "PLAYING", "MAP", "INVENTORY", "NOTE_VIEW", "KEYPAD", "ORGAN", "ORACLE", "DIALOGUE", "VICTORY", "GAMEOVER"
        self.ui_mode: str = "PLAYING"
        self.active_note_id: str = "note_10_vera_truth"
        self.keypad_Id: str = ""
        self.keypad_target: str = ""
        self.keypad_input: str = ""
        self.keypad_title: str = ""
        self.organ_sequence: List[str] = []
        self.oracle_card: Tuple[str, str] = ("", "")
        self.active_npc: Optional[NPCDef] = None
        self.dialogue_text: str = ""
        self.toast_message: str = "按 [WASD] 移動，[Q/E] 旋轉視角，按住 [滑鼠右鍵/空白鍵] 雷射瞄準，[E/F] 調查"
        self.toast_timer: float = 6.0
        self.ending_type: str = ""

        self._update_bgm_for_room()

    @property
    def current_room(self) -> RoomDef:
        return self.rooms[self.current_room_id]

    def show_toast(self, msg: str, duration: float = 4.0):
        self.toast_message = msg
        self.toast_timer = duration

    def _update_bgm_for_room(self):
        room = self.current_room
        if room.is_save_room:
            self.audio.set_bgm("bgm_saveroom")
        elif room.room_id == "pelagic_core" and any(e.alive for e in room.enemies):
            self.audio.set_bgm("bgm_boss")
        else:
            self.audio.set_bgm("bgm_explore")

    # ========================================================================
    # SMART MAP ROOM STATUS (Crow Country Color-Coded Map System)
    # ========================================================================
    def get_room_completion_state(self, room_id: str) -> Tuple[str, int]:
        """
        Returns (status, remaining_count):
        - "UNVISITED": Not yet visited
        - "SAVE_ROOM": Safe Haven (Teal)
        - "CLEARED": All items collected & room puzzles solved (Green/Cyan)
        - "REMAINING": Items or unsolved puzzles remain in room (Amber/Red)
        """
        room = self.rooms[room_id]
        if not room.visited:
            return ("UNVISITED", 0)
        remaining_items = sum(1 for p in room.pickups if not p.collected)
        unsolved = 0
        if room_id == "entrance_gate" and "door_keypad_1986" not in self.solved_puzzles:
            unsolved += 1
        elif room_id == "dolphinarium" and "organ_solved" not in self.solved_puzzles:
            unsolved += 1
        elif room_id == "marine_biolab" and "coral_melted" not in self.solved_puzzles:
            unsolved += 1
        elif room_id == "director_suite" and "safe_2142_opened" not in self.solved_puzzles:
            unsolved += 1
        elif room_id == "coolant_tunnel":
            if "flooded_drained" not in self.solved_puzzles:
                unsolved += 1
            if "astral_unlocked" not in self.solved_puzzles:
                unsolved += 1

        total_rem = remaining_items + unsolved
        if total_rem == 0:
            return ("CLEARED", 0)
        return ("REMAINING", total_rem)

    # ========================================================================
    # SPAWN PARTICLES & EFFECTS
    # ========================================================================
    def spawn_particles(self, x: float, y: float, z: float, color: Tuple[float, float, float],
                        count: int = 12, speed: float = 3.5, size: float = 0.14):
        for _ in range(count):
            ang = random.uniform(0, math.pi * 2)
            elev = random.uniform(-0.3, 1.0)
            spd = random.uniform(0.3, 1.0) * speed
            self.particles.append(
                Particle3D(
                    x=x,
                    y=y,
                    z=z,
                    vx=math.cos(ang) * spd,
                    vy=elev * spd + 1.2,
                    vz=math.sin(ang) * spd,
                    color=color,
                    size=size,
                    life=random.uniform(0.25, 0.65),
                    max_life=0.65,
                )
            )

    def add_floating_text(self, text: str, x: float, y: float, z: float, color=(255, 230, 90)):
        self.floating_texts.append(FloatingText(text=text, x=x, y=y, z=z, color=color, life=1.15))

    # ========================================================================
    # PLAYER MOVEMENT, ROTATABLE CAMERA & LASER AIMING
    # ========================================================================
    def update(self, dt: float, move_input: Tuple[float, float], aim_held: bool,
               mouse_world_dir: Optional[Tuple[float, float]]):
        if self.ui_mode != "PLAYING":
            return

        self.play_time_sec += dt
        if self.toast_timer > 0:
            self.toast_timer = max(0.0, self.toast_timer - dt)
        if self.invuln_timer > 0:
            self.invuln_timer = max(0.0, self.invuln_timer - dt)
        if self.fire_cooldown > 0:
            self.fire_cooldown = max(0.0, self.fire_cooldown - dt)
        if self.muzzle_flash_timer > 0:
            self.muzzle_flash_timer = max(0.0, self.muzzle_flash_timer - dt)

        # Smooth camera orbit interpolation
        diff_cam = (self.cam_target_yaw - self.cam_yaw + 180.0) % 360.0 - 180.0
        self.cam_yaw = (self.cam_yaw + diff_cam * min(1.0, dt * 10.0)) % 360.0

        # Aiming State (Crow Country rule: cannot run while aiming; laser sight activates)
        self.is_aiming = aim_held
        if self.is_aiming:
            focus_rate = 1.85 if self.has_laser_upgrade else 1.25
            self.aim_focus = min(1.0, self.aim_focus + dt * focus_rate)
            # Rotate player toward mouse world direction or A/D turn keys
            if mouse_world_dir is not None:
                dx, dz = mouse_world_dir
                if abs(dx) > 0.001 or abs(dz) > 0.001:
                    target_yaw = math.degrees(math.atan2(dx, dz))
                    diff = (target_yaw - self.p_yaw + 180.0) % 360.0 - 180.0
                    self.p_yaw = (self.p_yaw + diff * min(1.0, dt * 16.0)) % 360.0
            if abs(move_input[0]) > 0.05:
                self.p_yaw = (self.p_yaw - move_input[0] * 125.0 * dt) % 360.0
            self._compute_laser_raycast()
        else:
            self.aim_focus = max(0.0, self.aim_focus - dt * 3.0)
            self.laser_target_enemy = None
            self.laser_target_hazard = None
            self._update_movement(dt, move_input)

        # Auto-collect nearby ammo/health or highlight interactables
        self._check_hazard_damage(dt)
        self._update_projectiles(dt)
        self._update_enemies(dt)
        self._update_particles(dt)

    def _update_movement(self, dt: float, move_input: Tuple[float, float]):
        ix, iy = move_input  # ix: right(+1)/left(-1), iy: up(+1)/down(-1)
        speed = 5.6
        vx, vz = 0.0, 0.0

        if self.tank_controls:
            # Classic PS1 Tank Controls: A/D rotates character, W/S moves forward/back relative to facing
            if abs(ix) > 0.05:
                self.p_yaw = (self.p_yaw - ix * 145.0 * dt) % 360.0
            if abs(iy) > 0.05:
                rad = math.radians(self.p_yaw)
                mult = 1.0 if iy > 0 else -0.65
                vx = math.sin(rad) * speed * mult
                vz = math.cos(rad) * speed * mult
        else:
            # Modern 360° Camera-Relative Movement
            if abs(ix) > 0.05 or abs(iy) > 0.05:
                cam_rad = math.radians(self.cam_yaw)
                # Forward in camera view is (-sin(cam_rad), -cos(cam_rad))
                fwd_x = -math.sin(cam_rad)
                fwd_z = -math.cos(cam_rad)
                right_x = math.cos(cam_rad)
                right_z = -math.sin(cam_rad)

                dir_x = fwd_x * iy + right_x * ix
                dir_z = fwd_z * iy + right_z * ix
                mag = math.hypot(dir_x, dir_z)
                if mag > 0.001:
                    dir_x /= mag
                    dir_z /= mag
                    vx = dir_x * speed
                    vz = dir_z * speed
                    target_yaw = math.degrees(math.atan2(dir_x, dir_z))
                    diff = (target_yaw - self.p_yaw + 180.0) % 360.0 - 180.0
                    self.p_yaw = (self.p_yaw + diff * min(1.0, dt * 14.0)) % 360.0

        if abs(vx) > 0.01 or abs(vz) > 0.01:
            self.walk_anim += dt * 10.0
            self.step_timer += dt
            if self.step_timer >= 0.34:
                self.step_timer = 0.0
                self.audio.play("step")
            new_x = self.px + vx * dt
            new_z = self.pz + vz * dt
            # Slide collision against walls and props
            if not self._collides(new_x, self.pz, 0.55):
                self.px = new_x
            if not self._collides(self.px, new_z, 0.55):
                self.pz = new_z

    def _collides(self, x: float, z: float, radius: float) -> bool:
        room = self.current_room
        hw = room.width * 0.5 - 0.85
        hd = room.depth * 0.5 - 0.85
        if x < -hw or x > hw or z < -hd or z > hd:
            return True
        for prop in room.props:
            if prop.solid:
                if math.hypot(x - prop.x, z - prop.z) < (radius + prop.radius * 0.72):
                    return True
        return False

    def _compute_laser_raycast(self):
        room = self.current_room
        spec = WEAPON_SPECS[self.current_weapon]
        max_dist = spec["range"]
        rad = math.radians(self.p_yaw)
        dx = math.sin(rad)
        dz = math.cos(rad)

        best_t = max_dist
        hit_enemy = None
        hit_hazard = None

        # Wall intersection
        hw = room.width * 0.5 - 0.3
        hd = room.depth * 0.5 - 0.3
        for step in range(1, int(max_dist * 10)):
            t = step * 0.1
            rx = self.px + dx * t
            rz = self.pz + dz * t
            if rx <= -hw or rx >= hw or rz <= -hd or rz >= hd:
                best_t = t
                break
            # Check props
            hit_prop = False
            for prop in room.props:
                if prop.solid and math.hypot(rx - prop.x, rz - prop.z) < prop.radius * 0.65:
                    best_t = t
                    hit_prop = True
                    break
            if hit_prop:
                break

        # Enemy intersection
        for enemy in room.enemies:
            if not enemy.alive:
                continue
            ex, ez = enemy.x - self.px, enemy.z - self.pz
            proj = ex * dx + ez * dz
            if 0.2 < proj < best_t:
                perp = abs(ex * dz - ez * dx)
                hit_rad = 1.15 if enemy.kind == "boss_swan" else 0.78
                if perp < hit_rad:
                    best_t = proj
                    hit_enemy = enemy
                    hit_hazard = None

        # Explosive barrel intersection
        for haz in room.hazards:
            if not haz.active or haz.kind != "explosive_barrel":
                continue
            hx, hz = haz.x - self.px, haz.z - self.pz
            proj = hx * dx + hz * dz
            if 0.2 < proj < best_t:
                perp = abs(hx * dz - hz * dx)
                if perp < 0.75:
                    best_t = proj
                    hit_hazard = haz
                    hit_enemy = None

        self.laser_hit_point = (self.px + dx * best_t, 1.05, self.pz + dz * best_t)
        self.laser_target_enemy = hit_enemy
        self.laser_target_hazard = hit_hazard

    # ========================================================================
    # WEAPON FIRING, GRENADES & ENVIRONMENTAL EXPLOSIONS
    # ========================================================================
    def fire_current_weapon(self):
        if self.ui_mode != "PLAYING" or not self.is_aiming or self.fire_cooldown > 0:
            return
        spec = WEAPON_SPECS[self.current_weapon]
        ammo_key = spec["ammo_key"]
        if self.ammo.get(ammo_key, 0) <= 0:
            self.audio.play("locked")
            self.show_toast(f"【彈藥耗盡】{spec['name']} 沒有子彈了！可切換其他武器或引誘怪物踩陷阱。")
            self.fire_cooldown = 0.25
            return

        self.ammo[ammo_key] -= 1
        self.fire_cooldown = spec["cooldown"]
        self.muzzle_flash_timer = 0.09
        self.audio.play(spec["sound"])

        rad = math.radians(self.p_yaw)
        dx = math.sin(rad)
        dz = math.cos(rad)
        muzzle_pos = (self.px + dx * 0.65, 1.12, self.pz + dz * 0.65)
        self.spawn_particles(muzzle_pos[0], muzzle_pos[1], muzzle_pos[2], spec["laser_color"], count=6, speed=2.5)

        # Flamethrower spawns continuous plasma flame projectiles
        if self.current_weapon == "flamer":
            spread = random.uniform(-0.12, 0.12)
            ang = rad + spread
            self.projectiles.append(
                Projectile(
                    x=muzzle_pos[0],
                    y=1.0,
                    z=muzzle_pos[2],
                    vx=math.sin(ang) * 11.0,
                    vy=0.0,
                    vz=math.cos(ang) * 11.0,
                    kind="flame",
                    damage=spec["damage"],
                    from_player=True,
                    life=0.55,
                )
            )
            return

        # Hitscan pellets (Pistol, Shotgun, Magnum)
        is_focused_crit = self.aim_focus >= 0.82
        self._compute_laser_raycast()
        self.last_shot_line = (muzzle_pos, self.laser_hit_point, 0.12)

        # Did we hit an explosive barrel?
        if self.laser_target_hazard is not None and self.laser_target_hazard.active:
            self._detonate_barrel(self.laser_target_hazard)
            self.aim_focus = max(0.0, self.aim_focus - 0.5)
            return

        # Calculate damage across pellets
        room = self.current_room
        hit_any = False
        for _ in range(spec["pellets"]):
            ang_offset = math.radians(random.uniform(-spec["spread_deg"], spec["spread_deg"]))
            p_rad = rad + ang_offset
            pdx, pdz = math.sin(p_rad), math.cos(p_rad)

            best_enemy = None
            best_dist = spec["range"]
            for enemy in room.enemies:
                if not enemy.alive:
                    continue
                ex, ez = enemy.x - self.px, enemy.z - self.pz
                proj = ex * pdx + ez * pdz
                if 0.2 < proj < best_dist:
                    perp = abs(ex * pdz - ez * pdx)
                    hit_rad = 1.25 if enemy.kind == "boss_swan" else 0.88
                    if perp < hit_rad:
                        best_dist = proj
                        best_enemy = enemy

            if best_enemy is not None:
                hit_any = True
                dmg = spec["damage"]
                if is_focused_crit:
                    dmg = int(dmg * spec["crit_mult"])
                self._damage_enemy(best_enemy, dmg, is_crit=is_focused_crit)

        if not hit_any:
            hx, hy, hz = self.laser_hit_point
            self.spawn_particles(hx, hy, hz, (0.9, 0.85, 0.5), count=5, speed=2.2)

        # Recoil resets focus slightly
        self.aim_focus = max(0.0, self.aim_focus - 0.55)

    def throw_grenade(self):
        if self.ui_mode != "PLAYING" or self.grenades <= 0:
            if self.grenades <= 0:
                self.show_toast("沒有高爆手榴彈了！")
            return
        self.grenades -= 1
        self.audio.play("beep")
        rad = math.radians(self.p_yaw)
        self.projectiles.append(
            Projectile(
                x=self.px + math.sin(rad) * 0.7,
                y=1.2,
                z=self.pz + math.cos(rad) * 0.7,
                vx=math.sin(rad) * 8.5,
                vy=3.8,
                vz=math.cos(rad) * 8.5,
                kind="grenade",
                damage=95,
                from_player=True,
                life=1.1,
            )
        )
        self.show_toast("投擲高爆破片手榴彈！")

    def _detonate_barrel(self, barrel: HazardDef):
        if not barrel.active:
            return
        barrel.active = False
        self._trigger_explosion(barrel.x, barrel.z, radius=4.8, damage=95)

    def _trigger_explosion(self, x: float, z: float, radius: float, damage: int):
        self.audio.play("explosion")
        self.spawn_particles(x, 1.0, z, (1.0, 0.55, 0.1), count=36, speed=6.5, size=0.26)
        self.spawn_particles(x, 1.2, z, (1.0, 0.9, 0.3), count=20, speed=4.5, size=0.22)
        self.add_floating_text("BOOM!", x, 2.2, z, (255, 120, 40))

        room = self.current_room
        for enemy in room.enemies:
            if enemy.alive:
                d = math.hypot(enemy.x - x, enemy.z - z)
                if d <= radius:
                    self._damage_enemy(enemy, damage, is_crit=True)

        # Chain-detonate other nearby barrels
        for haz in room.hazards:
            if haz.active and haz.kind == "explosive_barrel":
                if math.hypot(haz.x - x, haz.z - z) <= radius * 0.85:
                    self._detonate_barrel(haz)

    def _damage_enemy(self, enemy: EnemySpawnDef, dmg: int, is_crit: bool = False):
        enemy.hp -= dmg
        self.audio.play("monster_hit")
        self.spawn_particles(enemy.x, 1.1, enemy.z, (0.2, 0.95, 0.75), count=10, speed=3.2)
        label = f"CRIT -{dmg}!" if is_crit else f"-{dmg}"
        col = (255, 75, 95) if is_crit else (255, 230, 110)
        self.add_floating_text(label, enemy.x, 2.1, enemy.z, col)

        # Pushback stagger
        dx = enemy.x - self.px
        dz = enemy.z - self.pz
        dist = max(0.1, math.hypot(dx, dz))
        push = 0.42 if enemy.kind != "boss_swan" else 0.12
        nx = enemy.x + (dx / dist) * push
        nz = enemy.z + (dz / dist) * push
        if not self._collides(nx, nz, 0.6):
            enemy.x, enemy.z = nx, nz

        if enemy.hp <= 0:
            enemy.alive = False
            self.enemies_defeated += 1
            self.spawn_particles(enemy.x, 1.0, enemy.z, (0.95, 0.2, 0.45), count=26, speed=4.8, size=0.22)
            self.add_floating_text("PURIFIED", enemy.x, 2.4, enemy.z, (110, 255, 200))
            if enemy.kind == "boss_swan":
                self.show_toast("【最終首領擊破！】維克多·斯旺的時空融合體崩解了！快去左上角實驗台領取【逆熵穩定血清】！", 8.0)
                self._update_bgm_for_room()

    # ========================================================================
    # ENEMY AI & PROJECTILES
    # ========================================================================
    def _update_projectiles(self, dt: float):
        if self.last_shot_line is not None:
            p0, p1, timer = self.last_shot_line
            if timer - dt <= 0:
                self.last_shot_line = None
            else:
                self.last_shot_line = (p0, p1, timer - dt)

        room = self.current_room
        kept: List[Projectile] = []
        for proj in self.projectiles:
            proj.life -= dt
            if proj.life <= 0:
                if proj.kind == "grenade":
                    self._trigger_explosion(proj.x, proj.z, radius=4.5, damage=proj.damage)
                continue

            proj.x += proj.vx * dt
            proj.y += proj.vy * dt
            proj.z += proj.vz * dt
            if proj.kind == "grenade":
                proj.vy -= 9.8 * dt
                if proj.y < 0.25:
                    proj.y = 0.25
                    proj.vy = -proj.vy * 0.45
                    proj.vx *= 0.7
                    proj.vz *= 0.7

            if proj.kind == "flame":
                self.spawn_particles(proj.x, proj.y, proj.z, (0.2, 0.85, 1.0), count=2, speed=1.2, size=0.18)
                hit = False
                for enemy in room.enemies:
                    if enemy.alive and math.hypot(enemy.x - proj.x, enemy.z - proj.z) < 1.1:
                        self._damage_enemy(enemy, proj.damage, is_crit=False)
                        hit = True
                        break
                for haz in room.hazards:
                    if haz.active and haz.kind == "explosive_barrel":
                        if math.hypot(haz.x - proj.x, haz.z - proj.z) < 1.1:
                            self._detonate_barrel(haz)
                            hit = True
                            break
                if hit:
                    continue

            elif proj.kind == "acid_orb" and not proj.from_player:
                self.spawn_particles(proj.x, proj.y, proj.z, (0.4, 1.0, 0.2), count=1, speed=0.8, size=0.12)
                if math.hypot(self.px - proj.x, self.pz - proj.z) < 0.75:
                    self.damage_player(proj.damage, poison_chance=0.35)
                    continue

            kept.append(proj)
        self.projectiles = kept

    def _update_enemies(self, dt: float):
        if self.exploration_mode:
            # In Crow Country's Exploration Mode, monsters do not attack the player
            return

        room = self.current_room
        for enemy in room.enemies:
            if not enemy.alive:
                continue

            dx = self.px - enemy.x
            dz = self.pz - enemy.z
            dist = math.hypot(dx, dz)

            # Check if enemy steps into an active electric puddle!
            for haz in room.hazards:
                if haz.active and haz.kind == "electric_puddle":
                    if math.hypot(enemy.x - haz.x, enemy.z - haz.z) < haz.radius:
                        if random.random() < dt * 2.5:
                            self._damage_enemy(enemy, 10, is_crit=False)

            if not enemy.alive:
                continue

            # Boss Phase 2 transition
            if enemy.kind == "boss_swan" and enemy.hp < enemy.max_hp * 0.5 and enemy.phase == 1:
                enemy.phase = 2
                enemy.speed = 3.1
                self.show_toast("【警告】維克多·斯旺進入第二階段『2142時間暴走』！移動速度提升並釋放深海酸液彈！", 5.0)
                self.spawn_particles(enemy.x, 1.5, enemy.z, (1.0, 0.2, 0.9), count=35, speed=5.5, size=0.25)

            # Ranged attack for acid_spitter and boss_swan
            if enemy.kind in ("acid_spitter", "boss_swan") and 3.2 < dist < 13.5:
                fire_prob = 0.65 if enemy.kind == "boss_swan" else 0.38
                if random.random() < dt * fire_prob:
                    ux, uz = dx / dist, dz / dist
                    self.projectiles.append(
                        Projectile(
                            x=enemy.x + ux * 0.8,
                            y=1.1,
                            z=enemy.z + uz * 0.8,
                            vx=ux * 6.8,
                            vy=0.0,
                            vz=uz * 6.8,
                            kind="acid_orb",
                            damage=14 if enemy.kind == "acid_spitter" else 18,
                            from_player=False,
                            life=2.2,
                        )
                    )

            # Move toward player
            if dist > 0.95:
                ux, uz = dx / dist, dz / dist
                nx = enemy.x + ux * enemy.speed * dt
                nz = enemy.z + uz * enemy.speed * dt
                if not self._collides(nx, enemy.z, 0.55):
                    enemy.x = nx
                if not self._collides(enemy.x, nz, 0.55):
                    enemy.z = nz
            else:
                # Melee bite/claw attack
                self.damage_player(enemy.damage, poison_chance=0.2 if enemy.kind == "acid_spitter" else 0.0)

    def _check_hazard_damage(self, dt: float):
        room = self.current_room
        for haz in room.hazards:
            if haz.active and haz.kind == "electric_puddle":
                if math.hypot(self.px - haz.x, self.pz - haz.z) < haz.radius:
                    self.damage_player(12)

    def damage_player(self, amount: int, poison_chance: float = 0.0):
        if self.invuln_timer > 0 or self.exploration_mode:
            return
        self.hp = max(0, self.hp - amount)
        self.total_damage_taken += amount
        self.invuln_timer = 1.15
        self.audio.play("player_hurt")
        self.spawn_particles(self.px, 1.0, self.pz, (1.0, 0.15, 0.2), count=14, speed=3.5)
        self.add_floating_text(f"-{amount} HP", self.px, 2.1, self.pz, (255, 80, 80))
        if random.random() < poison_chance:
            self.poisoned = True
            self.show_toast("【警告】受到時間珊瑚毒素感染！請使用急救噴霧治療。")
        if self.hp <= 0:
            self.ui_mode = "GAMEOVER"

    def use_medkit(self):
        if self.medkits <= 0:
            self.show_toast("沒有急救噴霧罐了！")
            return
        if self.hp >= self.max_hp and not self.poisoned:
            self.show_toast("目前體力充沛，無需使用急救噴霧。")
            return
        self.medkits -= 1
        self.heals_used += 1
        self.hp = min(self.max_hp, self.hp + 65)
        self.poisoned = False
        self.audio.play("heal")
        self.spawn_particles(self.px, 1.0, self.pz, (0.2, 1.0, 0.55), count=18, speed=3.0)
        self.add_floating_text("+65 HP", self.px, 2.2, self.pz, (100, 255, 160))
        self.show_toast("使用急救噴霧罐，體力恢復並清除珊瑚毒素！")

    def _update_particles(self, dt: float):
        kept_p = []
        for p in self.particles:
            p.life -= dt
            if p.life > 0:
                p.x += p.vx * dt
                p.y += p.vy * dt
                p.z += p.vz * dt
                p.vy -= 6.5 * dt
                if p.y < 0.05:
                    p.y = 0.05
                    p.vy = -p.vy * 0.3
                kept_p.append(p)
        self.particles = kept_p

        kept_t = []
        for ft in self.floating_texts:
            ft.life -= dt
            if ft.life > 0:
                ft.y += dt * 1.1
                kept_t.append(ft)
        self.floating_texts = kept_t

    # ========================================================================
    # CONTEXT-SENSITIVE INTERACTION ([E] / [F] Key)
    # ========================================================================
    def get_nearest_interactable_prompt(self) -> Optional[str]:
        room = self.current_room

        # 1. Pickups
        for p in room.pickups:
            if not p.collected and math.hypot(self.px - p.x, self.pz - p.z) < 1.85:
                return f"[E] 拾取：{p.name}"

        # 2. NPCs
        for npc in room.npcs:
            if math.hypot(self.px - npc.x, self.pz - npc.z) < 2.2:
                return f"[E] 交談：{npc.name}"

        # 3. Interactive Props
        for prop in room.props:
            if prop.interact_id and math.hypot(self.px - prop.x, self.pz - prop.z) < (prop.radius + 1.45):
                return f"[E] {prop.label}"

        # 4. Doors on North/South/East/West walls
        door_dir, door_def = self._get_nearby_door()
        if door_def is not None:
            target_name = self.rooms[door_def.target_room].name
            if door_def.unlocked or door_def.lock_id is None:
                return f"[E] 進入：{target_name}"
            else:
                return f"[E] 鎖定：{door_def.lock_name} (通往 {target_name})"

        return None

    def _get_nearby_door(self) -> Tuple[Optional[str], Optional[DoorDef]]:
        room = self.current_room
        hw = room.width * 0.5
        hd = room.depth * 0.5
        for d_name, door in room.doors.items():
            dx, dz = 0.0, 0.0
            if d_name == "north":
                dx, dz = door.pos_offset, -hd + 0.8
            elif d_name == "south":
                dx, dz = door.pos_offset, hd - 0.8
            elif d_name == "west":
                dx, dz = -hw + 0.8, door.pos_offset
            elif d_name == "east":
                dx, dz = hw - 0.8, door.pos_offset
            if math.hypot(self.px - dx, self.pz - dz) < 2.35:
                return d_name, door
        return None, None

    def trigger_interact(self):
        if self.ui_mode != "PLAYING":
            return
        room = self.current_room

        # 1. Pickups
        for p in room.pickups:
            if not p.collected and math.hypot(self.px - p.x, self.pz - p.z) < 1.85:
                self._collect_pickup(p)
                return

        # 2. NPCs
        for npc in room.npcs:
            if math.hypot(self.px - npc.x, self.pz - npc.z) < 2.2:
                self.active_npc = npc
                self.dialogue_text = npc.dialogues[npc.talk_index]
                npc.talk_index = (npc.talk_index + 1) % len(npc.dialogues)
                self.ui_mode = "DIALOGUE"
                self.audio.play("beep")
                return

        # 3. Interactive Props
        for prop in room.props:
            if prop.interact_id and math.hypot(self.px - prop.x, self.pz - prop.z) < (prop.radius + 1.45):
                self._interact_with_prop(prop)
                return

        # 4. Doors
        _, door_def = self._get_nearby_door()
        if door_def is not None:
            self._try_enter_door(door_def)

    def _collect_pickup(self, p: PickupDef):
        p.collected = True
        self.audio.play("pickup")
        self.spawn_particles(p.x, 0.6, p.z, (1.0, 0.9, 0.3), count=14, speed=2.8)

        if p.is_secret:
            self.secrets_found.add(p.uid)

        if p.kind in ("ammo_pistol", "ammo_shotgun", "ammo_flamer", "ammo_magnum"):
            self.ammo[p.kind] = self.ammo.get(p.kind, 0) + p.amount
            self.show_toast(f"獲得彈藥：{p.name}")
        elif p.kind == "medkit":
            self.medkits += p.amount
            self.show_toast(f"獲得：{p.name} (按 [H] 可立即治療)")
        elif p.kind == "grenade":
            self.grenades += p.amount
            self.show_toast(f"獲得：{p.name} (按 [G] 投擲手榴彈)")
        elif p.kind == "weapon":
            if p.item_id not in self.weapons_owned:
                self.weapons_owned.append(p.item_id)
            self.current_weapon = p.item_id
            self.show_toast(f"獲得新武器：{p.name}！可使用數字鍵 [1-4] 或滾輪切換。")
        elif p.kind == "key_item":
            self.key_items.add(p.item_id)
            self.key_item_names[p.item_id] = p.name
            self.show_toast(f"獲得關鍵道具：{p.name}！")
        elif p.kind == "upgrade":
            self.has_laser_upgrade = True
            self.show_toast(f"獲得秘密改裝：{p.name}！瞄準收束速度提升 50%！")
        elif p.kind == "secret":
            self.show_toast(f"發現隱藏秘密：{p.name}！（秘密收集進度：{len(self.secrets_found)}/{self.total_secrets}）")
        elif p.kind == "note":
            if p.note_id not in self.notes_read:
                self.notes_read.append(p.note_id)
            self.active_note_id = p.note_id
            self.ui_mode = "NOTE_VIEW"

    def _interact_with_prop(self, prop: PropDef):
        iid = prop.interact_id

        if iid == "use_oracle":
            if self.oracle_tokens_left <= 0:
                self.show_toast("星象神諭機的 10 枚代幣已全數用盡！")
                return
            self.oracle_tokens_left -= 1
            self.oracle_uses += 1
            self.audio.play("oracle")
            self.oracle_card = get_oracle_hint(self.key_items, self.solved_puzzles)
            self.ui_mode = "ORACLE"

        elif iid == "save_game":
            self.save_to_disk()

        elif iid == "heal_station":
            self.hp = self.max_hp
            self.poisoned = False
            self.audio.play("heal")
            self.spawn_particles(self.px, 1.0, self.pz, (0.2, 1.0, 0.7), count=20, speed=3.2)
            self.show_toast("【戰術補給醫療站】生命值已完全恢復，珊瑚結晶化暫時穩定！")

        elif iid == "puzzle_keypad_1986":
            if "door_keypad_1986" in self.solved_puzzles:
                self.show_toast("北側安檢旋轉閘門已經解鎖。")
                return
            self.keypad_Id = "door_keypad_1986"
            self.keypad_target = "1986"
            self.keypad_input = ""
            self.keypad_title = "北側安檢電子鎖 (提示：博覽館開幕年份)"
            self.ui_mode = "KEYPAD"
            self.audio.play("beep")

        elif iid == "puzzle_safe_2142":
            if "safe_2142_opened" in self.solved_puzzles:
                self.show_toast("館長室鈦金保險箱已經打開。")
                return
            self.keypad_Id = "safe_2142_opened"
            self.keypad_target = "2142"
            self.keypad_input = ""
            self.keypad_title = "館長室鈦金保險箱 (提示：未來難民逃離的毀滅年份)"
            self.ui_mode = "KEYPAD"
            self.audio.play("beep")

        elif iid == "door_to_dolphinarium":
            if "bronze_key" in self.key_items or "door_bronze" in self.solved_puzzles:
                if "door_bronze" not in self.solved_puzzles:
                    self.solved_puzzles.add("door_bronze")
                    self.audio.play("unlock")
                    self.show_toast("使用【青銅海豚徽章】解鎖了仿生海豚劇場！")
                self._change_room("dolphinarium", (0.0, 7.2))
            else:
                self.audio.play("locked")
                self.show_toast("西翼海豚劇場大門緊閉：需要嵌入【青銅海豚徽章】（可於西側員工安全室取得）。")

        elif iid == "puzzle_organ":
            if "organ_solved" in self.solved_puzzles:
                self.show_toast("諧波管風琴已經演奏過『深海搖籃曲 (C-E-G-B)』，機械海豚顎骨已開啟。")
                return
            self.organ_sequence = []
            self.ui_mode = "ORGAN"
            self.audio.play("beep")

        elif iid == "examine_giant_dolphin":
            if "organ_solved" in self.solved_puzzles:
                self.show_toast("機械海豚『波塞頓號』張開了巨顎，裡面的白銀星光徽章已經取出。")
            else:
                self.show_toast("巨型機械海豚嘴裡含著【白銀星光徽章】，需用左側的諧波管風琴彈奏正確旋律才能打開。")

        elif iid == "puzzle_melt_coral":
            if "coral_melted" in self.solved_puzzles:
                self.show_toast("鈣化時間珊瑚已經被強酸完全溶解。")
                return
            if "acid_vial" in self.key_items:
                self.solved_puzzles.add("coral_melted")
                self.audio.play("unlock")
                self.spawn_particles(prop.x, 1.2, prop.z, (0.3, 1.0, 0.4), count=30, speed=4.0)
                if "flamer" not in self.weapons_owned:
                    self.weapons_owned.append("flamer")
                self.current_weapon = "flamer"
                self.ammo["ammo_flamer"] += 60
                self.key_items.add("moon_medallion")
                self.key_item_names["moon_medallion"] = "【星象】深海新月浮雕"
                self.show_toast("使用【深海強酸試劑】溶解了鈣化珊瑚！獲得【極光熱熔噴射器】與【深海新月浮雕】！", 6.0)
            else:
                self.audio.play("locked")
                self.show_toast("展示櫃被堅硬的鈣化時間珊瑚封死了！需要實驗台上的【深海強酸試劑】。")

        elif iid == "puzzle_drain_flood":
            if "flooded_drained" in self.solved_puzzles:
                self.show_toast("冷卻水道的帶電廢水已經徹底排乾。")
                return
            if "hydraulic_crank" in self.key_items:
                self.solved_puzzles.add("flooded_drained")
                self.audio.play("unlock")
                for haz in self.current_room.hazards:
                    if haz.kind == "electric_puddle":
                        haz.active = False
                self.spawn_particles(0.0, 0.3, 0.5, (0.3, 0.85, 1.0), count=28, speed=3.8)
                self.show_toast("使用【液壓搖柄】轉動主排水閥！走廊中央的帶電廢水已完全排乾！", 5.0)
            else:
                self.audio.play("locked")
                self.show_toast("閥門沒有把手！需要【液壓搖柄】（位於仿生海豚劇場的貴賓後台）。")

        elif iid == "puzzle_astral_gate":
            if "astral_unlocked" in self.solved_puzzles:
                self.show_toast("三曜星盤祭壇已經啟動，北側通往零號時間晶簇核心的大門已敞開。")
                return
            if "gold_key" in self.key_items and "moon_medallion" in self.key_items:
                self.solved_puzzles.add("astral_unlocked")
                self.current_room.doors["north"].unlocked = True
                self.audio.play("oracle")
                self.spawn_particles(prop.x, 1.5, prop.z, (0.95, 0.8, 0.2), count=32, speed=4.5)
                self.show_toast("將【黃金日冕徽章】與【深海新月浮雕】嵌入三曜星盤——北側『零號時間晶簇核心』大門開啟！", 6.0)
            else:
                self.audio.play("locked")
                self.show_toast("三曜星盤祭壇缺少印記：需要同時持有【黃金日冕徽章】與【深海新月浮雕】。")

        elif iid == "claim_serum_ending":
            boss_alive = any(e.alive and e.kind == "boss_swan" for e in self.current_room.enemies)
            if boss_alive:
                self.audio.play("locked")
                self.show_toast("維克多·斯旺的時空融合體正擋在實驗台前！必須先擊敗他才能奪取【逆熵穩定血清】！")
            else:
                self.audio.play("oracle")
                if len(self.secrets_found) >= 5:
                    self.ending_type = "TRUE_ENDING"
                else:
                    self.ending_type = "GOOD_ENDING"
                self.ui_mode = "VICTORY"

        elif iid in ("examine_fountain", "secret_trash_gate", "secret_arcade_plaza"):
            self.show_toast(f"仔細調查了 {prop.label}。留意周圍地面閃爍的微光物品！")

    def _try_enter_door(self, door: DoorDef):
        if door.unlocked or door.lock_id is None:
            self.audio.play("step")
            self._change_room(door.target_room, door.target_spawn)
            return

        # Check if player holds the required key
        lid = door.lock_id
        if lid == "keypad_1986":
            self.keypad_Id = "door_keypad_1986"
            self.keypad_target = "1986"
            self.keypad_input = ""
            self.keypad_title = "北側安檢電子鎖 (提示：博覽館開幕年份)"
            self.ui_mode = "KEYPAD"
            self.audio.play("beep")
        elif lid in ("silver_key", "gold_key") and lid in self.key_items:
            door.unlocked = True
            self.solved_puzzles.add(f"door_{lid}")
            self.audio.play("unlock")
            self.show_toast(f"使用 {self.key_item_names.get(lid, lid)} 解鎖了大門！")
            self._change_room(door.target_room, door.target_spawn)
        elif lid == "astral_seal":
            self.audio.play("locked")
            self.show_toast("大門受三曜封印保護！請先調查門旁的【深海三曜星盤祭壇】。")
        else:
            self.audio.play("locked")
            self.show_toast(f"門鎖著：需要【{door.lock_name}】。")

    def _change_room(self, target_room_id: str, spawn_xz: Tuple[float, float]):
        self.current_room_id = target_room_id
        self.current_room.visited = True
        self.px, self.pz = spawn_xz
        self.projectiles.clear()
        self.particles.clear()
        self._update_bgm_for_room()
        self.show_toast(f"進入區域：【{self.current_room.name}】— {self.current_room.subtitle}", 4.5)

    # ========================================================================
    # PUZZLE CALLBACKS (KEYPAD & HARMONIC ORGAN)
    # ========================================================================
    def submit_keypad_digit(self, digit: str):
        self.audio.play("beep")
        if digit == "CLR":
            self.keypad_input = ""
            return
        if len(self.keypad_input) < 4:
            self.keypad_input += digit
        if len(self.keypad_input) == 4:
            if self.keypad_input == self.keypad_target:
                self.audio.play("unlock")
                self.solved_puzzles.add(self.keypad_Id)
                if self.keypad_Id == "door_keypad_1986":
                    self.rooms["entrance_gate"].doors["north"].unlocked = True
                    self.show_toast("【密碼正確：1986】北側通往新星中央廣場的旋轉閘門已開啟！", 5.0)
                elif self.keypad_Id == "safe_2142_opened":
                    if "magnum" not in self.weapons_owned:
                        self.weapons_owned.append("magnum")
                    self.current_weapon = "magnum"
                    self.ammo["ammo_magnum"] += 8
                    self.show_toast("【保險箱解鎖：2142】獲得終極武器【脈衝麥格農 .44】與 8 發子彈！", 6.0)
                self.ui_mode = "PLAYING"
            else:
                self.audio.play("locked")
                self.keypad_input = ""
                self.show_toast("密碼錯誤！請查閱收集到的文獻筆記（按 [I] 開啟檔案欄）。")

    def press_organ_note(self, note: str):
        self.audio.play(f"note_{note}")
        self.organ_sequence.append(note)
        if len(self.organ_sequence) > 4:
            self.organ_sequence = self.organ_sequence[-4:]
        if self.organ_sequence == ["C", "E", "G", "B"]:
            self.solved_puzzles.add("organ_solved")
            self.key_items.add("silver_key")
            self.key_item_names["silver_key"] = "【鑰匙】白銀星光徽章"
            self.audio.play("unlock")
            self.ui_mode = "PLAYING"
            self.show_toast("【深海搖籃曲共鳴成功！】機械海豚張開巨顎，獲得【白銀星光徽章】（可開啟廣場東翼大門）！", 6.5)

    # ========================================================================
    # SAVE / LOAD SYSTEM & S-RANK EVALUATION
    # ========================================================================
    def save_to_disk(self):
        self.saves_count += 1
        data = {
            "current_room_id": self.current_room_id,
            "px": self.px,
            "pz": self.pz,
            "hp": self.hp,
            "weapons_owned": self.weapons_owned,
            "current_weapon": self.current_weapon,
            "ammo": self.ammo,
            "medkits": self.medkits,
            "grenades": self.grenades,
            "key_items": list(self.key_items),
            "key_item_names": self.key_item_names,
            "notes_read": self.notes_read,
            "secrets_found": list(self.secrets_found),
            "solved_puzzles": list(self.solved_puzzles),
            "has_laser_upgrade": self.has_laser_upgrade,
            "oracle_tokens_left": self.oracle_tokens_left,
            "oracle_uses": self.oracle_uses,
            "play_time_sec": self.play_time_sec,
            "total_damage_taken": self.total_damage_taken,
            "heals_used": self.heals_used,
            "saves_count": self.saves_count,
            "enemies_defeated": self.enemies_defeated,
            "visited_rooms": [rid for rid, r in self.rooms.items() if r.visited],
            "collected_pickups": [
                p.uid for r in self.rooms.values() for p in r.pickups if p.collected
            ],
            "dead_enemies": [
                e.uid for r in self.rooms.values() for e in r.enemies if not e.alive
            ],
        }
        try:
            with open(self.save_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            self.audio.play("oracle")
            self.show_toast(f"【存檔成功】進度已寫入 CRT 磁帶終端機（累計存檔：{self.saves_count} 次）。", 4.5)
        except Exception as exc:
            self.show_toast(f"存檔失敗：{exc}")

    def load_from_disk(self) -> bool:
        if not os.path.exists(self.save_path):
            self.show_toast("找不到存檔記錄！")
            return False
        try:
            with open(self.save_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.reset_new_game()
            self.current_room_id = data["current_room_id"]
            self.px = data["px"]
            self.pz = data["pz"]
            self.hp = data["hp"]
            self.weapons_owned = data["weapons_owned"]
            self.current_weapon = data["current_weapon"]
            self.ammo = data["ammo"]
            self.medkits = data["medkits"]
            self.grenades = data["grenades"]
            self.key_items = set(data["key_items"])
            self.key_item_names = data["key_item_names"]
            self.notes_read = data["notes_read"]
            self.secrets_found = set(data["secrets_found"])
            self.solved_puzzles = set(data["solved_puzzles"])
            self.has_laser_upgrade = data.get("has_laser_upgrade", False)
            self.oracle_tokens_left = data["oracle_tokens_left"]
            self.oracle_uses = data["oracle_uses"]
            self.play_time_sec = data["play_time_sec"]
            self.total_damage_taken = data["total_damage_taken"]
            self.heals_used = data["heals_used"]
            self.saves_count = data["saves_count"]
            self.enemies_defeated = data["enemies_defeated"]

            visited = set(data.get("visited_rooms", []))
            collected = set(data.get("collected_pickups", []))
            dead = set(data.get("dead_enemies", []))
            for rid, r in self.rooms.items():
                r.visited = rid in visited
                for p in r.pickups:
                    p.collected = p.uid in collected
                for e in r.enemies:
                    e.alive = e.uid not in dead

            if "door_keypad_1986" in self.solved_puzzles:
                self.rooms["entrance_gate"].doors["north"].unlocked = True
            if "door_silver_key" in self.solved_puzzles:
                self.rooms["nova_plaza"].doors["east"].unlocked = True
            if "door_gold_key" in self.solved_puzzles:
                self.rooms["nova_plaza"].doors["north"].unlocked = True
            if "astral_unlocked" in self.solved_puzzles:
                self.rooms["coolant_tunnel"].doors["north"].unlocked = True
            if "flooded_drained" in self.solved_puzzles:
                for haz in self.rooms["coolant_tunnel"].hazards:
                    if haz.kind == "electric_puddle":
                        haz.active = False

            self._update_bgm_for_room()
            self.show_toast("【讀取存檔成功】歡迎回到 1994 年太陽神穹頂。")
            return True
        except Exception as exc:
            self.show_toast(f"讀取存檔失敗：{exc}")
            return False

    def calculate_final_rank(self) -> Tuple[str, int, List[str]]:
        """Calculates Crow Country style Final Performance Grade (S+, S, A, B, C)."""
        score = 100
        reasons = []

        # Time penalty (under 15 mins = 0 penalty)
        mins = self.play_time_sec / 60.0
        if mins > 20:
            score -= 10
        reasons.append(f"通關耗時：{int(mins):02d}分 {int(self.play_time_sec % 60):02d}秒")

        # Heals used penalty
        heal_pen = max(0, (self.heals_used - 2) * 6)
        score -= heal_pen
        reasons.append(f"醫療噴霧使用：{self.heals_used} 次 (扣分 -{heal_pen})")

        # Fortune Teller hints used penalty
        oracle_pen = self.oracle_uses * 5
        score -= oracle_pen
        reasons.append(f"星象神諭機提示：{self.oracle_uses}/10 次 (扣分 -{oracle_pen})")

        # Secrets bonus
        sec_bonus = len(self.secrets_found) * 4
        score += sec_bonus
        reasons.append(f"隱藏秘密收集：{len(self.secrets_found)}/{self.total_secrets} (加分 +{sec_bonus})")

        # Damage taken
        dmg_pen = int(self.total_damage_taken // 50) * 3
        score -= dmg_pen
        reasons.append(f"累計承受傷害：{self.total_damage_taken} 點 (扣分 -{dmg_pen})")

        if score >= 105:
            rank = "S+"
        elif score >= 90:
            rank = "S"
        elif score >= 75:
            rank = "A"
        elif score >= 60:
            rank = "B"
        else:
            rank = "C"
        return rank, score, reasons
