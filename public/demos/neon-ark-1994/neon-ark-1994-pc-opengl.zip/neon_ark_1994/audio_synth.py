# -*- coding: utf-8 -*-
"""
NEON ARK: 1994 - Procedural PS1 Survival Horror Audio & Music Synthesizer
Generates 32-bit era low-fi sound effects, eerie dark ambient drones, and
Resident Evil / Crow Country style tranquil Save Room synth pads in pure NumPy.
"""

import math
import numpy as np
import pygame


class RetroAudioEngine:
    def __init__(self):
        self.enabled = False
        self.sounds = {}
        self.current_bgm = None
        self.bgm_channel = None
        self.sample_rate = 22050

        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=self.sample_rate, size=-16, channels=2, buffer=1024)
            pygame.mixer.set_num_channels(16)
            self.bgm_channel = pygame.mixer.Channel(0)
            self.enabled = True
            self._build_all_sounds()
        except Exception as exc:
            print(f"[AudioEngine] Running in silent mode ({exc})")
            self.enabled = False

    def _to_sound(self, mono_wave: np.ndarray, volume: float = 0.6):
        if not self.enabled:
            return None
        clipped = np.clip(mono_wave * volume, -1.0, 1.0)
        pcm16 = (clipped * 32767).astype(np.int16)
        stereo = np.column_stack((pcm16, pcm16))
        return pygame.sndarray.make_sound(np.ascontiguousarray(stereo))

    def _build_all_sounds(self):
        sr = self.sample_rate

        # 1. Pistol shot (punchy 90s low-fi gunshot with reverb tail)
        dur = 0.32
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        noise = np.random.uniform(-1.0, 1.0, len(t))
        thump = np.sin(2 * np.pi * (190 * np.exp(-t * 28)) * t)
        env = np.exp(-t * 16.0)
        wave = (0.65 * noise + 0.75 * thump) * env
        # Low-pass filter emulation
        wave = np.convolve(wave, np.ones(4) / 4, mode="same")
        self.sounds["pistol"] = self._to_sound(wave, 0.55)

        # 2. Shotgun blast (heavy boom + wide metallic scatter)
        dur = 0.55
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        noise = np.random.uniform(-1.0, 1.0, len(t))
        sub = np.sin(2 * np.pi * (110 * np.exp(-t * 14)) * t)
        env = np.exp(-t * 8.5)
        wave = (0.8 * noise + 0.9 * sub) * env
        wave = np.convolve(wave, np.ones(7) / 7, mode="same")
        self.sounds["shotgun"] = self._to_sound(wave, 0.70)

        # 3. Magnum .44 (high-energy thunderous crack + sci-fi ring)
        dur = 0.62
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        noise = np.random.uniform(-1.0, 1.0, len(t))
        beam = np.sin(2 * np.pi * (420 * np.exp(-t * 9) + 95) * t)
        env = np.exp(-t * 7.0)
        wave = (0.65 * noise + 0.85 * beam) * env
        self.sounds["magnum"] = self._to_sound(wave, 0.75)

        # 4. Flamethrower burst (hissing plasma roar)
        dur = 0.25
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        noise = np.random.uniform(-1.0, 1.0, len(t))
        mod = 0.6 + 0.4 * np.sin(2 * np.pi * 28 * t)
        env = np.sin(np.pi * t / dur)
        wave = np.convolve(noise * mod * env, np.ones(9) / 9, mode="same")
        self.sounds["flamer"] = self._to_sound(wave, 0.42)

        # 5. Explosion (environmental trap / grenade)
        dur = 0.95
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        noise = np.random.uniform(-1.0, 1.0, len(t))
        rumble = np.sin(2 * np.pi * (65 * np.exp(-t * 3.5)) * t)
        env = np.exp(-t * 3.8)
        wave = np.convolve((0.85 * noise + 0.9 * rumble) * env, np.ones(12) / 12, mode="same")
        self.sounds["explosion"] = self._to_sound(wave, 0.80)

        # 6. UI / Keypad Beep
        dur = 0.08
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        wave = np.sin(2 * np.pi * 880 * t) * np.exp(-t * 25)
        self.sounds["beep"] = self._to_sound(wave, 0.40)

        # 7. Item Pickup (classic 90s survival horror chime: two warm fifths)
        dur = 0.38
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        f1 = np.where(t < 0.14, 523.25, 783.99)
        wave = (0.65 * np.sin(2 * np.pi * f1 * t) + 0.35 * np.sin(4 * np.pi * f1 * t)) * np.exp(-t * 5.5)
        self.sounds["pickup"] = self._to_sound(wave, 0.50)

        # 8. Door Unlock / Key Used (metallic clunk + resonant chime)
        dur = 0.48
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        clunk = np.sin(2 * np.pi * 160 * t) * np.exp(-t * 32)
        chime = np.sin(2 * np.pi * 659.25 * t) * np.exp(-np.maximum(0, t - 0.12) * 8) * (t >= 0.12)
        self.sounds["unlock"] = self._to_sound(clunk + chime, 0.55)

        # 9. Locked Door rattle
        dur = 0.22
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        rattle = np.sin(2 * np.pi * 115 * t) * np.sign(np.sin(2 * np.pi * 22 * t)) * np.exp(-t * 12)
        self.sounds["locked"] = self._to_sound(rattle, 0.45)

        # 10. Fortune Teller ("ASTRO-ORACLE") mystical jingle
        dur = 0.85
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        notes = [440.0, 554.37, 659.25, 880.0]
        wave = np.zeros_like(t)
        for idx, freq in enumerate(notes):
            start = idx * 0.18
            mask = t >= start
            lt = t[mask] - start
            wave[mask] += 0.45 * np.sin(2 * np.pi * freq * lt) * np.exp(-lt * 6.5)
        self.sounds["oracle"] = self._to_sound(wave, 0.52)

        # 11. Monster Groan / Echo Distortion
        dur = 0.65
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        carrier = np.sin(2 * np.pi * (135 + 25 * np.sin(2 * np.pi * 6 * t)) * t)
        growl = np.sign(carrier) * 0.5 + carrier * 0.5
        noise = np.random.uniform(-0.4, 0.4, len(t))
        env = np.sin(np.pi * t / dur)
        wave = np.convolve((growl + noise) * env, np.ones(14) / 14, mode="same")
        self.sounds["monster_hit"] = self._to_sound(wave, 0.50)

        # 12. Player Hurt
        dur = 0.35
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        wave = (np.sin(2 * np.pi * (290 - 180 * t) * t) + np.random.uniform(-0.5, 0.5, len(t))) * np.exp(-t * 9)
        self.sounds["player_hurt"] = self._to_sound(wave, 0.60)

        # 13. Heal / Serum used
        dur = 0.55
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        freq = 330 + 440 * (t / dur)
        wave = np.sin(2 * np.pi * freq * t) * np.sin(np.pi * t / dur)
        self.sounds["heal"] = self._to_sound(wave, 0.45)

        # 14. Footstep (subtle low click)
        dur = 0.06
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        wave = (np.random.uniform(-0.6, 0.6, len(t)) + np.sin(2 * np.pi * 110 * t)) * np.exp(-t * 45)
        self.sounds["step"] = self._to_sound(wave, 0.20)

        # 15. Organ Synth Note (for Dolphinarium Musical Puzzle)
        for name, freq in [("note_C", 261.63), ("note_E", 329.63), ("note_G", 392.00), ("note_B", 493.88)]:
            dur = 0.45
            t = np.linspace(0, dur, int(sr * dur), endpoint=False)
            organ = (0.6 * np.sin(2 * np.pi * freq * t)
                     + 0.3 * np.sin(4 * np.pi * freq * t)
                     + 0.15 * np.sin(6 * np.pi * freq * t)) * np.exp(-t * 3.5)
            self.sounds[name] = self._to_sound(organ, 0.52)

        # 16. Ambient Loops: Dark Expo Drone vs. Save Room Warm Tape Pad
        self.sounds["bgm_explore"] = self._build_explore_drone()
        self.sounds["bgm_saveroom"] = self._build_saveroom_pad()
        self.sounds["bgm_boss"] = self._build_boss_pulse()

    def _build_explore_drone(self):
        sr = self.sample_rate
        dur = 8.0
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        # Seamless loopable frequencies (integer multiples of 1/dur)
        drone = (
            0.35 * np.sin(2 * np.pi * 55.0 * t)
            + 0.25 * np.sin(2 * np.pi * 82.5 * t + np.sin(2 * np.pi * 0.25 * t))
            + 0.15 * np.sin(2 * np.pi * 110.0 * t)
            + 0.08 * np.sin(2 * np.pi * 164.0 * t) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.5 * t))
        )
        return self._to_sound(drone, 0.24)

    def _build_saveroom_pad(self):
        sr = self.sample_rate
        dur = 8.0
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        # Nostalgic Resident Evil / Crow Country warm minor-9th synth pad (A minor 9: A2, E3, G3, B3, C4)
        freqs = [110.0, 165.0, 196.0, 247.0, 261.5]
        pad = np.zeros_like(t)
        for idx, f in enumerate(freqs):
            lfo = 0.7 + 0.3 * np.sin(2 * np.pi * 0.25 * t + idx)
            pad += (0.22 * np.sin(2 * np.pi * f * t) + 0.07 * np.sin(4 * np.pi * f * t)) * lfo
        # Gentle Rhodes-like bell arpeggio every 2 seconds
        arp_notes = [523.0, 494.0, 392.0, 330.0]
        for i, nf in enumerate(arp_notes):
            start = i * 2.0
            mask = (t >= start) & (t < start + 1.8)
            lt = t[mask] - start
            pad[mask] += 0.22 * np.sin(2 * np.pi * nf * lt) * np.exp(-lt * 2.4)
        return self._to_sound(pad, 0.26)

    def _build_boss_pulse(self):
        sr = self.sample_rate
        dur = 4.0
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        pulse = np.sin(2 * np.pi * 65.0 * t) * (0.5 + 0.5 * np.sign(np.sin(2 * np.pi * 2.0 * t)))
        siren = 0.25 * np.sin(2 * np.pi * (220.0 + 30.0 * np.sin(2 * np.pi * 0.5 * t)) * t)
        return self._to_sound(0.5 * pulse + siren, 0.28)

    def play(self, name: str):
        if not self.enabled:
            return
        snd = self.sounds.get(name)
        if snd is not None:
            snd.play()

    def set_bgm(self, bgm_key: str):
        if not self.enabled or self.bgm_channel is None:
            return
        if self.current_bgm == bgm_key and self.bgm_channel.get_busy():
            return
        snd = self.sounds.get(bgm_key)
        if snd is not None:
            self.bgm_channel.play(snd, loops=-1, fade_ms=600)
            self.current_bgm = bgm_key
