# -*- coding: utf-8 -*-
"""
NEON ARK: 1994 - Hardware-Accelerated PyOpenGL 3D Isometric Diorama Renderer
Renders the rotatable PS1/32-bit style 3D diorama world, smart cutaway walls,
articulated low-poly characters & monsters, 3D laser sight, flashlight cone,
and 2D Pygame HUD/UI composite texture.
"""

import math
import time
from typing import Optional, Tuple

import pygame
from OpenGL.GL import (
    GL_ALPHA_TEST,
    GL_AMBIENT,
    GL_AMBIENT_AND_DIFFUSE,
    GL_BLEND,
    GL_COLOR_BUFFER_BIT,
    GL_COLOR_MATERIAL,
    GL_CULL_FACE,
    GL_DEPTH_BUFFER_BIT,
    GL_DEPTH_TEST,
    GL_DIFFUSE,
    GL_FOG,
    GL_FOG_COLOR,
    GL_FOG_END,
    GL_FOG_MODE,
    GL_FOG_START,
    GL_FRONT_AND_BACK,
    GL_GREATER,
    GL_LIGHT0,
    GL_LIGHT1,
    GL_LIGHTING,
    GL_LINEAR,
    GL_LINE_LOOP,
    GL_LINE_SMOOTH,
    GL_LINES,
    GL_MODELVIEW,
    GL_MODELVIEW_MATRIX,
    GL_NEAREST,
    GL_NORMALIZE,
    GL_ONE,
    GL_ONE_MINUS_SRC_ALPHA,
    GL_POSITION,
    GL_PROJECTION,
    GL_PROJECTION_MATRIX,
    GL_QUADS,
    GL_RGBA,
    GL_SRC_ALPHA,
    GL_TEXTURE_2D,
    GL_TEXTURE_MAG_FILTER,
    GL_TEXTURE_MIN_FILTER,
    GL_TRIANGLES,
    GL_TRIANGLE_FAN,
    GL_UNSIGNED_BYTE,
    GL_VIEWPORT,
    glAlphaFunc,
    glBegin,
    glBindTexture,
    glBlendFunc,
    glClear,
    glClearColor,
    glColor3f,
    glColor4f,
    glColorMaterial,
    glDisable,
    glEnable,
    glEnd,
    glFogf,
    glFogfv,
    glFogi,
    glGenTextures,
    glGetDoublev,
    glGetIntegerv,
    glLightfv,
    glLineWidth,
    glLoadIdentity,
    glMatrixMode,
    glNormal3f,
    glOrtho,
    glPopMatrix,
    glPushMatrix,
    glRotatef,
    glScalef,
    glTexCoord2f,
    glTexImage2D,
    glTexParameteri,
    glTexSubImage2D,
    glTranslatef,
    glVertex2f,
    glVertex3f,
    glViewport,
)
from OpenGL.GLU import gluLookAt, gluPerspective, gluProject, gluUnProject

from gameplay import WEAPON_SPECS, GameSession
from world_data import DoorDef, EnemySpawnDef, HazardDef, NPCDef, PickupDef, PropDef, RoomDef


def draw_box(sx: float, sy: float, sz: float, color: Tuple[float, float, float], alpha: float = 1.0):
    """Draws a shaded 3D low-poly box centered at (0, sy/2, 0)."""
    hx, hy, hz = sx * 0.5, sy, sz * 0.5
    r, g, b = color
    glBegin(GL_QUADS)
    # Top (+Y)
    glNormal3f(0, 1, 0)
    glColor4f(min(1.0, r * 1.15), min(1.0, g * 1.15), min(1.0, b * 1.15), alpha)
    glVertex3f(-hx, hy, -hz)
    glVertex3f(-hx, hy, hz)
    glVertex3f(hx, hy, hz)
    glVertex3f(hx, hy, -hz)
    # Bottom (-Y)
    glNormal3f(0, -1, 0)
    glColor4f(r * 0.55, g * 0.55, b * 0.55, alpha)
    glVertex3f(-hx, 0, -hz)
    glVertex3f(hx, 0, -hz)
    glVertex3f(hx, 0, hz)
    glVertex3f(-hx, 0, hz)
    # Front (+Z)
    glNormal3f(0, 0, 1)
    glColor4f(r * 0.95, g * 0.95, b * 0.95, alpha)
    glVertex3f(-hx, 0, hz)
    glVertex3f(hx, 0, hz)
    glVertex3f(hx, hy, hz)
    glVertex3f(-hx, hy, hz)
    # Back (-Z)
    glNormal3f(0, 0, -1)
    glColor4f(r * 0.78, g * 0.78, b * 0.78, alpha)
    glVertex3f(hx, 0, -hz)
    glVertex3f(-hx, 0, -hz)
    glVertex3f(-hx, hy, -hz)
    glVertex3f(hx, hy, -hz)
    # Right (+X)
    glNormal3f(1, 0, 0)
    glColor4f(r * 0.88, g * 0.88, b * 0.88, alpha)
    glVertex3f(hx, 0, hz)
    glVertex3f(hx, 0, -hz)
    glVertex3f(hx, hy, -hz)
    glVertex3f(hx, hy, hz)
    # Left (-X)
    glNormal3f(-1, 0, 0)
    glColor4f(r * 0.72, g * 0.72, b * 0.72, alpha)
    glVertex3f(-hx, 0, -hz)
    glVertex3f(-hx, 0, hz)
    glVertex3f(-hx, hy, hz)
    glVertex3f(-hx, hy, -hz)
    glEnd()


def draw_octa_crystal(radius: float, height: float, color: Tuple[float, float, float], alpha: float = 0.9):
    """Draws a low-poly PS1 style glowing octahedron crystal centered at (0, height/2, 0)."""
    r, g, b = color
    mid_y = height * 0.5
    pts = [
        (radius, mid_y, 0),
        (0, mid_y, radius),
        (-radius, mid_y, 0),
        (0, mid_y, -radius),
    ]
    glBegin(GL_TRIANGLES)
    for i in range(4):
        p1 = pts[i]
        p2 = pts[(i + 1) % 4]
        shade = 0.85 + 0.15 * (i % 2)
        # Upper pyramid
        glColor4f(min(1.0, r * shade * 1.2), min(1.0, g * shade * 1.2), min(1.0, b * shade * 1.2), alpha)
        glVertex3f(0, height, 0)
        glVertex3f(*p1)
        glVertex3f(*p2)
        # Lower pyramid
        glColor4f(r * shade * 0.75, g * shade * 0.75, b * shade * 0.75, alpha)
        glVertex3f(0, 0, 0)
        glVertex3f(*p2)
        glVertex3f(*p1)
    glEnd()


class DioramaRenderer3D:
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        self.ui_tex_id = None
        self.modelview_mat = None
        self.proj_mat = None
        self.viewport_mat = None
        self._init_gl()

    def _init_gl(self):
        glViewport(0, 0, self.width, self.height)
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glEnable(GL_COLOR_MATERIAL)
        glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)
        glEnable(GL_NORMALIZE)

        # Atmospheric survival horror fog
        glEnable(GL_FOG)
        glFogi(GL_FOG_MODE, GL_LINEAR)
        glFogfv(GL_FOG_COLOR, (0.04, 0.05, 0.09, 1.0))
        glFogf(GL_FOG_START, 16.0)
        glFogf(GL_FOG_END, 38.0)

        # Allocate 2D UI overlay texture
        self.ui_tex_id = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, self.ui_tex_id)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
        empty = bytes(self.width * self.height * 4)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, self.width, self.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, empty)

    def render_scene(self, session: GameSession):
        room = session.current_room
        ar, ag, ab = room.ambient_light
        glClearColor(ar * 0.12, ag * 0.12, ab * 0.16, 1.0)
        glFogfv(GL_FOG_COLOR, (ar * 0.12, ag * 0.12, ab * 0.16, 1.0))
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        # Setup 3D Isometric / Diorama Perspective Camera
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        fov = 34.0 if session.is_aiming else 38.0
        gluPerspective(fov, self.width / float(self.height), 0.5, 65.0)

        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()

        dist = session.cam_dist * (0.82 if session.is_aiming else 1.0)
        pitch_rad = math.radians(session.cam_pitch)
        yaw_rad = math.radians(session.cam_yaw)

        horiz = dist * math.cos(pitch_rad)
        cam_x = session.px + horiz * math.sin(yaw_rad)
        cam_z = session.pz + horiz * math.cos(yaw_rad)
        cam_y = 1.2 + dist * math.sin(pitch_rad)

        gluLookAt(
            cam_x, cam_y, cam_z,
            session.px, 1.0, session.pz,
            0.0, 1.0, 0.0,
        )

        # Cache matrices for 3D -> 2D floating labels and mouse raycasting
        self.modelview_mat = glGetDoublev(GL_MODELVIEW_MATRIX)
        self.proj_mat = glGetDoublev(GL_PROJECTION_MATRIX)
        self.viewport_mat = glGetIntegerv(GL_VIEWPORT)

        t_now = time.time()

        # 1. Draw Floor & Diorama Cutaway Walls + Doors
        self._draw_room_diorama(room, session.cam_yaw, t_now)

        # 2. Draw Environmental Hazards (Electric Puddles & Explosive Barrels)
        for haz in room.hazards:
            if haz.active:
                self._draw_hazard(haz, t_now, haz == session.laser_target_hazard)

        # 3. Draw Architectural Props (Fountains, Statues, ASTRO-ORACLE, Terminals, Organ, Vaults)
        for prop in room.props:
            self._draw_prop(prop, session, t_now)

        # 4. Draw Pickups (Weapons, Keys, Notes, Ammo, Secrets)
        for p in room.pickups:
            if not p.collected:
                self._draw_pickup(p, t_now)

        # 5. Draw NPCs
        for npc in room.npcs:
            self._draw_npc(npc, t_now)

        # 6. Draw Enemies & Boss
        for enemy in room.enemies:
            if enemy.alive:
                self._draw_enemy(enemy, t_now, enemy == session.laser_target_enemy)

        # 7. Draw Player (Vera Lin) + Flashlight Cone + Laser Sight Beam
        self._draw_player(session, t_now)

        # 8. Draw Projectiles & 3D Particles
        self._draw_projectiles_and_particles(session)

    # ========================================================================
    # ROOM DIORAMA GEOMETRY (FLOOR, TILES, CUTAWAY WALLS, NEON DOORS)
    # ========================================================================
    def _draw_room_diorama(self, room: RoomDef, cam_yaw: float, t_now: float):
        hw = room.width * 0.5
        hd = room.depth * 0.5
        fr, fg, fb = room.floor_color
        wr, wg, wb = room.wall_color

        # Base Diorama Pedestal Slab (gives that unmistakable Crow Country floating miniature box look!)
        glPushMatrix()
        glTranslatef(0.0, -1.2, 0.0)
        draw_box(room.width + 1.2, 1.18, room.depth + 1.2, (wr * 0.35, wg * 0.35, wb * 0.42))
        glPopMatrix()

        # Checkered Floor Tiles
        tile_size = 2.0
        nx = int(room.width / tile_size)
        nz = int(room.depth / tile_size)
        glBegin(GL_QUADS)
        glNormal3f(0, 1, 0)
        for ix in range(nx):
            for iz in range(nz):
                x0 = -hw + ix * tile_size
                z0 = -hd + iz * tile_size
                checker = (ix + iz) % 2 == 0
                mult = 1.08 if checker else 0.88
                glColor3f(fr * mult, fg * mult, fb * mult)
                glVertex3f(x0, 0.0, z0)
                glVertex3f(x0, 0.0, z0 + tile_size)
                glVertex3f(x0 + tile_size, 0.0, z0 + tile_size)
                glVertex3f(x0 + tile_size, 0.0, z0)
        glEnd()

        # Smart Cutaway Walls: determine which walls are between camera and room center
        cam_rad = math.radians(cam_yaw)
        cam_dx = math.sin(cam_rad)
        cam_dz = math.cos(cam_rad)

        wall_configs = [
            ("north", 0.0, -hd, room.width, 0.45, cam_dz < -0.25),
            ("south", 0.0, hd, room.width, 0.45, cam_dz > 0.25),
            ("west", -hw, 0.0, 0.45, room.depth, cam_dx < -0.25),
            ("east", hw, 0.0, 0.45, room.depth, cam_dx > 0.25),
        ]

        for d_name, wx, wz, sx, sz, is_front_facing in wall_configs:
            wall_h = 0.65 if is_front_facing else 3.4
            glPushMatrix()
            glTranslatef(wx, 0.0, wz)
            draw_box(sx, wall_h, sz, (wr, wg, wb))
            # Neon synthwave stripe along back walls
            if not is_front_facing:
                glTranslatef(0.0, 2.3, 0.0)
                stripe_col = (0.2, 0.85, 0.95) if not room.is_save_room else (0.2, 0.95, 0.6)
                draw_box(sx + 0.06, 0.12, sz + 0.06, stripe_col)
            glPopMatrix()

            # Render Door Portal if this wall has a door
            if d_name in room.doors:
                self._draw_door_portal(d_name, room.doors[d_name], hw, hd, is_front_facing, t_now)

    def _draw_door_portal(self, d_name: str, door: DoorDef, hw: float, hd: float, is_cutaway: bool, t_now: float):
        glPushMatrix()
        if d_name == "north":
            glTranslatef(door.pos_offset, 0.0, -hd)
        elif d_name == "south":
            glTranslatef(door.pos_offset, 0.0, hd)
        elif d_name == "west":
            glTranslatef(-hw, 0.0, door.pos_offset)
            glRotatef(90, 0, 1, 0)
        elif d_name == "east":
            glTranslatef(hw, 0.0, door.pos_offset)
            glRotatef(90, 0, 1, 0)

        unlocked = door.unlocked or door.lock_id is None
        pulse = 0.75 + 0.25 * math.sin(t_now * 4.0)
        if unlocked:
            arch_col = (0.15, 0.95 * pulse, 0.65 * pulse)
        elif door.lock_id == "silver_key":
            arch_col = (0.75, 0.85, 1.0)
        elif door.lock_id == "gold_key":
            arch_col = (1.0, 0.82, 0.20)
        else:
            arch_col = (1.0 * pulse, 0.22, 0.30)

        door_h = 1.35 if is_cutaway else 2.65
        draw_box(2.4, door_h, 0.68, (0.10, 0.12, 0.16))
        # Glowing frame arch
        draw_box(2.65, door_h + 0.18, 0.58, arch_col, alpha=0.85)
        # Floor threshold mat
        glTranslatef(0.0, 0.02, 0.0)
        draw_box(2.4, 0.04, 1.5, arch_col, alpha=0.55)
        glPopMatrix()

    # ========================================================================
    # ARCHITECTURAL PROPS & INTERACTIVE MACHINES
    # ========================================================================
    def _draw_prop(self, prop: PropDef, session: GameSession, t_now: float):
        glPushMatrix()
        glTranslatef(prop.x, 0.0, prop.z)
        glRotatef(prop.rot_y, 0, 1, 0)
        glScalef(prop.scale, prop.scale, prop.scale)

        k = prop.kind
        if k == "fountain":
            draw_box(3.4, 0.55, 3.4, (0.28, 0.32, 0.42))
            draw_box(2.8, 0.62, 2.8, (0.12, 0.58, 0.78), alpha=0.85)
            glTranslatef(0.0, 0.6, 0.0)
            draw_box(0.8, 1.3, 0.8, (0.45, 0.50, 0.62))
            glTranslatef(0.0, 1.3, 0.0)
            glRotatef(t_now * 35.0, 0, 1, 0)
            draw_octa_crystal(0.65, 1.3, (0.25, 0.90, 1.0))

        elif k == "statue_dolphin":
            # Pedestal + Stylized Retro 80s Cyber-Dolphin Sculpture
            draw_box(1.5, 0.8, 1.5, (0.25, 0.30, 0.38))
            glTranslatef(0.0, 0.8, 0.0)
            glPushMatrix()
            glRotatef(-25.0, 1, 0, 0)
            draw_box(0.7, 1.6, 1.1, (0.22, 0.72, 0.92))
            glTranslatef(0.0, 1.4, 0.35)
            # Snout / Open Jaw if organ puzzle solved
            if "organ_solved" in session.solved_puzzles:
                draw_box(0.45, 0.55, 0.85, (1.0, 0.85, 0.25))
            else:
                draw_box(0.45, 0.45, 0.75, (0.30, 0.82, 0.98))
            glPopMatrix()

        elif k == "oracle":
            # Crow Country Tribute: "ASTRO-ORACLE 86" Fortune Teller Machine
            draw_box(1.2, 1.1, 1.0, (0.38, 0.16, 0.48))
            glTranslatef(0.0, 1.1, 0.0)
            draw_box(1.1, 1.0, 0.9, (0.15, 0.85, 0.95), alpha=0.42)
            glPushMatrix()
            glTranslatef(0.0, 0.2, 0.0)
            glRotatef(t_now * 75.0, 0, 1, 0)
            draw_octa_crystal(0.38, 0.7, (1.0, 0.85, 0.25))
            glPopMatrix()
            glTranslatef(0.0, 1.0, 0.0)
            draw_box(1.3, 0.28, 1.1, (0.95, 0.25, 0.65))

        elif k == "save_terminal":
            # Desk + Glowing Green CRT Save Computer
            draw_box(1.5, 0.85, 1.0, (0.26, 0.28, 0.32))
            glTranslatef(0.0, 0.85, 0.0)
            draw_box(0.85, 0.72, 0.75, (0.72, 0.70, 0.64))
            glTranslatef(0.0, 0.10, 0.39)
            flicker = 0.82 + 0.18 * math.sin(t_now * 12.0)
            draw_box(0.68, 0.52, 0.05, (0.15, 0.95 * flicker, 0.45 * flicker))

        elif k == "storage_box":
            draw_box(1.6, 0.95, 1.0, (0.18, 0.48, 0.38))
            glTranslatef(0.0, 0.95, 0.0)
            draw_box(1.65, 0.18, 1.05, (0.25, 0.92, 0.68))

        elif k == "organ_console":
            draw_box(1.8, 1.0, 1.1, (0.32, 0.20, 0.16))
            glTranslatef(0.0, 1.0, 0.2)
            draw_box(1.6, 0.20, 0.45, (0.92, 0.92, 0.88))
            # Gold organ pipes
            glTranslatef(0.0, 0.2, -0.35)
            for px_off in (-0.6, -0.2, 0.2, 0.6):
                glPushMatrix()
                glTranslatef(px_off, 0.0, 0.0)
                draw_box(0.22, 1.35 + abs(px_off) * 0.4, 0.22, (0.92, 0.76, 0.24))
                glPopMatrix()

        elif k == "keypad_terminal":
            draw_box(0.5, 1.4, 0.4, (0.25, 0.28, 0.35))
            glTranslatef(0.0, 1.0, 0.22)
            col = (0.2, 0.95, 0.4) if "door_keypad_1986" in session.solved_puzzles else (1.0, 0.25, 0.3)
            draw_box(0.36, 0.36, 0.08, col)

        elif k == "coral_plaque":
            draw_box(1.8, 1.9, 0.7, (0.22, 0.28, 0.34))
            if "coral_melted" not in session.solved_puzzles:
                glTranslatef(0.0, 0.4, 0.35)
                draw_octa_crystal(0.85, 1.4, (0.95, 0.32, 0.62))

        elif k == "valve_wheel":
            draw_box(0.6, 1.2, 0.6, (0.32, 0.35, 0.40))
            glTranslatef(0.0, 1.1, 0.35)
            if "flooded_drained" in session.solved_puzzles:
                glRotatef(t_now * 40.0, 0, 0, 1)
            draw_box(0.95, 0.22, 0.15, (0.92, 0.22, 0.22))
            draw_box(0.22, 0.95, 0.15, (0.92, 0.22, 0.22))

        elif k == "safe_vault":
            col = (0.25, 0.65, 0.45) if "safe_2142_opened" in session.solved_puzzles else (0.38, 0.40, 0.46)
            draw_box(1.3, 1.5, 1.2, col)
            glTranslatef(0.0, 0.6, 0.62)
            draw_box(0.45, 0.45, 0.08, (0.95, 0.80, 0.25))

        elif k == "astral_pedestal":
            draw_box(1.4, 1.1, 1.0, (0.28, 0.22, 0.42))
            glTranslatef(0.0, 1.1, 0.0)
            col = (1.0, 0.88, 0.25) if "astral_unlocked" in session.solved_puzzles else (0.45, 0.35, 0.75)
            glRotatef(t_now * 50.0, 0, 1, 0)
            draw_octa_crystal(0.55, 0.95, col)

        elif k == "cryo_tank":
            draw_box(1.3, 0.35, 1.3, (0.25, 0.30, 0.35))
            glTranslatef(0.0, 0.35, 0.0)
            draw_box(1.1, 1.9, 1.1, (0.15, 0.88, 0.78), alpha=0.48)
            glTranslatef(0.0, 0.4, 0.0)
            draw_octa_crystal(0.4, 1.1, (0.85, 0.25, 0.55))

        elif k == "vein_crystal":
            # Colossal Temporal Singularity Crystal in the Final Boss Room
            glRotatef(t_now * 25.0, 0, 1, 0)
            draw_octa_crystal(1.35, 2.8, (0.85, 0.20, 0.95), alpha=0.88)
            glRotatef(45.0, 0, 1, 0)
            draw_octa_crystal(1.75, 1.8, (0.20, 0.85, 1.0), alpha=0.45)

        elif k == "pillar":
            draw_box(0.9, 3.2, 0.9, (0.26, 0.24, 0.36))
            glTranslatef(0.0, 1.8, 0.0)
            draw_box(0.96, 0.18, 0.96, (0.25, 0.85, 0.95))

        elif k == "arcade":
            draw_box(0.95, 1.75, 0.85, (0.22, 0.14, 0.38))
            glTranslatef(0.0, 1.0, 0.44)
            draw_box(0.72, 0.52, 0.05, (0.95, 0.25, 0.80))

        elif k == "vending":
            draw_box(1.1, 1.95, 0.85, (0.15, 0.45, 0.78))
            glTranslatef(0.0, 0.7, 0.44)
            draw_box(0.85, 0.95, 0.05, (0.35, 0.90, 1.0))

        else:
            # desk / crate
            draw_box(1.6, 0.85, 1.0, (0.36, 0.26, 0.20))

        glPopMatrix()

    def _draw_hazard(self, haz: HazardDef, t_now: float, is_targeted: bool):
        glPushMatrix()
        glTranslatef(haz.x, 0.0, haz.z)
        if haz.kind == "explosive_barrel":
            pulse = 1.0 if not is_targeted else (0.75 + 0.25 * math.sin(t_now * 18.0))
            draw_box(0.85, 1.15, 0.85, (0.92 * pulse, 0.18, 0.15))
            glTranslatef(0.0, 0.45, 0.0)
            draw_box(0.88, 0.22, 0.88, (0.98, 0.82, 0.15))
        elif haz.kind == "electric_puddle":
            r = haz.radius
            flicker = 0.65 + 0.35 * math.sin(t_now * 16.0)
            glBegin(GL_TRIANGLE_FAN)
            glColor4f(0.15, 0.75 * flicker, 1.0, 0.58)
            glVertex3f(0.0, 0.03, 0.0)
            for i in range(17):
                ang = i * (math.pi * 2 / 16.0)
                glVertex3f(math.cos(ang) * r, 0.03, math.sin(ang) * r)
            glEnd()
            # Sparking electric arcs
            glLineWidth(2.0)
            glBegin(GL_LINES)
            glColor4f(0.6, 0.95, 1.0, 0.9)
            for i in range(4):
                a1 = t_now * 7.0 + i * 1.57
                glVertex3f(math.cos(a1) * r * 0.3, 0.08, math.sin(a1) * r * 0.3)
                glVertex3f(math.cos(a1 + 0.7) * r * 0.85, 0.18, math.sin(a1 + 0.7) * r * 0.85)
            glEnd()
        glPopMatrix()

    def _draw_pickup(self, p: PickupDef, t_now: float):
        glPushMatrix()
        bob = 0.22 + 0.10 * math.sin(t_now * 3.8 + p.x)
        glTranslatef(p.x, bob, p.z)
        glRotatef(t_now * 85.0, 0, 1, 0)

        if p.kind == "key_item":
            draw_octa_crystal(0.38, 0.68, (1.0, 0.84, 0.20))
        elif p.kind == "weapon":
            draw_box(0.75, 0.28, 0.32, (0.95, 0.45, 0.15))
        elif p.kind == "medkit":
            draw_box(0.48, 0.42, 0.48, (0.20, 0.92, 0.52))
        elif p.kind == "note":
            draw_box(0.45, 0.08, 0.58, (0.95, 0.92, 0.78))
        elif p.kind in ("secret", "upgrade"):
            draw_octa_crystal(0.36, 0.65, (0.98, 0.30, 0.95))
        else:
            # Ammo / Grenades
            draw_box(0.42, 0.32, 0.42, (0.30, 0.78, 0.98))
        glPopMatrix()

    # ========================================================================
    # CHARACTERS: PROTAGONIST VERA LIN, NPCS & GROTESQUE ECHO MONSTERS
    # ========================================================================
    def _draw_player(self, session: GameSession, t_now: float):
        glPushMatrix()
        glTranslatef(session.px, 0.0, session.pz)
        glRotatef(session.p_yaw, 0, 1, 0)

        # Flashlight volumetric floor cone
        glBegin(GL_TRIANGLE_FAN)
        glColor4f(0.85, 0.92, 1.0, 0.18)
        glVertex3f(0.0, 0.04, 0.3)
        glColor4f(0.85, 0.92, 1.0, 0.0)
        for i in range(-4, 5):
            ang = math.radians(i * 7.5)
            glVertex3f(math.sin(ang) * 7.5, 0.04, math.cos(ang) * 7.5)
        glEnd()

        swing = math.sin(session.walk_anim) * 24.0 if not session.is_aiming else 0.0

        # Legs
        for side, mult in ((-0.16, 1.0), (0.16, -1.0)):
            glPushMatrix()
            glTranslatef(side, 0.55, 0.0)
            glRotatef(swing * mult, 1, 0, 0)
            glTranslatef(0.0, -0.55, 0.0)
            draw_box(0.18, 0.55, 0.20, (0.16, 0.20, 0.28))
            glPopMatrix()

        # Trenchcoat Torso (Vera Lin)
        glPushMatrix()
        glTranslatef(0.0, 0.52, 0.0)
        coat_col = (0.18, 0.42, 0.62) if session.invuln_timer <= 0 or int(t_now * 20) % 2 == 0 else (1.0, 0.2, 0.2)
        draw_box(0.48, 0.66, 0.30, coat_col)
        glPopMatrix()

        # Left Arm (with glowing blue-violet Temporal Coral bandage - Twist #2 visual cue!)
        glPushMatrix()
        glTranslatef(0.30, 1.05, 0.0)
        glRotatef(-swing * 0.7, 1, 0, 0)
        glTranslatef(0.0, -0.42, 0.0)
        draw_box(0.14, 0.44, 0.16, (0.35, 0.85, 0.98))
        glPopMatrix()

        # Right Arm + Weapon
        glPushMatrix()
        glTranslatef(-0.30, 1.05, 0.0)
        if session.is_aiming:
            glRotatef(85.0, 1, 0, 0)
        else:
            glRotatef(swing * 0.7, 1, 0, 0)
        glTranslatef(0.0, -0.42, 0.0)
        draw_box(0.14, 0.44, 0.16, coat_col)
        # Weapon model in hand
        glTranslatef(0.0, 0.0, 0.22)
        w_col = (0.85, 0.75, 0.25) if session.current_weapon == "magnum" else (0.30, 0.32, 0.36)
        draw_box(0.12, 0.16, 0.48, w_col)
        glPopMatrix()

        # Head & Dark Bob Hair (Crow Country chibi/diorama proportions!)
        glPushMatrix()
        glTranslatef(0.0, 1.20, 0.0)
        draw_box(0.42, 0.42, 0.40, (0.94, 0.80, 0.72))
        glTranslatef(0.0, 0.16, -0.03)
        draw_box(0.46, 0.30, 0.45, (0.12, 0.10, 0.16))
        glPopMatrix()

        glPopMatrix()

        # 3D Laser Sight Beam when Aiming!
        if session.is_aiming:
            spec = WEAPON_SPECS[session.current_weapon]
            lr, lg, lb = spec["laser_color"]
            rad = math.radians(session.p_yaw)
            sx = session.px + math.sin(rad) * 0.55
            sz = session.pz + math.cos(rad) * 0.55
            hx, hy, hz = session.laser_hit_point

            glLineWidth(2.4 if session.aim_focus >= 0.82 else 1.4)
            glBegin(GL_LINES)
            glColor4f(lr, lg, lb, 0.88)
            glVertex3f(sx, 1.08, sz)
            glVertex3f(hx, hy, hz)
            glEnd()

            # Target Laser Dot + Focus Ring in 3D space
            glPushMatrix()
            glTranslatef(hx, hy, hz)
            dot_scale = 0.14 + (1.0 - session.aim_focus) * 0.22
            draw_octa_crystal(dot_scale, dot_scale * 1.6, (lr, lg, lb), alpha=0.92)
            glPopMatrix()

    def _draw_npc(self, npc: NPCDef, t_now: float):
        glPushMatrix()
        glTranslatef(npc.x, 0.0, npc.z)
        glRotatef(npc.rot_y, 0, 1, 0)
        draw_box(0.44, 1.15, 0.32, npc.color)
        glTranslatef(0.0, 1.18, 0.0)
        draw_box(0.40, 0.40, 0.38, (0.92, 0.78, 0.70))
        # Floating cyan interaction crystal above NPC
        glTranslatef(0.0, 0.65 + 0.08 * math.sin(t_now * 4.0), 0.0)
        glRotatef(t_now * 60.0, 0, 1, 0)
        draw_octa_crystal(0.18, 0.35, (0.2, 0.95, 1.0))
        glPopMatrix()

    def _draw_enemy(self, enemy: EnemySpawnDef, t_now: float, is_targeted: bool):
        glPushMatrix()
        glTranslatef(enemy.x, 0.0, enemy.z)
        wobble = math.sin(t_now * 6.5 + enemy.x) * 8.0
        glRotatef(wobble, 0, 0, 1)

        if enemy.kind == "echo_walker":
            # Mutated 2142 refugee fused with fluorescent coral
            draw_box(0.52, 1.25, 0.36, (0.38, 0.26, 0.44))
            glTranslatef(0.22, 1.15, 0.0)
            draw_octa_crystal(0.35, 0.75, (0.95, 0.25, 0.60))
            glTranslatef(-0.32, 0.1, 0.0)
            draw_box(0.38, 0.38, 0.38, (0.72, 0.82, 0.78))

        elif enemy.kind == "coral_hound":
            draw_box(0.65, 0.65, 1.15, (0.55, 0.18, 0.32))
            glTranslatef(0.0, 0.65, 0.2)
            draw_octa_crystal(0.32, 0.65, (1.0, 0.35, 0.55))

        elif enemy.kind == "mascot_brute":
            # Hulking 80s Dolphin Mascot suit burst open with grotesque coral flesh
            draw_box(0.95, 1.65, 0.75, (0.20, 0.62, 0.85))
            glTranslatef(0.0, 0.8, 0.38)
            draw_octa_crystal(0.48, 0.85, (0.95, 0.20, 0.42))
            glTranslatef(0.0, 0.88, -0.38)
            draw_box(0.72, 0.68, 0.72, (0.25, 0.75, 0.95))

        elif enemy.kind == "acid_spitter":
            draw_box(0.58, 1.30, 0.48, (0.22, 0.48, 0.32))
            glTranslatef(0.0, 1.1, 0.15)
            pulse = 0.38 + 0.08 * math.sin(t_now * 9.0)
            draw_octa_crystal(pulse, 0.75, (0.35, 1.0, 0.25))

        elif enemy.kind == "boss_swan":
            # Final Boss: Dr. Victor Swan fused with the 2142 Temporal Singularity
            scale = 1.25 if enemy.phase == 2 else 1.05
            glScalef(scale, scale, scale)
            draw_box(1.35, 2.1, 1.05, (0.32, 0.14, 0.48))
            # Orbiting Temporal Halo Crystals
            for i in range(3):
                glPushMatrix()
                ang = t_now * 95.0 + i * 120.0
                glRotatef(ang, 0, 1, 0)
                glTranslatef(1.35, 1.4, 0.0)
                col = (1.0, 0.20, 0.55) if enemy.phase == 2 else (0.25, 0.90, 1.0)
                draw_octa_crystal(0.38, 0.85, col)
                glPopMatrix()
            glTranslatef(0.0, 2.1, 0.0)
            draw_octa_crystal(0.65, 1.1, (1.0, 0.85, 0.25))

        # Target lock-on indicator above enemy head
        if is_targeted:
            glTranslatef(0.0, 0.75, 0.0)
            glRotatef(t_now * 140.0, 0, 1, 0)
            draw_octa_crystal(0.24, 0.42, (1.0, 0.15, 0.20))

        glPopMatrix()

    def _draw_projectiles_and_particles(self, session: GameSession):
        for proj in session.projectiles:
            glPushMatrix()
            glTranslatef(proj.x, proj.y, proj.z)
            if proj.kind == "acid_orb":
                draw_octa_crystal(0.24, 0.42, (0.35, 1.0, 0.20))
            elif proj.kind == "grenade":
                draw_box(0.26, 0.26, 0.26, (0.95, 0.55, 0.15))
            elif proj.kind == "flame":
                draw_octa_crystal(0.28, 0.45, (0.20, 0.88, 1.0), alpha=0.75)
            glPopMatrix()

        if session.last_shot_line is not None:
            p0, p1, _ = session.last_shot_line
            glLineWidth(3.0)
            glBegin(GL_LINES)
            glColor4f(1.0, 0.95, 0.55, 0.95)
            glVertex3f(*p0)
            glVertex3f(*p1)
            glEnd()

        for pt in session.particles:
            glPushMatrix()
            glTranslatef(pt.x, pt.y, pt.z)
            alpha = max(0.0, pt.life / pt.max_life)
            draw_box(pt.size, pt.size, pt.size, pt.color, alpha=alpha)
            glPopMatrix()

    # ========================================================================
    # 3D <-> 2D PROJECTION & COMPOSITE UI OVERLAY
    # ========================================================================
    def project_to_screen(self, x: float, y: float, z: float) -> Optional[Tuple[int, int]]:
        if self.modelview_mat is None or self.proj_mat is None or self.viewport_mat is None:
            return None
        try:
            sx, sy, sz = gluProject(x, y, z, self.modelview_mat, self.proj_mat, self.viewport_mat)
            if 0.0 <= sz <= 1.0:
                return int(sx), int(self.height - sy)
        except Exception:
            pass
        return None

    def screen_ray_to_ground(self, mx: int, my: int, session: GameSession) -> Optional[Tuple[float, float]]:
        """Unprojects mouse screen coordinates onto the Y=1.0 aiming plane."""
        if self.modelview_mat is None or self.proj_mat is None or self.viewport_mat is None:
            return None
        try:
            win_x = float(mx)
            win_y = float(self.height - my)
            near_pt = gluUnProject(win_x, win_y, 0.0, self.modelview_mat, self.proj_mat, self.viewport_mat)
            far_pt = gluUnProject(win_x, win_y, 1.0, self.modelview_mat, self.proj_mat, self.viewport_mat)
            dy = far_pt[1] - near_pt[1]
            if abs(dy) < 1e-5:
                return None
            t = (1.0 - near_pt[1]) / dy
            gx = near_pt[0] + (far_pt[0] - near_pt[0]) * t
            gz = near_pt[2] + (far_pt[2] - near_pt[2]) * t
            return (gx - session.px, gz - session.pz)
        except Exception:
            return None

    def composite_ui_surface(self, ui_surface: pygame.Surface):
        """Uploads the 2D Pygame HUD/Modal surface and renders it over the 3D OpenGL scene."""
        raw_bytes = pygame.image.tobytes(ui_surface, "RGBA", True)
        glDisable(GL_DEPTH_TEST)
        glDisable(GL_FOG)
        glEnable(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, self.ui_tex_id)
        glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, self.width, self.height, GL_RGBA, GL_UNSIGNED_BYTE, raw_bytes)

        glMatrixMode(GL_PROJECTION)
        glPushMatrix()
        glLoadIdentity()
        glOrtho(0, self.width, 0, self.height, -1, 1)

        glMatrixMode(GL_MODELVIEW)
        glPushMatrix()
        glLoadIdentity()

        glColor4f(1.0, 1.0, 1.0, 1.0)
        glBegin(GL_QUADS)
        glTexCoord2f(0.0, 0.0)
        glVertex2f(0, 0)
        glTexCoord2f(1.0, 0.0)
        glVertex2f(self.width, 0)
        glTexCoord2f(1.0, 1.0)
        glVertex2f(self.width, self.height)
        glTexCoord2f(0.0, 1.0)
        glVertex2f(0, self.height)
        glEnd()

        glPopMatrix()
        glMatrixMode(GL_PROJECTION)
        glPopMatrix()
        glMatrixMode(GL_MODELVIEW)

        glDisable(GL_TEXTURE_2D)
        glEnable(GL_FOG)
        glEnable(GL_DEPTH_TEST)
