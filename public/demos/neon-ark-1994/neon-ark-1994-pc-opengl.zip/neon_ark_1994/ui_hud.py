# -*- coding: utf-8 -*-
"""
NEON ARK: 1994 - Retro 32-Bit Survival Horror HUD, Color-Coded Smart Map & Puzzle Modals
Implements Crow Country's signature UI elements:
- ECG Heartbeat Status Monitor (FINE / CAUTION / DANGER)
- Color-Coded Smart Map (Cleared = Cyan/Green, Remaining Items/Puzzles = Amber/Red, Unvisited = Dim)
- Interactive Keypad Lock, Harmonic Organ Console, ASTRO-ORACLE Fortune Card, and S-Rank Screen
"""

import math
import os
import time
from typing import Dict, List, Optional, Tuple

import pygame

from engine_3d import DioramaRenderer3D
from gameplay import WEAPON_SPECS, GameSession
from world_data import LORE_NOTES


def load_cjk_font(size: int, bold: bool = False) -> pygame.font.Font:
    """Loads a crisp Traditional Chinese font on Windows with safe fallbacks."""
    win_fonts = [
        r"C:\Windows\Fonts\msjhbd.ttc" if bold else r"C:\Windows\Fonts\msjh.ttc",
        r"C:\Windows\Fonts\msjh.ttc",
        r"C:\Windows\Fonts\mingliu.ttc",
        r"C:\Windows\Fonts\simhei.ttf",
    ]
    for path in win_fonts:
        if os.path.exists(path):
            try:
                return pygame.font.Font(path, size)
            except Exception:
                pass
    for sys_name in ("microsoftjhenghei", "mingliu", "simhei", "arial"):
        try:
            f = pygame.font.SysFont(sys_name, size, bold=bold)
            if f is not None:
                return f
        except Exception:
            pass
    return pygame.font.Font(None, size)


class RetroHUDRenderer:
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        self.surface = pygame.Surface((width, height), pygame.SRCALPHA)

        self.font_xs = load_cjk_font(15, False)
        self.font_sm = load_cjk_font(18, False)
        self.font_md = load_cjk_font(22, True)
        self.font_lg = load_cjk_font(30, True)
        self.font_xl = load_cjk_font(44, True)

        # Pre-render CRT scanline overlay for fast blitting
        self.crt_overlay = pygame.Surface((width, height), pygame.SRCALPHA)
        for y in range(0, height, 3):
            pygame.draw.line(self.crt_overlay, (0, 0, 0, 48), (0, y), (width, y))
        # Subtle corner frame border
        pygame.draw.rect(self.crt_overlay, (20, 45, 65, 90), (0, 0, width, height), 6)

        # Interactive button hitboxes for Keypad / Organ / Inventory
        self.clickable_rects: List[Tuple[pygame.Rect, str]] = []
        self.selected_inv_note_idx: int = 0

    def render(self, session: GameSession, renderer3d: DioramaRenderer3D, on_title_screen: bool = False) -> pygame.Surface:
        self.surface.fill((0, 0, 0, 0))
        self.clickable_rects.clear()
        t_now = time.time()

        if on_title_screen:
            self._draw_title_screen(session, t_now)
            if session.ps1_filter:
                self.surface.blit(self.crt_overlay, (0, 0))
            return self.surface

        # 1. 3D Projected World Labels (Floating Damage, Enemy Names, Pickup Sparkles)
        self._draw_3d_floating_elements(session, renderer3d)

        # 2. Always-on Survival Horror HUD
        self._draw_top_hud(session, t_now)
        self._draw_bottom_hud(session, t_now)

        # 3. Modal Screens (Map, Inventory, Notes, Keypad, Organ, Oracle, Dialogue, Victory, GameOver)
        mode = session.ui_mode
        if mode == "MAP":
            self._draw_smart_map_modal(session)
        elif mode == "INVENTORY":
            self._draw_inventory_modal(session)
        elif mode == "NOTE_VIEW":
            self._draw_note_modal(session)
        elif mode == "KEYPAD":
            self._draw_keypad_modal(session)
        elif mode == "ORGAN":
            self._draw_organ_modal(session)
        elif mode == "ORACLE":
            self._draw_oracle_modal(session)
        elif mode == "DIALOGUE":
            self._draw_dialogue_modal(session)
        elif mode == "VICTORY":
            self._draw_victory_s_rank_modal(session)
        elif mode == "GAMEOVER":
            self._draw_gameover_modal(session)

        # 4. PS1 CRT Scanline Overlay
        if session.ps1_filter:
            self.surface.blit(self.crt_overlay, (0, 0))

        return self.surface

    # ========================================================================
    # TITLE SCREEN
    # ========================================================================
    def _draw_title_screen(self, session: GameSession, t_now: float):
        # Semi-transparent dark synthwave backdrop over live rotating 3D diorama
        pygame.draw.rect(self.surface, (8, 10, 22, 185), (0, 0, self.width, self.height))

        panel = pygame.Rect(self.width // 2 - 430, 65, 860, 590)
        pygame.draw.rect(self.surface, (14, 20, 38, 235), panel, border_radius=12)
        pygame.draw.rect(self.surface, (60, 220, 255, 220), panel, 2, border_radius=12)

        tag = self.font_sm.render("A 32-BIT RETRO SURVIVAL HORROR DIORAMA — INSPIRED BY CROW COUNTRY", True, (110, 225, 255))
        self.surface.blit(tag, (self.width // 2 - tag.get_width() // 2, 92))

        title = self.font_xl.render("《 NEON ARK : 1994 — 霓虹方舟 》", True, (255, 95, 185))
        self.surface.blit(title, (self.width // 2 - title.get_width() // 2, 130))

        sub = self.font_md.render("太陽神穹頂博覽館・零號時間晶簇事件 (Project: Solaris Dome)", True, (255, 230, 130))
        self.surface.blit(sub, (self.width // 2 - sub.get_width() // 2, 188))

        story_lines = [
            "1994年，東海人工島上的80年代復古未來主義海洋主題樂園「太陽神穹頂」已荒廢兩年。",
            "創辦人維克多·斯旺博士離奇失蹤，而自稱海事保險調查員的少女【林薇拉 (Vera Lin)】獨自登島。",
            "在微笑的海豚吉祥物與合成波霓虹燈下，徘徊著長滿深海時間珊瑚的扭曲怪物「迴響體」。",
            "然而，迴響體並非單純的變異生物，而薇拉左臂繃帶下的藍紫結晶也藏著她真正的身分……",
        ]
        y = 240
        for line in story_lines:
            surf = self.font_sm.render(line, True, (215, 228, 245))
            self.surface.blit(surf, (self.width // 2 - surf.get_width() // 2, y))
            y += 28

        # Controls quick guide box
        ctrl_box = pygame.Rect(self.width // 2 - 380, 370, 760, 155)
        pygame.draw.rect(self.surface, (22, 32, 56, 220), ctrl_box, border_radius=8)
        pygame.draw.rect(self.surface, (90, 160, 220, 160), ctrl_box, 1, border_radius=8)

        ctrls = [
            "【核心操作】 [WASD / 方向鍵] 移動   |   [Q / E] 360°旋轉箱庭鏡頭   |   [E / F] 調查 / 拾取 / 開門",
            "【雷射戰鬥】 按住 [滑鼠右鍵 / 空白鍵] 停步雷射瞄準 (準星收束後爆頭雙倍傷害) + [左鍵 / Enter] 射擊",
            "【戰術系統】 [1-4 / 滾輪] 切換四種武器   |   [H] 急救噴霧   |   [G] 投擲手榴彈   |   [TAB / M] 顏色編碼智慧地圖",
            "【復古切換】 [I] 檔案與文獻欄   |   [F1] PS1 CRT濾鏡   |   [F2] 現代/坦克操作切換   |   [F3] 生存/探索無敵模式",
        ]
        cy = 384
        for c_line in ctrls:
            cs = self.font_xs.render(c_line, True, (170, 235, 210))
            self.surface.blit(cs, (ctrl_box.x + 20, cy))
            cy += 32

        pulse = int(185 + 70 * math.sin(t_now * 5.0))
        start_btn = pygame.Rect(self.width // 2 - 220, 548, 440, 48)
        pygame.draw.rect(self.surface, (35, 95, 130, 240), start_btn, border_radius=8)
        pygame.draw.rect(self.surface, (100, 255, 220, pulse), start_btn, 2, border_radius=8)
        btn_txt = self.font_md.render("按 [ENTER / 空白鍵 / 滑鼠點擊] 潛入太陽神穹頂", True, (255, 255, 255))
        self.surface.blit(btn_txt, (start_btn.centerx - btn_txt.get_width() // 2, start_btn.y + 11))
        self.clickable_rects.append((start_btn, "START_GAME"))

        if os.path.exists(session.save_path):
            load_txt = self.font_xs.render("偵測到安全屋存檔記錄：進入遊戲後可按 [F9] 隨時讀取存檔", True, (255, 215, 110))
            self.surface.blit(load_txt, (self.width // 2 - load_txt.get_width() // 2, 608))

    # ========================================================================
    # 3D PROJECTED LABELS & CROSSHAIR
    # ========================================================================
    def _draw_3d_floating_elements(self, session: GameSession, renderer3d: DioramaRenderer3D):
        room = session.current_room

        # Pickup labels when player is close
        for p in room.pickups:
            if not p.collected and math.hypot(session.px - p.x, session.pz - p.z) < 3.6:
                scr = renderer3d.project_to_screen(p.x, 0.85, p.z)
                if scr is not None:
                    lbl = self.font_xs.render(f"◆ {p.name}", True, (255, 240, 150))
                    bg = pygame.Rect(scr[0] - lbl.get_width() // 2 - 6, scr[1] - 12, lbl.get_width() + 12, 22)
                    pygame.draw.rect(self.surface, (10, 14, 26, 190), bg, border_radius=4)
                    self.surface.blit(lbl, (bg.x + 6, bg.y + 2))

        # NPC names
        for npc in room.npcs:
            scr = renderer3d.project_to_screen(npc.x, 2.15, npc.z)
            if scr is not None:
                lbl = self.font_xs.render(npc.name, True, (110, 240, 255))
                self.surface.blit(lbl, (scr[0] - lbl.get_width() // 2, scr[1] - 10))

        # Aiming Laser Reticle projected on 3D hit point
        if session.is_aiming:
            hx, hy, hz = session.laser_hit_point
            scr = renderer3d.project_to_screen(hx, hy, hz)
            if scr is not None:
                sx, sy = scr
                radius = int(24 - session.aim_focus * 15)
                is_crit_ready = session.aim_focus >= 0.82
                col = (255, 60, 90, 240) if is_crit_ready else (255, 210, 80, 210)
                pygame.draw.circle(self.surface, col, (sx, sy), radius, 2)
                pygame.draw.line(self.surface, col, (sx - radius - 5, sy), (sx - 4, sy), 2)
                pygame.draw.line(self.surface, col, (sx + 4, sy), (sx + radius + 5, sy), 2)
                pygame.draw.line(self.surface, col, (sx, sy - radius - 5), (sx, sy - 4), 2)
                pygame.draw.line(self.surface, col, (sx, sy + 4), (sx, sy + radius + 5), 2)
                if is_crit_ready:
                    crit_lbl = self.font_xs.render("LOCK-ON CRIT x2", True, (255, 80, 100))
                    self.surface.blit(crit_lbl, (sx - crit_lbl.get_width() // 2, sy - radius - 20))

        # Floating Damage & Status Numbers
        for ft in session.floating_texts:
            scr = renderer3d.project_to_screen(ft.x, ft.y, ft.z)
            if scr is not None:
                txt = self.font_md.render(ft.text, True, ft.color)
                self.surface.blit(txt, (scr[0] - txt.get_width() // 2, scr[1]))

    # ========================================================================
    # TOP & BOTTOM HUD BARS
    # ========================================================================
    def _draw_top_hud(self, session: GameSession, t_now: float):
        # Top-Left: ECG Heartbeat Monitor & Room Status
        ecg_panel = pygame.Rect(16, 14, 355, 84)
        pygame.draw.rect(self.surface, (12, 18, 32, 215), ecg_panel, border_radius=8)
        pygame.draw.rect(self.surface, (55, 165, 210, 190), ecg_panel, 2, border_radius=8)

        if session.poisoned:
            ecg_col = (210, 95, 255)
            status_str = "CORAL TOXIN (中毒)"
        elif session.hp >= 65:
            ecg_col = (65, 245, 145)
            status_str = "FINE (正常)"
        elif session.hp >= 35:
            ecg_col = (255, 200, 60)
            status_str = "CAUTION (警告)"
        else:
            ecg_col = (255, 65, 75)
            status_str = "DANGER (瀕危)"

        # Animated ECG Waveform
        pts = []
        base_y = 44
        speed = 7.0 if session.hp >= 50 else 12.0
        for ix in range(130):
            phase = (ix * 0.12 - t_now * speed) % (math.pi * 2)
            spike = 0.0
            if 2.6 < phase < 3.0:
                spike = -16.0 * math.sin((phase - 2.6) / 0.4 * math.pi)
            elif 3.0 <= phase < 3.3:
                spike = 11.0 * math.sin((phase - 3.0) / 0.3 * math.pi)
            pts.append((28 + ix, int(base_y + spike)))
        if len(pts) > 2:
            pygame.draw.lines(self.surface, ecg_col, False, pts, 2)

        hp_lbl = self.font_md.render(f"HP {session.hp}/{session.max_hp}", True, ecg_col)
        st_lbl = self.font_xs.render(status_str, True, (220, 230, 245))
        self.surface.blit(hp_lbl, (172, 22))
        self.surface.blit(st_lbl, (172, 48))

        room_state, rem_cnt = session.get_room_completion_state(session.current_room_id)
        badge_col = (70, 245, 185) if room_state == "CLEARED" else (255, 180, 75)
        badge_txt = "★ 區域已完全搜刮" if room_state == "CLEARED" else f"◆ 區域尚餘 {rem_cnt} 項線索/物資"
        rm_lbl = self.font_xs.render(f"【{session.current_room.name}】 {badge_txt}", True, badge_col)
        self.surface.blit(rm_lbl, (28, 72))

        # Top-Right: System Toggles & Metrics Panel
        sys_panel = pygame.Rect(self.width - 435, 14, 419, 84)
        pygame.draw.rect(self.surface, (12, 18, 32, 215), sys_panel, border_radius=8)
        pygame.draw.rect(self.surface, (55, 165, 210, 190), sys_panel, 2, border_radius=8)

        ctrl_mode = "坦克操作(Tank)" if session.tank_controls else "現代360°(Modern)"
        diff_mode = "探索無敵(Explore)" if session.exploration_mode else "生存恐怖(Survival)"
        row1 = self.font_xs.render(
            f"[TAB/M] 智慧地圖  |  [I] 物品文獻({len(session.notes_read)}/12)  |  視角: {int(session.cam_yaw)}° [Q/E]",
            True, (210, 235, 255)
        )
        row2 = self.font_xs.render(
            f"[F1] CRT濾鏡:{'ON' if session.ps1_filter else 'OFF'} | [F2] {ctrl_mode} | [F3] {diff_mode}",
            True, (165, 215, 235)
        )
        row3 = self.font_xs.render(
            f"神諭代幣: {session.oracle_tokens_left}/10  |  隱藏秘密: {len(session.secrets_found)}/{session.total_secrets}  |  [F5]快速存檔 [F9]讀檔",
            True, (255, 220, 125)
        )
        self.surface.blit(row1, (sys_panel.x + 12, 22))
        self.surface.blit(row2, (sys_panel.x + 12, 46))
        self.surface.blit(row3, (sys_panel.x + 12, 70))

        # Boss Health Bar if in Pelagic Core with Boss alive
        for enemy in session.current_room.enemies:
            if enemy.alive and enemy.kind == "boss_swan":
                b_rect = pygame.Rect(self.width // 2 - 230, 18, 460, 34)
                pygame.draw.rect(self.surface, (28, 10, 36, 230), b_rect, border_radius=6)
                fill_w = int(452 * max(0.0, enemy.hp / float(enemy.max_hp)))
                pygame.draw.rect(self.surface, (225, 45, 115), (b_rect.x + 4, b_rect.y + 4, fill_w, 26), border_radius=4)
                pygame.draw.rect(self.surface, (255, 190, 230), b_rect, 2, border_radius=6)
                b_txt = self.font_sm.render(f"{enemy.name}  ({enemy.hp}/{enemy.max_hp})", True, (255, 255, 255))
                self.surface.blit(b_txt, (b_rect.centerx - b_txt.get_width() // 2, b_rect.y + 5))

    def _draw_bottom_hud(self, session: GameSession, t_now: float):
        # Bottom-Left: Weapon, Ammo, Laser Focus & Consumables
        w_panel = pygame.Rect(16, self.height - 96, 430, 80)
        pygame.draw.rect(self.surface, (12, 18, 32, 220), w_panel, border_radius=8)
        pygame.draw.rect(self.surface, (55, 165, 210, 190), w_panel, 2, border_radius=8)

        spec = WEAPON_SPECS[session.current_weapon]
        ammo_cnt = session.ammo.get(spec["ammo_key"], 0)
        w_title = self.font_md.render(f"武器：{spec['name']}", True, (255, 230, 115))
        a_title = self.font_md.render(f"彈藥：{ammo_cnt}", True, (100, 245, 255) if ammo_cnt > 0 else (255, 80, 80))
        self.surface.blit(w_title, (28, self.height - 88))
        self.surface.blit(a_title, (315, self.height - 88))

        # Weapon slots [1-4] + Medkit [H] + Grenade [G]
        slots_str = []
        slot_names = [("pistol", "1:手槍"), ("shotgun", "2:霰彈"), ("flamer", "3:熱熔"), ("magnum", "4:麥格農")]
        for wid, label in slot_names:
            if wid in session.weapons_owned:
                mark = "★" if session.current_weapon == wid else ""
                slots_str.append(f"[{mark}{label}]")
        cons_line = f"{' '.join(slots_str)}  |  [H]急救:{session.medkits}  [G]手榴彈:{session.grenades}"
        c_surf = self.font_xs.render(cons_line, True, (200, 220, 240))
        self.surface.blit(c_surf, (28, self.height - 56))

        # Focus Charge Bar
        pygame.draw.rect(self.surface, (30, 40, 60), (28, self.height - 32, 390, 10), border_radius=4)
        focus_w = int(390 * session.aim_focus)
        f_col = (255, 65, 95) if session.aim_focus >= 0.82 else (70, 220, 255)
        if focus_w > 0:
            pygame.draw.rect(self.surface, f_col, (28, self.height - 32, focus_w, 10), border_radius=4)

        # Interaction Prompt Banner (Center-Bottom)
        prompt = session.get_nearest_interactable_prompt()
        if prompt and session.ui_mode == "PLAYING":
            p_surf = self.font_md.render(prompt, True, (255, 245, 130))
            p_rect = pygame.Rect(
                self.width // 2 - p_surf.get_width() // 2 - 18,
                self.height - 142,
                p_surf.get_width() + 36,
                38,
            )
            pygame.draw.rect(self.surface, (16, 26, 48, 235), p_rect, border_radius=8)
            pygame.draw.rect(self.surface, (255, 220, 90, 230), p_rect, 2, border_radius=8)
            self.surface.blit(p_surf, (p_rect.x + 18, p_rect.y + 6))

        # Toast Message Bar
        if session.toast_timer > 0 and session.toast_message:
            t_surf = self.font_sm.render(session.toast_message, True, (235, 250, 255))
            t_rect = pygame.Rect(
                max(460, self.width - t_surf.get_width() - 46),
                self.height - 68,
                t_surf.get_width() + 30,
                42,
            )
            pygame.draw.rect(self.surface, (18, 28, 52, 230), t_rect, border_radius=8)
            pygame.draw.rect(self.surface, (90, 225, 255, 200), t_rect, 2, border_radius=8)
            self.surface.blit(t_surf, (t_rect.x + 15, t_rect.y + 9))

    # ========================================================================
    # MODAL 1: CROW COUNTRY COLOR-CODED SMART MAP ([TAB] / [M])
    # ========================================================================
    def _draw_smart_map_modal(self, session: GameSession):
        panel = pygame.Rect(self.width // 2 - 440, 75, 880, 560)
        pygame.draw.rect(self.surface, (10, 16, 30, 242), panel, border_radius=12)
        pygame.draw.rect(self.surface, (80, 220, 255, 230), panel, 2, border_radius=12)

        hdr = self.font_lg.render("太陽神穹頂博覽館・智慧戰術地圖 (SMART COMPLETION MAP)", True, (110, 235, 255))
        self.surface.blit(hdr, (panel.centerx - hdr.get_width() // 2, panel.y + 18))

        legend = self.font_xs.render(
            "圖例： [亮青綠] 已完全清空搜刮   |   [琥珀橘] 尚有未解謎題或物資   |   [翡翠藍] 安全屋存檔點   |   [暗灰] 未探索區域",
            True, (205, 225, 240)
        )
        self.surface.blit(legend, (panel.centerx - legend.get_width() // 2, panel.y + 58))

        # Grid origin for 3 cols x 4 rows
        cell_w, cell_h = 225, 92
        gap_x, gap_y = 42, 24
        start_x = panel.centerx - (3 * cell_w + 2 * gap_x) // 2
        start_y = panel.y + 100

        # Draw door connections between rooms first
        for rid, room in session.rooms.items():
            c1, r1 = room.map_grid
            cx1 = start_x + c1 * (cell_w + gap_x) + cell_w // 2
            cy1 = start_y + r1 * (cell_h + gap_y) + cell_h // 2
            for d_name, door in room.doors.items():
                target = session.rooms[door.target_room]
                c2, r2 = target.map_grid
                cx2 = start_x + c2 * (cell_w + gap_x) + cell_w // 2
                cy2 = start_y + r2 * (cell_h + gap_y) + cell_h // 2
                unlocked = door.unlocked or door.lock_id is None
                line_col = (70, 235, 175) if unlocked else (255, 90, 105)
                pygame.draw.line(self.surface, line_col, (cx1, cy1), (cx2, cy2), 4)

        # Draw room cards
        for rid, room in session.rooms.items():
            col, row = room.map_grid
            rx = start_x + col * (cell_w + gap_x)
            ry = start_y + row * (cell_h + gap_y)
            r_rect = pygame.Rect(rx, ry, cell_w, cell_h)

            state, rem_cnt = session.get_room_completion_state(rid)
            if state == "UNVISITED":
                bg_col = (24, 30, 44, 200)
                border_col = (75, 85, 110)
                status_txt = "？？？ (未踏足)"
            elif room.is_save_room and state == "CLEARED":
                bg_col = (18, 68, 65, 240)
                border_col = (80, 255, 220)
                status_txt = "★ 安全屋 (已清空)"
            elif state == "CLEARED":
                bg_col = (18, 65, 52, 240)
                border_col = (75, 255, 165)
                status_txt = "★ CLEAR (搜刮完畢)"
            else:
                bg_col = (72, 42, 22, 240)
                border_col = (255, 175, 70)
                status_txt = f"◆ 尚餘 {rem_cnt} 項物資/謎題"

            pygame.draw.rect(self.surface, bg_col, r_rect, border_radius=8)
            pygame.draw.rect(self.surface, border_col, r_rect, 3 if rid == session.current_room_id else 2, border_radius=8)

            title_str = room.name if room.visited else "未知展區"
            t_surf = self.font_sm.render(title_str, True, (255, 255, 255) if room.visited else (140, 150, 170))
            s_surf = self.font_xs.render(status_txt, True, border_col)
            self.surface.blit(t_surf, (rx + 12, ry + 12))
            self.surface.blit(s_surf, (rx + 12, ry + 40))

            if rid == session.current_room_id:
                you_surf = self.font_xs.render("▲ 林薇拉目前位置", True, (255, 240, 100))
                self.surface.blit(you_surf, (rx + 12, ry + 64))

        ftr = self.font_sm.render("按 [TAB / M / ESC] 關閉地圖返回探索", True, (180, 220, 255))
        self.surface.blit(ftr, (panel.centerx - ftr.get_width() // 2, panel.bottom - 36))

    # ========================================================================
    # MODAL 2: INVENTORY, KEY ITEMS & LORE ARCHIVE ([I])
    # ========================================================================
    def _draw_inventory_modal(self, session: GameSession):
        panel = pygame.Rect(self.width // 2 - 460, 65, 920, 580)
        pygame.draw.rect(self.surface, (12, 18, 34, 244), panel, border_radius=12)
        pygame.draw.rect(self.surface, (90, 220, 255, 230), panel, 2, border_radius=12)

        hdr = self.font_lg.render("戰術手提箱與機密文獻檔案 (INVENTORY & ARCHIVES)", True, (255, 230, 120))
        self.surface.blit(hdr, (panel.x + 26, panel.y + 18))

        # Left column: Weapons & Key Items
        left_box = pygame.Rect(panel.x + 24, panel.y + 68, 360, 455)
        pygame.draw.rect(self.surface, (18, 26, 48, 230), left_box, border_radius=8)
        pygame.draw.rect(self.surface, (65, 140, 195), left_box, 1, border_radius=8)

        w_hdr = self.font_md.render("【持有武器與關鍵道具】", True, (110, 235, 255))
        self.surface.blit(w_hdr, (left_box.x + 14, left_box.y + 12))

        y = left_box.y + 46
        for wid in session.weapons_owned:
            spec = WEAPON_SPECS[wid]
            cnt = session.ammo.get(spec["ammo_key"], 0)
            eq = " (裝備中)" if session.current_weapon == wid else ""
            ws = self.font_xs.render(f"• {spec['name']} — 彈藥: {cnt}{eq}", True, (255, 235, 150))
            self.surface.blit(ws, (left_box.x + 16, y))
            y += 24

        y += 10
        k_hdr = self.font_sm.render("【關鍵鑰匙與星象印記】", True, (130, 250, 190))
        self.surface.blit(k_hdr, (left_box.x + 14, y))
        y += 26
        if not session.key_items:
            none_s = self.font_xs.render("尚未取得特殊徽章或工具", True, (150, 165, 185))
            self.surface.blit(none_s, (left_box.x + 16, y))
            y += 24
        else:
            for kid in sorted(session.key_items):
                kname = session.key_item_names.get(kid, kid)
                ks = self.font_xs.render(f"◆ {kname}", True, (255, 220, 110))
                self.surface.blit(ks, (left_box.x + 16, y))
                y += 24

        # Right column: Collected Lore Notes List & Reader
        right_box = pygame.Rect(panel.x + 404, panel.y + 68, 492, 455)
        pygame.draw.rect(self.surface, (18, 26, 48, 230), right_box, border_radius=8)
        pygame.draw.rect(self.surface, (65, 140, 195), right_box, 1, border_radius=8)

        n_hdr = self.font_md.render(f"【已回收機密文獻 ({len(session.notes_read)}/12)】(點擊或上下鍵切換)", True, (255, 210, 120))
        self.surface.blit(n_hdr, (right_box.x + 14, right_box.y + 12))

        if session.notes_read:
            self.selected_inv_note_idx = max(0, min(self.selected_inv_note_idx, len(session.notes_read) - 1))
            ny = right_box.y + 46
            for idx, nid in enumerate(session.notes_read):
                ndata = LORE_NOTES.get(nid, {})
                is_sel = idx == self.selected_inv_note_idx
                btn_r = pygame.Rect(right_box.x + 12, ny, 468, 22)
                if is_sel:
                    pygame.draw.rect(self.surface, (45, 95, 135, 220), btn_r, border_radius=4)
                nt = self.font_xs.render(ndata.get("title", nid), True, (255, 245, 160) if is_sel else (190, 210, 230))
                self.surface.blit(nt, (btn_r.x + 8, btn_r.y + 2))
                self.clickable_rects.append((btn_r, f"SELECT_NOTE:{idx}"))
                ny += 23

            # Display selected note body at bottom of right_box
            sel_nid = session.notes_read[self.selected_inv_note_idx]
            sel_note = LORE_NOTES.get(sel_nid, {})
            div_y = right_box.y + 245
            pygame.draw.line(self.surface, (80, 160, 210), (right_box.x + 12, div_y), (right_box.right - 12, div_y), 1)
            by = div_y + 10
            for line in sel_note.get("body", "").split("\n"):
                ls = self.font_xs.render(line, True, (225, 240, 250))
                self.surface.blit(ls, (right_box.x + 16, by))
                by += 21

        ftr = self.font_sm.render("按 [上下方向鍵] 翻閱文獻   |   按 [H] 使用急救噴霧   |   按 [I / ESC] 返回遊戲", True, (180, 230, 255))
        self.surface.blit(ftr, (panel.centerx - ftr.get_width() // 2, panel.bottom - 38))

    # ========================================================================
    # MODAL 3: SINGLE DOCUMENT READER (`NOTE_VIEW`)
    # ========================================================================
    def _draw_note_modal(self, session: GameSession):
        note = LORE_NOTES.get(session.active_note_id, {"title": "未知檔案", "date": "", "body": ""})
        panel = pygame.Rect(self.width // 2 - 390, 105, 780, 480)
        pygame.draw.rect(self.surface, (16, 22, 38, 246), panel, border_radius=12)
        pygame.draw.rect(self.surface, (255, 215, 110, 235), panel, 2, border_radius=12)

        t_surf = self.font_lg.render(note["title"], True, (255, 230, 120))
        d_surf = self.font_xs.render(f"檔案日期：{note['date']}", True, (160, 215, 240))
        self.surface.blit(t_surf, (panel.x + 28, panel.y + 24))
        self.surface.blit(d_surf, (panel.x + 28, panel.y + 64))
        pygame.draw.line(self.surface, (100, 150, 190), (panel.x + 28, panel.y + 92), (panel.right - 28, panel.y + 92), 1)

        y = panel.y + 112
        for line in note["body"].split("\n"):
            l_surf = self.font_sm.render(line, True, (235, 242, 250))
            self.surface.blit(l_surf, (panel.x + 32, y))
            y += 30

        close_s = self.font_md.render("按 [E / ENTER / 空白鍵 / ESC] 收起檔案", True, (110, 245, 210))
        self.surface.blit(close_s, (panel.centerx - close_s.get_width() // 2, panel.bottom - 44))

    # ========================================================================
    # MODAL 4: SECURITY KEYPAD PUZZLE (`KEYPAD` - 1986 & 2142)
    # ========================================================================
    def _draw_keypad_modal(self, session: GameSession):
        panel = pygame.Rect(self.width // 2 - 240, 110, 480, 490)
        pygame.draw.rect(self.surface, (14, 22, 36, 246), panel, border_radius=12)
        pygame.draw.rect(self.surface, (90, 235, 200, 235), panel, 2, border_radius=12)

        t_surf = self.font_md.render(session.keypad_title, True, (255, 230, 120))
        self.surface.blit(t_surf, (panel.centerx - t_surf.get_width() // 2, panel.y + 20))

        # Digital LED Display
        led_rect = pygame.Rect(panel.x + 60, panel.y + 64, 360, 64)
        pygame.draw.rect(self.surface, (8, 28, 22), led_rect, border_radius=6)
        pygame.draw.rect(self.surface, (60, 220, 150), led_rect, 2, border_radius=6)
        disp_str = session.keypad_input.ljust(4, "_")
        d_surf = self.font_xl.render(" ".join(disp_str), True, (80, 255, 165))
        self.surface.blit(d_surf, (led_rect.centerx - d_surf.get_width() // 2, led_rect.y + 6))

        # 3x4 Keypad Buttons
        keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "CLR", "0", "ESC"]
        bw, bh = 96, 62
        gx, gy = 18, 14
        sx = panel.centerx - (3 * bw + 2 * gx) // 2
        sy = panel.y + 150

        for idx, k in enumerate(keys):
            c = idx % 3
            r = idx // 3
            brect = pygame.Rect(sx + c * (bw + gx), sy + r * (bh + gy), bw, bh)
            pygame.draw.rect(self.surface, (28, 46, 72), brect, border_radius=8)
            pygame.draw.rect(self.surface, (100, 205, 245), brect, 2, border_radius=8)
            ks = self.font_lg.render(k, True, (255, 255, 255))
            self.surface.blit(ks, (brect.centerx - ks.get_width() // 2, brect.y + 12))
            self.clickable_rects.append((brect, f"KEYPAD:{k}"))

        hint = self.font_xs.render("可直接按鍵盤數字鍵 [0-9] 或滑鼠點擊輸入  |  [ESC] 離開", True, (180, 220, 240))
        self.surface.blit(hint, (panel.centerx - hint.get_width() // 2, panel.bottom - 34))

    # ========================================================================
    # MODAL 5: DOLPHINARIUM HARMONIC ORGAN PUZZLE (`ORGAN` - C-E-G-B)
    # ========================================================================
    def _draw_organ_modal(self, session: GameSession):
        panel = pygame.Rect(self.width // 2 - 350, 130, 700, 430)
        pygame.draw.rect(self.surface, (18, 20, 38, 246), panel, border_radius=12)
        pygame.draw.rect(self.surface, (255, 210, 95, 235), panel, 2, border_radius=12)

        hdr = self.font_lg.render("仿生海豚劇場・諧波管風琴控制台", True, (255, 225, 115))
        self.surface.blit(hdr, (panel.centerx - hdr.get_width() // 2, panel.y + 22))

        sub = self.font_sm.render("請依序彈奏『深海搖籃曲』四個音符以開啟波塞頓號巨顎 (線索見劇場樂譜筆記)", True, (205, 230, 250))
        self.surface.blit(sub, (panel.centerx - sub.get_width() // 2, panel.y + 68))

        seq_str = " ➔ ".join(session.organ_sequence) if session.organ_sequence else "（尚無輸入音符）"
        seq_surf = self.font_md.render(f"目前共鳴序列： {seq_str}", True, (100, 255, 210))
        self.surface.blit(seq_surf, (panel.centerx - seq_surf.get_width() // 2, panel.y + 112))

        notes = [
            ("C", "鍵[1/C] 深海之底 (Do)", (50, 150, 235)),
            ("E", "鍵[2/E] 珊瑚微光 (Mi)", (55, 210, 165)),
            ("G", "鍵[3/G] 潮汐湧動 (Sol)", (235, 175, 60)),
            ("B", "鍵[4/B] 星辰倒影 (Si)", (215, 85, 210)),
        ]
        kw, kh = 142, 165
        gap = 18
        sx = panel.centerx - (4 * kw + 3 * gap) // 2
        sy = panel.y + 168

        for i, (note_code, label, col) in enumerate(notes):
            krect = pygame.Rect(sx + i * (kw + gap), sy, kw, kh)
            pygame.draw.rect(self.surface, col, krect, border_radius=10)
            pygame.draw.rect(self.surface, (255, 255, 255), krect, 2, border_radius=10)
            n_big = self.font_xl.render(note_code, True, (255, 255, 255))
            n_lbl = self.font_xs.render(label, True, (255, 255, 255))
            self.surface.blit(n_big, (krect.centerx - n_big.get_width() // 2, krect.y + 34))
            self.surface.blit(n_lbl, (krect.centerx - n_lbl.get_width() // 2, krect.bottom - 38))
            self.clickable_rects.append((krect, f"ORGAN:{note_code}"))

        ftr = self.font_sm.render("按鍵盤 [1 / 2 / 3 / 4] 或 [C / E / G / B] 或滑鼠點擊琴鍵   |   [ESC] 離開", True, (190, 220, 245))
        self.surface.blit(ftr, (panel.centerx - ftr.get_width() // 2, panel.bottom - 38))

    # ========================================================================
    # MODAL 6: ASTRO-ORACLE 86 FORTUNE TELLER CARD (`ORACLE`)
    # ========================================================================
    def _draw_oracle_modal(self, session: GameSession):
        title, body = session.oracle_card
        panel = pygame.Rect(self.width // 2 - 360, 165, 720, 340)
        pygame.draw.rect(self.surface, (24, 14, 42, 246), panel, border_radius=14)
        pygame.draw.rect(self.surface, (255, 120, 235, 240), panel, 3, border_radius=14)

        hdr = self.font_lg.render("★ 星象神諭機 ASTRO-ORACLE 86 ★", True, (255, 225, 110))
        self.surface.blit(hdr, (panel.centerx - hdr.get_width() // 2, panel.y + 24))

        t_surf = self.font_md.render(title, True, (115, 245, 255))
        self.surface.blit(t_surf, (panel.centerx - t_surf.get_width() // 2, panel.y + 78))

        # Word-wrap body
        words = body
        lines = [words[i:i + 34] for i in range(0, len(words), 34)]
        y = panel.y + 135
        for ln in lines:
            ls = self.font_sm.render(ln, True, (245, 235, 255))
            self.surface.blit(ls, (panel.centerx - ls.get_width() // 2, y))
            y += 32

        rem = self.font_xs.render(f"（剩餘神諭代幣：{session.oracle_tokens_left} / 10 枚 — 按 [E / ENTER / ESC] 收起神諭籤）", True, (255, 195, 130))
        self.surface.blit(rem, (panel.centerx - rem.get_width() // 2, panel.bottom - 42))

    # ========================================================================
    # MODAL 7: SURVIVOR NPC DIALOGUE BOX (`DIALOGUE`)
    # ========================================================================
    def _draw_dialogue_modal(self, session: GameSession):
        panel = pygame.Rect(self.width // 2 - 420, self.height - 230, 840, 175)
        pygame.draw.rect(self.surface, (12, 20, 38, 245), panel, border_radius=12)
        pygame.draw.rect(self.surface, (95, 235, 255, 235), panel, 2, border_radius=12)

        npc = session.active_npc
        if npc is not None:
            name_s = self.font_md.render(f"【{npc.name}】 — {npc.role}", True, (255, 230, 115))
            self.surface.blit(name_s, (panel.x + 24, panel.y + 18))

        text = session.dialogue_text
        lines = [text[i:i + 40] for i in range(0, len(text), 40)]
        y = panel.y + 62
        for ln in lines:
            ls = self.font_sm.render(ln, True, (235, 245, 255))
            self.surface.blit(ls, (panel.x + 28, y))
            y += 30

        cont = self.font_xs.render("按 [E / ENTER / 空白鍵] 繼續交談或結束對話", True, (120, 240, 200))
        self.surface.blit(cont, (panel.right - cont.get_width() - 24, panel.bottom - 30))

    # ========================================================================
    # MODAL 8: VICTORY & CROW COUNTRY S-RANK EVALUATION SCREEN (`VICTORY`)
    # ========================================================================
    def _draw_victory_s_rank_modal(self, session: GameSession):
        pygame.draw.rect(self.surface, (6, 10, 22, 235), (0, 0, self.width, self.height))
        panel = pygame.Rect(self.width // 2 - 440, 55, 880, 610)
        pygame.draw.rect(self.surface, (14, 22, 42, 248), panel, border_radius=14)
        pygame.draw.rect(self.surface, (255, 215, 90, 245), panel, 3, border_radius=14)

        rank, score, reasons = session.calculate_final_rank()

        hdr = self.font_xl.render("《 NEON ARK : 1994 》 通關結算報告", True, (255, 225, 110))
        self.surface.blit(hdr, (panel.centerx - hdr.get_width() // 2, panel.y + 22))

        if session.ending_type == "TRUE_ENDING":
            end_title = "【真結局 TRUE ENDING：跨越淹沒世紀的黎明】"
        else:
            end_title = "【標準結局 GOOD ENDING：逃離太陽神穹頂】"
        et_surf = self.font_md.render(end_title, True, (105, 245, 220))
        self.surface.blit(et_surf, (panel.centerx - et_surf.get_width() // 2, panel.y + 82))

        epilogue = [
            "林薇拉（1992年零號接觸者・林克拉拉）將斯旺博士留下的【逆熵穩定血清】注入左臂。",
            "藍紫色的時間珊瑚結晶逐漸消退，她帶著艾蕾娜與生還者搭乘最後一班救援艇駛離東海人工島。",
            "而在海底三千公尺下，零號時間晶簇已被永久封存——西元 2142 年的毀滅未來，將由活著的人類親手改寫。",
        ]
        y = panel.y + 124
        for ln in epilogue:
            es = self.font_sm.render(ln, True, (225, 235, 250))
            self.surface.blit(es, (panel.centerx - es.get_width() // 2, y))
            y += 28

        # Rank Badge Box
        r_box = pygame.Rect(panel.x + 48, panel.y + 230, 784, 285)
        pygame.draw.rect(self.surface, (20, 32, 58, 235), r_box, border_radius=10)
        pygame.draw.rect(self.surface, (90, 210, 255), r_box, 2, border_radius=10)

        ry = r_box.y + 22
        for r_line in reasons:
            rs = self.font_sm.render(f"• {r_line}", True, (215, 235, 250))
            self.surface.blit(rs, (r_box.x + 28, ry))
            ry += 34

        rank_col = (255, 225, 75) if "S" in rank else (100, 245, 200)
        rank_big = self.font_xl.render(f"最終評價 RANK : 【 {rank} 】 ({score} pts)", True, rank_col)
        self.surface.blit(rank_big, (r_box.centerx - rank_big.get_width() // 2, r_box.bottom - 68))

        ftr = self.font_md.render("按 [R] 重新開始二週目挑戰   |   按 [ESC] 離開遊戲", True, (255, 240, 150))
        self.surface.blit(ftr, (panel.centerx - ftr.get_width() // 2, panel.bottom - 48))

    def _draw_gameover_modal(self, session: GameSession):
        pygame.draw.rect(self.surface, (28, 4, 10, 230), (0, 0, self.width, self.height))
        t1 = self.font_xl.render("YOU WERE CONSUMED BY THE PELAGIC VEIN", True, (255, 70, 85))
        t2 = self.font_lg.render("林薇拉體內的時間珊瑚徹底結晶化……意識永遠迷失於 1994 與 2142 的夾縫中", True, (240, 200, 210))
        t3 = self.font_md.render("按 [F9] 讀取最近存檔   |   按 [R] 重新開始遊戲   |   按 [ESC] 離開", True, (255, 230, 130))
        self.surface.blit(t1, (self.width // 2 - t1.get_width() // 2, self.height // 2 - 80))
        self.surface.blit(t2, (self.width // 2 - t2.get_width() // 2, self.height // 2 - 15))
        self.surface.blit(t3, (self.width // 2 - t3.get_width() // 2, self.height // 2 + 55))
