# -*- coding: utf-8 -*-
"""
NEON ARK: 1994 (霓虹方舟：1994) - Main Game Entrypoint
A 32-bit PS1 Retro Survival Horror 3D Diorama Game inspired by Crow Country (SFB Games).
Built with Python + PyOpenGL + Pygame-CE + NumPy Procedural Audio Synthesizer.
"""

import math
import sys
import pygame

from audio_synth import RetroAudioEngine
from engine_3d import DioramaRenderer3D
from gameplay import GameSession
from ui_hud import RetroHUDRenderer


WINDOW_WIDTH = 1280
WINDOW_HEIGHT = 720
WINDOW_TITLE = "NEON ARK: 1994 (霓虹方舟：1994) — 3D Isometric Survival Horror"


def handle_modal_click(mx: int, my: int, session: GameSession, hud: RetroHUDRenderer, on_title: bool) -> bool:
    """Handles mouse clicks on interactive Keypad, Organ, Inventory, or Title buttons."""
    for rect, action in hud.clickable_rects:
        if rect.collidepoint(mx, my):
            if action == "START_GAME" and on_title:
                session.audio.play("unlock")
                return False
            elif action.startswith("KEYPAD:"):
                key_val = action.split(":", 1)[1]
                if key_val == "ESC":
                    session.ui_mode = "PLAYING"
                else:
                    session.submit_keypad_digit(key_val)
            elif action.startswith("ORGAN:"):
                note_val = action.split(":", 1)[1]
                session.press_organ_note(note_val)
            elif action.startswith("SELECT_NOTE:"):
                idx = int(action.split(":", 1)[1])
                hud.selected_inv_note_idx = idx
                session.audio.play("beep")
            break
    return on_title


def run_game(smoke_test_frames: int = 0):
    pygame.init()
    pygame.display.gl_set_attribute(pygame.GL_DEPTH_SIZE, 24)
    flags = pygame.OPENGL | pygame.DOUBLEBUF
    pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), flags)
    pygame.display.set_caption(WINDOW_TITLE)

    audio = RetroAudioEngine()
    session = GameSession(audio)
    renderer3d = DioramaRenderer3D(WINDOW_WIDTH, WINDOW_HEIGHT)
    hud = RetroHUDRenderer(WINDOW_WIDTH, WINDOW_HEIGHT)

    clock = pygame.time.Clock()
    on_title_screen = smoke_test_frames == 0
    running = True
    frame_count = 0

    while running:
        dt = min(0.05, clock.tick(60) / 1000.0)
        frame_count += 1

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos
                if on_title_screen:
                    on_title_screen = handle_modal_click(mx, my, session, hud, on_title_screen)
                    if on_title_screen and event.button == 1:
                        audio.play("unlock")
                        on_title_screen = False
                elif session.ui_mode != "PLAYING":
                    handle_modal_click(mx, my, session, hud, False)
                    if event.button == 1 and session.ui_mode in ("NOTE_VIEW", "ORACLE", "DIALOGUE"):
                        session.ui_mode = "PLAYING"
                        audio.play("beep")
                else:
                    if event.button == 1 and session.is_aiming:
                        session.fire_current_weapon()
                    elif event.button == 4:
                        _cycle_weapon(session, -1)
                    elif event.button == 5:
                        _cycle_weapon(session, 1)

            elif event.type == pygame.KEYDOWN:
                if on_title_screen:
                    if event.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_e):
                        audio.play("unlock")
                        on_title_screen = False
                    elif event.key == pygame.K_ESCAPE:
                        running = False
                    continue

                # Global Function Hotkeys
                if event.key == pygame.K_F1:
                    session.ps1_filter = not session.ps1_filter
                    session.show_toast(f"PS1 CRT 掃描線濾鏡：{'開啟' if session.ps1_filter else '關閉'}")
                elif event.key == pygame.K_F2:
                    session.tank_controls = not session.tank_controls
                    mode_lbl = "經典坦克式操作 (Tank Controls)" if session.tank_controls else "現代 360° 鏡頭相對操作 (Modern)"
                    session.show_toast(f"操作模式已切換為：{mode_lbl}")
                elif event.key == pygame.K_F3:
                    session.exploration_mode = not session.exploration_mode
                    diff_lbl = "探索模式 (敵人不會攻擊)" if session.exploration_mode else "生存恐怖模式 (標準難度)"
                    session.show_toast(f"難度模式已切換為：{diff_lbl}")
                elif event.key == pygame.K_F5:
                    session.save_to_disk()
                elif event.key == pygame.K_F9:
                    session.load_from_disk()

                # Modal State Input Handling
                if session.ui_mode != "PLAYING":
                    _handle_modal_keydown(event.key, session, hud)
                    continue

                # Playing State Keydowns
                if event.key == pygame.K_ESCAPE:
                    session.ui_mode = "MAP"
                    audio.play("beep")
                elif event.key in (pygame.K_TAB, pygame.K_m):
                    session.ui_mode = "MAP"
                    audio.play("beep")
                elif event.key == pygame.K_i:
                    session.ui_mode = "INVENTORY"
                    audio.play("beep")
                elif event.key in (pygame.K_e, pygame.K_f):
                    session.trigger_interact()
                elif event.key == pygame.K_h:
                    session.use_medkit()
                elif event.key == pygame.K_g:
                    session.throw_grenade()
                elif event.key == pygame.K_z:
                    session.cam_dist = 13.5 if session.cam_dist > 15.0 else 17.5
                elif event.key == pygame.K_1 and "pistol" in session.weapons_owned:
                    session.current_weapon = "pistol"
                    audio.play("beep")
                elif event.key == pygame.K_2 and "shotgun" in session.weapons_owned:
                    session.current_weapon = "shotgun"
                    audio.play("beep")
                elif event.key == pygame.K_3 and "flamer" in session.weapons_owned:
                    session.current_weapon = "flamer"
                    audio.play("beep")
                elif event.key == pygame.K_4 and "magnum" in session.weapons_owned:
                    session.current_weapon = "magnum"
                    audio.play("beep")
                elif event.key == pygame.K_RETURN and session.is_aiming:
                    session.fire_current_weapon()

        # Continuous Polling when PLAYING
        keys = pygame.key.get_pressed()
        mouse_btns = pygame.mouse.get_pressed()

        if on_title_screen:
            # Slowly orbit the 3D diorama camera on the title screen
            session.cam_target_yaw = (session.cam_target_yaw + 14.0 * dt) % 360.0
            session.cam_yaw = session.cam_target_yaw
        elif session.ui_mode == "PLAYING":
            # Rotatable Isometric Camera [Q / E]
            if keys[pygame.K_q]:
                session.cam_target_yaw = (session.cam_target_yaw - 95.0 * dt) % 360.0
            if keys[pygame.K_e] and not session.get_nearest_interactable_prompt():
                session.cam_target_yaw = (session.cam_target_yaw + 95.0 * dt) % 360.0
            elif keys[pygame.K_c]:
                session.cam_target_yaw = (session.cam_target_yaw + 95.0 * dt) % 360.0

            # Movement vector [WASD / Arrow Keys]
            ix = 0.0
            iy = 0.0
            if keys[pygame.K_a] or keys[pygame.K_LEFT]:
                ix -= 1.0
            if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
                ix += 1.0
            if keys[pygame.K_w] or keys[pygame.K_UP]:
                iy += 1.0
            if keys[pygame.K_s] or keys[pygame.K_DOWN]:
                iy -= 1.0

            aim_held = bool(mouse_btns[2] or keys[pygame.K_SPACE] or keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT])
            mx, my = pygame.mouse.get_pos()
            mouse_dir = renderer3d.screen_ray_to_ground(mx, my, session) if aim_held else None

            session.update(dt, (ix, iy), aim_held, mouse_dir)

            # Continuous fire for Flamethrower or held Left Mouse while aiming
            if aim_held and (mouse_btns[0] or keys[pygame.K_RETURN]):
                session.fire_current_weapon()

        # Render 3D OpenGL Scene + Composite 2D Retro HUD
        renderer3d.render_scene(session)
        ui_surf = hud.render(session, renderer3d, on_title_screen=on_title_screen)
        renderer3d.composite_ui_surface(ui_surf)
        pygame.display.flip()

        if smoke_test_frames > 0:
            # Exercise rooms & UI modals during automated smoke test
            if frame_count == 2:
                session.submit_keypad_digit("1")
                session.submit_keypad_digit("9")
                session.submit_keypad_digit("8")
                session.submit_keypad_digit("6")
            elif frame_count == 4:
                session._change_room("nova_plaza", (0.0, 0.0))
                session.ui_mode = "MAP"
            elif frame_count == 6:
                session._change_room("dolphinarium", (0.0, 4.0))
                session.ui_mode = "ORGAN"
                for n in ("C", "E", "G", "B"):
                    session.press_organ_note(n)
            elif frame_count == 8:
                session._change_room("pelagic_core", (0.0, 5.0))
                session.is_aiming = True
                session.fire_current_weapon()
            elif frame_count >= smoke_test_frames:
                rank, score, _ = session.calculate_final_rank()
                print(f"[SMOKE_TEST_OK] Rendered {frame_count} 3D OpenGL frames across rooms. Sample Rank={rank} ({score} pts)")
                running = False

    pygame.quit()


def _cycle_weapon(session: GameSession, step: int):
    if len(session.weapons_owned) <= 1:
        return
    idx = session.weapons_owned.index(session.current_weapon)
    session.current_weapon = session.weapons_owned[(idx + step) % len(session.weapons_owned)]
    session.audio.play("beep")


def _handle_modal_keydown(key: int, session: GameSession, hud: RetroHUDRenderer):
    mode = session.ui_mode
    if mode == "MAP":
        if key in (pygame.K_TAB, pygame.K_m, pygame.K_ESCAPE, pygame.K_e, pygame.K_RETURN):
            session.ui_mode = "PLAYING"
            session.audio.play("beep")
    elif mode == "INVENTORY":
        if key in (pygame.K_i, pygame.K_ESCAPE):
            session.ui_mode = "PLAYING"
            session.audio.play("beep")
        elif key == pygame.K_UP:
            hud.selected_inv_note_idx = max(0, hud.selected_inv_note_idx - 1)
            session.audio.play("beep")
        elif key == pygame.K_DOWN:
            hud.selected_inv_note_idx = min(len(session.notes_read) - 1, hud.selected_inv_note_idx + 1)
            session.audio.play("beep")
        elif key == pygame.K_h:
            session.use_medkit()
    elif mode in ("NOTE_VIEW", "ORACLE", "DIALOGUE"):
        if key in (pygame.K_e, pygame.K_f, pygame.K_RETURN, pygame.K_SPACE, pygame.K_ESCAPE):
            session.ui_mode = "PLAYING"
            session.audio.play("beep")
    elif mode == "KEYPAD":
        if key == pygame.K_ESCAPE:
            session.ui_mode = "PLAYING"
        elif key == pygame.K_BACKSPACE:
            session.submit_keypad_digit("CLR")
        elif pygame.K_0 <= key <= pygame.K_9:
            session.submit_keypad_digit(chr(key))
        elif pygame.K_KP0 <= key <= pygame.K_KP9:
            session.submit_keypad_digit(str(key - pygame.K_KP0))
    elif mode == "ORGAN":
        if key == pygame.K_ESCAPE:
            session.ui_mode = "PLAYING"
        elif key in (pygame.K_1, pygame.K_c):
            session.press_organ_note("C")
        elif key in (pygame.K_2, pygame.K_e):
            session.press_organ_note("E")
        elif key in (pygame.K_3, pygame.K_g):
            session.press_organ_note("G")
        elif key in (pygame.K_4, pygame.K_b):
            session.press_organ_note("B")
    elif mode in ("VICTORY", "GAMEOVER"):
        if key == pygame.K_r:
            session.reset_new_game()
        elif key == pygame.K_ESCAPE:
            pygame.event.post(pygame.event.Event(pygame.QUIT))


if __name__ == "__main__":
    if "--smoke-test" in sys.argv:
        run_game(smoke_test_frames=12)
    else:
        run_game(smoke_test_frames=0)
