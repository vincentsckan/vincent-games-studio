class_name HUDController
extends CanvasLayer
## HUDController.gd
## Real-time Survival Horror HUD featuring:
## - ECG Vitals Monitor (FINE / CAUTION / DANGER / ICHOR_INFECTED)
## - Dynamic Shrinking Aim Reticle & Focus Critical Indicator (0% -> 100%)
## - 3 Difficulty Modes switcher ([F2]: Survival / Exploration / Murder of Crows)
## - Dual Control Scheme switcher ([F4]: Modern Direct / Classic Tank Controls)
## - Typewriter Dialogue, Lore Document Reader, and Puzzle Keypad Modal

@export var player_path: NodePath
@export var retro_post_rect_path: NodePath

var player: PlayerController
var _active_puzzle_id: String = ""

var vitals_label: Label
var weapon_label: Label
var room_banner_label: Label
var edelweiss_label: Label
var mode_badge_label: Label
var reticle_focus_label: Label
var aim_target_label: Label
var interact_prompt_label: Label
var controls_help_label: Label

var dialogue_panel: PanelContainer
var dialogue_speaker_label: Label
var dialogue_body_label: Label

var document_panel: PanelContainer
var document_title_label: Label
var document_body_label: RichTextLabel

var puzzle_panel: PanelContainer
var puzzle_title_label: Label
var puzzle_hint_label: Label
var puzzle_input: LineEdit
var puzzle_feedback_label: Label

var pause_inventory_ui: Control
var title_and_ending_ui: Control
var retro_overlay_rect: ColorRect

func _ready() -> void:
	_build_hud_hierarchy()
	_connect_signals()
	if not player_path.is_empty():
		var p_node := get_node_or_null(player_path) as PlayerController
		if p_node:
			bind_player(p_node)
	_refresh_vitals(GameManager.player_hp, GameManager.player_max_hp, GameManager.player_status)
	_refresh_weapon_hud()
	_refresh_room_banner(GameManager.current_room_id)
	_refresh_edelweiss(GameManager.collected_edelweiss_ids.size(), GameManager.MAX_EDELWEISS_COUNT)

func bind_player(p: PlayerController) -> void:
	player = p
	if player:
		player.interaction_prompt_changed.connect(_on_interaction_prompt_changed)
		if player.weapon_system:
			player.weapon_system.target_locked.connect(_on_laser_target_locked)
			player.weapon_system.weapon_fired.connect(func(_w, _c, _r): _refresh_weapon_hud())
			player.weapon_system.reticle_focus_changed.connect(_on_reticle_focus_changed)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_F2:
			GameManager.cycle_game_mode()
			AudioManager.play_synth_sfx("ui_click")
			_refresh_mode_badge()
		elif event.keycode == KEY_F3:
			GameManager.retro_filter_active = not GameManager.retro_filter_active
			_apply_retro_overlay(GameManager.retro_filter_active)
			AudioManager.play_synth_sfx("ui_click")
			_refresh_mode_badge()
		elif event.keycode == KEY_F4:
			GameManager.toggle_control_scheme()
			AudioManager.play_synth_sfx("ui_click")
			_refresh_mode_badge()

	if (event.is_action_pressed("inventory") or event.is_action_pressed("map")) and not DialogueManager.is_dialogue_active and not puzzle_panel.visible:
		if pause_inventory_ui:
			pause_inventory_ui.visible = not pause_inventory_ui.visible
			if pause_inventory_ui.visible and pause_inventory_ui.has_method("refresh_all_tabs"):
				pause_inventory_ui.call("refresh_all_tabs", event.is_action_pressed("map"))
			AudioManager.play_synth_sfx("ui_click")

func _build_hud_hierarchy() -> void:
	# A screen-texture ColorRect paints black on the WebGL export and hides the
	# 3D view. Keep the overlay transparent until the player opts into F3.
	retro_overlay_rect = ColorRect.new()
	retro_overlay_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	retro_overlay_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	retro_overlay_rect.color = Color(0, 0, 0, 0)
	add_child(retro_overlay_rect)

	var top_left := PanelContainer.new()
	top_left.position = Vector2(24, 20)
	top_left.custom_minimum_size = Vector2(465, 155)
	add_child(top_left)

	var tl_vbox := VBoxContainer.new()
	tl_vbox.add_theme_constant_override("separation", 6)
	top_left.add_child(tl_vbox)

	room_banner_label = Label.new()
	room_banner_label.add_theme_font_size_override("font_size", 19)
	room_banner_label.modulate = Color(0.95, 0.88, 0.68)
	tl_vbox.add_child(room_banner_label)

	vitals_label = Label.new()
	vitals_label.add_theme_font_size_override("font_size", 18)
	tl_vbox.add_child(vitals_label)

	weapon_label = Label.new()
	weapon_label.add_theme_font_size_override("font_size", 17)
	weapon_label.modulate = Color(0.82, 0.9, 1.0)
	tl_vbox.add_child(weapon_label)

	edelweiss_label = Label.new()
	edelweiss_label.add_theme_font_size_override("font_size", 15)
	edelweiss_label.modulate = Color(0.75, 0.95, 0.88)
	tl_vbox.add_child(edelweiss_label)

	mode_badge_label = Label.new()
	mode_badge_label.add_theme_font_size_override("font_size", 14)
	tl_vbox.add_child(mode_badge_label)
	_refresh_mode_badge()

	var top_right := PanelContainer.new()
	top_right.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	top_right.position = Vector2(-460, 20)
	top_right.custom_minimum_size = Vector2(435, 145)
	add_child(top_right)

	controls_help_label = Label.new()
	controls_help_label.add_theme_font_size_override("font_size", 14)
	controls_help_label.modulate = Color(0.86, 0.88, 0.92)
	controls_help_label.text = (
		"【操作指南 — 完整參照《Crow Country》系統】\n" +
		"• 移動: [WASD] | 旋轉等距 45° 鏡頭: [Q]/[E] 或滑鼠中鍵\n" +
		"• 雷射瞄準+準星收縮: 按住 [右鍵] 站立 1 秒提升爆頭率\n" +
		"• 開火: [左鍵] | 裝填: [R] | 閃避: [Shift] | 調查: [F]\n" +
		"• 手提箱與箱庭地圖: [Tab] / [M] | 手電筒: [T]\n" +
		"• [F2] 難度(生存/探索/謀殺之鴉) | [F4] 現代/坦克操作"
	)
	top_right.add_child(controls_help_label)

	# Shrinking Aim Reticle & Target Lock Display
	reticle_focus_label = Label.new()
	reticle_focus_label.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	reticle_focus_label.position = Vector2(-280, -222)
	reticle_focus_label.custom_minimum_size = Vector2(560, 32)
	reticle_focus_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	reticle_focus_label.add_theme_font_size_override("font_size", 18)
	reticle_focus_label.visible = false
	add_child(reticle_focus_label)

	aim_target_label = Label.new()
	aim_target_label.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	aim_target_label.position = Vector2(-260, -185)
	aim_target_label.custom_minimum_size = Vector2(520, 32)
	aim_target_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	aim_target_label.add_theme_font_size_override("font_size", 19)
	add_child(aim_target_label)

	interact_prompt_label = Label.new()
	interact_prompt_label.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	interact_prompt_label.position = Vector2(-280, -145)
	interact_prompt_label.custom_minimum_size = Vector2(560, 36)
	interact_prompt_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	interact_prompt_label.add_theme_font_size_override("font_size", 21)
	interact_prompt_label.modulate = Color(1.0, 0.92, 0.55)
	add_child(interact_prompt_label)

	dialogue_panel = PanelContainer.new()
	dialogue_panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	dialogue_panel.position = Vector2(-420, -210)
	dialogue_panel.custom_minimum_size = Vector2(840, 175)
	dialogue_panel.visible = false
	add_child(dialogue_panel)

	var d_vbox := VBoxContainer.new()
	d_vbox.add_theme_constant_override("separation", 10)
	dialogue_panel.add_child(d_vbox)

	dialogue_speaker_label = Label.new()
	dialogue_speaker_label.add_theme_font_size_override("font_size", 20)
	dialogue_speaker_label.modulate = Color(0.95, 0.76, 0.32)
	d_vbox.add_child(dialogue_speaker_label)

	dialogue_body_label = Label.new()
	dialogue_body_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	dialogue_body_label.add_theme_font_size_override("font_size", 18)
	d_vbox.add_child(dialogue_body_label)

	document_panel = PanelContainer.new()
	document_panel.set_anchors_preset(Control.PRESET_CENTER)
	document_panel.position = Vector2(-380, -250)
	document_panel.custom_minimum_size = Vector2(760, 500)
	document_panel.visible = false
	add_child(document_panel)

	var doc_vbox := VBoxContainer.new()
	doc_vbox.add_theme_constant_override("separation", 12)
	document_panel.add_child(doc_vbox)

	document_title_label = Label.new()
	document_title_label.add_theme_font_size_override("font_size", 22)
	document_title_label.modulate = Color(0.98, 0.85, 0.45)
	doc_vbox.add_child(document_title_label)

	document_body_label = RichTextLabel.new()
	document_body_label.custom_minimum_size = Vector2(720, 390)
	document_body_label.add_theme_font_size_override("normal_font_size", 18)
	doc_vbox.add_child(document_body_label)

	var close_doc_btn := Button.new()
	close_doc_btn.text = "關閉文件 [F / Esc]"
	close_doc_btn.pressed.connect(func(): DialogueManager.close_lore_document())
	doc_vbox.add_child(close_doc_btn)

	puzzle_panel = PanelContainer.new()
	puzzle_panel.set_anchors_preset(Control.PRESET_CENTER)
	puzzle_panel.position = Vector2(-300, -180)
	puzzle_panel.custom_minimum_size = Vector2(600, 340)
	puzzle_panel.visible = false
	add_child(puzzle_panel)

	var p_vbox := VBoxContainer.new()
	p_vbox.add_theme_constant_override("separation", 12)
	puzzle_panel.add_child(p_vbox)

	puzzle_title_label = Label.new()
	puzzle_title_label.add_theme_font_size_override("font_size", 22)
	puzzle_title_label.modulate = Color(0.95, 0.82, 0.38)
	p_vbox.add_child(puzzle_title_label)

	puzzle_hint_label = Label.new()
	puzzle_hint_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	puzzle_hint_label.add_theme_font_size_override("font_size", 16)
	p_vbox.add_child(puzzle_hint_label)

	puzzle_input = LineEdit.new()
	puzzle_input.placeholder_text = "請輸入密碼數字 (例如：0415 / 13542 / 85 / 440)"
	puzzle_input.add_theme_font_size_override("font_size", 22)
	p_vbox.add_child(puzzle_input)

	puzzle_feedback_label = Label.new()
	puzzle_feedback_label.add_theme_font_size_override("font_size", 16)
	p_vbox.add_child(puzzle_feedback_label)

	var p_btn_row := HBoxContainer.new()
	p_btn_row.add_theme_constant_override("separation", 16)
	p_vbox.add_child(p_btn_row)

	var submit_btn := Button.new()
	submit_btn.text = "確認輸入機關密碼"
	submit_btn.pressed.connect(_on_puzzle_submit_pressed)
	p_btn_row.add_child(submit_btn)

	var cancel_btn := Button.new()
	cancel_btn.text = "取消離開"
	cancel_btn.pressed.connect(func(): puzzle_panel.visible = false)
	p_btn_row.add_child(cancel_btn)

	var PauseUIScript := load("res://src/ui/PauseInventoryUI.gd")
	if PauseUIScript:
		pause_inventory_ui = PauseUIScript.new()
		pause_inventory_ui.visible = false
		add_child(pause_inventory_ui)

	var TitleEndingScript := load("res://src/ui/TitleAndEndingUI.gd")
	if TitleEndingScript:
		title_and_ending_ui = TitleEndingScript.new()
		title_and_ending_ui.visible = true
		add_child(title_and_ending_ui)

func _apply_retro_overlay(enabled: bool) -> void:
	if retro_overlay_rect == null:
		return
	if not enabled:
		retro_overlay_rect.material = null
		retro_overlay_rect.color = Color(0, 0, 0, 0)
		return
	var sh := load("res://assets/shaders/retro_diorama_post.gdshader") as Shader
	if sh == null:
		return
	var sm := ShaderMaterial.new()
	sm.shader = sh
	sm.set_shader_parameter("retro_mode_enabled", true)
	retro_overlay_rect.material = sm
	retro_overlay_rect.color = Color(1, 1, 1, 1)

func _connect_signals() -> void:
	GameManager.player_vitals_changed.connect(_refresh_vitals)
	GameManager.room_state_updated.connect(_refresh_room_banner)
	GameManager.edelweiss_collected.connect(_refresh_edelweiss)
	GameManager.game_mode_changed.connect(func(_m): _refresh_mode_badge())
	GameManager.control_scheme_changed.connect(func(_c): _refresh_mode_badge())
	InventoryManager.inventory_updated.connect(_refresh_weapon_hud)
	InventoryManager.weapon_equipped.connect(func(_w): _refresh_weapon_hud())

	DialogueManager.dialogue_started.connect(func(_s, _l): dialogue_panel.visible = true)
	DialogueManager.dialogue_line_advanced.connect(_on_dialogue_line_advanced)
	DialogueManager.dialogue_finished.connect(func(): dialogue_panel.visible = false)
	DialogueManager.document_opened.connect(_on_document_opened)
	DialogueManager.document_closed.connect(func(): document_panel.visible = false)
	DialogueManager.puzzle_modal_requested.connect(_on_puzzle_modal_requested)

func _on_reticle_focus_changed(focus_ratio: float, aiming_active: bool) -> void:
	if reticle_focus_label == null:
		return
	reticle_focus_label.visible = aiming_active
	if not aiming_active:
		return
	var pct: int = int(focus_ratio * 100.0)
	var pad_spaces: int = int((1.0 - focus_ratio) * 6.0)
	var space_str: String = " ".repeat(pad_spaces)
	if pct >= 95:
		reticle_focus_label.text = "🎯 準星收縮完成 [%s+%s] (%d%% — ★弱點暴擊率 MAX★)" % [space_str, space_str, pct]
		reticle_focus_label.modulate = Color(1.0, 0.85, 0.22)
	else:
		reticle_focus_label.text = "⌖ 準星收縮聚焦中 [%s+%s] (%d%%)" % [space_str, space_str, pct]
		reticle_focus_label.modulate = Color(0.82, 0.92, 1.0)

func _refresh_vitals(hp: float, max_hp: float, status: String) -> void:
	if vitals_label == null:
		return
	vitals_label.text = "♥ 生命體徵 (ECG): %d / %d  [%s]" % [int(hp), int(max_hp), status]
	match status:
		"FINE":
			vitals_label.modulate = Color(0.32, 0.95, 0.52)
		"CAUTION":
			vitals_label.modulate = Color(0.98, 0.85, 0.25)
		"DANGER":
			vitals_label.modulate = Color(1.0, 0.28, 0.25)
		"ICHOR_INFECTED":
			vitals_label.modulate = Color(0.85, 0.38, 0.98)

func _refresh_weapon_hud() -> void:
	if weapon_label == null:
		return
	var w_id: String = InventoryManager.equipped_weapon_id
	var st: Dictionary = InventoryManager.weapon_states.get(w_id, {})
	if st.is_empty():
		weapon_label.text = "裝備武器：無"
		return
	var reserve: int = InventoryManager.get_item_count(String(st["ammo_item_id"]))
	weapon_label.text = "⌖ 武器：【%s】 彈匣: %d / %d (備彈: %d)" % [
		String(st["name"]), int(st["clip"]), int(st["max_clip"]), reserve
	]

func _refresh_room_banner(room_id: String) -> void:
	if room_banner_label == null:
		return
	var r_info: Dictionary = GameManager.room_database.get(room_id, {})
	var r_name: String = String(r_info.get("name", room_id))
	var rem: int = int(r_info.get("remaining_items", 0))
	var status_tag: String = "✓ 已完全搜刮" if rem == 0 else ("尚有 %d 項線索/物資" % rem)
	room_banner_label.text = "📍 %s (%s)" % [r_name, status_tag]

func _refresh_edelweiss(collected: int, max_count: int) -> void:
	if edelweiss_label:
		var rank_info: Dictionary = GameManager.calculate_survival_rank()
		edelweiss_label.text = "❄ 水晶雪絨花: %d / %d   |   評價預測: 【%s 級】" % [
			collected, max_count, String(rank_info["rank"])
		]

func _refresh_mode_badge() -> void:
	if mode_badge_label == null:
		return
	var m_str: String = "生存模式 (Survival)"
	if GameManager.current_mode == GameManager.GameMode.EXPLORATION_ONLY:
		m_str = "探索模式 (Exploration)"
	elif GameManager.current_mode == GameManager.GameMode.MURDER_OF_CROWS:
		m_str = "☠ 謀殺之鴉 (Murder of Crows)"

	var c_str: String = "經典坦克操作 (Tank)" if GameManager.control_scheme == GameManager.ControlScheme.TANK_CONTROLS else "現代全向移動 (Direct)"
	mode_badge_label.text = "⚙ 難度: %s  |  操作: %s" % [m_str, c_str]

func _on_interaction_prompt_changed(prompt_text: String) -> void:
	if interact_prompt_label:
		interact_prompt_label.text = prompt_text

func _on_laser_target_locked(target_name: String, is_weakpoint: bool) -> void:
	if aim_target_label == null:
		return
	aim_target_label.text = target_name
	aim_target_label.modulate = Color(1.0, 0.25, 0.25) if is_weakpoint else Color(0.95, 0.88, 0.72)

func _on_dialogue_line_advanced(speaker: String, line_text: String, idx: int, total: int) -> void:
	dialogue_speaker_label.text = "▸ %s (%d/%d) — 按 [F] 或 [左鍵] 繼續" % [speaker, idx + 1, total]
	dialogue_body_label.text = line_text

func _on_document_opened(title: String, date_str: String, body: String) -> void:
	document_panel.visible = true
	document_title_label.text = "%s  (%s)" % [title, date_str]
	document_body_label.text = body

func _on_puzzle_modal_requested(puzzle_id: String, title: String, hint: String) -> void:
	_active_puzzle_id = puzzle_id
	puzzle_title_label.text = title
	puzzle_hint_label.text = hint
	puzzle_input.text = ""
	puzzle_feedback_label.text = ""
	puzzle_panel.visible = true
	puzzle_input.grab_focus()

func open_ending_report() -> void:
	if title_and_ending_ui and title_and_ending_ui.has_method("show_ending_rank_report"):
		title_and_ending_ui.call("show_ending_rank_report")

func _on_puzzle_submit_pressed() -> void:
	var code: String = puzzle_input.text.strip_edges()
	var puzzles: Array[Node] = get_tree().get_nodes_in_group("puzzles")
	for p in puzzles:
		if p.get("puzzle_id") == _active_puzzle_id and p.has_method("verify_code_submission"):
			var ok: bool = bool(p.call("verify_code_submission", code))
			if ok:
				puzzle_panel.visible = false
				return
	puzzle_feedback_label.text = "✗ 機關毫無反應，密碼似乎不正確。"
	puzzle_feedback_label.modulate = Color(1.0, 0.35, 0.35)
