class_name TitleAndEndingUI
extends PanelContainer
## TitleAndEndingUI.gd
## Provides:
## 1. Interactive Startup Title Overlay (Difficulty Mode selection: Survival / Exploration / Murder of Crows,
##    Control Scheme selection: Modern Direct vs. Classic Tank Controls, and Tape Load)
## 2. Post-Game S-Rank Victory Report Card & New Game+ Bonus Unlocks (Crow Country style).

var title_box: VBoxContainer
var ending_box: VBoxContainer
var ending_report_label: RichTextLabel

func _ready() -> void:
	# Center anchors plus a one-sided position used to collapse this panel to
	# size (0, 0) at (-430, -270), so the startup menu never appeared.
	custom_minimum_size = Vector2(860, 540)
	size = custom_minimum_size
	mouse_filter = Control.MOUSE_FILTER_STOP
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.05, 0.07, 0.12, 0.94)
	style.border_color = Color(0.96, 0.85, 0.48)
	style.set_border_width_all(2)
	style.set_corner_radius_all(10)
	style.content_margin_left = 28
	style.content_margin_right = 28
	style.content_margin_top = 24
	style.content_margin_bottom = 24
	add_theme_stylebox_override("panel", style)
	_center_on_viewport()
	if not get_viewport().size_changed.is_connected(_center_on_viewport):
		get_viewport().size_changed.connect(_center_on_viewport)
	_build_ui()

func _center_on_viewport() -> void:
	if size.x < 100.0 or size.y < 100.0:
		size = custom_minimum_size
	var vp := get_viewport_rect().size
	position = (vp - size) * 0.5

func _build_ui() -> void:
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 28)
	margin.add_theme_constant_override("margin_right", 28)
	margin.add_theme_constant_override("margin_top", 24)
	margin.add_theme_constant_override("margin_bottom", 24)
	add_child(margin)

	# 1. Startup Title / Mode Selection Screen
	title_box = VBoxContainer.new()
	title_box.add_theme_constant_override("separation", 14)
	margin.add_child(title_box)

	var main_title := Label.new()
	main_title.text = "《霧嶺療養院：白鴉之冬》\nEISWALD SANATORIUM: WINTER OF THE WHITE CROW"
	main_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	main_title.add_theme_font_size_override("font_size", 26)
	main_title.modulate = Color(0.96, 0.85, 0.48)
	title_box.add_child(main_title)

	var subtitle := Label.new()
	subtitle.text = "1991 阿爾卑斯山箱庭生存恐怖 — 四大主題園區（童話鎮・鬧鬼山丘・海洋王國・地下挖掘場）"
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 16)
	subtitle.modulate = Color(0.78, 0.86, 0.95)
	title_box.add_child(subtitle)

	var desc := Label.new()
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.text = (
		"請選擇你的遊戲難度與操作模式（進入遊戲後亦可隨時按 [F2] 切換難度、[F4] 切換現代/坦克操作）：\n" +
		"• 生存模式 (Survival Mode)：標準生存恐怖體驗，有限彈藥、急救噴霧與環境陷阱。\n" +
		"• 探索模式 (Exploration Mode)：所有怪物不會主動攻擊，無壓力漫步樂園解謎與體驗完整故事。\n" +
		"• 謀殺之鴉模式 (Murder of Crows)：高難度極限生存，敵人速度與攻擊力大幅提升且附帶白髓劇毒！"
	)
	desc.add_theme_font_size_override("font_size", 16)
	title_box.add_child(desc)

	var mode_row := HBoxContainer.new()
	mode_row.alignment = BoxContainer.ALIGNMENT_CENTER
	mode_row.add_theme_constant_override("separation", 16)
	title_box.add_child(mode_row)

	var btn_survival := Button.new()
	btn_survival.text = "▶ 開始【生存模式】(標準)"
	btn_survival.custom_minimum_size = Vector2(240, 48)
	btn_survival.pressed.connect(func(): _start_with_mode(GameManager.GameMode.SURVIVAL_HORROR))
	mode_row.add_child(btn_survival)

	var btn_explore := Button.new()
	btn_explore.text = "🔍 開始【探索模式】(純解謎)"
	btn_explore.custom_minimum_size = Vector2(240, 48)
	btn_explore.pressed.connect(func(): _start_with_mode(GameManager.GameMode.EXPLORATION_ONLY))
	mode_row.add_child(btn_explore)

	var btn_crows := Button.new()
	btn_crows.text = "☠ 開始【謀殺之鴉】(極限難度)"
	btn_crows.custom_minimum_size = Vector2(250, 48)
	btn_crows.pressed.connect(func(): _start_with_mode(GameManager.GameMode.MURDER_OF_CROWS))
	mode_row.add_child(btn_crows)

	var ctrl_row := HBoxContainer.new()
	ctrl_row.alignment = BoxContainer.ALIGNMENT_CENTER
	ctrl_row.add_theme_constant_override("separation", 16)
	title_box.add_child(ctrl_row)

	var btn_modern := Button.new()
	btn_modern.text = "操作方式：現代全方向移動 (預設)"
	btn_modern.pressed.connect(func():
		GameManager.control_scheme = GameManager.ControlScheme.MODERN_DIRECT
		GameManager.control_scheme_changed.emit(GameManager.control_scheme)
		AudioManager.play_synth_sfx("ui_click")
	)
	ctrl_row.add_child(btn_modern)

	var btn_tank := Button.new()
	btn_tank.text = "操作方式：經典坦克式操作 (Tank Controls)"
	btn_tank.pressed.connect(func():
		GameManager.control_scheme = GameManager.ControlScheme.TANK_CONTROLS
		GameManager.control_scheme_changed.emit(GameManager.control_scheme)
		AudioManager.play_synth_sfx("ui_click")
	)
	ctrl_row.add_child(btn_tank)

	var btn_load := Button.new()
	btn_load.text = "📼 讀取安全屋第 #1 號盤式磁帶存檔"
	btn_load.pressed.connect(func():
		var data := SaveManager.load_from_tape(1)
		if not data.is_empty():
			visible = false
	)
	ctrl_row.add_child(btn_load)

	# 2. Post-Game S-Rank Victory Report Screen
	ending_box = VBoxContainer.new()
	ending_box.visible = false
	ending_box.add_theme_constant_override("separation", 14)
	margin.add_child(ending_box)

	var end_header := Label.new()
	end_header.text = "🏆 霧嶺調查結案報告 — 通關評級與獎勵結算 🏆"
	end_header.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	end_header.add_theme_font_size_override("font_size", 25)
	end_header.modulate = Color(0.98, 0.86, 0.42)
	ending_box.add_child(end_header)

	ending_report_label = RichTextLabel.new()
	ending_report_label.bbcode_enabled = true
	ending_report_label.custom_minimum_size = Vector2(780, 340)
	ending_report_label.add_theme_font_size_override("normal_font_size", 18)
	ending_box.add_child(ending_report_label)

	var ng_btn := Button.new()
	ng_btn.text = "★ 領取通關獎勵武器並繼續探索霧嶺 (New Game+ Bonus) ★"
	ng_btn.custom_minimum_size = Vector2(420, 48)
	ng_btn.pressed.connect(_on_claim_ng_plus_bonus)
	ending_box.add_child(ng_btn)

func _start_with_mode(mode: GameManager.GameMode) -> void:
	GameManager.set_game_mode(mode)
	AudioManager.play_synth_sfx("puzzle_solved")
	visible = false

func show_ending_rank_report() -> void:
	title_box.visible = false
	ending_box.visible = true
	visible = true
	AudioManager.play_synth_sfx("puzzle_solved")

	var r: Dictionary = GameManager.calculate_survival_rank()
	var sb: String = "[b][color=#ffe66d]【結局：白鴉之冬的終焉】[/color][/b]\n"
	sb += "特別調查員 薇拉·林德奎斯特 成功摧毀了地底 300 公尺的『白髓母體核心』，並帶回了亞歷山大·范斯利用四大主題園區掩蓋活體實驗的完整鐵證。\n\n"
	sb += "[b][color=#4cd964]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[/color][/b]\n"
	sb += "• 最終通關評級：[b][color=#4cd964]【 %s 級 】[/color][/b] （綜合得分：%d 分）\n" % [String(r["rank"]), int(r["score"])]
	sb += "• 總通關時間：%s\n" % String(r["play_time_formatted"])
	sb += "• 醫療耗材使用次數：%d 次\n" % int(r["heals_used"])
	sb += "• 雪山神諭算命機提示次數：%d 次\n" % int(r["oracle_hints_used"])
	sb += "• 水晶雪絨花收集數：%s\n" % String(r["edelweiss_found"])
	sb += "• 雷射瞄準命中率：%s\n" % String(r["accuracy"])
	sb += "• 解鎖通關特典獎勵：[b][color=#5ac8fa]%s[/color][/b]\n" % String(r["reward"])
	sb += "[b][color=#4cd964]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[/color][/b]\n"
	ending_report_label.text = sb

func _on_claim_ng_plus_bonus() -> void:
	# Grant infinite ammo reserves & max upgrades for New Game+ exploration!
	InventoryManager.add_item("weapon_white_crow_magnum", 1)
	InventoryManager.add_item("weapon_geothermal_flamethrower", 1)
	InventoryManager.add_item("ammo_44magnum", 18)
	InventoryManager.add_item("ammo_fuel_tank", 100)
	InventoryManager.add_item("first_aid_spray", 3)
	AudioManager.play_synth_sfx("item_pickup")
	visible = false
