shader_type spatial;
render_mode blend_add, depth_draw_never, cull_disabled, unshaded;

uniform vec4 laser_color : source_color = vec4(1.0, 0.12, 0.18, 0.9);
uniform float core_intensity : hint_range(0.5, 10.0) = 3.8;
uniform float pulse_speed : hint_range(0.0, 20.0) = 6.0;
uniform float fade_distance : hint_range(1.0, 50.0) = 18.0;

varying float local_z;

void vertex() {
	local_z = abs(VERTEX.y);
}

void fragment() {
	float radial = clamp(1.0 - abs(UV.x - 0.5) * 2.0, 0.0, 1.0);
	float core = pow(radial, 3.0);
	float pulse = 0.88 + 0.12 * sin(TIME * pulse_speed - local_z * 4.0);
	float dist_atten = clamp(1.0 - (local_z / fade_distance), 0.0, 1.0);

	ALBEDO = laser_color.rgb * core_intensity * pulse;
	ALPHA = core * laser_color.a * dist_atten;
}
