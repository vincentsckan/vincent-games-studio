shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back, diffuse_burley, specular_schlick_ggx;

uniform vec4 base_albedo : source_color = vec4(0.18, 0.14, 0.11, 1.0);
uniform vec4 snow_albedo : source_color = vec4(0.88, 0.93, 0.98, 1.0);
uniform float base_roughness : hint_range(0.0, 1.0) = 0.78;
uniform float snow_roughness : hint_range(0.0, 1.0) = 0.35;
uniform float snow_metallic : hint_range(0.0, 1.0) = 0.05;
uniform float snow_threshold : hint_range(-1.0, 1.0) = 0.35;
uniform float snow_blend_sharpness : hint_range(1.0, 32.0) = 8.0;
uniform float frost_sparkle_intensity : hint_range(0.0, 2.0) = 0.45;

varying vec3 world_normal;
varying vec3 world_pos;

float hash31(vec3 p) {
	p = fract(p * 0.1031);
	p += dot(p, p.yzx + 33.33);
	return fract((p.x + p.y) * p.z);
}

void vertex() {
	world_normal = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
	world_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	float up_dot = dot(world_normal, vec3(0.0, 1.0, 0.0));
	float noise = hash31(floor(world_pos * 18.0)) * 0.15;
	float snow_mask = clamp((up_dot + noise - snow_threshold) * snow_blend_sharpness, 0.0, 1.0);

	float sparkle = pow(hash31(floor(world_pos * 60.0 + VIEW * 4.0)), 14.0) * frost_sparkle_intensity * snow_mask;
	vec3 final_color = mix(base_albedo.rgb, snow_albedo.rgb + vec3(sparkle), snow_mask);

	ALBEDO = final_color;
	ROUGHNESS = mix(base_roughness, snow_roughness, snow_mask);
	METALLIC = mix(0.05, snow_metallic, snow_mask);
	SPECULAR = mix(0.4, 0.75, snow_mask);
}
