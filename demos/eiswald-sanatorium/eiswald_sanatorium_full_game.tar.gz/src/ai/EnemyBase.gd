class_name EnemyBase
extends CharacterBody3D
## EnemyBase.gd
## Survival Horror AI for "The Retained / Hollow Guests" (滯留住客) and "Porcelain Lurkers".
## Respects GameManager.GameMode.EXPLORATION_ONLY (disables aggression in Exploration Mode),
## reacts to locational laser-sight shots (Headshot stagger, Leg cripple, Incendiary burn),
## and executes proximity lunge attacks.

enum AIState {
	IDLE = 0,
	PATROL = 1,
	CHASE = 2,
	STAGGERED = 3,
	ATTACK_COOLDOWN = 4,
	DEAD = 5
}

@export var enemy_title: String = "白髓滯留住客"
@export var max_hp: float = 90.0
@export var move_speed: float = 2.15
@export var detection_radius: float = 9.5
@export var attack_range: float = 1.45
@export var attack_damage: float = 22.0
@export var inflicts_ichor_infection: bool = true
@export var patrol_offset_a: Vector3 = Vector3(-3.0, 0.0, 0.0)
@export var patrol_offset_b: Vector3 = Vector3(3.0, 0.0, 0.0)

var current_hp: float = 90.0
var state: AIState = AIState.PATROL
var is_dead: bool = false
var is_leg_crippled: bool = false
var _spawn_origin: Vector3 = Vector3.ZERO
var _patrol_to_b: bool = true
var _state_timer: float = 0.0
var _gravity: float = 22.0

@onready var mesh_pivot: Node3D = $MeshPivot

func _ready() -> void:
	add_to_group("enemies")
	current_hp = max_hp
	_spawn_origin = global_position
	var anim := ProceduralAnimController.new()
	anim.target_pivot = mesh_pivot
	add_child(anim)
	GameManager.game_mode_changed.connect(_on_game_mode_changed)
	_on_game_mode_changed(GameManager.current_mode)

func _on_game_mode_changed(new_mode: int) -> void:
	var exploration: bool = (new_mode == GameManager.GameMode.EXPLORATION_ONLY)
	visible = not exploration and not is_dead
	set_physics_process(not exploration and not is_dead)

func _physics_process(delta: float) -> void:
	if is_dead or GameManager.current_mode == GameManager.GameMode.EXPLORATION_ONLY:
		return

	if not is_on_floor():
		velocity.y -= _gravity * delta
	else:
		velocity.y = -0.1

	if _state_timer > 0.0:
		_state_timer -= delta
		if _state_timer <= 0.0 and (state == AIState.STAGGERED or state == AIState.ATTACK_COOLDOWN):
			state = AIState.CHASE

	var player: Node3D = get_tree().get_first_node_in_group("player") as Node3D
	var dist_to_player: float = 999.0
	if player != null:
		dist_to_player = global_position.distance_to(player.global_position)

	var diff_mult: float = GameManager.get_difficulty_enemy_multiplier()
	var eff_speed: float = move_speed * diff_mult * (0.42 if is_leg_crippled else 1.0)

	match state:
		AIState.STAGGERED, AIState.ATTACK_COOLDOWN:
			velocity.x = move_toward(velocity.x, 0.0, delta * 8.0)
			velocity.z = move_toward(velocity.z, 0.0, delta * 8.0)

		AIState.PATROL, AIState.IDLE:
			if dist_to_player <= detection_radius:
				state = AIState.CHASE
			else:
				var target_pt: Vector3 = _spawn_origin + (patrol_offset_b if _patrol_to_b else patrol_offset_a)
				var dir: Vector3 = (target_pt - global_position)
				dir.y = 0.0
				if dir.length() < 0.45:
					_patrol_to_b = not _patrol_to_b
				else:
					dir = dir.normalized()
					velocity.x = dir.x * eff_speed * 0.65
					velocity.z = dir.z * eff_speed * 0.65
					_face_direction(dir, delta)

		AIState.CHASE:
			if player == null or dist_to_player > detection_radius * 1.45:
				state = AIState.PATROL
			elif dist_to_player <= attack_range:
				_perform_attack()
			else:
				var chase_dir: Vector3 = (player.global_position - global_position)
				chase_dir.y = 0.0
				chase_dir = chase_dir.normalized()
				velocity.x = chase_dir.x * eff_speed
				velocity.z = chase_dir.z * eff_speed
				_face_direction(chase_dir, delta)

	move_and_slide()

func _face_direction(dir: Vector3, delta: float) -> void:
	if mesh_pivot and dir.length_squared() > 0.01:
		var target_yaw: float = atan2(-dir.x, -dir.z)
		mesh_pivot.rotation.y = lerp_angle(mesh_pivot.rotation.y, target_yaw, clampf(delta * 8.0, 0.0, 1.0))

func _perform_attack() -> void:
	state = AIState.ATTACK_COOLDOWN
	_state_timer = 1.35
	AudioManager.play_synth_sfx("door_locked")
	GameManager.apply_player_damage(attack_damage, inflicts_ichor_infection)

func get_aim_label() -> String:
	return "" if is_dead else "%s (HP: %d%%)" % [enemy_title, int((current_hp / max_hp) * 100.0)]

func is_weakpoint_hitbox() -> bool:
	return false

func on_laser_shot_hit(base_damage: float, _hit_pos: Vector3, is_incendiary: bool) -> void:
	apply_damage(base_damage, is_incendiary, "TORSO")

func apply_damage(amount: float, is_incendiary: bool, zone_tag: String) -> void:
	if is_dead:
		return

	var final_dmg: float = amount
	if zone_tag == "HEAD":
		final_dmg *= 1.85
		state = AIState.STAGGERED
		_state_timer = 0.75
	elif zone_tag == "LEG" and not is_leg_crippled:
		is_leg_crippled = true
		state = AIState.STAGGERED
		_state_timer = 0.65
		if mesh_pivot:
			mesh_pivot.scale.y = 0.68
	elif zone_tag == "VALVE" or is_incendiary:
		final_dmg *= 2.2

	current_hp -= final_dmg
	state = AIState.CHASE if state != AIState.STAGGERED else state

	if current_hp <= 0.0:
		_die()

func _die() -> void:
	is_dead = true
	state = AIState.DEAD
	GameManager.enemies_neutralized += 1
	AudioManager.play_synth_sfx("puzzle_solved")
	if mesh_pivot:
		var tw := create_tween()
		tw.tween_property(mesh_pivot, "rotation_degrees:x", -88.0, 0.35)
		tw.tween_property(mesh_pivot, "position:y", -0.55, 0.35)
	set_collision_layer_value(1, false)
	set_collision_layer_value(3, false)
