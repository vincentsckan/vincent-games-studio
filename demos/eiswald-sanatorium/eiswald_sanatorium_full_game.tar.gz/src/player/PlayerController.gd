class_name PlayerController
extends CharacterBody3D
## PlayerController.gd
## Supports BOTH Modern Omnidirectional Movement (relative to 45° rotatable camera)
## AND Classic Tank Controls (W/S forward/back along character facing, A/D turn in place),
## plus Laser-Sight Reticle Shrink Aiming, Dodge Backstep, and Flashlight toggle.

signal interaction_prompt_changed(prompt_text: String)

@export var walk_speed: float = 4.6
@export var tank_reverse_speed: float = 2.8
@export var tank_turn_speed: float = 2.8
@export var aim_strafe_speed: float = 2.0
@export var dodge_speed: float = 8.4
@export var rotation_speed: float = 12.0
@export var camera_rig_path: NodePath

@onready var visual_pivot: Node3D = $VisualPivot
@onready var weapon_system: WeaponSystem = $VisualPivot/WeaponMount
@onready var flashlight_spot: SpotLight3D = $VisualPivot/FlashlightSpot3D
@onready var interaction_area: Area3D = $VisualPivot/InteractionArea3D

var camera_rig: CameraRig
var is_aiming: bool = false
var _dodge_timer: float = 0.0
var _dodge_dir: Vector3 = Vector3.ZERO
var _nearby_interactables: Array[Node] = []
var _gravity: float = 22.0

func _ready() -> void:
	if not camera_rig_path.is_empty():
		camera_rig = get_node_or_null(camera_rig_path) as CameraRig
	var anim := ProceduralAnimController.new()
	anim.target_pivot = visual_pivot
	add_child(anim)
	if interaction_area:
		interaction_area.body_entered.connect(_on_interact_entered)
		interaction_area.body_exited.connect(_on_interact_exited)
		interaction_area.area_entered.connect(_on_interact_entered)
		interaction_area.area_exited.connect(_on_interact_exited)

func _unhandled_input(event: InputEvent) -> void:
	if DialogueManager.is_dialogue_active:
		if event.is_action_pressed("interact") or event.is_action_pressed("fire"):
			DialogueManager.advance_dialogue()
		return

	if DialogueManager.is_document_active:
		if event.is_action_pressed("interact") or event.is_action_pressed("inventory"):
			DialogueManager.close_lore_document()
		return

	if event.is_action_pressed("flashlight") and flashlight_spot:
		flashlight_spot.visible = not flashlight_spot.visible
		AudioManager.play_synth_sfx("ui_click")

	if event.is_action_pressed("reload"):
		InventoryManager.reload_equipped_weapon()

	if event.is_action_pressed("interact") and not is_aiming:
		_trigger_nearest_interactable()

	if event.is_action_pressed("dodge") and _dodge_timer <= 0.0 and not is_aiming:
		_start_dodge()

	if event is InputEventMouseMotion and is_aiming and weapon_system:
		weapon_system.adjust_aim_elevation(event.relative.y)

	if event.is_action_pressed("fire") and is_aiming and weapon_system:
		if weapon_system.attempt_fire() and camera_rig:
			camera_rig.apply_camera_shake(0.14)

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= _gravity * delta
	else:
		velocity.y = -0.1

	if DialogueManager.is_dialogue_active or DialogueManager.is_document_active:
		velocity.x = 0.0
		velocity.z = 0.0
		move_and_slide()
		return

	var want_aim: bool = Input.is_action_pressed("aim") and _dodge_timer <= 0.0
	if want_aim != is_aiming:
		is_aiming = want_aim
		if weapon_system:
			weapon_system.set_aiming_active(is_aiming)
		if camera_rig:
			camera_rig.set_aiming_mode(is_aiming)

	# Continuous fire support for Geothermal Flamethrower
	if is_aiming and Input.is_action_pressed("fire") and InventoryManager.equipped_weapon_id == "weapon_geothermal_flamethrower":
		if weapon_system:
			weapon_system.attempt_fire()

	if _dodge_timer > 0.0:
		_dodge_timer -= delta
		velocity.x = _dodge_dir.x * dodge_speed
		velocity.z = _dodge_dir.z * dodge_speed
		move_and_slide()
		return

	var input_vec: Vector2 = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	if weapon_system:
		weapon_system.is_moving_while_aiming = (input_vec.length_squared() > 0.02)

	# Branch between Classic Tank Controls and Modern Camera-Relative Direct Controls
	if GameManager.control_scheme == GameManager.ControlScheme.TANK_CONTROLS and not is_aiming:
		if visual_pivot:
			visual_pivot.rotate_y(-input_vec.x * tank_turn_speed * delta)
			var char_forward: Vector3 = -visual_pivot.global_transform.basis.z
			char_forward.y = 0.0
			char_forward = char_forward.normalized()
			var forward_amount: float = -input_vec.y # W is -1 on Y axis
			var spd: float = walk_speed if forward_amount >= 0.0 else tank_reverse_speed
			velocity.x = char_forward.x * forward_amount * spd
			velocity.z = char_forward.z * forward_amount * spd
	else:
		var cam_basis: Basis = camera_rig.global_transform.basis if camera_rig else global_transform.basis
		var forward_dir: Vector3 = Vector3(cam_basis.z.x, 0.0, cam_basis.z.z).normalized()
		var right_dir: Vector3 = Vector3(cam_basis.x.x, 0.0, cam_basis.x.z).normalized()
		var move_dir: Vector3 = (right_dir * input_vec.x + forward_dir * input_vec.y).normalized()

		var current_speed: float = aim_strafe_speed if is_aiming else walk_speed
		velocity.x = move_dir.x * current_speed
		velocity.z = move_dir.z * current_speed

		if is_aiming:
			_rotate_toward_mouse_cursor(delta)
		elif move_dir.length_squared() > 0.01 and visual_pivot:
			var target_angle: float = atan2(-move_dir.x, -move_dir.z)
			visual_pivot.rotation.y = lerp_angle(visual_pivot.rotation.y, target_angle, clampf(delta * rotation_speed, 0.0, 1.0))

	move_and_slide()
	_refresh_interaction_prompt()

func _rotate_toward_mouse_cursor(delta: float) -> void:
	if camera_rig == null or visual_pivot == null:
		return
	var cam: Camera3D = camera_rig.get_camera_3d()
	if cam == null:
		return

	var mouse_pos: Vector2 = get_viewport().get_mouse_position()
	var ray_origin: Vector3 = cam.project_ray_origin(mouse_pos)
	var ray_normal: Vector3 = cam.project_ray_normal(mouse_pos)
	var aim_plane := Plane(Vector3.UP, global_position.y + 1.1)
	var intersection: Variant = aim_plane.intersects_ray(ray_origin, ray_normal)
	if intersection != null:
		var look_pt: Vector3 = intersection
		var dir: Vector3 = (look_pt - global_position)
		dir.y = 0.0
		if dir.length_squared() > 0.01:
			var target_yaw: float = atan2(-dir.x, -dir.z)
			visual_pivot.rotation.y = lerp_angle(visual_pivot.rotation.y, target_yaw, clampf(delta * 16.0, 0.0, 1.0))

func _start_dodge() -> void:
	_dodge_timer = 0.28
	if visual_pivot:
		var forward_facing: Vector3 = -visual_pivot.global_transform.basis.z
		_dodge_dir = -forward_facing.normalized()
	AudioManager.play_synth_sfx("camera_snap")

func _on_interact_entered(node: Node) -> void:
	if node.has_method("interact") and not _nearby_interactables.has(node):
		_nearby_interactables.append(node)
		_refresh_interaction_prompt()

func _on_interact_exited(node: Node) -> void:
	if _nearby_interactables.has(node):
		_nearby_interactables.erase(node)
		_refresh_interaction_prompt()

func _refresh_interaction_prompt() -> void:
	if _nearby_interactables.is_empty() or is_aiming:
		interaction_prompt_changed.emit("")
		return
	var best: Node = _nearby_interactables[0]
	var label: String = String(best.call("get_interaction_prompt")) if best.has_method("get_interaction_prompt") else "按 [F] 調查"
	interaction_prompt_changed.emit(label)

func _trigger_nearest_interactable() -> void:
	if _nearby_interactables.is_empty():
		return
	var target: Node = _nearby_interactables[0]
	if is_instance_valid(target) and target.has_method("interact"):
		target.call("interact", self)
		_refresh_interaction_prompt()
