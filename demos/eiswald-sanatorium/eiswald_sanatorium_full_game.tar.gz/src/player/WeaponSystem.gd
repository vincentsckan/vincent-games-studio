class_name WeaponSystem
extends Node3D
## WeaponSystem.gd
## Implements Crow Country's 3D Laser-Sight + Reticle Shrink Focus Critical System.
## Standing still while aiming shrinks the reticle over 1.1s, boosting weakpoint/headshot damage up to +55%.

signal weapon_fired(weapon_id: String, clip_remaining: int, reserve_remaining: int)
signal target_locked(target_name: String, is_weakpoint: bool)
signal reticle_focus_changed(focus_ratio: float, aiming_active: bool)

@onready var ray_cast: RayCast3D = $LaserRayCast3D
@onready var laser_beam_mesh: MeshInstance3D = $LaserBeamMesh
@onready var laser_hit_dot: OmniLight3D = $LaserHitDotLight
@onready var muzzle_flash_light: OmniLight3D = $MuzzleFlashLight

var is_aiming: bool = false
var aim_pitch_offset_deg: float = 0.0
var focus_charge: float = 0.0 # 0.0 (wide reticle) -> 1.0 (fully shrunk critical reticle)
var is_moving_while_aiming: bool = false
var _cooldown_timer: float = 0.0
var _muzzle_timer: float = 0.0

func _ready() -> void:
	set_aiming_active(false)

func set_aiming_active(active: bool) -> void:
	is_aiming = active
	if laser_beam_mesh:
		laser_beam_mesh.visible = active
	if laser_hit_dot:
		laser_hit_dot.visible = active
	if not active:
		focus_charge = 0.0
		aim_pitch_offset_deg = 0.0
		rotation_degrees.x = 0.0
	reticle_focus_changed.emit(focus_charge, is_aiming)

func adjust_aim_elevation(mouse_delta_y: float) -> void:
	if not is_aiming:
		return
	aim_pitch_offset_deg = clampf(aim_pitch_offset_deg - mouse_delta_y * 0.14, -28.0, 35.0)
	rotation_degrees.x = aim_pitch_offset_deg

func _physics_process(delta: float) -> void:
	if _cooldown_timer > 0.0:
		_cooldown_timer -= delta
	if _muzzle_timer > 0.0:
		_muzzle_timer -= delta
		if _muzzle_timer <= 0.0 and muzzle_flash_light:
			muzzle_flash_light.visible = false

	if not is_aiming or ray_cast == null:
		return

	# Reticle shrink calculation: shrinks when standing steady, blooms slightly if strafing
	if is_moving_while_aiming:
		focus_charge = clampf(focus_charge - delta * 0.75, 0.0, 1.0)
	else:
		focus_charge = clampf(focus_charge + delta * 0.90, 0.0, 1.0)
	reticle_focus_changed.emit(focus_charge, true)

	ray_cast.force_raycast_update()
	var max_len: float = 22.0
	var hit_point: Vector3 = ray_cast.to_global(Vector3(0.0, 0.0, -max_len))

	if ray_cast.is_colliding():
		hit_point = ray_cast.get_collision_point()
		var collider: Object = ray_cast.get_collider()
		if collider and collider.has_method("get_aim_label"):
			var is_weak: bool = bool(collider.call("is_weakpoint_hitbox")) if collider.has_method("is_weakpoint_hitbox") else false
			target_locked.emit(String(collider.call("get_aim_label")), is_weak)
		else:
			target_locked.emit("", false)
	else:
		target_locked.emit("", false)

	var beam_len: float = global_position.distance_to(hit_point)
	if laser_beam_mesh:
		laser_beam_mesh.scale = Vector3(1.0, beam_len * 0.5, 1.0)
		laser_beam_mesh.position = Vector3(0.0, 0.0, -beam_len * 0.5)
	if laser_hit_dot:
		laser_hit_dot.global_position = hit_point + ray_cast.get_collision_normal() * 0.04

func attempt_fire() -> bool:
	if not is_aiming or _cooldown_timer > 0.0:
		return false

	var w_id: String = InventoryManager.equipped_weapon_id
	if not InventoryManager.weapon_states.has(w_id):
		return false

	var st: Dictionary = InventoryManager.weapon_states[w_id]
	var clip: int = int(st["clip"])
	if clip <= 0:
		AudioManager.play_synth_sfx("door_locked")
		return false

	st["clip"] = clip - 1
	_cooldown_timer = float(st["fire_rate"])
	GameManager.shots_fired += 1

	var sfx_type: String = "gunshot_shotgun" if (w_id == "weapon_alpine_shotgun" or w_id == "weapon_white_crow_magnum") else "gunshot_pistol"
	AudioManager.play_synth_sfx(sfx_type)
	if muzzle_flash_light:
		muzzle_flash_light.visible = true
		_muzzle_timer = 0.07

	ray_cast.force_raycast_update()
	if ray_cast.is_colliding():
		var collider: Object = ray_cast.get_collider()
		var hit_pos: Vector3 = ray_cast.get_collision_point()
		# Up to +55% critical bonus when reticle is fully shrunk
		var crit_mult: float = 1.0 + (focus_charge * 0.55)
		var base_dmg: float = float(st["damage"]) * crit_mult
		var is_incendiary: bool = (w_id == "weapon_geothermal_flamethrower")

		if collider != null:
			if collider.has_method("on_laser_shot_hit"):
				GameManager.shots_hit += 1
				collider.call("on_laser_shot_hit", base_dmg, hit_pos, is_incendiary)
			elif collider.get_parent() and collider.get_parent().has_method("on_laser_shot_hit"):
				GameManager.shots_hit += 1
				collider.get_parent().call("on_laser_shot_hit", base_dmg, hit_pos, is_incendiary)

	# Recoil blooms the reticle back out after firing
	focus_charge = maxf(0.0, focus_charge - 0.65)
	reticle_focus_changed.emit(focus_charge, true)

	var reserve: int = InventoryManager.get_item_count(String(st["ammo_item_id"]))
	InventoryManager.inventory_updated.emit()
	weapon_fired.emit(w_id, int(st["clip"]), reserve)
	return true
