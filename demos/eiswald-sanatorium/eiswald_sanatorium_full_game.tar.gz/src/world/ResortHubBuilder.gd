class_name ResortHubBuilder
extends Node3D
## ResortHubBuilder.gd
## Constructs the complete radial Metroidvania 3D world across all 4 themed zones:
## 1. Fairytale Town Central Hub (雪絨花童話村 — 旋轉木馬樞紐、毒蠅傘蘑菇屋、壁爐營火安全屋)
## 2. Haunted Hilltop (霧嶺鬧鬼山丘 — 哥德古堡、真假鬼屋墓園、星座自動鋼琴謎題、.44馬格南、單向捷徑門)
## 3. Ocean Kingdom (冰川海洋王國 — 藍綠深海水族館、海盜船餐廳、85 PSI 水壓謎題、強酸液瓶、單向捷徑門)
## 4. The Roots / Underground (地下挖掘場與秘密設施 — 陰暗礦坑、440V 配電謎題、火焰噴射器、白髓母體池頭目戰)

var mat_snow_stone: ShaderMaterial
var mat_pale_ichor: ShaderMaterial
var mat_dark_timber: StandardMaterial3D
var mat_fairytale_red: StandardMaterial3D
var mat_gothic_slate: StandardMaterial3D
var mat_ocean_aqua: StandardMaterial3D
var mat_rusted_steel: StandardMaterial3D
var mat_brass_gold: StandardMaterial3D

func _ready() -> void:
	_init_pbr_materials()
	_build_zone1_fairytale_hub()
	_build_zone2_haunted_hilltop()
	_build_zone3_ocean_kingdom()
	_build_zone4_underground_roots()
	_build_radial_doors_and_shortcuts()
	_build_campfire_safe_room_facilities()
	_build_npcs_and_progression_items()
	_build_four_zone_puzzles()
	_build_enemies_and_five_trap_types()
	_build_crystal_edelweiss_targets()
	var furnisher := SubRoomFurnisher.new()
	add_child(furnisher)
	furnisher.populate_commercial_details(self)

func _init_pbr_materials() -> void:
	var snow_sh := load("res://assets/shaders/snow_accumulation.gdshader") as Shader
	if snow_sh:
		mat_snow_stone = ShaderMaterial.new()
		mat_snow_stone.shader = snow_sh

	var ichor_sh := load("res://assets/shaders/pale_ichor_fluid.gdshader") as Shader
	if ichor_sh:
		mat_pale_ichor = ShaderMaterial.new()
		mat_pale_ichor.shader = ichor_sh

	mat_dark_timber = StandardMaterial3D.new()
	mat_dark_timber.albedo_color = Color(0.20, 0.13, 0.09)
	mat_dark_timber.roughness = 0.72

	mat_fairytale_red = StandardMaterial3D.new()
	mat_fairytale_red.albedo_color = Color(0.76, 0.16, 0.18)
	mat_fairytale_red.roughness = 0.45

	mat_gothic_slate = StandardMaterial3D.new()
	mat_gothic_slate.albedo_color = Color(0.16, 0.15, 0.22)
	mat_gothic_slate.roughness = 0.65

	mat_ocean_aqua = StandardMaterial3D.new()
	mat_ocean_aqua.albedo_color = Color(0.08, 0.34, 0.42)
	mat_ocean_aqua.roughness = 0.22
	mat_ocean_aqua.metallic = 0.25

	mat_rusted_steel = StandardMaterial3D.new()
	mat_rusted_steel.albedo_color = Color(0.32, 0.25, 0.22)
	mat_rusted_steel.metallic = 0.78
	mat_rusted_steel.roughness = 0.55

	mat_brass_gold = StandardMaterial3D.new()
	mat_brass_gold.albedo_color = Color(0.85, 0.68, 0.26)
	mat_brass_gold.metallic = 0.88
	mat_brass_gold.roughness = 0.24

func _build_zone1_fairytale_hub() -> void:
	# Arrival Gates & Parking Lot (Z = +18 to +6)
	_spawn_static_box("ArrivalFloor", Vector3(0, -0.25, 13), Vector3(24, 0.5, 18), mat_snow_stone)
	_spawn_glb_or_fallback("res://assets/models/investigator_sedan.glb", Vector3(-4.5, 0.65, 17.5), Vector3(2.2, 1.3, 4.4), mat_rusted_steel)
	_spawn_omni_light(Vector3(-3.0, 4.2, 16.0), Color(0.95, 0.72, 0.42), 3.2, 11.0)

	# Fairytale Town Central Hub (Center X=0, Z=-8) — Carousel & Witch Stall
	_spawn_static_box("FairytaleHubFloor", Vector3(0, -0.25, -8.0), Vector3(24, 0.5, 20), mat_snow_stone)
	_spawn_glb_or_fallback("res://assets/models/fairytale_carousel.glb", Vector3(0.0, 1.5, -7.5), Vector3(4.2, 3.0, 4.2), mat_fairytale_red)
	_spawn_omni_light(Vector3(0, 4.2, -7.5), Color(1.0, 0.72, 0.38), 4.5, 15.0)

	# Toadstool Mushroom Cottage (South-West Alcove: X=-22, Z=8)
	_spawn_static_box("MushroomCottageFloor", Vector3(-22.0, -0.25, 8.0), Vector3(13.0, 0.5, 13.0), mat_dark_timber)
	_spawn_glb_or_fallback("res://assets/models/toadstool_cottage.glb", Vector3(-22.0, 2.2, 12.2), Vector3(5.0, 4.2, 3.0), mat_fairytale_red)
	_spawn_omni_light(Vector3(-22.0, 3.4, 8.0), Color(0.98, 0.62, 0.42), 3.4, 12.0)

	# Campfire Safe Room (North-West Sanctuary: X=-17, Z=-8)
	_spawn_static_box("SafeRoomFloor", Vector3(-17.5, -0.25, -8.0), Vector3(11.0, 0.5, 12.0), mat_dark_timber)
	_spawn_omni_light(Vector3(-17.5, 3.0, -8.0), Color(1.0, 0.68, 0.32), 4.0, 12.0)

func _build_zone2_haunted_hilltop() -> void:
	# West Radial Zone (X = -38, Z = -8): Gothic Crypt, Fake-Ghost Corridor & Constellation Piano Chapel
	_spawn_static_box("HauntedHilltopFloor", Vector3(-38.0, -0.25, -8.0), Vector3(20.0, 0.5, 20.0), mat_gothic_slate)
	_spawn_static_box("GothicCryptAltar", Vector3(-44.0, 1.4, -14.0), Vector3(4.5, 2.8, 2.2), mat_gothic_slate)
	_spawn_omni_light(Vector3(-38.0, 4.0, -8.0), Color(0.68, 0.42, 0.95), 3.6, 16.0) # Eerie gothic violet glow

func _build_zone3_ocean_kingdom() -> void:
	# East Radial Zone (X = +26, Z = -8): Abyssal Aquarium Dome & Pirate Ship Restaurant
	_spawn_static_box("OceanKingdomFloor", Vector3(26.0, -0.25, -8.0), Vector3(22.0, 0.5, 20.0), mat_ocean_aqua)
	_spawn_static_box("AbyssalWaterTank", Vector3(26.0, 0.12, -13.0), Vector3(9.0, 0.25, 5.0), mat_pale_ichor)
	_spawn_glb_or_fallback("res://assets/models/pirate_galleon_ship.glb", Vector3(31.5, 1.8, -4.0), Vector3(4.5, 3.5, 7.5), mat_dark_timber)
	_spawn_omni_light(Vector3(26.0, 4.2, -8.0), Color(0.15, 0.88, 0.92), 4.2, 17.0) # Deep-sea blue-green caustics

func _build_zone4_underground_roots() -> void:
	# North/Subterranean Radial Zone (X = 0, Z = -32): The Pale Roots Mining Quarry & Vance's Bio-Lab
	_spawn_static_box("UndergroundQuarryFloor", Vector3(0.0, -0.25, -32.0), Vector3(26.0, 0.5, 20.0), mat_rusted_steel)
	_spawn_static_box("PaleIchorMotherPool", Vector3(0.0, 0.15, -38.0), Vector3(8.0, 0.3, 4.5), mat_pale_ichor)
	_spawn_omni_light(Vector3(0.0, 4.0, -32.0), Color(0.95, 0.28, 0.22), 4.0, 17.0)

func _build_radial_doors_and_shortcuts() -> void:
	# 1. Fairytale Hub <-> Campfire Safe Room (Always open sanctuary)
	_spawn_door(
		"door_safe_enter", "童話村壁爐營火安全屋", "Z1_R04_CampfireSafeRoom",
		Vector3(-11.2, 1.2, -8.0), Vector3(-14.2, 0.2, -8.0), 45.0,
		false, "", "", "", false, false
	)
	_spawn_door(
		"door_safe_exit", "返回雪絨花童話中央廣場", "Z1_R02_FairytaleHub",
		Vector3(-12.5, 1.2, -5.2), Vector3(-8.5, 0.2, -8.0), 45.0,
		false, "", "", "", false, false
	)

	# 2. Fairytale Hub <-> Toadstool Mushroom Cottage (Blocked by wooden planks -> Requires Steel Crowbar!)
	_spawn_door(
		"door_mushroom_enter", "木板封死的毒蠅傘蘑菇屋門", "Z1_R03_ToadstoolCottage",
		Vector3(-9.5, 1.2, -1.5), Vector3(-18.5, 0.2, 8.0), 45.0,
		true, "tool_crowbar", "精鋼撬棍 (Crowbar)", "mushroom_cottage_pried", false, false
	)
	_spawn_door(
		"door_mushroom_exit", "返回雪絨花童話中央廣場", "Z1_R02_FairytaleHub",
		Vector3(-16.5, 1.2, 5.0), Vector3(-7.5, 0.2, -3.5), 45.0,
		false, "", "", "", false, false
	)

	# 3. Fairytale Hub <-> Zone 2: Haunted Hilltop (Requires Bronze Wing Key!)
	_spawn_door(
		"door_haunted_enter", "【鬧鬼山丘】哥德古堡鐵門", "Z2_R06_HauntedChapel",
		Vector3(-11.2, 1.2, -13.5), Vector3(-31.0, 0.2, -8.0), 45.0,
		true, "key_bronze_wing", "銅翼雙鴉鑰匙", "haunted_hilltop_unlocked", false, false
	)
	# One-Way Shortcut from Haunted Hilltop directly back to Campfire Safe Room / Hub!
	_spawn_door(
		"door_haunted_shortcut_inside", "【單向捷徑鐵門】拉開插銷直通童話鎮安全屋", "Z1_R04_CampfireSafeRoom",
		Vector3(-29.5, 1.2, -3.5), Vector3(-16.0, 0.2, -5.0), 45.0,
		true, "", "", "shortcut_haunted_to_hub_opened", true, true
	)

	# 4. Fairytale Hub <-> Zone 3: Ocean Kingdom (Requires Silver Seahorse Key!)
	_spawn_door(
		"door_ocean_enter", "【海洋王國】深海圓頂水族館大門", "Z3_R07_AbyssalAquarium",
		Vector3(11.2, 1.2, -8.0), Vector3(17.5, 0.2, -8.0), -45.0,
		true, "key_silver_seahorse", "銀冠海馬鑰匙", "ocean_kingdom_unlocked", false, false
	)
	# One-Way Shortcut from Ocean Kingdom back to Fairytale Hub!
	_spawn_door(
		"door_ocean_shortcut_inside", "【單向捷徑鐵門】拉開插銷返回童話中央廣場", "Z1_R02_FairytaleHub",
		Vector3(16.2, 1.2, -3.0), Vector3(8.5, 0.2, -5.0), 45.0,
		true, "", "", "shortcut_ocean_to_hub_opened", true, true
	)

	# 5. Fairytale Hub <-> Zone 4: The Underground Roots (Locked by rusted chains -> Requires Acid Vial!)
	_spawn_door(
		"door_roots_enter", "【地下挖掘場】重型鏽蝕鐵鍊升降梯門", "Z4_R09_SubterraneanQuarry",
		Vector3(0.0, 1.2, -17.2), Vector3(0.0, 0.2, -24.0), 0.0,
		true, "acid_vial", "高濃度強酸液瓶 (Acid Vial)", "underground_roots_unlocked", false, false
	)
	_spawn_door(
		"door_roots_exit", "搭乘礦坑升降梯返回童話中央廣場", "Z1_R02_FairytaleHub",
		Vector3(0.0, 1.2, -22.2), Vector3(0.0, 0.2, -14.0), 45.0,
		false, "", "", "", false, false
	)

func _build_campfire_safe_room_facilities() -> void:
	# 1. Warm Hearth Campfire in Safe Room
	var campfire := SafeRoomTerminal.new()
	campfire.terminal_kind = SafeRoomTerminal.TerminalKind.CAMPFIRE_HEARTH
	campfire.position = Vector3(-17.5, 0.6, -12.5)
	_attach_collider_and_mesh(campfire, Vector3(1.5, 1.2, 1.5), mat_fairytale_red)
	add_child(campfire)

	# 2. Reel-to-Reel Tape Recorder (Save Game)
	var tape := SafeRoomTerminal.new()
	tape.terminal_kind = SafeRoomTerminal.TerminalKind.TAPE_RECORDER_SAVE
	tape.position = Vector3(-20.5, 0.8, -11.5)
	_attach_collider_and_mesh(tape, Vector3(1.1, 1.0, 0.9), mat_brass_gold, "res://assets/models/reel_tape_recorder.glb")
	add_child(tape)

	# 3. Progressive 3-Tier Fortune Teller ("The Alpine Oracle")
	var oracle := SafeRoomTerminal.new()
	oracle.terminal_kind = SafeRoomTerminal.TerminalKind.ALPINE_ORACLE_FORTUNE
	oracle.position = Vector3(-14.5, 1.1, -11.5)
	_attach_collider_and_mesh(oracle, Vector3(1.1, 2.2, 1.1), mat_brass_gold, "res://assets/models/alpine_oracle_machine.glb")
	add_child(oracle)

func _build_npcs_and_progression_items() -> void:
	# Arrival Gates: Summons Document #01 & Car Trunk Ammo
	_spawn_doc("doc_01_summons", "調查卷宗 #01：四大主題園區與地底秘密", "Z1_R01_ArrivalGates", Vector3(-3.0, 0.8, 19.2))
	_spawn_pickup("ammo_9mm", 15, "調查員轎車後車廂彈藥箱", "Z1_R01_ArrivalGates", Vector3(-4.5, 0.8, 19.8), "car_trunk_inspected")

	# Fairytale Hub: Architect Arthur Vance (Gives Steel Crowbar!) + Shotgun
	var arthur := Interactable.new()
	arthur.interact_type = Interactable.InteractType.NPC_DIALOGUE
	arthur.npc_name = "總建築師 亞瑟·范斯 (Arthur Vance)"
	arthur.object_title = "總建築師 亞瑟·范斯"
	arthur.room_id = "Z1_R02_FairytaleHub"
	arthur.sets_world_flag = "crowbar_obtained"
	arthur.gives_item_on_dialogue = "tool_crowbar"
	arthur.dialogue_lines = [
		"「薇拉！這座『雪絨花童話村』是整座樂園的放射狀中央樞紐，通往西翼『鬧鬼山丘』、東翼『海洋王國』與北側『地下挖掘場』的大門都在這裡！」",
		"「拿著這把【精鋼撬棍 (Crowbar)】，先去撬開廣場南側被木板封死的『毒蠅傘蘑菇屋』，找出裡面的懷錶與【銅翼雙鴉鑰匙】！」",
		"「如果卡關了，隨時去西側的『壁爐營火安全屋』向算命機索取三階段漸進式提示。」"
	]
	arthur.position = Vector3(-3.8, 1.1, -13.2)
	_attach_collider_and_mesh(arthur, Vector3(0.9, 1.9, 0.9), mat_brass_gold)
	add_child(arthur)

	_spawn_pickup("weapon_alpine_shotgun", 1, "阿爾卑斯雙管霰彈槍", "Z1_R02_FairytaleHub", Vector3(3.8, 0.9, -13.2))

	# Safe Room: Memo #02, First-Aid Spray & Antidote
	_spawn_doc("doc_02_TeaRoomMemo", "安全屋指南：壁爐營火與漸進式算命機", "Z1_R04_CampfireSafeRoom", Vector3(-16.5, 0.8, -5.5))
	_spawn_pickup("first_aid_spray", 1, "急救噴霧 (First-Aid Spray)", "Z1_R04_CampfireSafeRoom", Vector3(-20.2, 0.7, -6.5))
	_spawn_pickup("ichor_antidote", 2, "白髓解毒血清 (Antidote)", "Z1_R04_CampfireSafeRoom", Vector3(-20.2, 0.7, -8.5))

	# Toadstool Mushroom Cottage: Stopped Brass Pocket Watch + Journal #03
	_spawn_pickup("brass_pocket_watch", 1, "停擺的銅製懷錶", "Z1_R03_ToadstoolCottage", Vector3(-21.5, 0.85, 8.0), "pocket_watch_found", "res://assets/models/brass_pocket_watch.glb")
	_spawn_doc("doc_03_CuratorJournal", "童話鎮日誌：毒蠅傘蘑菇屋與女巫時鐘", "Z1_R03_ToadstoolCottage", Vector3(-24.0, 0.85, 8.0))

	# Haunted Hilltop: Lore #04
	_spawn_doc("doc_04_HauntedNotes", "鬧鬼山丘手札：真假鬼屋與烏鴉座星盤", "Z2_R06_HauntedChapel", Vector3(-35.0, 0.85, -12.0))

	# Ocean Kingdom: Lore #05
	_spawn_doc("doc_05_OceanKingdomLog", "海洋王國日誌：水下展廳水壓與海盜船強酸", "Z3_R07_AbyssalAquarium", Vector3(22.5, 0.85, -12.0))

	# Underground Roots: Lore #06
	_spawn_doc("doc_06_UndergroundRootsReport", "最高機密：地下挖掘場與白髓計畫", "Z4_R09_SubterraneanQuarry", Vector3(-4.5, 0.85, -28.0))

func _build_four_zone_puzzles() -> void:
	# Zone 1 Puzzle: Toadstool Cottage Grandfather Clock ("0415" -> Bronze Wing Key)
	var clock_puzzle := ClockworkSafePuzzle.new()
	clock_puzzle.add_to_group("puzzles")
	clock_puzzle.position = Vector3(-26.0, 1.3, 8.0)
	_attach_collider_and_mesh(clock_puzzle, Vector3(1.2, 2.6, 1.2), mat_brass_gold, "res://assets/models/grandfather_clock_safe.glb")
	add_child(clock_puzzle)

	# Zone 2 Puzzle: Haunted Hilltop Corvus Constellation Piano ("13542" -> Silver Seahorse Key + .44 Magnum)
	var piano_puzzle := OrganMelodyPuzzle.new()
	piano_puzzle.add_to_group("puzzles")
	piano_puzzle.position = Vector3(-42.5, 1.3, -8.5)
	_attach_collider_and_mesh(piano_puzzle, Vector3(2.4, 2.0, 1.4), mat_brass_gold)
	add_child(piano_puzzle)

	# Zone 3 Puzzle: Ocean Kingdom 3-Chamber Hydro Pressure ("85" -> Acid Vial)
	var hydro_puzzle := SteamValvePuzzle.new()
	hydro_puzzle.add_to_group("puzzles")
	hydro_puzzle.position = Vector3(32.0, 1.2, -11.5)
	_attach_collider_and_mesh(hydro_puzzle, Vector3(1.4, 2.2, 1.4), mat_ocean_aqua)
	add_child(hydro_puzzle)

	# Zone 4 Puzzle: Underground Quarry 440V Mining Generator ("440" -> Geothermal Flamethrower)
	var voltage_puzzle := VoltageGridPuzzle.new()
	voltage_puzzle.add_to_group("puzzles")
	voltage_puzzle.position = Vector3(-7.5, 1.2, -33.0)
	_attach_collider_and_mesh(voltage_puzzle, Vector3(1.5, 2.2, 1.2), mat_rusted_steel)
	add_child(voltage_puzzle)

	# Zone 1 Bonus Puzzle: Fairytale Town Retro Arcade Cabinet ("1991" -> VP-9 Mag Upgrade + First-Aid Spray)
	var arcade_puzzle := ArcadeMinigamePuzzle.new()
	arcade_puzzle.add_to_group("puzzles")
	arcade_puzzle.position = Vector3(7.2, 1.2, -13.0)
	_attach_collider_and_mesh(arcade_puzzle, Vector3(1.1, 2.2, 1.1), mat_fairytale_red, "res://assets/models/arcade_cabinet_retro.glb")
	add_child(arcade_puzzle)

	# Zone 3 Bonus Puzzle: Pirate Ship Captain's Compass & Deck Cannon ("2486" -> .44 Magnum & Shotgun Ammo)
	var pirate_puzzle := PirateCannonPuzzle.new()
	pirate_puzzle.add_to_group("puzzles")
	pirate_puzzle.position = Vector3(29.5, 1.2, -4.0)
	_attach_collider_and_mesh(pirate_puzzle, Vector3(1.2, 1.8, 1.2), mat_brass_gold)
	add_child(pirate_puzzle)

	# Zone 2 Crypt Skeleton Cipher Puzzle ("741" -> Satchel 12-Slot Expansion + Shotgun Ammo)
	var crypt_puzzle := CryptSkeletonPuzzle.new()
	crypt_puzzle.add_to_group("puzzles")
	crypt_puzzle.position = Vector3(-44.0, 1.2, -13.5)
	_attach_collider_and_mesh(crypt_puzzle, Vector3(1.8, 1.6, 1.2), mat_gothic_slate)
	add_child(crypt_puzzle)

	# Zone 4 Bio-Lab Final Genetic Sequence Terminal ("1989" -> Unseals Clara's Cryo-Spire & Victory S-Rank Report)
	var biolab_puzzle := BioLabGenePuzzle.new()
	biolab_puzzle.add_to_group("puzzles")
	biolab_puzzle.position = Vector3(0.0, 1.3, -39.5)
	_attach_collider_and_mesh(biolab_puzzle, Vector3(1.8, 2.4, 1.2), mat_ocean_aqua)
	biolab_puzzle.final_cryo_spire_unsealed.connect(func():
		var hud := get_tree().current_scene.get_node_or_null("HUDController")
		if hud and hud.has_method("open_ending_report"):
			hud.call("open_ending_report")
	)
	add_child(biolab_puzzle)

	# Haunted Hilltop Fake vs Real Spooky Coffins (Crow Country Haunted Hilltop signature feature)
	var fake_coffin := HauntedFakeGhostProp.new()
	fake_coffin.coffin_title = "哥德驚魂屋彩繪棺木 #1"
	fake_coffin.is_fake_theme_park_prop = true
	fake_coffin.hides_item_id = "ammo_9mm"
	fake_coffin.hides_item_qty = 10
	fake_coffin.position = Vector3(-33.5, 1.1, -12.5)
	_attach_collider_and_mesh(fake_coffin, Vector3(1.1, 2.1, 0.9), mat_dark_timber, "res://assets/models/haunted_coffin_prop.glb")
	add_child(fake_coffin)

	var real_coffin := HauntedFakeGhostProp.new()
	real_coffin.coffin_title = "滲出白髓的古老石棺 #2"
	real_coffin.is_fake_theme_park_prop = false
	real_coffin.position = Vector3(-39.5, 1.1, -13.5)
	_attach_collider_and_mesh(real_coffin, Vector3(1.1, 2.1, 0.9), mat_gothic_slate, "res://assets/models/haunted_coffin_prop.glb")
	add_child(real_coffin)

func _build_enemies_and_five_trap_types() -> void:
	var trap_red := StandardMaterial3D.new()
	trap_red.albedo_color = Color(0.92, 0.22, 0.18)

	# 1. Explosive Fuel Barrel in Arrival Courtyard
	_spawn_trap(EnvironmentalTrap.TrapKind.EXPLOSIVE_GAS_CANISTER, "高壓易爆油桶", Vector3(2.0, 0.7, 9.5), Vector3(0.75, 1.35, 0.75), trap_red)
	# 2. Alpine Bear Trap in Fairytale Hub East Path
	_spawn_trap(EnvironmentalTrap.TrapKind.ALPINE_BEAR_TRAP, "雪山捕熊夾", Vector3(6.5, 0.15, -6.5), Vector3(0.85, 0.25, 0.85), mat_rusted_steel)
	# 3. Proximity Landmine in Haunted Hilltop Cemetery
	_spawn_trap(EnvironmentalTrap.TrapKind.PROXIMITY_LANDMINE, "感應地雷 (Proximity Mine)", Vector3(-35.5, 0.15, -6.5), Vector3(0.65, 0.2, 0.65), trap_red)
	# 4. Toxic Ichor Gas Pipe in Ocean Kingdom
	_spawn_trap(EnvironmentalTrap.TrapKind.TOXIC_GAS_PIPE, "破裂白髓毒氣管線", Vector3(24.5, 1.0, -5.5), Vector3(0.6, 1.8, 0.6), mat_pale_ichor)
	# 5. Fragile Ceiling Chandelier / Icicle in Underground Quarry (Shoot overhead to crush enemies below!)
	_spawn_trap(EnvironmentalTrap.TrapKind.FRAGILE_CEILING_ICICLE, "脆弱鐘乳石吊燈 (可射落砸毀下方敵人)", Vector3(0.0, 3.8, -32.0), Vector3(1.5, 0.9, 1.5), mat_brass_gold)

	# Enemies across the 4 zones with custom 3D GLB model paths
	_spawn_enemy_with_hitboxes("童話村異變木偶師 #01", Vector3(3.0, 0.1, 9.5), false, "res://assets/models/monster_fairytale_puppet.glb")
	_spawn_enemy_with_hitboxes("鬧鬼山丘棺木潛行者 #02", Vector3(-37.0, 0.1, -6.5), false, "res://assets/models/monster_haunted_stalker.glb")
	_spawn_enemy_with_hitboxes("海洋王國深水潛水夫畸變體 #03", Vector3(26.5, 0.1, -6.5), false, "res://assets/models/monster_ocean_diver.glb")
	_spawn_enemy_with_hitboxes("【最終頭目】白髓母體君王 克羅爾", Vector3(0.0, 0.1, -34.0), true, "res://assets/models/boss_pale_sovereign.glb")

func _build_crystal_edelweiss_targets() -> void:
	var positions: Array[Dictionary] = [
		{"id": "edelweiss_01", "pos": Vector3(0.0, 3.6, 1.8), "hint": "童話鎮大門拱廊上方"},
		{"id": "edelweiss_02", "pos": Vector3(-5.5, 3.2, 16.5), "hint": "山門停車場路燈頂端"},
		{"id": "edelweiss_03", "pos": Vector3(0.0, 3.9, -7.5), "hint": "童話中央廣場旋轉木馬尖頂"},
		{"id": "edelweiss_04", "pos": Vector3(8.5, 3.5, -13.5), "hint": "童話廣場復古街機上方樑柱"},
		{"id": "edelweiss_05", "pos": Vector3(-17.5, 3.3, -12.5), "hint": "壁爐營火安全屋煙囪口"},
		{"id": "edelweiss_06", "pos": Vector3(-25.5, 3.5, 4.0), "hint": "毒蠅傘蘑菇屋閣樓"},
		{"id": "edelweiss_07", "pos": Vector3(-22.0, 4.4, 12.0), "hint": "毒蠅傘巨型紅傘頂冠"},
		{"id": "edelweiss_08", "pos": Vector3(-33.5, 3.6, -12.5), "hint": "鬧鬼山丘假鬼屋棺木廊上方"},
		{"id": "edelweiss_09", "pos": Vector3(-42.0, 3.8, -13.0), "hint": "鬧鬼山丘哥德靈廟尖塔"},
		{"id": "edelweiss_10", "pos": Vector3(-44.0, 3.5, -4.5), "hint": "鬧鬼山丘三聖骸骨石棺後方"},
		{"id": "edelweiss_11", "pos": Vector3(26.0, 3.9, -13.0), "hint": "海洋王國深海水族館圓頂"},
		{"id": "edelweiss_12", "pos": Vector3(31.5, 4.0, -4.0), "hint": "海洋王國破冰船號主桅杆"},
		{"id": "edelweiss_13", "pos": Vector3(20.0, 3.4, -2.5), "hint": "海洋王國單向捷徑門上方"},
		{"id": "edelweiss_14", "pos": Vector3(-7.5, 3.8, -33.0), "hint": "地下挖掘場 440V 發電機頂端"},
		{"id": "edelweiss_15", "pos": Vector3(0.0, 4.1, -38.0), "hint": "秘密設施白髓母體池穹頂"}
	]
	var crystal_mat := StandardMaterial3D.new()
	crystal_mat.albedo_color = Color(0.55, 0.95, 1.0)
	crystal_mat.emission_enabled = true
	crystal_mat.emission = Color(0.35, 0.85, 1.0)
	crystal_mat.emission_energy_multiplier = 2.4

	for info in positions:
		var ce := CrystalEdelweiss.new()
		ce.crystal_id = String(info["id"])
		ce.location_hint = String(info["hint"])
		ce.position = info["pos"]
		_attach_collider_and_mesh(ce, Vector3(0.55, 0.55, 0.55), crystal_mat)
		add_child(ce)

func _spawn_trap(kind: EnvironmentalTrap.TrapKind, t_name: String, pos: Vector3, size: Vector3, mat: Material) -> void:
	var trap := EnvironmentalTrap.new()
	trap.trap_kind = kind
	trap.trap_name = t_name
	trap.position = pos
	_attach_collider_and_mesh(trap, size, mat)
	add_child(trap)

func _spawn_pickup(item_id: String, qty: int, title: String, room: String, pos: Vector3, flag: String = "", glb: String = "") -> void:
	var p := Interactable.new()
	p.interact_type = Interactable.InteractType.ITEM_PICKUP
	p.object_title = title
	p.item_id = item_id
	p.item_quantity = qty
	p.room_id = room
	p.sets_world_flag = flag
	p.position = pos
	_attach_collider_and_mesh(p, Vector3(0.75, 0.65, 0.75), mat_brass_gold, glb)
	add_child(p)

func _spawn_doc(doc_id: String, title: String, room: String, pos: Vector3) -> void:
	var d := Interactable.new()
	d.interact_type = Interactable.InteractType.LORE_DOCUMENT
	d.object_title = title
	d.document_id = doc_id
	d.room_id = room
	d.position = pos
	_attach_collider_and_mesh(d, Vector3(0.7, 0.45, 0.7), mat_brass_gold)
	add_child(d)

func _spawn_enemy_with_hitboxes(title: String, pos: Vector3, is_boss: bool, optional_glb: String = "") -> void:
	var enemy: EnemyBase = BossHelenaAI.new() if is_boss else EnemyBase.new()
	enemy.enemy_title = title
	enemy.position = pos

	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.42
	cap.height = 1.85
	col.shape = cap
	col.position = Vector3(0, 0.92, 0)
	enemy.add_child(col)

	var pivot := Node3D.new()
	pivot.name = "MeshPivot"
	enemy.add_child(pivot)

	if not optional_glb.is_empty() and ResourceLoader.exists(optional_glb):
		var packed := load(optional_glb) as PackedScene
		if packed:
			pivot.add_child(packed.instantiate())
	else:
		var body_mesh := MeshInstance3D.new()
		var c_mesh := CapsuleMesh.new()
		c_mesh.radius = 0.42 if not is_boss else 0.56
		c_mesh.height = 1.85 if not is_boss else 2.25
		body_mesh.mesh = c_mesh
		body_mesh.position = Vector3(0, 0.95, 0)
		body_mesh.material_override = mat_pale_ichor
		pivot.add_child(body_mesh)

	var head_hb := HitboxComponent.new()
	head_hb.body_zone = HitboxComponent.BodyZone.HEAD_WEAKPOINT
	head_hb.damage_multiplier = 2.2
	head_hb.zone_display_name = "頭部弱點 (準星收縮 2.2x 暴擊)"
	head_hb.parent_enemy = enemy
	head_hb.position = Vector3(0, 1.68, 0)
	var h_col := CollisionShape3D.new()
	var h_sphere := SphereShape3D.new()
	h_sphere.radius = 0.34
	h_col.shape = h_sphere
	head_hb.add_child(h_col)
	enemy.add_child(head_hb)

	var leg_hb := HitboxComponent.new()
	leg_hb.body_zone = HitboxComponent.BodyZone.LEG_CRIPPLE
	leg_hb.damage_multiplier = 0.9
	leg_hb.zone_display_name = "膝蓋關節 (射擊致殘減速)"
	leg_hb.parent_enemy = enemy
	leg_hb.position = Vector3(0, 0.42, 0)
	var l_col := CollisionShape3D.new()
	var l_box := BoxShape3D.new()
	l_box.size = Vector3(0.65, 0.65, 0.65)
	l_col.shape = l_box
	leg_hb.add_child(l_col)
	enemy.add_child(leg_hb)

	if is_boss:
		var valve_hb := HitboxComponent.new()
		valve_hb.body_zone = HitboxComponent.BodyZone.PRESSURE_VALVE_CRITICAL
		valve_hb.damage_multiplier = 2.6
		valve_hb.zone_display_name = "背後高壓氣閥／核心弱點 (2.6x 超高暴擊)"
		valve_hb.parent_enemy = enemy
		valve_hb.position = Vector3(0, 1.35, 0.42)
		var v_col := CollisionShape3D.new()
		var v_sphere := SphereShape3D.new()
		v_sphere.radius = 0.36
		v_col.shape = v_sphere
		valve_hb.add_child(v_col)
		enemy.add_child(valve_hb)

	add_child(enemy)

func _spawn_door(
	id: String, title: String, target_room: String,
	door_pos: Vector3, dest_pos: Vector3, dest_yaw: float,
	locked: bool, req_key_id: String, req_key_name: String, flag_name: String,
	one_way_bolt: bool, can_unbolt: bool
) -> void:
	var door := DoorTransition.new()
	door.door_id = id
	door.door_title = title
	door.target_room_id = target_room
	door.position = door_pos
	door.destination_position = dest_pos
	door.destination_camera_yaw = dest_yaw
	door.is_locked = locked
	door.required_key_item_id = req_key_id
	door.required_key_display_name = req_key_name
	door.unlocked_by_world_flag = flag_name
	door.is_one_way_bolt = one_way_bolt
	door.can_unbolt_from_this_side = can_unbolt
	_attach_collider_and_mesh(door, Vector3(1.6, 2.5, 0.45), mat_brass_gold if locked else mat_dark_timber)
	add_child(door)

func _spawn_static_box(node_name: String, pos: Vector3, size: Vector3, mat: Material) -> StaticBody3D:
	var sb := StaticBody3D.new()
	sb.name = node_name
	sb.position = pos
	_attach_collider_and_mesh(sb, size, mat)
	add_child(sb)
	return sb

func _attach_collider_and_mesh(body: CollisionObject3D, size: Vector3, mat: Material, optional_glb_path: String = "") -> void:
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	col.shape = shape
	body.add_child(col)

	if not optional_glb_path.is_empty() and ResourceLoader.exists(optional_glb_path):
		var packed := load(optional_glb_path) as PackedScene
		if packed:
			var inst := packed.instantiate()
			body.add_child(inst)
			return

	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	body.add_child(mi)

func _spawn_glb_or_fallback(glb_path: String, pos: Vector3, fallback_size: Vector3, mat: Material) -> void:
	var sb := StaticBody3D.new()
	sb.position = pos
	_attach_collider_and_mesh(sb, fallback_size, mat, glb_path)
	add_child(sb)

func _spawn_omni_light(pos: Vector3, col: Color, energy: float, radius: float) -> void:
	var light := OmniLight3D.new()
	light.position = pos
	light.light_color = col
	light.light_energy = energy
	light.omni_range = radius
	light.shadow_enabled = true
	add_child(light)
