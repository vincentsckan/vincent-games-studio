class_name ProceduralAnimController
extends Node
## ProceduralAnimController.gd
## Commercial Indie-AAA procedural animation driver for 3D character and creature meshes.
## Provides walk-cycle vertical bob, stride pitch/roll, idle breathing, aiming posture lean,
## recoil kickback, and crippled-leg dragging animations without requiring external MoCap clips.

@export var target_pivot: Node3D
@export var is_boss_entity: bool = false

var _time_accum: float = 0.0
var _base_y: float = 0.0
var _recoil_offset: float = 0.0

func _ready() -> void:
	if target_pivot == null and get_parent() is Node3D:
		target_pivot = get_parent().get_node_or_null("VisualPivot")
		if target_pivot == null:
			target_pivot = get_parent().get_node_or_null("MeshPivot")
	if target_pivot:
		_base_y = target_pivot.position.y
	_time_accum = randf() * 10.0

func trigger_recoil_kick(strength: float = 0.12) -> void:
	_recoil_offset = strength

func _process(delta: float) -> void:
	if target_pivot == null:
		return
	var parent_body := get_parent() as CharacterBody3D
	if parent_body == null:
		return
	if parent_body.get("is_dead") == true:
		return

	_time_accum += delta
	var horiz_vel := Vector2(parent_body.velocity.x, parent_body.velocity.z)
	var speed: float = horiz_vel.length()

	if _recoil_offset > 0.001:
		_recoil_offset = move_toward(_recoil_offset, 0.0, delta * 0.85)

	if speed > 0.25:
		var freq: float = 11.5 if not is_boss_entity else 7.5
		var bob_amp: float = 0.055 if not is_boss_entity else 0.085
		var sway_amp_deg: float = 3.2 if not is_boss_entity else 4.8
		if parent_body.get("is_leg_crippled") == true:
			freq = 6.0
			sway_amp_deg = 9.5

		target_pivot.position.y = _base_y + abs(sin(_time_accum * freq)) * bob_amp
		target_pivot.rotation_degrees.z = sin(_time_accum * freq * 0.5) * sway_amp_deg
		target_pivot.rotation_degrees.x = -3.5 + _recoil_offset * 45.0
	else:
		# Subtle idle breathing animation
		var breath_freq: float = 2.2 if not is_boss_entity else 3.4
		var breath_amp: float = 0.018 if not is_boss_entity else 0.04
		target_pivot.position.y = lerpf(target_pivot.position.y, _base_y + sin(_time_accum * breath_freq) * breath_amp, delta * 6.0)
		target_pivot.rotation_degrees.z = lerpf(target_pivot.rotation_degrees.z, 0.0, delta * 8.0)
		target_pivot.rotation_degrees.x = lerpf(target_pivot.rotation_degrees.x, _recoil_offset * 45.0, delta * 10.0)
