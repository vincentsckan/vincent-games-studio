﻿# ==============================================================================
# 《霧嶺療養院：白鴉之冬》(Eiswald Sanatorium: Winter of the White Crow)
# One-Click Website Publisher (https://vincentsckan.github.io/vincent-games-studio/)
# & Cloud VM Synchronizer + Local Click-to-Launch Protocol Installer
# ==============================================================================

$ErrorActionPreference = "Continue"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host " [步驟 1/4] 正在本機註冊 vincentgame:// 網頁一鍵啟動協定..." -ForegroundColor Cyan
Write-Host "=====================================================================" -ForegroundColor Cyan
powershell -NoProfile -ExecutionPolicy Bypass -File "$ProjectRoot\tools\register_local_click_launcher.ps1" -GameProjectDir $ProjectRoot

Write-Host "`n=====================================================================" -ForegroundColor Cyan
Write-Host " [步驟 2/4] 正在打包遊戲完整檔案並準備網站發佈資源..." -ForegroundColor Cyan
Write-Host "=====================================================================" -ForegroundColor Cyan
$WebGameDir = Join-Path $ProjectRoot "web_portal\eiswald-sanatorium"
New-Item -ItemType Directory -Force -Path $WebGameDir | Out-Null

Copy-Item -Force "$ProjectRoot\EiswaldSanatorium_ClickToPlay_Setup.bat" "$WebGameDir\EiswaldSanatorium_ClickToPlay_Setup.bat"

$ArchivePath = Join-Path $WebGameDir "eiswald_sanatorium_full_game.tar.gz"
tar -czf $ArchivePath --exclude="web_portal" --exclude=".godot" -C $ProjectRoot .
Write-Host "[OK] 遊戲完整安裝包已建立: $ArchivePath" -ForegroundColor Green

function Inject-EiswaldCardIntoRepo($RepoDir) {
    $TargetGameDir = Join-Path $RepoDir "eiswald-sanatorium"
    New-Item -ItemType Directory -Force -Path $TargetGameDir | Out-Null
    Copy-Item -Recurse -Force "$WebGameDir\*" $TargetGameDir

    $IndexHtmlPath = Join-Path $RepoDir "index.html"
    if (Test-Path $IndexHtmlPath) {
        $HtmlContent = Get-Content -Raw -Encoding UTF8 $IndexHtmlPath
        if ($HtmlContent -notmatch "eiswald-sanatorium") {
            $CardHtml = @"

<!-- === EISWALD SANATORIUM: WINTER OF THE WHITE CROW (CLICK-TO-PLAY CARD) === -->
<div class="game-card" id="card-eiswald-sanatorium" style="position:relative; border-radius:16px; overflow:hidden; background:linear-gradient(145deg,#101722,#192334); border:1px solid rgba(120,180,255,0.28); box-shadow:0 12px 32px rgba(0,0,0,0.55); transition:transform 0.25s ease, box-shadow 0.25s ease; cursor:pointer; max-width:380px; margin:16px auto;" onclick="window.LaunchEiswaldSanatorium(event)">
  <div style="position:relative; height:210px; overflow:hidden; background:#0b0f17;">
    <img src="eiswald-sanatorium/scene_fairytale_hub.png" alt="霧嶺療養院：白鴉之冬" style="width:100%; height:100%; object-fit:cover; filter:contrast(1.08) brightness(0.92);">
    <span style="position:absolute; top:12px; left:12px; background:rgba(180,28,45,0.92); color:#fff; font-size:12px; font-weight:700; padding:4px 10px; border-radius:999px; letter-spacing:0.5px;">3D 生存恐怖 · 點擊即玩</span>
    <span style="position:absolute; bottom:12px; right:12px; background:rgba(15,23,36,0.88); color:#8ecae6; font-size:12px; font-weight:600; padding:4px 10px; border-radius:6px; border:1px solid rgba(142,202,230,0.35);">Godot 4.3 Forward+</span>
  </div>
  <div style="padding:18px 20px;">
    <h3 style="margin:0 0 8px 0; color:#f1f5f9; font-size:20px; font-weight:700;">《霧嶺療養院：白鴉之冬》</h3>
    <p style="margin:0 0 14px 0; color:#94a3b8; font-size:13.5px; line-height:1.55;">
      致敬《Crow Country》箱庭式立體解謎生存恐怖。探索四大主題分區、45° 自由旋轉微縮視角、雷射瞄準弱點暴擊與三大難度模式。
    </p>
    <div style="display:flex; gap:10px; align-items:center;">
      <a href="vincentgame://launch/eiswald-sanatorium" onclick="window.LaunchEiswaldSanatorium(event)" style="flex:1; text-align:center; background:linear-gradient(135deg,#2563eb,#1d4ed8); color:#ffffff; font-weight:700; font-size:14px; padding:10px 14px; border-radius:10px; text-decoration:none; box-shadow:0 4px 14px rgba(37,99,235,0.45);">
        ▶ 點擊 Icon 立即在本機啟動遊玩
      </a>
      <a href="eiswald-sanatorium/index.html" onclick="event.stopPropagation();" style="background:rgba(255,255,255,0.08); color:#cbd5e1; font-size:13px; padding:10px 12px; border-radius:10px; text-decoration:none; border:1px solid rgba(255,255,255,0.12);">
        詳情 / 首次安裝
      </a>
    </div>
  </div>
</div>
<script>
window.LaunchEiswaldSanatorium = function(e) {
  if (e) e.preventDefault();
  var blurred = false;
  var onBlur = function() { blurred = true; };
  window.addEventListener('blur', onBlur, { once: true });
  window.location.href = 'vincentgame://launch/eiswald-sanatorium';
  setTimeout(function() {
    window.removeEventListener('blur', onBlur);
    if (!blurred) {
      window.location.href = 'eiswald-sanatorium/index.html?autoinstall=1';
    }
  }, 1400);
};
</script>
<!-- === END EISWALD SANATORIUM CARD === -->
"@
            if ($HtmlContent -match "(?i)</main>") {
                $HtmlContent = $HtmlContent -replace "(?i)</main>", "$CardHtml`n</main>"
            } elseif ($HtmlContent -match "(?i)</body>") {
                $HtmlContent = $HtmlContent -replace "(?i)</body>", "$CardHtml`n</body>"
            } else {
                $HtmlContent += "`n$CardHtml"
            }
            [System.IO.File]::WriteAllText($IndexHtmlPath, $HtmlContent, [System.Text.Encoding]::UTF8)
            Write-Host "[OK] 已將《霧嶺療養院：白鴉之冬》Icon 卡片注入 $IndexHtmlPath" -ForegroundColor Green
        }
    }
}

# 搜尋本機是否有 vincent-games-studio 資料夾與 git/gh
$GitExe = (Get-Command git -ErrorAction SilentlyContinue).Source
if (-not $GitExe) {
    $GitCandidates = @(
        "C:\Program Files\Git\cmd\git.exe",
        "C:\Program Files (x86)\Git\cmd\git.exe",
        "$env:LOCALAPPDATA\Programs\Git\cmd\git.exe"
    ) + (Get-ChildItem "$env:LOCALAPPDATA\GitHubDesktop\app-*\resources\app\git\cmd\git.exe" -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName)
    foreach ($cand in $GitCandidates) {
        if ($cand -and (Test-Path $cand)) {
            $GitExe = $cand
            break
        }
    }
}

# 搜尋本機現有的 vincent-games-studio 資料夾
$LocalRepoDirs = @()
foreach ($root in @("$env:USERPROFILE", "$env:USERPROFILE\Documents", "$env:USERPROFILE\Desktop", "$env:USERPROFILE\.gemini\antigravity")) {
    if (Test-Path $root) {
        $found = Get-ChildItem -Path $root -Directory -Filter "*vincent-games-studio*" -Depth 3 -ErrorAction SilentlyContinue
        if ($found) {
            $LocalRepoDirs += $found.FullName
        }
    }
}

Write-Host "[INFO] 本機 Git: $GitExe"
Write-Host "[INFO] 本機找到的 vincent-games-studio 目錄: $($LocalRepoDirs -join ', ')"

$PushedLocally = $false
if ($GitExe) {
    $TargetRepo = $null
    foreach ($d in $LocalRepoDirs) {
        if (Test-Path "$d\.git") {
            $TargetRepo = $d
            break
        }
    }
    if (-not $TargetRepo) {
        $TargetRepo = Join-Path $env:TEMP "vincent-games-studio-local"
        if (Test-Path $TargetRepo) { Remove-Item -Recurse -Force $TargetRepo }
        & $GitExe clone https://github.com/vincentsckan/vincent-games-studio.git $TargetRepo
    }
    if (Test-Path "$TargetRepo\.git") {
        Push-Location $TargetRepo
        & $GitExe pull --rebase
        Inject-EiswaldCardIntoRepo $TargetRepo
        & $GitExe add .
        & $GitExe commit -m "Add Eiswald Sanatorium: Winter of the White Crow click-to-play game icon"
        & $GitExe push
        if ($LASTEXITCODE -eq 0) {
            $PushedLocally = $true
            Write-Host "[SUCCESS] 已透過本機 Git 成功推送至 https://vincentsckan.github.io/vincent-games-studio/ !" -ForegroundColor Green
        }
        Pop-Location
    }
}

Write-Host "`n=====================================================================" -ForegroundColor Cyan
Write-Host " [步驟 3 & 4] 正在同步至 Google Cloud VM 並檢查/推送 GitHub Pages..." -ForegroundColor Cyan
Write-Host "=====================================================================" -ForegroundColor Cyan
$GcloudCmd = "$env:LOCALAPPDATA\Google\Cloud SDK\google-cloud-sdk\bin\gcloud.cmd"
if (-not (Test-Path $GcloudCmd)) {
    $GcloudCmd = "gcloud"
}

$FullBundleTar = Join-Path $env:TEMP "eiswald_portal_and_game.tar.gz"
tar -czf $FullBundleTar --exclude=".godot" -C $ProjectRoot .

& $GcloudCmd compute scp $FullBundleTar "vincentkan-vm-20260921-000319:/home/vincentsc_kan/eiswald_portal_and_game.tar.gz" --zone=asia-east2-c --tunnel-through-iap

$RemoteDeploySh = @'
#!/usr/bin/env bash
set -e
mkdir -p /home/vincentsc_kan/eiswald_sanatorium
tar -xzf /home/vincentsc_kan/eiswald_portal_and_game.tar.gz -C /home/vincentsc_kan/eiswald_sanatorium
rm -f /home/vincentsc_kan/eiswald_portal_and_game.tar.gz

cd /home/vincentsc_kan/eiswald_sanatorium
if command -v blender >/dev/null 2>&1; then
    blender -b -P tools/generate_3d_assets_blender.py >/dev/null 2>&1 || true
fi

echo "=== Checking VM for git / gh / vincent-games-studio ==="
which git || true
which gh || true
gh auth status || true

REPO_DIR=""
FOUND=$(find /home/vincentsc_kan /tmp /var /opt -maxdepth 4 -type d -name "*vincent-games-studio*" 2>/dev/null | head -n 1)
if [ -n "$FOUND" ] && [ -d "$FOUND/.git" ]; then
    REPO_DIR="$FOUND"
    echo "[FOUND REPO ON VM]: $REPO_DIR"
fi

if [ -z "$REPO_DIR" ]; then
    REPO_DIR="/home/vincentsc_kan/vincent-games-studio"
    if command -v gh >/dev/null 2>&1 && gh auth status >/dev/null 2>&1; then
        gh repo clone vincentsckan/vincent-games-studio "$REPO_DIR"
    else
        git clone https://github.com/vincentsckan/vincent-games-studio.git "$REPO_DIR" || true
    fi
fi

if [ -d "$REPO_DIR/.git" ]; then
    cd "$REPO_DIR"
    git remote -v
    git pull --rebase origin main || git pull --rebase origin master || true
    mkdir -p "$REPO_DIR/eiswald-sanatorium"
    cp -rf /home/vincentsc_kan/eiswald_sanatorium/web_portal/eiswald-sanatorium/* "$REPO_DIR/eiswald-sanatorium/"
    python3 /home/vincentsc_kan/eiswald_sanatorium/tools/inject_into_studio_site.py "$REPO_DIR"
    git add .
    git status -s
    if ! git diff --cached --quiet; then
        git config user.name "Vincent Kan" || true
        git config user.email "vincentsckan@users.noreply.github.com" || true
        git commit -m "Add Eiswald Sanatorium: Winter of the White Crow click-to-play game icon"
        git push
        echo "[SUCCESS] Pushed to GitHub Pages from VM!"
    else
        echo "[INFO] GitHub Pages repo already has changes committed, pushing..."
        git push || true
    fi
fi
'@

$RemoteShFile = Join-Path $env:TEMP "deploy_studio_site.sh"
[System.IO.File]::WriteAllText($RemoteShFile, ($RemoteDeploySh -replace "`r`n", "`n"))

& $GcloudCmd compute scp $RemoteShFile "vincentkan-vm-20260921-000319:/home/vincentsc_kan/deploy_studio_site.sh" --zone=asia-east2-c --tunnel-through-iap
& $GcloudCmd compute ssh "vincentkan-vm-20260921-000319" --zone=asia-east2-c --tunnel-through-iap --command="chmod +x /home/vincentsc_kan/deploy_studio_site.sh && /home/vincentsc_kan/deploy_studio_site.sh"
